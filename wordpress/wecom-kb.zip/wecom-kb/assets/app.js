/* GENERATED from index.html by wordpress/build.cjs — do not edit by hand. */
var TOPICS=[
  {id:1,cat:'sim',title:'הפעלת SIM פיזי חדש',desc:'שלבי הפעלה, זיהוי לקוח, בדיקת סטטוס קו, מה לומר ללקוח'},
  {id:2,cat:'sim',title:'הפעלת eSIM – קוד QR',desc:'דרישות מקדימות, שליחת QR, סריקה, טעויות נפוצות, אימות'},
  {id:3,cat:'sim',title:'מעבר SIM פיזי ↔ eSIM',desc:'בדיקת תאימות, ביטול פרופיל ישן, הפקה מחדש'},
  {id:4,cat:'sim',title:'תקלה אחרי הפעלת SIM/eSIM',desc:'אבחון, רענון קו, APN, הסלמה'},
  {id:5,cat:'sim',title:'QR לא נסרק / קוד לא התקבל',desc:'סיבות, שליחה מחדש, בדיקת מצלמה, חלופות'},
  {id:6,cat:'sim',title:'החלפת SIM אבוד/גנוב',desc:'חסימה מיידית, אימות מוגבר, הנפקה חדשה'},
  {id:7,cat:'sim',title:'בירור סטטוס משלוח SIM',desc:'בדיקת הזמנה, שליח, נקודת איסוף'},
  {id:8,cat:'sim',title:'איסוף SIM מהום סנטר',desc:'תנאי איסוף, מה לקוח צריך להביא'},
  {id:9,cat:'sim',title:'תאימות מכשיר – VoLTE/eSIM/5G',desc:'בדיקת דגם, גרסת מערכת, הסבר מגבלות'},
  {id:10,cat:'sim',title:'קווים שנרכשו ולא הופעלו',desc:'בדיקת סטטוס, הדרכת הפעלה, סגירת טיפול'},
  {id:11,cat:'data',title:'אין גלישה סלולרית',desc:'אבחון, חבילה וקו, נתונים, APN, איפוס, הסלמה'},
  {id:12,cat:'data',title:'גלישה איטית / ניתוקים',desc:'אזור, דור רשת, עומס, מכשיר, שיפור'},
  {id:13,cat:'intl',title:'הגדרת APN במכשיר',desc:'בחו"ל: ערך APN נדרש, איפוס לברירת מחדל, לפי יצרן'},
  {id:14,cat:'signal',title:'אין קליטה / אין שירות',desc:'רשת, SIM, מצב טיסה, אזור גיאוגרפי, איפוס'},
  {id:15,cat:'calls',title:'לא מצליח להוציא/לקבל שיחות',desc:'חסימות, חוב, VoLTE, קליטה, מצב קו'},
  {id:16,cat:'calls',title:'שיחות מתנתקות / שמע ירוד',desc:'אזור, מכשיר, VoLTE, קליטה, SIM'},
  {id:17,cat:'calls',title:'בעיות VoLTE ומכשירים ישנים',desc:'זיהוי חוסר תמיכה, חלופות, הסבר'},
  {id:18,cat:'sms',title:'בעיות SMS וקודי אימות',desc:'קבלת SMS, חסימות, קודי בנקים, איפוס'},
  {id:19,cat:'data',title:'Hotspot לא עובד',desc:'תמיכה בחבילה, APN, הגדרות שיתוף'},
  {id:20,cat:'tech',title:'טרבלשוטינג בסיסי: כיבוי ואיפוס',desc:'סדר פעולות אחיד, הסבר ללקוח, מתי להסלים'},
  {id:21,cat:'billing',title:'בירור חיוב גבוה / לא מזוהה',desc:'פירוק חיוב, השוואה לחודשים, שירותים נלווים'},
  {id:22,cat:'billing',title:'הסבר חשבונית וסעיפי חיוב',desc:'מבנה חשבונית, קבועים/משתנים, זיכויים, מע"מ'},
  {id:23,cat:'billing',title:'תשלום חוב / חסימת קו',desc:'בדיקת יתרה, אפשרויות תשלום, הסרת חסימה'},
  {id:24,cat:'billing',title:'עדכון אמצעי תשלום / אשראי',desc:'אימות לקוח, עדכון כרטיס, פג תוקף, הוראת קבע'},
  {id:25,cat:'billing',title:'זיכויים והחזרים',desc:'בדיקת זכאות, SLA, עדכון לקוח, הסלמה'},
  {id:26,cat:'billing',title:'שליחת חשבונית / אישור תשלום',desc:'סוגי מסמכים, אימות, זמני שליחה'},
  {id:27,cat:'plans',title:'שינוי מסלול / הוזלת חבילה',desc:'מסלול נוכחי, הצעות זמינות, השפעה על התחייבויות'},
  {id:28,cat:'plans',title:'צירוף קו / שדרוג 5G',desc:'תנאי הצטרפות, בדיקת מכשיר, עלויות, הפעלה'},
  {id:29,cat:'plans',title:'ניתוק / ביטול קו',desc:'אימות, סיבת ניתוק, שימור, מועד, אישור'},
  {id:30,cat:'plans',title:'הקפאת קו זמנית',desc:'תנאי הקפאה, משך, עלות, חזרה לפעילות'},
  {id:31,cat:'plans',title:'העברת בעלות על קו',desc:'מסמכים, אימות שני צדדים, השפעה על חיובים'},
  {id:32,cat:'plans',title:'עדכון פרטי לקוח',desc:'כתובת, מייל, טלפון, פרטי חיוב, אימות'},
  {id:33,cat:'plans',title:'ניוד מספרים',desc:'שלבי ניוד, סטטוס, זמני השלמה, תקלות'},
  {id:34,cat:'intl',title:'רכישת חבילת חו"ל לפני טיסה',desc:'התאמת חבילה, מדינות, נפח, מועד הפעלה'},
  {id:35,cat:'intl',title:'תקלת גלישה/קליטה בחו"ל',desc:'Roaming, בחירת רשת ידנית, APN'},
  {id:36,cat:'intl',title:'בירור תעריפי חו"ל / חיוב אחרי חזרה',desc:'הסבר תעריפים, חריגה, טיפול'},
  {id:42,cat:'intl',title:"אבחון מרכזי לתקלות ושירות בחו\"ל",desc:"זיהוי תקלה ראשוני, הפניה למסלול הנכון: קליטה, גלישה, שיחות, הודעות"},
  {id:43,cat:'intl',title:"אין קליטה / רישום לרשת בחו\"ל",desc:"שירות נדידה, נדידת נתונים, בחירת רשת ידנית, ארה\"ב"},
  {id:44,cat:'intl',title:"אין גלישה בחו\"ל",desc:"בדיקות מערכת, APN, זהות רשת, ריענון SIM, איפוס רשת"},
  {id:45,cat:'intl',title:"תקלה באפליקציה מסוימת בחו\"ל",desc:"הרשאות נתונים, חוסך נתונים, הפניה לספק האפליקציה"},
  {id:46,cat:'intl',title:"תקלות שיחות בחו\"ל",desc:"שיחות יוצאות/נכנסות, קידומת חיוג, רשת מארחת, VoLTE"},
  {id:47,cat:'intl',title:"תקלות הודעות בחו\"ל",desc:"שליחה/קבלה, קוד אימות, רשת מארחת, זהות רשת"},
  {id:48,cat:'intl',title:"הפעלת נדידת נתונים במכשיר",desc:"לפי יצרן: iPhone, Samsung, שיאומי, וואווי, פיקסל ועוד"},
  {id:50,cat:'intl',title:"תפעול STK ושינוי זהות רשת בחו\"ל",desc:"מתי לבצע שינוי זהות פרטנר, מתי להימנע (מסמך חלקי)"},
  {id:51,cat:'intl',title:"בחירת רשת ידנית בחו\"ל",desc:"חיבור ידני למפעיל מאושר, לפי יצרן, ארה\"ב בנפרד"},
  {id:52,cat:'intl',title:"העברה למומחה בתקלת חו\"ל",desc:"מתי להעביר, מה לתעד לפני ההעברה"},
  {id:37,cat:'ops',title:'זיהוי ואימות לקוח',desc:'פרטים נדרשים לכל פעולה, אימות מוגבר, ניסוח'},
  {id:38,cat:'ops',title:'ניתוב והעברת שיחה',desc:'מתי להעביר, מה לתעד, מניעת העברה חוזרת'},
  {id:39,cat:'ops',title:'תיאום Callback / מעקב',desc:'מתי לפתוח, SLA, עדכון לקוח, סגירת מעגל'},
  {id:40,cat:'ops',title:'תלונות, הסלמות, קושי תקשורתי',desc:'לקוח מתוסכל, בקשת מנהל, מחסום שפה'},
  {id:41,cat:'ops',title:'דיבאג נטישה',desc:'זיהוי לקוח מאותת נטישה, 3 מסלולי טיפול, תסריטי שיחה והתנגדויות'},
  // ── map topics (generated by map-seed.cjs) ──
  {id:1001,cat:'sim',title:'סים דאטה',desc:'סים לגלישה בלבד: למי מתאים, הגדרת APN, תפעול'},
  {id:1002,cat:'intl',title:'חיוג בינלאומי (מב״ל)',desc:'חיוג מהארץ לחו״ל, קידומות, ספקים, תעריפים, תקלות'},
  {id:1003,cat:'plans',title:'שירותים נוספים – תא קולי, סינון תכנים',desc:'הפעלה, ביטול, עלויות ומגבלות'},
  {id:1004,cat:'plans',title:'הצטרפות לקוח חדש ושיתופי פעולה',desc:'תנאי הצטרפות, מסמכים, זיהוי, מסלול, אמצעי תשלום'},
  {id:1005,cat:'plans',title:'אזור אישי',desc:'כניסה, חשבוניות, חבילות ופעולות עצמאיות'},
  {id:1006,cat:'plans',title:'פטירת לקוח',desc:'מסמכים נדרשים, מי רשאי לפנות, טיפול בקו ובחיובים'},
  {id:1007,cat:'plans',title:'סטטוס מנוי ושינוי מצב קו',desc:'סטטוסים במערכת, משמעות כל סטטוס ופעולות אפשריות'},
  {id:1008,cat:'plans',title:'החלפת מספר ומספר יפה',desc:'תנאים, מגבלות, עלויות ואופן הביצוע'},
  {id:1009,cat:'ops',title:'נגישות בשירות',desc:'ערוצי שירות נגישים, מוקד תיווך, התאמות'},
  {id:1010,cat:'ops',title:'הסרה ממסרים שיווקיים',desc:'בקשת הסרה, אופן ביצוע, משמעות ללקוח'},
  {id:1011,cat:'ops',title:'חיוג למספרי 1-700 / 1-800 / 1-900',desc:'כללי חיוג וטיפול בפניות'},
  {id:1012,cat:'ops',title:'לקוח עסקי / VIP',desc:'הגדרת סוג הלקוח וניתוב הטיפול'},
  {id:1013,cat:'ops',title:'תביעות ייצוגיות',desc:'טיפול בפנייה הקשורה לתביעה ייצוגית'},
  // ── HQ guides (מדריכי מטה) ──
  {id:1014,cat:'hq',title:'נוהל העברת בעלות',desc:'מסמכים בגלסיקס, אישורים מוקלטים, חשבון חדש והעברת הקווים ב-CRM'},
  {id:1015,cat:'hq',title:'חישובי נתונים ודוחות',desc:'עמלות ונתונים בתחילת חודש: TSF, אחוז מענה, זמן שיחה, פיריון; דוח למשרד התקשורת'},
];
// Snapshot of the highest topic id shipped in the code itself. Used later to
// tell "genuinely user-created" topics (added through the app) apart from
// the built-in seed topics when reconciling with saved browser data.
var NB_SEED_MAX_TOPIC_ID = Math.max.apply(null, TOPICS.map(function(t){return t.id;}));
// Topic id ranges: 1–52 original built-in topics, 53–999 topics people created
// before built-in topics got their own range, 1001–1999 later built-in topics
// (from the document map), 2000+ topics people create from now on.
var NB_USER_TOPIC_START = 2000;
function nbIsUserTopicId(id){ return (id>52&&id<1000)||id>=NB_USER_TOPIC_START; }
// Bump this whenever the hardcoded TOPICS/dynamicDocs seed content changes in
// the code, so a browser with older saved data doesn't keep masking it.
var NB_SEED_VERSION = 72; // HQ guides O-200 and O-201 in the new content world מטה
// ── KNOWLEDGE ARCHITECTURE (spec §2–3) ──────────────────────────────────
// עולם תוכן → נושא → פריטי ידע. A knowledge item (window.dynamicDocs entry)
// belongs to one or more topics (item.topicIds) and one or more content
// worlds (item.worlds), and has one of the 7 document types (item.kind).
var NB_KINDS={
  M:{label:'אבחון',full:'מסמך מרכזי / אבחון',color:'#6D3FD1',bg:'#F1ECFC',hint:'נקודת כניסה לנושא – מזהה את סוג המקרה ומנתב למסלול המתאים'},
  R:{label:'טיפול',full:'מסלול טיפול',color:'#D9361B',bg:'#FFEDE6',hint:'טיפול מלא בתרחיש – מהתשאול ועד פתרון או מעבר לשלב הבא'},
  O:{label:'תפעול',full:'מסמך תפעול',color:'#2E5CE0',bg:'#EBF1FF',hint:'הוראות לביצוע פעולה ספציפית במערכת, במכשיר או בתהליך'},
  E:{label:'הסלמה',full:'מסמך הסלמה',color:'#B45309',bg:'#FEF3E2',hint:'מתי מפסיקים טיפול, למי מעבירים ומה חובה לתעד'},
  S:{label:'מומחה',full:'מסלול מומחה',color:'#0E7490',bg:'#E3F5F8',hint:'המשך טיפול לבעל תפקיד מקצועי או דרג מתקדם'},
  T:{label:'תסריט',full:'תסריטי שיחה',color:'#0E7A4F',bg:'#EDFAF3',hint:'ניסוחים מול לקוח: הסבר, תיאום ציפיות, התנגדות וסיום'},
  I:{label:'מידע',full:'מסמך מידע',color:'#475569',bg:'#F1F3F6',hint:'מידע לדעת או למסור – ללא תהליך אבחון תקלה'}
};
var NB_KIND_ORDER=['M','R','O','E','S','T','I'];
// Content worlds = departments. Editors can add more (stored with the library).
var NB_DEFAULT_WORLDS=[{id:'service',name:'שירות'},{id:'tech',name:'טכני'},{id:'eng',name:'הנדסה'},{id:'hq',name:'מטה'}];
var WORLDS=NB_DEFAULT_WORLDS.slice();
// Built-in documents: which topic(s) each belongs to and its document type.
// Applied once to the built-in content; afterwards links live on the items.
var NB_SEED_META={
  'view-browsing-doc':{topics:[11],kind:'R'},'view-churn-doc':{topics:[41],kind:'R'},
  pdf_001:{topics:[12],kind:'O'},pdf_002:{topics:[14],kind:'R'},pdf_003:{topics:[17],kind:'I'},
  pdf_005:{topics:[20],kind:'O'},pdf_006:{topics:[40],kind:'T'},
  pdf_007:{topics:[15],kind:'R'},pdf_008:{topics:[16],kind:'R'},pdf_009:{topics:[18],kind:'R'},
  // R-01 and R-02 also appear under topic 35 (one source, several places).
  pdf_011:{topics:[42],kind:'M'},pdf_012:{topics:[43,35],kind:'R'},
  pdf_013:{topics:[44,35],kind:'R'},pdf_014:{topics:[45],kind:'R'},pdf_015:{topics:[46],kind:'R'},
  pdf_016:{topics:[47],kind:'R'},pdf_017:{topics:[48],kind:'O'},pdf_018:{topics:[13],kind:'O'},
  pdf_019:{topics:[50],kind:'O'},pdf_020:{topics:[51],kind:'O'},pdf_021:{topics:[52],kind:'E'},
  // Documents from the abroad knowledge map that are still being written (drafts).
  kb_o01:{topics:[42,43],kind:'O'},kb_h01:{topics:[34],kind:'I'},kb_h02:{topics:[51],kind:'I'},
  kb_h03:{topics:[43,9],kind:'I'},kb_s01:{topics:[52],kind:'S'},
  kbd_o10:{topics:[1],kind:'O'},kbd_o11:{topics:[2],kind:'O'},kbd_o12:{topics:[3],kind:'O'},kbd_r10:{topics:[4],kind:'O'},kbd_r11:{topics:[5],kind:'O'},kbd_r12:{topics:[6],kind:'O'},kbd_o13:{topics:[7],kind:'O'},kbd_i10:{topics:[8],kind:'O'},kbd_r13:{topics:[10],kind:'O'},kbd_r14:{topics:[19],kind:'R'},kbd_r15:{topics:[21],kind:'R'},kbd_i11:{topics:[22],kind:'I'},kbd_r16:{topics:[23],kind:'I'},kbd_o14:{topics:[24],kind:'I'},kbd_r17:{topics:[25],kind:'I'},kbd_o15:{topics:[26],kind:'O'},kbd_r18:{topics:[27],kind:'I'},kbd_r19:{topics:[28],kind:'R'},kbd_r20:{topics:[29],kind:'I'},kbd_o16:{topics:[30],kind:'I'},kbd_o17:{topics:[31],kind:'I'},kbd_o18:{topics:[32],kind:'I'},kbd_r21:{topics:[33],kind:'I'},kbd_r22:{topics:[36],kind:'I'},kbd_i12:{topics:[37],kind:'I'},kbd_i13:{topics:[38],kind:'I'},kbd_o19:{topics:[39],kind:'O'},kbd_i14:{topics:[9],kind:'O'},
  kbd_o10:{topics:[1],kind:'O'},kbd_o11:{topics:[2],kind:'O'},kbd_o12:{topics:[3],kind:'O'},kbd_r10:{topics:[4],kind:'O'},kbd_r11:{topics:[5],kind:'O'},kbd_r12:{topics:[6],kind:'O'},kbd_o13:{topics:[7],kind:'O'},kbd_i10:{topics:[8],kind:'O'},kbd_r13:{topics:[10],kind:'O'},kbd_r14:{topics:[19],kind:'R'},kbd_r15:{topics:[21],kind:'R'},kbd_i11:{topics:[22],kind:'I'},kbd_r16:{topics:[23],kind:'I'},kbd_o14:{topics:[24],kind:'I'},kbd_r17:{topics:[25],kind:'I'},kbd_o15:{topics:[26],kind:'O'},kbd_r18:{topics:[27],kind:'I'},kbd_r19:{topics:[28],kind:'R'},kbd_r20:{topics:[29],kind:'I'},kbd_o16:{topics:[30],kind:'I'},kbd_o17:{topics:[31],kind:'I'},kbd_o18:{topics:[32],kind:'I'},kbd_r21:{topics:[33],kind:'I'},kbd_r22:{topics:[36],kind:'I'},kbd_i12:{topics:[37],kind:'I'},kbd_i13:{topics:[38],kind:'I'},kbd_o19:{topics:[39],kind:'O'},kbd_i14:{topics:[9],kind:'O'},
  kbm_i01:{topics:[34],kind:'I'},kbm_m10:{topics:[14],kind:'M'},kbm_r11:{topics:[14],kind:'R'},kbm_r12:{topics:[14],kind:'R'},kbm_r13:{topics:[14],kind:'R'},kbm_o10:{topics:[14],kind:'O'},kbm_o12:{topics:[14],kind:'O'},kbm_o13:{topics:[14],kind:'O'},kbm_e10:{topics:[14],kind:'E'},kbm_t10:{topics:[14],kind:'T'},kbm_s10:{topics:[14],kind:'S'},kbm_m30:{topics:[11],kind:'M'},kbm_r31:{topics:[11],kind:'R'},kbm_r32:{topics:[11],kind:'R'},kbm_r33:{topics:[12],kind:'R'},kbm_r34:{topics:[12],kind:'R'},kbm_r35:{topics:[11],kind:'R'},kbm_o31:{topics:[11],kind:'O'},kbm_o32:{topics:[13],kind:'O'},kbm_o33:{topics:[11],kind:'O'},kbm_o34:{topics:[11],kind:'O'},kbm_o35:{topics:[11],kind:'O'},kbm_e30:{topics:[11],kind:'E'},kbm_s30:{topics:[11],kind:'S'},kbm_m40:{topics:[15],kind:'M'},kbm_r40:{topics:[15],kind:'R'},kbm_r41:{topics:[15],kind:'R'},kbm_r42:{topics:[15],kind:'R'},kbm_r43:{topics:[15],kind:'R'},kbm_r44:{topics:[15],kind:'R'},kbm_o40:{topics:[15],kind:'O'},kbm_o41:{topics:[15],kind:'O'},kbm_o42:{topics:[15],kind:'O'},kbm_o43:{topics:[17],kind:'O'},kbm_o44:{topics:[17],kind:'O'},kbm_o45:{topics:[15],kind:'O'},kbm_e40:{topics:[15],kind:'E'},kbm_s40:{topics:[15],kind:'S'},kbm_m60:{topics:[18],kind:'M'},kbm_r60:{topics:[18],kind:'R'},kbm_r61:{topics:[18],kind:'R'},kbm_r62:{topics:[18],kind:'R'},kbm_r63:{topics:[18],kind:'R'},kbm_o60:{topics:[18],kind:'O'},kbm_o61:{topics:[18],kind:'O'},kbm_e60:{topics:[18],kind:'E'},kbm_s60:{topics:[18],kind:'S'},kbm_o70:{topics:[1001],kind:'O'},kbm_r150:{topics:[1002],kind:'R'},kbm_m90:{topics:[23],kind:'M'},kbm_i91:{topics:[23],kind:'I'},kbm_i92:{topics:[23],kind:'I'},kbm_i94:{topics:[23],kind:'I'},kbm_i95:{topics:[23],kind:'I'},kbm_i96:{topics:[23],kind:'I'},kbm_i97:{topics:[23],kind:'I'},kbm_m100:{topics:[27],kind:'M'},kbm_i104:{topics:[1003],kind:'I'},kbm_i105:{topics:[1003],kind:'I'},kbm_m120:{topics:[1004],kind:'M'},kbm_i122:{topics:[33],kind:'I'},kbm_i123:{topics:[33],kind:'I'},kbm_i124:{topics:[33],kind:'I'},kbm_i125:{topics:[1004],kind:'I'},kbm_i113:{topics:[1005],kind:'I'},kbm_i114:{topics:[1006],kind:'I'},kbm_i117:{topics:[1007],kind:'I'},kbm_i118:{topics:[1008],kind:'I'},kbm_i103:{topics:[41],kind:'I'},kbm_m106:{topics:[34],kind:'M'},kbm_i107:{topics:[34],kind:'I'},kbm_i108:{topics:[1009],kind:'I'},kbm_i109:{topics:[40],kind:'I'},kbm_i110:{topics:[1010],kind:'I'},kbm_i150:{topics:[1002],kind:'I'},kbm_i151:{topics:[7],kind:'I'},kbm_i152:{topics:[1011],kind:'I'},kbm_i153:{topics:[1012],kind:'I'},kbm_i154:{topics:[1013],kind:'I'}
};
NB_SEED_META.kbnew_o06={topics:[9],kind:'O'};
NB_SEED_META.kbnew_r14={topics:[14],kind:'R'};
NB_SEED_META.kbnew_o37={topics:[11],kind:'O'};
NB_SEED_META.kbnew_o36={topics:[19],kind:'O'};
NB_SEED_META.kbnew_r45={topics:[46],kind:'R'};
NB_SEED_META.kbnew_r50={topics:[4],kind:'R'};
NB_SEED_META.kbnew_r51={topics:[5],kind:'R'};
NB_SEED_META.kbhq_o200={topics:[1014],kind:'O'};
NB_SEED_META.kbhq_o201={topics:[1015],kind:'O'};
// Default department for existing items, by their old category.
var NB_CAT_TO_WORLD={hq:'hq',sim:'tech',data:'tech',signal:'tech',calls:'tech',sms:'tech',tech:'tech',tech2:'tech',intl:'tech',billing:'service',plans:'service',ops:'service'};

function nbEsc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function nbWorldName(id){var w=WORLDS.find(function(x){return x.id===id;});return w?w.name:id;}
function nbKindBadge(kind,small){
  var k=NB_KINDS[kind]||NB_KINDS.R;
  return '<span class="kind-badge'+(small?' sm':'')+'" style="color:'+k.color+';background:'+k.bg+';border-color:'+k.color+'33" title="'+nbEsc(k.full)+'"><b>'+(NB_KINDS[kind]?kind:'R')+'</b>'+(small?'':' '+k.label)+'</span>';
}
// Items of a topic that the current user may see. Expired / archived items
// come last.
function nbTopicItems(topicId){
  var docs=window.dynamicDocs||{};
  return Object.keys(docs).map(function(k){return docs[k];}).filter(function(d){
    return d&&d.topicIds&&d.topicIds.indexOf(topicId)!==-1&&nbVisible(d);
  }).sort(function(a,b){
    return (nbActive(b)-nbActive(a))||(NB_KIND_ORDER.indexOf(a.kind)-NB_KIND_ORDER.indexOf(b.kind))||nbPlain(a.topic).localeCompare(nbPlain(b.topic),'he');
  });
}
function nbFmtDate(ts){return ts?new Date(ts).toLocaleDateString('he-IL'):'';}

// ── STATUSES (spec §10) and editorial tracking ──────────────────────────
// Only "published" items are shown to agents. Editors see everything, with
// a badge. An item that was ever published is never permanently deleted.
var NB_STATUSES={
  draft:{label:'טיוטה',color:'#6B7280',bg:'#F1F3F6'},
  pending:{label:'ממתין לאישור',color:'#B45309',bg:'#FEF3E2'},
  published:{label:'פורסם',color:'#0F7A3E',bg:'#EDFAF3'},
  expired:{label:'לא בתוקף',color:'#B42318',bg:'#FDECEA'},
  archived:{label:'ארכיון',color:'#475569',bg:'#E9EDF2'}
};
var NB_STATUS_ORDER=['draft','pending','published','expired','archived'];
// Editorial tracking (from the knowledge-map spreadsheet): content state,
// required action, main source, priority. Editors only.
var NB_TRACK_STATES=['קיים','קיים חלקית','חסר חלקית','חסר','שחר להשלים'];
var NB_PRIORITIES=['גבוהה','בינונית','נמוכה'];

// Read-only users (agents) — set by the demo gate or by WordPress.
function nbIsReadonly(){ return document.body.classList.contains('wkb-readonly'); }
// Whether the current user may see an item in the library, search and flows.
function nbVisible(d){ return !!d&&(!nbIsReadonly()||d.status==='published'); }
// Expired / archived items stay out of the active flows (spec §10).
function nbActive(d){ return !!d&&d.status!=='expired'&&d.status!=='archived'; }
function nbWasPublished(d){ return !!d&&(d.status==='published'||!!d.publishedAt); }
function nbStatusBadge(d,always){
  var s=NB_STATUSES[d&&d.status]||NB_STATUSES.published;
  if(!always&&d.status==='published') return '';
  return '<span class="status-badge" style="color:'+s.color+';background:'+s.bg+'">'+s.label+'</span>';
}

// Brings any library (built-in seed, older saved data, restored history) to
// the current model. Idempotent: safe to run after every load or restore.
//  - old one-document-per-topic links (topic.dynId) become item.topicIds
//  - waves/priorities are dropped (removed from the product)
//  - missing item fields get defaults (type, worlds, tags, description)
function nbNormalizeModel(){
  var docs=window.dynamicDocs=window.dynamicDocs||{};
  // Built-in worlds added to the code after a library was saved are added to it.
  // A world someone created by hand with the same name becomes the built-in one.
  NB_DEFAULT_WORLDS.forEach(function(dw){
    if(WORLDS.some(function(w){return w.id===dw.id;})) return;
    var same=WORLDS.find(function(w){return w.name.trim()===dw.name;});
    if(same){
      var old=same.id; same.id=dw.id;
      Object.keys(docs).forEach(function(k){ var d=docs[k]; if(d&&Array.isArray(d.worlds)) d.worlds=d.worlds.map(function(w){return w===old?dw.id:w;}); });
      if(nbCurrentWorld===old) nbCurrentWorld=dw.id;
    } else WORLDS.push({id:dw.id,name:dw.name});
  });
  TOPICS.forEach(function(t){
    if(t.dynId&&docs[t.dynId]){
      var d=docs[t.dynId];
      d.topicIds=d.topicIds||[];
      if(d.topicIds.indexOf(t.id)===-1) d.topicIds.push(t.id);
    }
    delete t.dynId; delete t.active; delete t.wave; delete t.pri;
    if(t.desc==null) t.desc='';
  });
  Object.keys(docs).forEach(function(k){
    var d=docs[k]; if(!d) return;
    var seed=NB_SEED_META[k];
    if(!d.topicIds) d.topicIds=seed?seed.topics.slice():[];
    if(!NB_KINDS[d.kind]) d.kind=seed?seed.kind:'R';
    if(!Array.isArray(d.worlds)||!d.worlds.length) d.worlds=[NB_CAT_TO_WORLD[d.cat]||'service'];
    if(typeof d.tags==='string') d.tags=d.tags.split(',').map(function(s){return s.trim();}).filter(Boolean);
    if(!Array.isArray(d.tags)) d.tags=[];
    if(d.desc==null) d.desc='';
    if(d.owner==null) d.owner='';
    // Items from before statuses existed were all live: they count as published.
    if(!NB_STATUSES[d.status]) d.status='published';
    if(d.status==='published'&&!d.publishedAt) d.publishedAt=d.updatedAt||d.createdAt||null;
    if(!d.track||typeof d.track!=='object') d.track={};
    delete d.wave;
  });
}
var SIM_ICON='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:-2px;margin-left:1px"><path d="M16 2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8l-6-6z"/><path d="M16 2v6h6"/><rect x="9.3" y="12" width="5.4" height="3.4" rx="0.9"/></svg>';
// Categories in the order of the library filter row. 'tech' is kept for
// older topics and items that have no specific technical category.
var CAT={hq:'🏢 מטה',sim:SIM_ICON+' SIM/eSIM',data:'🌐 גלישה',signal:'📶 קליטה',calls:'📞 שיחות',sms:'✉️ SMS',intl:'✈️ חו"ל',tech:'🔧 טכני',tech2:'🔧 טכני',billing:'💳 חיובים',plans:'📋 מסלולים',intl:'✈️ חו"ל',ops:'🎧 שיחה'};

function setTocActive(el){
  document.querySelectorAll('.doc-toc-item').forEach(function(i){i.classList.remove('active')});
  if(el) el.classList.add('active');
}

function showView(id){
  document.querySelectorAll('.view').forEach(function(v){v.classList.remove('active')});
  var target=document.getElementById('view-'+id);
  if(!target) return;
  target.classList.add('active');
  // The item's view switch and table of contents in the sidebar belong to the item page only.
  if(id!=='article'){ var sd=document.getElementById('snav-doc'); if(sd) sd.innerHTML=''; }
  document.querySelectorAll('.snav-item').forEach(function(i){i.classList.remove('active')});
  var sm=document.getElementById('snav-'+id);
  if(sm) sm.classList.add('active');
  ['library','new','tracking'].forEach(function(t){var b=document.getElementById('mob-'+t);if(b)b.classList.toggle('active',t===id||(t==='library'&&['browsing','churn','article','topic'].indexOf(id)!==-1)||(t==='tracking'&&id==='review'))});
  if(id==='library'){var sl=document.getElementById('snav-library');if(sl)sl.classList.toggle('active',nbCurrentWorld==='all');}
  if(id==='library'){
    nbMostViewedFilter=false;
    nbCurrentKind='all';
    nbRenderLibFilters();
    renderLibrary('all');
    var fb=document.querySelectorAll('#lib-filters .filter-btn');
    fb.forEach(function(b,i){b.classList.toggle('active',i===0);});
  }
  if(id==='new'&&!nbState['s1'].applied) nbRender();
  window.scrollTo(0,0);
  setTimeout(function(){document.querySelectorAll('#view-'+id+' .fade-in:not(.visible)').forEach(function(el,i){setTimeout(function(){el.classList.add('visible')},i*55)})},80);
}

// Waves were removed from the product (spec). Kept as a no-op for older callers.
function renderHomeWaves(){}

// A topic is shown under a content world when at least one of its items
// belongs to that world.
function nbTopicInWorld(t,world){
  if(world==='all') return true;
  return nbTopicItems(t.id).some(function(d){return d.worlds.indexOf(world)!==-1;});
}

// Item-level filters (world + document type) shared by browsing and search.
function nbItemPassesFilters(d){
  return (nbCurrentWorld==='all'||(d.worlds||[]).indexOf(nbCurrentWorld)!==-1)
    &&(nbCurrentKind==='all'||d.kind===nbCurrentKind);
}
// A topic is shown when it has an item matching the world/type filters
// (or always, when neither filter is set).
function nbTopicMatchesFilters(t){
  // Agents don't see topics whose items are all unpublished (drafts, placeholders).
  if(nbIsReadonly()&&!nbTopicItems(t.id).length) return false;
  if(nbCurrentWorld==='all'&&nbCurrentKind==='all') return true;
  return nbTopicItems(t.id).some(nbItemPassesFilters);
}
function nbCatMatches(cat,c){ return cat==='all'||c===cat||(cat==='tech'&&c==='tech2'); }

function nbCurrentLibraryItemCount(){
  var cat=nbCurrentLibCat||'all', docs=window.dynamicDocs||{}, count=0, seen=[];
  Object.keys(docs).forEach(function(key){
    var d=docs[key];
    if(!d||!nbVisible(d)||!nbItemPassesFilters(d)) return;
    var matchesTopic=(d.topicIds||[]).some(function(topicId){
      var topic=TOPICS.find(function(t){return t.id===topicId;});
      return topic&&nbCatMatches(cat,topic.cat);
    });
    var id=d.id||key;
    if(matchesTopic&&seen.indexOf(id)===-1){seen.push(id);count++;}
  });
  return count;
}
function nbUpdateLibraryItemCount(count){
  var title=document.getElementById('lib-count');
  if(title) title.textContent=count;
  var badge=document.querySelector('#snav-library .snav-badge');
  if(badge) badge.textContent=count;
}

function renderLibrary(cat){
  nbCurrentLibCat=cat;
  if(nbMostViewedFilter){ nbRenderMostViewed(); return; }
  if(nbSearchQuery){ nbRenderSearch(); return; }
  var f=TOPICS.filter(function(t){
    return nbCatMatches(cat,t.cat)&&nbTopicMatchesFilters(t);
  });
  nbUpdateLibraryItemCount(nbCurrentLibraryItemCount());
  document.getElementById('library-content').innerHTML=f.length
    ?'<div class="topic-grid">'+f.map(cardHTML).join('')+'</div>'
    :'<div class="empty-state">אין נושאים בסינון הזה</div>';
  setTimeout(function(){document.querySelectorAll('#library-content .fade-in:not(.visible)').forEach(function(el,i){setTimeout(function(){el.classList.add('visible')},i*40)})},50);
}

var nbCurrentLibCat='all';
var nbCurrentWorld='all';
var nbCurrentKind='all';
var nbMostViewedFilter=false;
function filterKind(kind){
  nbMostViewedFilter=false;
  nbCurrentKind=kind;
  nbRenderLibFilters();
  renderLibrary(nbCurrentLibCat);
}
// Choosing a category or a content world sets the item type back to "הכל",
// so a type picked earlier doesn't silently hide items.
function filterLibrary(cat,btn){
  nbMostViewedFilter=false;
  nbCurrentKind='all';
  nbRenderLibFilters();
  document.querySelectorAll('#lib-filters .filter-btn').forEach(function(b){b.classList.remove('active')});
  if(btn) btn.classList.add('active');
  renderLibrary(cat);
}
function filterWorld(world){
  nbMostViewedFilter=false;
  nbCurrentWorld=world;
  nbCurrentKind='all';
  nbRenderLibFilters();
  nbRenderSidebar();
  renderLibrary(nbCurrentLibCat);
}
function filterMostViewed(btn){
  nbMostViewedFilter=true;
  nbCurrentLibCat='all';
  nbCurrentWorld='all';
  nbCurrentKind='all';
  nbSearchQuery='';
  var input=document.getElementById('nb-search');
  if(input) input.value='';
  document.querySelectorAll('#lib-filters .filter-btn').forEach(function(b){b.classList.remove('active')});
  if(btn) btn.classList.add('active');
  nbRenderLibFilters();
  renderLibrary('all');
}

// World filter row above the category filters (worlds are editable data).
function nbRenderLibFilters(){
  var el=document.getElementById('lib-worlds');
  if(!el) return;
  el.innerHTML='<span class="filter-label">עולם תוכן</span>'
    +[{id:'all',name:'הכל'}].concat(WORLDS).map(function(w){
      return '<button class="filter-btn world-btn'+(nbCurrentWorld===w.id?' active':'')+'" onclick="filterWorld(\''+nbEsc(w.id)+'\')">'+nbEsc(w.name)+'</button>';
    }).join('')
    +'<button class="filter-btn world-btn ghost nb-edit-only nb-admin-only" onclick="nbManageWorlds()" title="ניהול עולמות תוכן">⚙ ניהול</button>';
  var kel=document.getElementById('lib-kinds');
  if(kel) kel.innerHTML='<span class="filter-label">סוג פריט</span>'
    +'<button class="filter-btn world-btn'+(nbCurrentKind==='all'?' active':'')+'" onclick="filterKind(\'all\')">הכל</button>'
    +NB_KIND_ORDER.map(function(k){
      var K=NB_KINDS[k], on=nbCurrentKind===k;
      return '<button class="filter-btn kind-btn'+(on?' active':'')+'" style="'+(on?'background:'+K.color+';border-color:'+K.color+';color:#fff':'color:'+K.color)+'" onclick="filterKind(\''+k+'\')" title="'+nbEsc(K.full)+'"><b>'+k+'</b> '+K.label+'</button>';
    }).join('');
}

// Sidebar: the content worlds and categories filters are on the home page only;
// the sidebar holds the main links and, on an item page, the item's view switch
// and table of contents. This keeps the library count current.
function nbRenderSidebar(){
  var el=document.getElementById('snav-dynamic');
  if(!el) return;
  nbUpdateLibraryItemCount(nbCurrentLibraryItemCount());
  el.innerHTML='';
}

function nbManageWorlds(){
  var existing=document.getElementById('nb-worlds-overlay');
  if(existing) existing.remove();
  var overlay=document.createElement('div');
  overlay.id='nb-worlds-overlay';
  overlay.className='nb-overlay';
  overlay.innerHTML='<div class="nb-modal"><div class="nb-modal-head"><div class="nb-modal-title">עולמות תוכן</div><button class="nb-x" onclick="this.closest(\'.nb-overlay\').remove()">✕</button></div>'
    +'<div class="nb-modal-sub">עולם תוכן הוא תחום או מחלקה (שירות, טכני, הנדסה…). פריט ידע יכול להשתייך לכמה עולמות.</div>'
    +'<div id="nb-worlds-list">'+WORLDS.map(function(w,i){
      var used=Object.keys(window.dynamicDocs||{}).filter(function(k){var d=window.dynamicDocs[k];return d&&d.worlds&&d.worlds.indexOf(w.id)!==-1;}).length;
      return '<div class="nb-row"><input class="nb-input" value="'+nbEsc(w.name)+'" onchange="nbRenameWorld('+i+',this.value)"><span class="nb-row-meta">'+used+' פריטים</span></div>';
    }).join('')+'</div>'
    +'<div class="nb-row"><input class="nb-input" id="nb-new-world" placeholder="שם עולם תוכן חדש"><button class="nb-btn" onclick="nbAddWorld()">+ הוסף</button></div>'
    +'</div>';
  overlay.addEventListener('click',function(e){if(e.target===overlay) overlay.remove();});
  document.body.appendChild(overlay);
}
function nbAddWorld(){
  var inp=document.getElementById('nb-new-world');
  var name=(inp&&inp.value||'').trim();
  if(!name) return;
  if(WORLDS.some(function(w){return w.name===name;})){alert('עולם תוכן בשם הזה כבר קיים');return;}
  WORLDS.push({id:'w'+Date.now(),name:name});
  nbSaveLibrary('נוסף עולם תוכן: '+name);
  nbRenderLibFilters();nbRenderSidebar();nbManageWorlds();
}
function nbRenameWorld(i,name){
  name=(name||'').trim();
  if(!name||!WORLDS[i]) return;
  var old=WORLDS[i].name;
  WORLDS[i].name=name;
  nbSaveLibrary('שם עולם תוכן שונה: '+old+' ← '+name);
  nbRenderLibFilters();nbRenderSidebar();
}

// ── SEARCH (spec §7) ────────────────────────────────────────────────────
// Free text across item names, descriptions, tags, owners, topic names and
// the full content of every item type. Every word must appear somewhere in
// the item. "#tag" searches tags only. Results are the knowledge items
// themselves (plus matching topics), filtered by world / type / category.
var nbSearchQuery='';

function searchTopics(query){ nbSearch(query); }

// Search typed before the library finished loading waits until it is ready.
var nbLibraryReady=false, nbPendingSearch=null;
function nbSearch(query){
  var rawQuery=query||'';
  if(!nbLibraryReady){ nbPendingSearch=rawQuery; return; }
  nbSearchQuery=rawQuery.trim();
  if(nbSearchQuery){
    nbMostViewedFilter=false;
    document.querySelectorAll('#lib-filters .filter-btn').forEach(function(b){b.classList.remove('active')});
    var allFilter=document.querySelector('#lib-filters .filter-btn');
    if(allFilter) allFilter.classList.add('active');
  }
  var inp=document.getElementById('nb-search');
  if(inp&&inp.value!==rawQuery&&document.activeElement!==inp) inp.value=nbSearchQuery;
  var lib=document.getElementById('view-library');
  if(nbSearchQuery&&lib&&!lib.classList.contains('active')) showView('library');
  else renderLibrary(nbCurrentLibCat||'all');
}
function nbClearSearch(){ nbSearch(''); }
function nbSearchTag(tag){ nbSearch('#'+tag); window.scrollTo(0,0); }

// ── Search vocabulary ──
// Words in the same group find each other (written in any case; quote marks
// inside Hebrew words are ignored anyway, so חו"ל = חו״ל = חול). Add a group
// here to teach search another equivalent spelling.
var NB_SEARCH_SYNONYMS=[
  ['esim','איסים','אי-סים','e-sim'],
  ['sim','סים']
];
var NB_HEB_PREFIXES='הובלמשכ';

// Normalized text for matching, plus a map from each normalized character
// back to its position in the plain text (used for excerpts):
// lower-case, unified quote marks, no niqqud, single spaces, and no quote
// marks inside Hebrew words (gershayim / geresh: חו"ל → חול, ארה״ב → ארהב).
function nbNormMap(s){
  var src=nbPlain(s), out='', map=[], prevSpace=false;
  for(var i=0;i<src.length;i++){
    var c=src.charAt(i);
    if(/[֑-ׇ]/.test(c)) continue;
    if(/[״“”]/.test(c)) c='"'; else if(/[׳‘’`]/.test(c)) c="'";
    if((c==='"'||c==="'")&&/[א-ת]/.test(out.charAt(out.length-1))&&/[א-ת]/.test(src.charAt(i+1))) continue;
    if(/\s/.test(c)){ if(prevSpace) continue; c=' '; prevSpace=true; } else prevSpace=false;
    out+=c.toLowerCase(); map.push(i);
  }
  return {norm:out,map:map,src:src};
}
function nbNorm(s){ return nbNormMap(s).norm; }

// All spellings that count as this word (itself, or its synonym group).
function nbVariants(tok){
  for(var i=0;i<NB_SEARCH_SYNONYMS.length;i++){
    var g=NB_SEARCH_SYNONYMS[i].map(nbNorm);
    if(g.indexOf(tok)!==-1) return g;
  }
  return [tok];
}
function nbReEsc(s){ return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
// Position of a word in normalized text, or -1. Short words (up to 3
// characters) must start a word, optionally after a one-letter Hebrew
// prefix — so "סים" finds "לסים" but not "כרטיסים", and "זרה" not "חזרה".
var nbWordReCache={};
function nbWordIndex(text,v){
  if(v.length>3) return text.indexOf(v);
  var re=nbWordReCache[v]||(nbWordReCache[v]=new RegExp('(^|[^a-z0-9א-ת])(['+NB_HEB_PREFIXES+'])?'+nbReEsc(v)));
  var m=re.exec(text);
  return m?m.index+m[1].length+(m[2]?1:0):-1;
}

// All searchable text of an item's content, whatever its type.
function nbContentText(d){
  var parts=[];
  var b=nbGetBody(d);
  if(b){
    switch(d.kind){
      case 'O': b.groups.forEach(function(g){parts.push(g.title);g.steps.forEach(function(s){parts.push(s.text);});}); break;
      case 'I': parts.push(String(b.html||'').replace(/<(\/?(p|h\d|li|tr|td|th|br|div)[^>]*)>/gi,' ')); break;
      case 'T': b.scripts.forEach(function(s){parts.push(s.situation);parts=parts.concat(s.lines);}); break;
      case 'E': parts=parts.concat(b.when,b.to,b.conditions,b.document); (b.extra||[]).forEach(function(x){parts.push(x.title);parts=parts.concat(x.lines);}); break;
      case 'M': parts=parts.concat(b.intro,b.outro); b.questions.forEach(function(q){parts.push(q.title,q.q,q.hint);q.answers.forEach(function(a){parts.push(a.text,a.note);});}); break;
    }
  } else {
    (d.stages||[]).forEach(function(s){parts.push(s.title);nbStageItems(s).forEach(function(i){parts.push(i.text);});});
  }
  // The two hand-designed documents keep their text in their own pages.
  if(d._isViewDoc){ var v=document.getElementById('view-'+d._isViewDoc); if(v) parts.push(v.innerText); }
  return parts.filter(Boolean).map(nbPlain).join(' · ');
}

// Finds a query word in normalized text, with its synonyms. A one-letter
// Hebrew prefix on the query word is tolerated too ("הגלישה" finds "גלישה",
// "לאיסים" finds "eSIM"). Returns the form that matched, or null.
function nbFindToken(text,tok){
  var cands=nbVariants(tok);
  if(tok.length>3&&NB_HEB_PREFIXES.indexOf(tok.charAt(0))!==-1) cands=cands.concat(nbVariants(tok.slice(1)));
  for(var i=0;i<cands.length;i++){ if(nbWordIndex(text,cands[i])!==-1) return cands[i]; }
  return null;
}

// "M-10", "m10", "m 10" → "M-10"; anything else → null.
function nbCodeQuery(query){
  var m=/^\s*([a-z])\s*[-–‑]?\s*(\d{1,3})\s*$/i.exec(query||'');
  return m?m[1].toUpperCase()+'-'+m[2]:null;
}
function nbSearchItems(query){
  var docs=window.dynamicDocs||{};
  var tagMode=query.charAt(0)==='#';
  var tokens=tagMode?[nbNorm(query.slice(1)).trim()]:nbNorm(query).split(' ').filter(function(t){return t.length>1||/\d/.test(t);});
  if(!tokens.length||!tokens[0]) return [];
  // An item code ("M-10", "m10", "m 10") finds that item only; a partial
  // code ("O-5") finds the items whose code starts with it (O-50 … O-59).
  var codeQuery=nbCodeQuery(query);
  if(codeQuery){
    var exact=[], partial=[];
    Object.keys(docs).forEach(function(k){
      var d=docs[k];
      if(!d||!nbVisible(d)||!nbItemPassesFilters(d)) return;
      var topics=TOPICS.filter(function(t){return (d.topicIds||[]).indexOf(t.id)!==-1;});
      if(nbCurrentLibCat!=='all'&&!topics.some(function(t){return nbCatMatches(nbCurrentLibCat,t.cat);})) return;
      var code=(/^\s*([A-Z]-\d{2,3})(?!\d)/.exec(nbPlain(d.topic))||[])[1]||'';
      var r={d:d,topics:topics,score:100,where:['קוד'],matched:[nbNorm(code)],matchedCount:1,code:code};
      if(code===codeQuery) exact.push(r); else if(code.indexOf(codeQuery)===0) partial.push(r);
    });
    return (exact.length?exact:partial).sort(function(a,b){return parseInt(a.code.slice(2),10)-parseInt(b.code.slice(2),10);});
  }
  function findResults(requireEveryToken){
    var results=[];
    Object.keys(docs).forEach(function(k){
      var d=docs[k];
      if(!d||!nbVisible(d)||!nbItemPassesFilters(d)) return;
      // Items not normalized yet (search typed while the page is still loading) have no topicIds/tags.
      var topics=TOPICS.filter(function(t){return (d.topicIds||[]).indexOf(t.id)!==-1;});
      if(nbCurrentLibCat!=='all'&&!topics.some(function(t){return nbCatMatches(nbCurrentLibCat,t.cat);})) return;
      var tags=(d.tags||[]).map(nbNorm);
      if(tagMode){
        var tagVariants=nbVariants(tokens[0]);
        if(!tags.some(function(t){return tagVariants.some(function(v){return t===v||t.indexOf(v)!==-1;});})) return;
        results.push({d:d,topics:topics,score:10,where:['תגית'],matched:[]});
        return;
      }
      var f={title:nbNorm(d.topic),tags:tags.join(' '),desc:nbNorm(d.desc),owner:nbNorm(d.owner),
        topics:topics.map(function(t){return nbNorm(t.title);}).join(' '),content:null};
      var score=0, where={}, matched=[], matchedCount=0;
      for(var i=0;i<tokens.length;i++){
        var tok=tokens[i], hit=false;
        if(nbFindToken(f.title,tok)){score+=10;where['שם']=1;hit=true;}
        if(nbFindToken(f.tags,tok)){score+=8;where['תגיות']=1;hit=true;}
        if(nbFindToken(f.desc,tok)){score+=5;where['תיאור']=1;hit=true;}
        if(nbFindToken(f.topics,tok)){score+=4;where['נושא']=1;hit=true;}
        if(nbFindToken(f.owner,tok)){score+=2;where['אחראי']=1;hit=true;}
        if(f.content===null) f.content=nbNorm(nbContentText(d));
        var cm=nbFindToken(f.content,tok);
        if(cm){score+=1+Math.min(f.content.split(cm).length-1,5);where['תוכן']=1;hit=true;}
        if(!hit){
          if(requireEveryToken) return;
          continue;
        }
        matchedCount++;
        matched.push(nbFindToken(f.title,tok)||cm||tok);
      }
      if(!matchedCount) return;
      // The exact phrase ranks far above the words scattered around (or
      // found inside longer words, e.g. "זרה" inside "חזרה").
      if(tokens.length>1&&matchedCount===tokens.length){
        var phrase=tokens.join(' ');
        if(f.title.indexOf(phrase)!==-1) score+=25;
        else if((f.desc+' '+f.tags+' '+f.content).indexOf(phrase)!==-1){ score+=15; matched.unshift(phrase); }
      }
      results.push({d:d,topics:topics,score:score,where:Object.keys(where),matched:matched,matchedCount:matchedCount});
    });
    return results.sort(function(a,b){return b.score-a.score;});
  }
  var results=findResults(true);
  // Keep all-terms matches precise; if none exist, show useful partial matches
  // instead of making a multiword search look as if only one word is supported.
  if(!results.length&&tokens.length>1){
    results=findResults(false).sort(function(a,b){return b.matchedCount-a.matchedCount||b.score-a.score;});
  }
  return results;
}

function nbSearchTopicsList(query){
  if(query.charAt(0)==='#'||nbCodeQuery(query)) return [];
  var tokens=nbNorm(query).split(' ').filter(function(t){return t.length>1;});
  if(!tokens.length) return [];
  return TOPICS.filter(function(t){
    if(!nbCatMatches(nbCurrentLibCat,t.cat)||!nbTopicMatchesFilters(t)) return false;
    var txt=nbNorm(t.title+' '+(t.desc||''));
    return tokens.every(function(tok){return nbFindToken(txt,tok);});
  });
}

// Escapes text and wraps the matched words in <mark>. Matched words are in
// normalized form, so quote marks may sit between their letters in the text
// (חול highlights חו"ל), and short words only at the start of a word.
function nbHighlight(text,words){
  var safe=nbEsc(nbPlain(text));
  var Q='(?:&quot;|&#39;|״|׳)?';
  var ws=(words||[]).filter(function(w){return w&&w.length>1;}).map(function(w){
    var pat=w.split('').map(nbReEsc).join(Q);
    return w.length>3?pat:'(?<![a-z0-9א-ת])['+NB_HEB_PREFIXES+']?'+pat;
  });
  if(!ws.length) return safe;
  try{ return safe.replace(new RegExp('('+ws.join('|')+')','gi'),'<mark>$1</mark>'); }
  catch(e){ return safe; } // very old browsers without look-behind: no highlight
}
// A short excerpt of the content around the first matched word.
function nbSnippet(d,words){
  var nm=nbNormMap(nbContentText(d)), pos=-1;
  (words||[]).some(function(w){var i=nbWordIndex(nm.norm,w);if(i!==-1){pos=nm.map[i];return true;}return false;});
  if(pos===-1) return '';
  var text=nm.src;
  var start=Math.max(0,pos-60), end=Math.min(text.length,pos+110);
  return (start>0?'…':'')+nbHighlight(text.slice(start,end).replace(/\s+/g,' '),words)+(end<text.length?'…':'');
}

function nbRenderSearch(){
  var el=document.getElementById('library-content');
  if(!el) return;
  var q=nbSearchQuery;
  var items=nbSearchItems(q), topics=nbSearchTopicsList(q);
  nbUpdateLibraryItemCount(items.length);
  var filtersOn=nbCurrentWorld!=='all'||nbCurrentKind!=='all'||nbCurrentLibCat!=='all';
  var html='<div class="search-head"><div><span class="search-q">'+(q.charAt(0)==='#'?'תגית ':'')+'<bdi>"'+nbEsc(q.charAt(0)==='#'?q.slice(1):q)+'"</bdi></span>'
    +'<span class="search-count">'+items.length+' פריטי ידע'+(topics.length?' · '+topics.length+' נושאים':'')+(filtersOn?' · לפי הסינון שנבחר':'')+'</span></div>'
    +'<button class="search-clear" onclick="nbClearSearch()">✕ נקה חיפוש</button></div>';
  if(!items.length&&!topics.length){
    html+='<div class="empty-state">לא נמצאו תוצאות'+(filtersOn?'. נסו להסיר את הסינון של עולם התוכן / סוג הפריט / הקטגוריה.':'. נסו מילה אחרת או פחות מילים.')+'</div>';
  }
  if(items.length){
    html+='<div class="search-section">פריטי ידע</div><div class="result-list">'+items.map(function(r){
      var d=r.d, snip=r.where.indexOf('תוכן')!==-1?nbSnippet(d,r.matched):'';
      return '<div class="result-card fade-in" style="--kind:'+(NB_KINDS[d.kind]||NB_KINDS.R).color+'" onclick="nbOpenResult(\''+nbEsc(d.id)+'\')">'
        +'<div class="rc-top">'+nbKindBadge(d.kind)+nbStatusBadge(d)
        +'<span class="rc-title">'+nbHighlight(d.topic,r.matched)+'</span>'+nbNewTabIcon(d.id)+'</div>'
        +'<div class="rc-path">'+(r.topics.length?r.topics.map(function(t){return '<a onclick="event.stopPropagation();nbOpenTopic('+t.id+')">'+nbEsc(nbPlain(t.title))+'</a>';}).join(' · '):'ללא נושא')
        +' · '+d.worlds.map(function(w){return nbEsc(nbWorldName(w));}).join(', ')+'</div>'
        +(d.desc?'<div class="rc-desc">'+nbHighlight(d.desc,r.matched)+'</div>':'')
        +(snip?'<div class="rc-snippet">'+snip+'</div>':'')
        +'<div class="rc-foot">'+(d.tags.length?'<span class="ic-tags">'+d.tags.map(nbTagChip).join('')+'</span>':'')
        +'<span class="rc-where">נמצא ב: '+r.where.join(', ')+'</span></div>'
        +'</div>';
    }).join('')+'</div>';
  }
  if(topics.length){
    html+='<div class="search-section">נושאים</div><div class="topic-grid">'+topics.map(cardHTML).join('')+'</div>';
  }
  el.innerHTML=html;
  setTimeout(function(){document.querySelectorAll('#library-content .fade-in:not(.visible)').forEach(function(e2,i){setTimeout(function(){e2.classList.add('visible')},i*30)})},30);
}

function nbGetRecentItems(){
  try{
    var entries=JSON.parse(localStorage.getItem(NB_STORAGE_KEYS.recent)||'[]');
    return Array.isArray(entries)?entries.filter(function(entry){
      return entry&&typeof entry.id==='string'&&Number.isFinite(entry.viewedAt);
    }).slice(0,10):[];
  }catch(e){
    console.warn('Could not read recently viewed knowledge items.',e);
    return [];
  }
}
function nbRecordRecentItem(docId){
  var recent=nbGetRecentItems().filter(function(entry){return entry.id!==docId;});
  recent.unshift({id:docId,viewedAt:Date.now()});
  try{localStorage.setItem(NB_STORAGE_KEYS.recent,JSON.stringify(recent.slice(0,10)));}
  catch(e){console.warn('Could not save recently viewed knowledge items.',e);}
}
function nbRenderMostViewed(){
  var el=document.getElementById('library-content');
  if(!el) return;
  var docs=window.dynamicDocs||{};
  var recent=nbGetRecentItems().map(function(entry){
    return {entry:entry,doc:docs[entry.id]};
  }).filter(function(row){
    return row.doc&&nbVisible(row.doc);
  });
  nbUpdateLibraryItemCount(recent.length);
  el.innerHTML='<div class="search-head"><div><span class="search-q">הנצפות ביותר</span>'
    +'<span class="search-count">עד 10 פריטי הידע האחרונים שנפתחו בדפדפן זה</span></div></div>'
    +(recent.length?'<div class="result-list">'+recent.map(function(row){
      var d=row.doc, topics=TOPICS.filter(function(t){return (d.topicIds||[]).indexOf(t.id)!==-1;});
      var viewedAt=new Date(row.entry.viewedAt);
      var time=viewedAt.toLocaleDateString('he-IL')+' '+viewedAt.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
      return '<div class="result-card fade-in" style="--kind:'+(NB_KINDS[d.kind]||NB_KINDS.R).color+'" onclick="nbOpenResult(\''+nbEsc(d.id)+'\')">'
        +'<div class="rc-top">'+nbKindBadge(d.kind)+nbStatusBadge(d)+'<span class="rc-title">'+nbEsc(nbPlain(d.topic))+'</span>'+nbNewTabIcon(d.id)+'</div>'
        +'<div class="rc-path">'+(topics.length?topics.map(function(t){return nbEsc(nbPlain(t.title));}).join(' · '):'ללא נושא')
        +(d.worlds&&d.worlds.length?' · '+d.worlds.map(function(w){return nbEsc(nbWorldName(w));}).join(', '):'')+'</div>'
        +(d.desc?'<div class="rc-desc">'+nbEsc(d.desc)+'</div>':'')
        +'<div class="rc-foot"><span class="rc-where">נפתח לאחרונה: '+nbEsc(time)+'</span></div>'
        +'</div>';
    }).join('')+'</div>':'<div class="empty-state">עדיין לא נפתחו פריטי ידע בדפדפן זה</div>');
  setTimeout(function(){document.querySelectorAll('#library-content .fade-in:not(.visible)').forEach(function(e2,i){setTimeout(function(){e2.classList.add('visible')},i*30)})},30);
}

// Open a result in the context of its first topic (for the back button and sibling strip).
function nbOpenResult(docId){
  var d=window.dynamicDocs[docId];
  if(!d) return;
  nbCurrentTopicId=d.topicIds.length?d.topicIds[0]:null;
  showDynamicDoc(docId);
}

function nbTagChip(tg){
  return '<span class="tag-chip clickable" data-tag="'+nbEsc(tg)+'" onclick="event.stopPropagation();nbSearchTag(this.getAttribute(\'data-tag\'))" title="כל הפריטים עם התגית">#'+nbEsc(tg)+'</span>';
}

function filterCategory(cat){
  showView('library');
  setTimeout(function(){filterLibrary(cat,document.querySelector('#lib-filters .filter-btn[data-cat="'+cat+'"]'))},100);
}

var CAT_RAIL={hq:'#1E3A5F',sim:'#2E5CE0',data:'#1D6FB8',signal:'#4F46E5',calls:'#0F766E',sms:'#9D4EDD',tech:'#3A4A5C',tech2:'#3A4A5C',billing:'#0E7A4F',plans:'#6D3FD1',intl:'#0891B2',ops:'#C2410C'};
function cardHTML(t){
  var railColor=CAT_RAIL[t.cat]||'#8A94A3';
  var items=nbTopicItems(t.id);
  var kinds=[];
  items.forEach(function(d){if(kinds.indexOf(d.kind)===-1)kinds.push(d.kind);});
  var delBtn='<span class="tc-del" onclick="event.stopPropagation();nbConfirmDeleteTopic('+t.id+')" title="מחק נושא">🗑️</span>';
  return '<div class="topic-card fade-in" onclick="nbOpenTopicCard('+t.id+')">'
    +'<div class="tc-rail" style="background:'+railColor+'"></div>'
    +'<div class="tc-body">'
    +delBtn
    +'<div class="tc-top"><span class="tc-cat" style="color:'+railColor+'">'+(CAT[t.cat]||'📄 כללי')+'</span></div>'
    +'<div class="tc-title">'+t.title+'</div>'
    +'<div class="tc-desc">'+(t.desc||'')+'</div>'
    +'<div class="tc-foot">'
    +(items.length
      ?'<span class="tc-count">'+items.length+' '+(items.length===1?'פריט ידע':'פריטי ידע')+'</span><span class="tc-kinds">'+kinds.map(function(k){return nbKindBadge(k,true);}).join('')+'</span>'
      :'<span class="tc-count empty">טרם נכתב תוכן</span>')
    +'</div>'
    +'</div></div>';
}

// ── TOPIC VIEW (spec §6) ────────────────────────────────────────────────
// Every knowledge item in the topic, identifiable at a glance by type.
var nbCurrentTopicId=null;

// A topic card with a single item opens that item directly; the topic page
// (a list of one) would be an extra click. The item page still links back to
// the topic, where editors can add more items.
function nbOpenTopicCard(id){
  var items=nbTopicItems(id);
  if(items.length===1&&items[0].id&&window.dynamicDocs[items[0].id]){ nbCurrentTopicId=id; showDynamicDoc(items[0].id); }
  else nbOpenTopic(id);
}

function nbOpenTopic(id){
  var t=TOPICS.find(function(x){return x.id===id;});
  if(!t) return;
  nbCurrentTopicId=id;
  var items=nbTopicItems(id);
  var railColor=CAT_RAIL[t.cat]||'#8A94A3';
  var el=document.getElementById('topic-content');
  el.innerHTML='<div class="topic-head">'
      +'<div class="tc-cat" style="color:'+railColor+'">'+(CAT[t.cat]||'📄 כללי')+'</div>'
      +'<h1 class="topic-title">'+t.title+'</h1>'
      +(t.desc?'<div class="topic-desc">'+t.desc+'</div>':'')
      +'<div class="topic-kinds">'+NB_KIND_ORDER.map(function(k){
        var n=items.filter(function(d){return d.kind===k;}).length;
        return n?'<span class="topic-kind-pill" style="color:'+NB_KINDS[k].color+';background:'+NB_KINDS[k].bg+'"><b>'+k+'</b> '+NB_KINDS[k].label+' · '+n+'</span>':'';
      }).join('')+'</div>'
    +'</div>'
    +(items.length
      ?'<div class="item-grid">'+items.map(nbItemCardHTML).join('')+'</div>'
      :'<div class="empty-state">📝 עדיין אין פריטי ידע בנושא זה.</div>')
    +'<button class="nb-add-item nb-edit-only" onclick="nbNewItemForTopic('+t.id+')">+ הוסף פריט ידע לנושא זה</button>';
  showView('topic');
}

function nbItemCardHTML(d){
  var k=NB_KINDS[d.kind]||NB_KINDS.R;
  return '<div class="item-card fade-in'+(nbActive(d)?'':' inactive')+'" style="--kind:'+k.color+'" onclick="showDynamicDoc(\''+nbEsc(d.id)+'\')">'
    +'<div class="ic-top"><span class="ic-badges">'+nbKindBadge(d.kind)+nbStatusBadge(d)+'<span class="nb-edit-only">'+nbReviewBadge(d)+'</span></span><span class="ic-worlds">'+d.worlds.map(function(w){return '<span class="world-chip">'+nbEsc(nbWorldName(w))+'</span>';}).join('')+nbNewTabIcon(d.id)+'</span></div>'
    +'<div class="ic-title">'+d.topic+'</div>'
    +(d.desc?'<div class="ic-desc">'+d.desc+'</div>':'')
    +(d.tags.length?'<div class="ic-tags">'+d.tags.map(nbTagChip).join('')+'</div>':'')
    +'<div class="ic-foot">'+(d.updatedAt?'עודכן '+nbFmtDate(d.updatedAt):'תוכן מובנה')+(d.owner?' · אחראי: '+nbEsc(d.owner):'')+'</div>'
    +'</div>';
}

function nbNewItemForTopic(topicId){
  nbResetNewForm(topicId);
  showView('new');
  nbRender();
}

function nbResetNewForm(topicId){
  NB_STAGES.forEach(function(s){nbState[s.id]={picked:[],custom:[],applied:false,s1data:{},images:{}};}); nbState._bodies={};
  nbCustomStages=[];
  nbStageOrder=[];
  window.nbEditingDocId=null;
  window.nbLinkToTopicId=topicId==null?null:topicId;
  if(topicId!=null) nbState['s1'].s1data={topicId:String(topicId),kind:'R',worlds:[]};
}

function nbNewItem(){
  nbResetNewForm();
  showView('new');
  nbRender();
  window.scrollTo(0,0);
}

// Kept for older links/calls: a topic always opens its topic view now.
function openArticle(id){ nbOpenTopic(id); }


function nbShowSuccessModal(topic){
  // Remove existing modal if any
  var old=document.getElementById('nb-success-modal');
  if(old) old.remove();

  var overlay=document.createElement('div');
  overlay.id='nb-success-modal';
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.35);z-index:9998;display:flex;align-items:center;justify-content:center';

  var card=document.createElement('div');
  card.style.cssText='background:#fff;border-radius:14px;padding:28px 32px;box-shadow:0 20px 60px rgba(0,0,0,.25);text-align:center;max-width:340px;width:90%;font-family:Rubik,sans-serif;direction:rtl';

  var emoji=document.createElement('div');
  emoji.style.cssText='font-size:28px;margin-bottom:12px';
  emoji.textContent='🎉';

  var title=document.createElement('div');
  title.style.cssText='font-size:16px;font-weight:600;color:#1F2E3B;margin-bottom:8px';
  title.textContent='פריט הידע נוצר בהצלחה!';

  var desc=document.createElement('div');
  desc.style.cssText='font-size:14px;color:#6B7280;margin-bottom:20px;line-height:1.6';
  desc.innerHTML='פריט הידע <strong style="color:#FF3D00">'+topic.replace(/</g,'&lt;')+'</strong> נוסף לספריית הידע.';

  var btn=document.createElement('button');
  btn.style.cssText='background:#FF3D00;color:#fff;border:none;border-radius:8px;padding:10px 28px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
  btn.textContent='אוקיי!';
  btn.addEventListener('click',function(){overlay.remove();});

  card.appendChild(emoji);
  card.appendChild(title);
  card.appendChild(desc);
  card.appendChild(btn);
  overlay.appendChild(card);
  document.body.appendChild(overlay);
}
function nbCloseMsg(el){
  var p=el.parentElement;
  while(p&&p.style.position!=='fixed') p=p.parentElement;
  if(p) p.remove();
}

// Resolves the topic chosen in stage 1: an existing topic id, or "new" →
// creates the topic. Returns the topic id, or null if nothing valid chosen.
function nbResolveTopic(d){
  if(d.topicId&&d.topicId!=='new'){
    var id=parseInt(d.topicId);
    if(TOPICS.some(function(t){return t.id===id;})) return id;
  }
  if(d.topicId==='new'&&(d.newTopic||'').trim()){
    var newId=Math.max(NB_USER_TOPIC_START,TOPICS.length>0?Math.max.apply(null,TOPICS.map(function(t){return t.id;}))+1:1);
    TOPICS.push({id:newId,cat:d.cat||'tech',title:d.newTopic.trim(),desc:''});
    return newId;
  }
  return null;
}

// Copies the stage-1 fields onto an item.
function nbApplyS1Fields(doc,d){
  doc.topic=(d.topic||'').trim();
  doc.desc=(d.desc||'').trim();
  doc.kind=NB_KINDS[d.kind]?d.kind:'R';
  doc.worlds=(d.worlds&&d.worlds.length)?d.worlds.slice():[WORLDS[0]?WORLDS[0].id:'service'];
  doc.tags=(d.tags||'').split(',').map(function(s){return s.trim();}).filter(Boolean);
  doc.owner=(d.owner||'').trim();
  var newStatus=NB_STATUSES[d.status]?d.status:'draft';
  if(newStatus==='published'&&doc.status!=='published') doc.publishedAt=Date.now();
  doc.status=newStatus;
  doc.track={state:d.trackState||'',priority:d.trackPriority||'',gap:(d.trackGap||'').trim(),source:(d.trackSource||'').trim()};
  if(d.source) doc.source=d.source; // the uploaded source document (spec §8)
  if(d.fromRevision) delete doc.revision; // a proposed update was reviewed and saved
  doc.updatedAt=Date.now();
}

function nbAddToLibrary(docId,title,topicId){
  var doc=window.dynamicDocs[docId];
  if(doc&&topicId) doc.topicIds=[topicId];
  var t=TOPICS.find(function(x){return x.id===topicId;});
  if(t){ var cat=t.cat; doc.cat=cat; }
  nbRenderSidebar();
  renderLibrary(nbCurrentLibCat||'all');
  nbSaveLibrary('נוצר: '+title);
}


// "Other items in this topic" strip — move between M/R/O/E… without
// searching again (spec §6).
function nbSiblingStripHTML(doc){
  var tid=(nbCurrentTopicId!=null&&doc.topicIds.indexOf(nbCurrentTopicId)!==-1)?nbCurrentTopicId:doc.topicIds[0];
  var t=TOPICS.find(function(x){return x.id===tid;});
  if(!t) return '';
  var items=nbTopicItems(t.id);
  if(items.length<2) return '';
  return '<div class="sibling-strip"><span class="ss-label">בנושא <a onclick="nbOpenTopic('+t.id+')">'+t.title+'</a>:</span>'
    +items.map(function(d){
      return '<button class="ss-item'+(d.id===doc.id?' current':'')+'" onclick="showDynamicDoc(\''+nbEsc(d.id)+'\')">'+nbKindBadge(d.kind,true)+' '+d.topic+'</button>';
    }).join('')+'</div>';
}
// noKind: the item page shows the type as its own label under the title.
function nbItemMetaHTML(doc,noKind){
  return '<div class="article-meta">'+(noKind?'':nbKindBadge(doc.kind))+nbStatusBadge(doc)+'<span class="nb-edit-only">'+nbReviewBadge(doc)+'</span>'
    +doc.worlds.map(function(w){return '<span class="world-chip">'+nbEsc(nbWorldName(w))+'</span>';}).join('')
    +'</div>'
    // Editors get a direct link to the formatted source document (Word for the web).
    +(doc.source&&(doc.status==='published'||!doc.draftDoc)?'<div class="draft-src nb-edit-only">📄 '+(doc.status==='published'?'מסמך מקור מעוצב: ':'מסמך מקור מעוצב לבדיקה לפני פרסום: ')+nbSourceLink(doc.source)+'</div>':'')
    +(doc.draftDoc&&doc.status!=='published'?'<div class="draft-src nb-edit-only">📝 טיוטת Word לעריכה: '+nbSourceLink(doc.draftDoc)+'</div>':'')
    +(doc.reviewNotes&&doc.reviewNotes.length&&doc.status!=='published'?'<div class="import-issues nb-edit-only"><div class="ii-title">⚠ הערות לפני אישור</div><ul>'+doc.reviewNotes.map(function(note){return '<li>'+nbEsc(note)+'</li>';}).join('')+'</ul></div>':'');
}
// noDate: the item page shows the update date in its header.
function nbItemFieldsHTML(doc,noDate){
  var rows=[];
  if(doc.tags.length) rows.push('<div class="ic-tags">'+doc.tags.map(nbTagChip).join('')+'</div>');
  var meta=[];
  if(!noDate) meta.push(doc.updatedAt?'עודכן לאחרונה: '+nbFmtDate(doc.updatedAt):'תוכן מובנה');
  if(doc.owner) meta.push('גורם מקצועי אחראי: '+nbEsc(doc.owner));
  // The read-only origin document (name only, never a link); otherwise editors see the internal ID.
  if(doc.originName) meta.push('מסמך מקור: '+nbEsc(doc.originName));
  else if(!nbIsReadonly()) meta.push('מזהה: '+nbEsc(doc.id));
  rows.push('<div class="item-fields">'+meta.join(' · ')+'</div>');
  rows.push(nbTrackPanelHTML(doc));
  return rows.join('');
}

// Editor-only panel: status (changeable here) and the tracking fields.
// The item's documents and missing details, from NB_DOC_INFO (scripts/doc-info.cjs), by item code.
function nbDocInfo(doc){ var c=nbSplitTitle(doc.topic).code; return (c&&typeof NB_DOC_INFO!=='undefined'&&NB_DOC_INFO[c])||{}; }
// Only what editors track: the read-only origin document, the formatted document to edit,
// the published and last edited dates, and the missing details (yellow in the formatted document).
function nbTrackPanelHTML(doc){
  var info=nbDocInfo(doc), cells=[];
  var link=function(l){ return '<a href="'+nbEsc(l.url)+'" target="_blank" rel="noopener">'+nbEsc(l.name)+'</a>'; };
  cells.push('<div class="wide"><span>מסמך מקור (קריאה בלבד)</span><b>'+(info.origin?'📄 '+link(info.origin):'לא נמצא בתיקיית "מסמכי DOCx מוכנים לפרסום"')+'</b></div>');
  cells.push('<div class="wide"><span>מסמך לעריכה (Word)</span><b>'+(doc.source&&doc.source.url?'✏️ '+nbSourceLink(doc.source):'אין מסמך מעוצב')+'</b></div>');
  cells.push('<div><span>תאריך פרסום</span><b>'+(doc.publishedAt?nbFmtDate(doc.publishedAt):'טרם פורסם')+'</b></div>');
  cells.push('<div><span>נערך לאחרונה</span><b>'+(doc.updatedAt?nbFmtDate(doc.updatedAt):'—')+'</b></div>');
  var miss=info.missing;
  cells.push('<div class="wide'+(miss&&miss.length?' gap':'')+'"><span>פער / מידע חסר</span><b>'
    +(!miss?'לא נבדק — אין מסמך לעריכה'
      :!miss.length?'אין פרטים חסרים מסומנים במסמך לעריכה'
      :miss.length+(miss.length===1?' פרט חסר':' פרטים חסרים')+' (מסומנים בצהוב במסמך לעריכה):<ol class="tp-missing">'+miss.map(function(m){return '<li>'+nbEsc(m)+'</li>';}).join('')+'</ol>')
    +'</b></div>');
  // Feedback agents sent from the item page ("דיווח על בעיה / משוב"), newest first.
  var fb=nbFeedbackFor(doc.id).slice().reverse();
  if(fb.length) cells.push('<div class="wide gap"><span>משוב מנציגים ('+fb.length+')</span><b><ul class="tp-missing">'
    +fb.map(function(f){return '<li>'+nbFmtDate(f.at)+': '+nbEsc(f.text)+'</li>';}).join('')+'</ul></b></div>');
  var canImport=typeof window.nbImportSourceDoc==='function'&&window.NB_CAN_IMPORT;
  var actions=(doc.revision?'<button type="button" class="tp-btn warn" onclick="nbOpenReview(\''+nbEsc(doc.id)+'\')">🔎 גרסה מוצעת ממתינה — השווה ואשר</button>':'')
    +(canImport?'<button type="button" class="tp-btn" onclick="nbStartSourceUpdate(\''+nbEsc(doc.id)+'\')">📄 עדכון ממסמך מקור</button>':'');
  return '<div class="track-panel nb-edit-only">'
    +'<div class="tp-head"><span class="tp-title">מעקב עריכה</span><label>סטטוס '
    +'<select onchange="nbSetStatus(\''+nbEsc(doc.id)+'\',this.value)">'
    +NB_STATUS_ORDER.map(function(s){return '<option value="'+s+'"'+(doc.status===s?' selected':'')+'>'+NB_STATUSES[s].label+'</option>';}).join('')
    +'</select></label></div>'
    +(cells.length?'<div class="tp-grid">'+cells.join('')+'</div>':'')
    +(actions?'<div class="tp-actions">'+actions+'</div>':'')
    +'</div>';
}

// ── SOURCE DOCUMENTS → DRAFTS (spec §8) ─────────────────────────────────
// An editor uploads the source document (PDF / Word / text). On WordPress the
// server stores it and Claude converts it into a draft in the app's structure
// (window.nbImportSourceDoc, from wp-bridge.js). Nothing reaches agents until
// an editor approves: new items start as "ממתין לאישור"; for an existing item
// the conversion is kept as a proposed revision next to the published version.

// Codes and titles of existing items, so references in the source resolve.
function nbCatalogText(){
  var docs=window.dynamicDocs||{};
  return Object.keys(docs).map(function(k){return docs[k];}).filter(Boolean).map(function(d){
    return nbPlain(d.topic)+' · '+((NB_KINDS[d.kind]||{}).full||'');
  }).sort().join('\n');
}
// Plain-text version of an item, sent along when converting an update.
function nbItemToText(d){
  return nbPlain(d.topic)+'\n'+(d.desc||'')+'\n'+nbContentText(d).split(' · ').join('\n');
}

// Converts the structured draft returned by the server into item fields.
function nbDraftToItem(draft,source){
  var k=NB_KINDS[draft.kind]?draft.kind:'R';
  var code=(draft.code||'').trim();
  var item={kind:k,topic:(code?code+' · ':'')+(draft.title||'').trim(),desc:(draft.desc||'').trim(),
    tags:(draft.tags||[]).filter(Boolean),stages:[],source:source||null,_issues:(draft.issues||[]).filter(Boolean)};
  var lines=function(a){return (a||[]).map(function(s){return String(s||'').trim();}).filter(Boolean);};
  switch(k){
    case 'R': case 'S':
      item.stages=(draft.stages||[]).map(function(s,i){
        return {num:String(i+1),title:(s.title||'').trim(),items:lines(s.items).map(function(t){return {text:t,img:null};}),images:[]};
      }).filter(function(s){return s.title||s.items.length;});
      break;
    case 'O':
      item.body={groups:(draft.groups||[]).map(function(g){return {title:(g.title||'').trim(),steps:lines(g.steps).map(function(t){return {text:t,img:null};})};}).filter(function(g){return g.steps.length;})};
      break;
    case 'I': item.body={html:nbSanitizeRich(draft.html||'')}; break;
    case 'T': item.body={scripts:(draft.scripts||[]).map(function(s){return {situation:(s.situation||'').trim(),lines:lines(s.lines)};})}; break;
    case 'E':
      var e=draft.escalation||{};
      item.body={when:lines(e.when),to:lines(e.to),conditions:lines(e.conditions),document:lines(e.document),
        extra:(e.extra||[]).map(function(x){return {title:(x.title||'').trim(),lines:lines(x.lines)};}).filter(function(x){return x.lines.length;})};
      break;
    case 'M':
      var dg=draft.diagnosis||{};
      item.body={intro:lines(dg.intro),outro:lines(dg.outro),questions:(dg.questions||[]).map(function(q){
        return {q:(q.q||'').trim(),hint:(q.hint||'').trim(),answers:(q.answers||[]).map(function(a){
          var go='', note=(a.note||'').trim(), n=a.go_question;
          if(typeof n==='number'&&n>=0) go='q:'+n;
          else if(a.go_code){
            var t=nbFindByCode(String(a.go_code).trim());
            if(t) go='item:'+t.id; else note=(note?note+' ':'')+'(מסמך '+a.go_code+')';
          }
          return {text:(a.text||'').trim(),note:note,go:go};
        })};
      })};
      break;
  }
  return item;
}

// "Busy" overlay while the conversion runs (usually 30 seconds to 2 minutes).
function nbBusy(msg){
  var o=document.getElementById('nb-busy');
  if(!o){ o=document.createElement('div'); o.id='nb-busy'; o.className='nb-overlay'; document.body.appendChild(o); }
  o.innerHTML='<div class="nb-modal busy-card"><div class="busy-spin"></div><div class="busy-msg">'+msg+'</div>'
    +'<div class="nb-modal-sub">ההמרה נמשכת בדרך כלל בין חצי דקה לשתי דקות. אפשר להמשיך לעבוד בלשונית אחרת.</div></div>';
}
function nbBusyDone(){ var o=document.getElementById('nb-busy'); if(o) o.remove(); }
function nbImportError(err){
  nbBusyDone();
  nbConfirmGeneric('ההמרה לא הצליחה',nbEsc((err&&err.message)||'שגיאה לא ידועה')+'<br><span style="font-size:12px">אפשר לנסות שוב, או להזין את התוכן ידנית.</span>','הבנתי','var(--navy)',function(){});
}

// Import box at the top of "פריט ידע חדש" (new items only).
function nbRenderImportBox(){
  var el=document.getElementById('nb-import-box');
  if(!el) return;
  var d=nbState.s1&&nbState.s1.s1data||{};
  var issues=(d.issues||[]).length?'<div class="import-issues"><div class="ii-title">⚠ לבדיקתך לפני השמירה — הערות מההמרה:</div><ul>'
      +d.issues.map(function(x){return '<li>'+nbEsc(x)+'</li>';}).join('')+'</ul></div>':'';
  var src=d.source?'<div class="import-src">מסמך מקור: '+nbSourceLink(d.source)+'</div>':'';
  if(window.nbEditingDocId){ el.innerHTML=issues+src; return; }
  var body;
  if(typeof window.nbImportSourceDoc!=='function'){
    body='<div class="import-note">זמין באתר ה-WordPress: העלאת מסמך מקור (PDF / PNG / Word) והמרה אוטומטית לטיוטה. בגרסת ההדגמה הזו אין שרת שמבצע את ההמרה.</div>';
  } else if(!window.NB_CAN_IMPORT){
    body='<div class="import-note">המרת מסמכים לא הוגדרה עדיין. מנהל המערכת צריך להזין מפתח API בהגדרות התוסף (כלים ← wecom מאגר ידע).</div>';
  } else {
    body='<div class="import-row"><input type="file" id="nb-import-file" accept=".pdf,.png,.docx,.txt,application/pdf,image/png,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain">'
      +'<select id="nb-import-kind" class="s1-input"><option value="">סוג: זיהוי אוטומטי</option>'
      +NB_KIND_ORDER.map(function(k){return '<option value="'+k+'">'+k+' · '+NB_KINDS[k].full+'</option>';}).join('')+'</select>'
      +'<button type="button" class="nb-btn" onclick="nbStartImport()">המר לטיוטה</button></div>'
      +'<div class="import-note">הטיוטה נפתחת כאן לבדיקה ונשמרת בסטטוס "ממתין לאישור" — לא מוצגת לנציגים עד שתאשרו ותפרסמו.</div>';
  }
  el.innerHTML='<div class="import-box nb-edit-only"><div class="import-title">📄 יצירת פריט ממסמך מקור</div>'+body+'</div>'+issues+src;
}

function nbStartImport(){
  var f=document.getElementById('nb-import-file');
  var file=f&&f.files&&f.files[0];
  if(!file){ alert('בחרו קובץ PDF, Word או טקסט'); return; }
  var kind=(document.getElementById('nb-import-kind')||{}).value||'';
  nbBusy('ממיר את "'+nbEsc(file.name)+'" לטיוטה…');
  window.nbImportSourceDoc(file,{kind:kind,catalog:nbCatalogText()}).then(function(res){
    nbBusyDone();
    var item=nbDraftToItem(res.draft,res.source);
    item.status='pending';
    item.worlds=[]; item.topicIds=[];
    item.track={state:'קיים',source:res.source?res.source.name:'',gap:'',priority:''};
    nbFillForm(item,null);
    nbState.s1.applied=false; // editor picks topic and worlds before saving
    nbRender(); nbRenderImportBox();
  }).catch(nbImportError);
}

function nbSourceLink(src){
  if(!src||!/^https?:\/\//i.test(src.url||'')) return nbEsc((src&&src.name)||'');
  return '<a href="'+nbEsc(src.url)+'" target="_blank" rel="noopener">'+nbEsc(src.name||'מסמך מקור')+'</a>';
}
function nbReviewBadge(d){ return d&&d.revision?'<span class="status-badge review">נדרשת לבדיקה</span>':''; }

// Existing item: upload an updated source document → proposed revision.
function nbStartSourceUpdate(docId){
  var d=window.dynamicDocs[docId];
  if(!d) return;
  var inp=document.createElement('input');
  inp.type='file'; inp.accept='.pdf,.png,.docx,.txt,application/pdf,image/png,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain';
  inp.onchange=function(){
    var file=inp.files&&inp.files[0];
    if(!file) return;
    nbBusy('ממיר את "'+nbEsc(file.name)+'" ומשווה לגרסה הנוכחית…');
    window.nbImportSourceDoc(file,{kind:d.kind,catalog:nbCatalogText(),current:nbItemToText(d)}).then(function(res){
      nbBusyDone();
      var item=nbDraftToItem(res.draft,res.source);
      d.revision={item:{kind:item.kind,topic:item.topic,desc:item.desc,tags:item.tags,stages:item.stages,body:item.body||null},
        issues:item._issues,source:res.source||null,createdAt:Date.now()};
      nbSaveLibrary('הוצעה גרסה חדשה ממסמך מקור: '+nbPlain(d.topic));
      nbOpenReview(docId);
    }).catch(nbImportError);
  };
  inp.click();
}

// Read-only outline of an item (any type), used to compare versions side by side.
function nbOutlineHTML(it){
  var h='<div class="ol-head">'+nbKindBadge(it.kind)+'<div class="ol-title">'+nbEsc(nbPlain(it.topic))+'</div>'
    +(it.desc?'<div class="ol-desc">'+nbEsc(it.desc)+'</div>':'')
    +((it.tags||[]).length?'<div class="ic-tags">'+it.tags.map(function(t){return '<span class="tag-chip">#'+nbEsc(t)+'</span>';}).join('')+'</div>':'')+'</div>';
  var ul=function(a){return a&&a.length?'<ul>'+a.map(function(x){return '<li>'+nbEsc(nbPlain(x))+'</li>';}).join('')+'</ul>':'';};
  var b=it.body||(nbIsStageKind(it.kind)?null:nbGetBody(it));
  if(nbIsStageKind(it.kind)||!b){
    h+='<ol class="ol-stages">'+(it.stages||[]).map(function(s){return '<li><b>'+nbEsc(nbPlain(s.title))+'</b>'+ul(nbStageItems(s).map(function(i){return i.text;}))+'</li>';}).join('')+'</ol>';
  } else switch(it.kind){
    case 'O': h+=b.groups.map(function(g){var list=g.ordered===false?'ul':'ol';return (g.title?'<h4>'+nbEsc(g.title)+'</h4>':'')+'<'+list+'>'+g.steps.map(function(s){return '<li>'+nbEsc(nbPlain(s.text))+'</li>';}).join('')+'</'+list+'>';}).join(''); break;
    case 'I': h+='<div class="kv-rich">'+nbSanitizeRich(b.html)+'</div>'; break;
    case 'T': h+=b.scripts.map(function(s){return '<h4>'+nbEsc(s.situation)+'</h4>'+ul(s.lines);}).join(''); break;
    case 'E':
      [['when','מתי מעבירים'],['to','למי מעבירים'],['conditions','תנאים לפני ההעברה'],['document','מה לתעד']].forEach(function(f){
        h+='<h4>'+f[1]+'</h4>'+(b[f[0]]&&b[f[0]].length?ul(b[f[0]]):'<div class="e-missing">⚠ לא הוגדר</div>');
      });
      (b.extra||[]).forEach(function(x){ h+='<h4>'+nbEsc(x.title)+'</h4>'+ul(x.lines); });
      break;
    case 'M':
      h+=ul(b.intro)+'<ol class="ol-stages">'+b.questions.map(function(q,qi){
        return '<li><b>'+nbEsc(q.q)+'</b>'+(q.hint?'<div class="ol-desc">'+nbEsc(q.hint)+'</div>':'')+'<ul>'+q.answers.map(function(a){
          var to=/^q:\d+$/.test(a.go)?'שאלה '+(parseInt(a.go.slice(2))+1):(a.go.indexOf('item:')===0?nbPlain((window.dynamicDocs[a.go.slice(5)]||{}).topic||a.go):'סיום');
          return '<li>'+nbEsc(a.text)+' ← <b>'+nbEsc(to)+'</b>'+(a.note?'<div class="ol-desc">'+nbEsc(a.note)+'</div>':'')+'</li>';
        }).join('')+'</ul></li>';
      }).join('')+'</ol>'+ul(b.outro);
      break;
  }
  return h;
}

function nbOpenReview(docId){
  var d=window.dynamicDocs[docId];
  if(!d||!d.revision){ showDynamicDoc(docId); return; }
  var r=d.revision, el=document.getElementById('review-content');
  el.innerHTML='<div class="article-back" onclick="showDynamicDoc(\''+nbEsc(docId)+'\')">← חזרה לפריט</div>'
    +'<div class="page-header"><div class="page-title">🔎 בדיקת גרסה מוצעת</div>'
    +'<div class="page-sub">נוצרה מהמסמך '+nbSourceLink(r.source)+' ב-'+nbFmtDate(r.createdAt)+'. הנציגים ממשיכים לראות את הגרסה המפורסמת עד שתאשרו.</div></div>'
    +((r.issues||[]).length?'<div class="import-issues"><div class="ii-title">⚠ הערות מההמרה — לבדיקתך:</div><ul>'+r.issues.map(function(x){return '<li>'+nbEsc(x)+'</li>';}).join('')+'</ul></div>':'')
    +'<div class="review-actions">'
      +'<button class="nb-btn approve" onclick="nbApproveRevision(\''+nbEsc(docId)+'\')">✓ אשר ופרסם</button>'
      +'<button class="nb-btn" onclick="nbEditRevision(\''+nbEsc(docId)+'\')">✎ ערוך לפני פרסום</button>'
      +'<button class="nb-btn ghost" onclick="nbRejectRevision(\''+nbEsc(docId)+'\')">✕ דחה</button></div>'
    +'<div class="review-grid"><div class="review-col"><div class="rc-label">הגרסה המפורסמת היום</div>'+nbOutlineHTML(d)+'</div>'
    +'<div class="review-col proposed"><div class="rc-label">הגרסה המוצעת מהמסמך</div>'+nbOutlineHTML(r.item)+'</div></div>';
  nbEnhance(el.querySelector('.review-grid'));
  showView('review');
}
function nbApproveRevision(docId){
  var d=window.dynamicDocs[docId];
  if(!d||!d.revision) return;
  var r=d.revision.item;
  ['kind','topic','desc','tags','stages'].forEach(function(f){ d[f]=JSON.parse(JSON.stringify(r[f])); });
  if(r.body) d.body=JSON.parse(JSON.stringify(r.body)); else delete d.body;
  d.source=d.revision.source||d.source;
  d.status='published'; d.publishedAt=Date.now(); d.updatedAt=Date.now();
  delete d.revision;
  nbMarkLocalEdit(d,docId);
  nbSaveLibrary('אושרה ופורסמה גרסה ממסמך מקור: '+nbPlain(d.topic));
  nbRenderSidebar(); renderLibrary(nbCurrentLibCat||'all');
  showDynamicDoc(docId);
}
function nbEditRevision(docId){
  var d=window.dynamicDocs[docId];
  if(!d||!d.revision) return;
  var tmp=JSON.parse(JSON.stringify(d));
  var r=d.revision.item;
  ['kind','topic','desc','tags','stages'].forEach(function(f){ tmp[f]=JSON.parse(JSON.stringify(r[f])); });
  if(r.body) tmp.body=JSON.parse(JSON.stringify(r.body)); else delete tmp.body;
  tmp.source=d.revision.source; tmp._issues=d.revision.issues; tmp._fromRevision=true; tmp.status='published';
  nbFillForm(tmp,docId);
}
function nbRejectRevision(docId){
  var d=window.dynamicDocs[docId];
  if(!d||!d.revision) return;
  nbConfirmGeneric('דחיית הגרסה המוצעת','הגרסה המפורסמת תישאר כמו שהיא. הגרסה המוצעת תימחק (קובץ המקור נשאר בספריית המדיה).','דחה','var(--red)',function(){
    delete d.revision;
    nbMarkLocalEdit(d,docId);
    nbSaveLibrary('נדחתה גרסה מוצעת: '+nbPlain(d.topic));
    showDynamicDoc(docId);
  });
}

// ── TRACKING VIEW: the knowledge-map tracking sheet, inside the app ──
var nbTrackFilter='all';
function nbOpenTracking(){ nbRenderTracking(); showView('tracking'); }
function nbTrackRows(){
  var docs=window.dynamicDocs||{};
  var codeOf=function(d){ var m=/^\s*([A-Z]-\d{2,3})(?!\d)/.exec(nbPlain(d.topic)); return m?m[1]:''; };
  var codeNum=function(c){ return parseInt(c.slice(2),10)||0; };
  var prio={'גבוהה':0,'בינונית':1,'נמוכה':2};
  return Object.keys(docs).map(function(k){return docs[k];}).filter(Boolean).map(function(d){
    return {d:d,code:codeOf(d),title:nbPlain(d.topic).replace(/^\s*[A-Z]-\d{2,3}\s*·\s*/,''),t:d.track||{},
      topics:TOPICS.filter(function(t){return (d.topicIds||[]).indexOf(t.id)!==-1;}).map(function(t){return nbPlain(t.title);})};
  }).filter(function(r){
    var f=nbTrackFilter;
    return f==='all'||(NB_STATUSES[f]&&r.d.status===f)||(f==='gap'&&r.t.gap)||(f==='high'&&r.t.priority==='גבוהה')||(f==='review'&&r.d.revision);
  }).sort(function(a,b){
    if(!!a.code!==!!b.code) return a.code?-1:1;
    // Same order as the knowledge map: diagnosis → routes → operations → help → escalation → specialist.
    var layer='MRTOIHES', la=layer.indexOf(a.code.charAt(0)), lb=layer.indexOf(b.code.charAt(0));
    var pa=a.t.priority in prio?prio[a.t.priority]:9, pb=b.t.priority in prio?prio[b.t.priority]:9;
    return (a.code&&b.code&&((la-lb)||(codeNum(a.code)-codeNum(b.code))))||(pa-pb)||a.title.localeCompare(b.title,'he');
  });
}
function nbRenderTracking(){
  var el=document.getElementById('tracking-content');
  if(!el) return;
  var all=Object.keys(window.dynamicDocs||{}).map(function(k){return window.dynamicDocs[k];}).filter(Boolean);
  var count=function(fn){return all.filter(fn).length;};
  var chips=[['all','הכל',all.length]].concat(NB_STATUS_ORDER.map(function(s){return [s,NB_STATUSES[s].label,count(function(d){return d.status===s;})];}))
    .concat([['review','נדרשת לבדיקה',count(function(d){return !!d.revision;})],['gap','עם פער פתוח',count(function(d){return d.track&&d.track.gap;})],['high','עדיפות גבוהה',count(function(d){return d.track&&d.track.priority==='גבוהה';})]]);
  var fbAll=nbFeedbackAll();
  chips.push(['feedback','💬 משוב',fbAll.length]);
  var rows=nbTrackFilter==='feedback'?[]:nbTrackRows();
  el.innerHTML='<div class="page-header"><div class="page-title"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:-4px;margin-left:6px"><rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 12h6"/><path d="M9 16h6"/></svg>מעקב מסמכים</div>'
      +'<div class="page-sub">סטטוס, מצב התוכן ופערים לכל פריט ידע — לעורכים בלבד. לחיצה על שורה פותחת את הפריט.</div></div>'
    +'<div class="lib-filter-row">'+chips.map(function(c){
      return '<button class="filter-btn world-btn'+(nbTrackFilter===c[0]?' active':'')+'" onclick="nbTrackFilter=\''+c[0]+'\';nbRenderTracking()">'+c[1]+' <span class="chip-n">'+c[2]+'</span></button>';
    }).join('')+'<button class="filter-btn world-btn ghost" onclick="nbExportTracking()">⬇ ייצוא ל-Excel</button></div>'
    +(nbTrackFilter==='feedback'?nbFeedbackTableHTML(fbAll):rows.length?'<div class="track-table-wrap"><table class="track-table"><thead><tr>'
      +'<th>קוד</th><th>שם</th><th>סוג</th><th>נושא</th><th>סטטוס</th><th>מצב התוכן</th><th>עדיפות</th><th>פער / פעולה נדרשת</th><th>אחראי</th><th>עודכן</th></tr></thead><tbody>'
      +rows.map(function(r){
        return '<tr onclick="showDynamicDoc(\''+nbEsc(r.d.id)+'\')">'
          +'<td class="tt-code">'+nbEsc(r.code)+'</td><td class="tt-title">'+nbEsc(r.title)+'</td>'
          +'<td>'+nbKindBadge(r.d.kind,true)+'</td><td class="tt-muted">'+nbEsc(r.topics.join(', '))+'</td>'
          +'<td>'+nbStatusBadge(r.d,true)+nbReviewBadge(r.d)+'</td><td>'+nbEsc(r.t.state||'')+'</td>'
          +'<td>'+(r.t.priority?'<span class="prio prio-'+(r.t.priority==='גבוהה'?'h':r.t.priority==='בינונית'?'m':'l')+'">'+nbEsc(r.t.priority)+'</span>':'')+'</td>'
          +'<td class="tt-gap">'+nbEsc(r.t.gap||'')+'</td><td>'+nbEsc(r.d.owner||'')+'</td>'
          +'<td class="tt-muted">'+nbFmtDate(r.d.updatedAt)+'</td></tr>';
      }).join('')+'</tbody></table></div>'
      // Phones: the same rows as cards, every field on its own line.
      +'<div class="track-cards">'+rows.map(function(r){
        var prioCls=r.t.priority==='גבוהה'?'h':r.t.priority==='בינונית'?'m':'l';
        return '<div class="track-card" onclick="showDynamicDoc(\''+nbEsc(r.d.id)+'\')">'
          +'<div class="tc2-top">'+nbKindBadge(r.d.kind,true)+(r.code?'<span class="tt-code">'+nbEsc(r.code)+'</span>':'')
          +'<span class="tc2-title">'+nbEsc(r.title)+'</span></div>'
          +'<div class="tc2-badges">'+nbStatusBadge(r.d,true)+nbReviewBadge(r.d)
          +(r.t.state?'<span class="tc2-chip">'+nbEsc(r.t.state)+'</span>':'')
          +(r.t.priority?'<span class="prio prio-'+prioCls+'">עדיפות '+nbEsc(r.t.priority)+'</span>':'')+'</div>'
          +(r.t.gap?'<div class="tc2-gap"><span>פער / פעולה נדרשת</span>'+nbEsc(r.t.gap)+'</div>':'')
          +'<div class="tc2-meta">'+[r.topics.length?'נושא: '+nbEsc(r.topics.join(', ')):'',r.d.owner?'אחראי: '+nbEsc(r.d.owner):'',r.d.updatedAt?'עודכן: '+nbFmtDate(r.d.updatedAt):''].filter(Boolean).join(' · ')+'</div>'
          +'</div>';
      }).join('')+'</div>'
      :'<div class="empty-state">אין פריטים בסינון הזה</div>');
}
// The "משוב" tab: everything agents sent with "דיווח על בעיה / משוב", newest
// first, in the same table style. Editors mark each one as handled.
function nbFeedbackRows(all){
  return all.map(function(f,i){
    var d=window.dynamicDocs[f.docId], st=nbSplitTitle(d?d.topic:f.title);
    return {f:f,i:i,d:d,code:st.code,title:st.title};
  }).reverse();
}
function nbFeedbackTableHTML(all){
  var rows=nbFeedbackRows(all);
  if(!rows.length) return '<div class="empty-state">עדיין לא התקבל משוב מנציגים. משוב נשלח מכפתור "דיווח על בעיה / משוב" בתחתית כל פריט.</div>';
  var open=function(r){ return r.d?' onclick="showDynamicDoc(\''+nbEsc(r.d.id)+'\')"':''; };
  var done=function(r){
    return '<button type="button" class="fb-state'+(r.f.done?' done':'')+'" onclick="event.stopPropagation();nbToggleFeedbackDone('+r.i+')" title="'+(r.f.done?'סמן כפתוח':'סמן כטופל')+'">'+(r.f.done?'✓ טופל':'חדש')+'</button>';
  };
  var version=function(r){ return r.f.version?nbFmtDate(r.f.version):''; };
  return '<div class="track-table-wrap"><table class="track-table"><thead><tr>'
      +'<th>התקבל</th><th>קוד</th><th>פריט</th><th>סוג</th><th>משוב</th><th>גרסה שנקראה</th><th>טיפול</th></tr></thead><tbody>'
      +rows.map(function(r){
        return '<tr'+open(r)+(r.f.done?' class="fb-done"':'')+'>'
          +'<td class="tt-muted">'+nbFmtDate(r.f.at)+'</td><td class="tt-code">'+nbEsc(r.code)+'</td>'
          +'<td class="tt-title">'+nbEsc(r.title)+(r.d?'':' <span class="tt-muted">(הפריט נמחק)</span>')+'</td>'
          +'<td>'+(r.d?nbKindBadge(r.d.kind,true):'')+'</td>'
          +'<td class="tt-gap fb-text">'+nbEsc(r.f.text)+'</td>'
          +'<td class="tt-muted">'+version(r)+'</td><td>'+done(r)+'</td></tr>';
      }).join('')+'</tbody></table></div>'
    +'<div class="track-cards">'+rows.map(function(r){
      return '<div class="track-card'+(r.f.done?' fb-done':'')+'"'+open(r)+'>'
        +'<div class="tc2-top">'+(r.d?nbKindBadge(r.d.kind,true):'')+(r.code?'<span class="tt-code">'+nbEsc(r.code)+'</span>':'')
        +'<span class="tc2-title">'+nbEsc(r.title)+'</span></div>'
        +'<div class="tc2-gap"><span>משוב</span>'+nbEsc(r.f.text)+'</div>'
        +'<div class="tc2-meta">'+['התקבל: '+nbFmtDate(r.f.at),r.f.version?'גרסה שנקראה: '+version(r):''].filter(Boolean).join(' · ')+'</div>'
        +'<div class="tc2-badges">'+done(r)+'</div>'
        +'</div>';
    }).join('')+'</div>';
}
function nbToggleFeedbackDone(i){
  var all=nbFeedbackAll();
  if(!all[i]) return;
  all[i].done=!all[i].done;
  try{ localStorage.setItem(NB_FEEDBACK_KEY,JSON.stringify(all)); }catch(e){}
  nbRenderTracking();
}
// Download the tracking table (or, in the "משוב" tab, the feedback) as a CSV
// that Excel opens (UTF-8 with BOM, Hebrew safe).
function nbExportTracking(){
  var q=function(v){ v=String(v==null?'':v); return /[",\n]/.test(v)?'"'+v.replace(/"/g,'""')+'"':v; };
  var fb=nbTrackFilter==='feedback', head, body;
  if(fb){
    head=['התקבל','קוד','פריט','סוג','משוב','גרסה שנקראה','טיפול'];
    body=nbFeedbackRows(nbFeedbackAll()).map(function(r){
      return [nbFmtDate(r.f.at),r.code,r.title,r.d?(NB_KINDS[r.d.kind]||{}).full:'',r.f.text,r.f.version?nbFmtDate(r.f.version):'',r.f.done?'טופל':'חדש'].map(q).join(',');
    });
  } else {
    head=['קוד','שם','סוג','נושא','סטטוס','מצב התוכן','עדיפות','פער / פעולה נדרשת','מקור ידע','אחראי','פורסם','עודכן'];
    body=nbTrackRows().map(function(r){
      return [r.code,r.title,(NB_KINDS[r.d.kind]||{}).full,r.topics.join('; '),NB_STATUSES[r.d.status].label,r.t.state,r.t.priority,r.t.gap,r.t.source,r.d.owner,nbFmtDate(r.d.publishedAt),nbFmtDate(r.d.updatedAt)].map(q).join(',');
    });
  }
  var lines=[head.join(',')].concat(body);
  var a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob(['﻿'+lines.join('\r\n')],{type:'text/csv;charset=utf-8'}));
  a.download=fb?'משוב-מנציגים.csv':'מעקב-מסמכים.csv';
  document.body.appendChild(a); a.click(); a.remove();
}

function nbStatusNote(d){
  return (d&&d.status!=='published')?' (נשמר בסטטוס "'+NB_STATUSES[d.status].label+'" — לא מוצג לנציגים עד לפרסום)':'';
}

function nbSetStatus(docId,status){
  var d=window.dynamicDocs[docId];
  if(!d||!NB_STATUSES[status]||d.status===status) return;
  var old=d.status;
  d.status=status;
  if(status==='published') d.publishedAt=Date.now();
  d.updatedAt=Date.now();
  nbSaveLibrary('סטטוס: '+nbPlain(d.topic)+' — '+NB_STATUSES[old].label+' ← '+NB_STATUSES[status].label);
  nbRenderSidebar();
  renderLibrary(nbCurrentLibCat||'all');
  showDynamicDoc(docId);
}
// Back from an item returns to the topic it was opened from.
function nbSetBack(sel,doc){
  var back=document.querySelector(sel);
  if(!back) return;
  var tid=(nbCurrentTopicId!=null&&doc.topicIds.indexOf(nbCurrentTopicId)!==-1)?nbCurrentTopicId:doc.topicIds[0];
  var t=TOPICS.find(function(x){return x.id===tid;});
  if(t){ back.setAttribute('onclick','nbOpenTopic('+t.id+')'); back.textContent='← חזרה לנושא: '+t.title.replace(/<[^>]*>/g,''); }
  else { back.setAttribute('onclick',"showView('library')"); back.textContent='← חזרה לספרייה'; }
}

function showDynamicDoc(docId){
  var doc=window.dynamicDocs[docId];
  if(!doc||!nbVisible(doc)) return;
  nbRecordRecentItem(docId);
  if(doc._isViewDoc){
    // Hand-designed documents: keep their own page, add the shared header strip.
    var strip=document.getElementById('special-strip-'+doc._isViewDoc);
    if(strip) strip.innerHTML=nbSiblingStripHTML(doc)+'<div class="special-meta">'+nbItemMetaHTML(doc)+nbItemFieldsHTML(doc)+'</div>';
    showView(doc._isViewDoc);
    nbSetBack('#view-'+doc._isViewDoc+' .article-back',doc);
    return;
  }

  var hasStageTitles=doc.stages.some(function(s){return nbStageNum(s.title);});
  var stagesHtml=doc.stages.map(function(s){
    var items=s.items.map(function(item){
      var txt=typeof item==='object'?item.text:item;
      var img=typeof item==='object'?item.img:null;
      return '<div class="step-card fade-in">'
        +'<div class="step-num" style="background:var(--navy);width:20px;height:20px;font-size:10px">›</div>'
        +'<div class="step-content" style="margin-top:0">'
        +'<div class="action-list" style="margin-top:0"><div class="action-item"><span class="ai-icon">›</span>'+txt+'</div></div>'
        +'</div></div>'
        +(img?'<div style="margin:6px 0 10px 0"><img src="'+img+'" onclick="event.stopPropagation();nbOpenLightbox(this.src)" style="max-width:100%;max-height:240px;width:auto;border-radius:8px;border:1px solid var(--border);display:block;cursor:zoom-in"></div>':'');
    }).join('');

    var stageImgHtml=(s.images&&s.images.length)?s.images.map(function(img){
      return '<div style="margin:8px 0;width:100%"><img src="'+img+'" onclick="event.stopPropagation();nbOpenLightbox(this.src)" style="width:100%;max-height:400px;object-fit:contain;border-radius:8px;border:1px solid var(--border);background:#f9f9f9;display:block;cursor:zoom-in"></div>';
    }).join(''):'';
    // When the source numbers its stages in the titles ("שלב 2 - …"), only those are stages to jump to.
    var stageNo=hasStageTitles?nbStageNum(s.title):s.num;
    return '<div class="step-card fade-in" style="margin-bottom:4px"'+(stageNo?' data-stage="'+stageNo+'"':'')+'>'
      +'<div class="step-num red">'+s.num+'</div>'
      +'<div class="step-content">'
      +'<div class="step-title">'+s.title+'</div>'
      +'</div></div>'
      +'<div style="padding-right:52px;margin-bottom:16px">'+items+stageImgHtml+'</div>';
  }).join('');

  // R / S (and any item still in plain stages): numbered units the agent opens and closes.
  var kindHtml=nbKindBodyHTML(doc);
  if(kindHtml==null&&doc.stages.length) kindHtml=nbStagesViewHTML(doc);
  var html=nbSiblingStripHTML(doc)
    +'<div class="article-box">'
    +nbViewHeadHTML(doc)
    +'<div class="article-body">'
    +'<div class="av-toolbar" id="av-toolbar"></div>'
    +(kindHtml!=null?kindHtml:(doc.stages.length?stagesHtml:'<div class="info-box">לא נבחרו שלבים לפריט הידע זה.</div>'))
    +nbFeedbackRowHTML(doc)
    +'</div></div>';

  document.getElementById('article-content').innerHTML=html;
  window.nbShownDocId=doc.id; // an item's own code is not linked
  var body=document.querySelector('#article-content .article-body');
  // Section cards take the item type's color on their edge (as M steps do).
  body.style.setProperty('--kc',(NB_KINDS[doc.kind]||NB_KINDS.R).color);
  nbEnhance(body);
  // In a handling item (R) a referral stays one sentence with the target as a link in it;
  // the other types show referrals as boxes.
  if(doc.kind!=='R') nbRefRows(body);
  nbBuildToolbar(body);

  // Add "עדכן מסמך" button
  var btnRow=document.createElement('div');
  btnRow.className='nb-edit-only'; // hidden for read-only users in the WordPress version
  btnRow.style.cssText='display:flex;flex-wrap:wrap;gap:10px;margin:16px 0 0;max-width:680px';

  var updateBtn=document.createElement('button');
  updateBtn.style.cssText='flex:1 1 170px;height:40px;padding:0 22px;background:var(--navy);color:#fff;border:none;border-radius:var(--rs);font-size:13.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
  updateBtn.textContent='✏️ עדכן פריט ידע';
  updateBtn.addEventListener('click',function(){ nbEditDoc(docId); });

  var deleteBtn=document.createElement('button');
  deleteBtn.style.cssText='flex:1 1 170px;height:40px;padding:0 22px;background:#fff;color:var(--red);border:2px solid var(--red);border-radius:var(--rs);font-size:13.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
  deleteBtn.textContent='🗑 מחק פריט ידע';
  deleteBtn.addEventListener('click',function(){ nbConfirmDeleteDoc(docId,doc.topic); });

  btnRow.appendChild(updateBtn);
  if(typeof window.nbImportSourceDoc==='function'&&window.NB_CAN_IMPORT){
    var uploadBtn=document.createElement('button');
    uploadBtn.style.cssText='flex:1 1 170px;height:40px;padding:0 14px;background:#fff;color:var(--navy);border:1.5px solid var(--border-strong);border-radius:var(--rs);font-size:13.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
    uploadBtn.textContent='📄 העלה טיוטה';
    uploadBtn.title='העלאת Word, PNG או PDF כגרסה מוצעת לבדיקה';
    uploadBtn.addEventListener('click',function(){ nbStartSourceUpdate(docId); });
    btnRow.appendChild(uploadBtn);
  }
  btnRow.appendChild(deleteBtn);
  document.getElementById('article-content').appendChild(btnRow);

  showView('article');
  nbSetBack('#view-article .article-back',doc);
}

// ── IMAGE LIGHTBOX ───────────────────────────────────────────────────────
// Full-screen viewer for attached images, behaving like the iOS Photos app:
// pinch to zoom, double-tap/double-click to zoom, drag to pan once zoomed,
// mouse wheel to zoom on desktop, tap outside (or on an unzoomed image) to
// dismiss.
function nbMakeZoomable(imgEl){
  if(!imgEl) return;
  imgEl.style.cursor='zoom-in';
  imgEl.addEventListener('click',function(e){
    e.stopPropagation();
    nbOpenLightbox(imgEl.src);
  });
}

function nbOpenLightbox(src){
  var overlay=document.getElementById('nb-lightbox-overlay');
  if(!overlay){
    overlay=document.createElement('div');
    overlay.id='nb-lightbox-overlay';
    overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:99999;display:flex;align-items:center;justify-content:center;overflow:hidden;touch-action:none';

    var img=document.createElement('img');
    img.id='nb-lightbox-img';
    img.style.cssText='max-width:92vw;max-height:92vh;transform-origin:center center;user-select:none;-webkit-user-drag:none;touch-action:none;will-change:transform;cursor:zoom-out';
    img.draggable=false;

    var closeBtn=document.createElement('button');
    closeBtn.textContent='✕';
    closeBtn.title='סגור';
    closeBtn.style.cssText='position:absolute;top:16px;left:16px;width:40px;height:40px;border-radius:50%;background:rgba(255,255,255,.12);border:none;color:#fff;font-size:16px;cursor:pointer;z-index:2';
    closeBtn.addEventListener('click',function(e){ e.stopPropagation(); nbCloseLightbox(); });

    var hint=document.createElement('div');
    hint.textContent='גע פעמיים או צבוט כדי להתקרב';
    hint.style.cssText='position:absolute;bottom:18px;left:0;right:0;text-align:center;color:rgba(255,255,255,.55);font-size:12px;font-family:Rubik,sans-serif;pointer-events:none';

    overlay.appendChild(img);
    overlay.appendChild(closeBtn);
    overlay.appendChild(hint);
    document.body.appendChild(overlay);

    var scale=1,tx=0,ty=0;
    var pointers={};
    var lastDist=0,isPanning=false,panStart=null,startTx=0,startTy=0;

    function applyTransform(){ img.style.transform='translate('+tx+'px,'+ty+'px) scale('+scale+')'; }
    function clampScale(s){ return Math.min(Math.max(s,1),5); }
    function resetTransform(){ scale=1;tx=0;ty=0;applyTransform(); }
    overlay._reset=resetTransform;

    img.addEventListener('pointerdown',function(e){
      try{ img.setPointerCapture(e.pointerId); }catch(err){}
      pointers[e.pointerId]={x:e.clientX,y:e.clientY};
      var ids=Object.keys(pointers);
      if(ids.length===1){
        isPanning=true;
        panStart={x:e.clientX,y:e.clientY};
        startTx=tx;startTy=ty;
      } else if(ids.length===2){
        isPanning=false;
        var pts=ids.map(function(id){return pointers[id];});
        lastDist=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);
      }
    });
    img.addEventListener('pointermove',function(e){
      if(!pointers[e.pointerId]) return;
      pointers[e.pointerId]={x:e.clientX,y:e.clientY};
      var ids=Object.keys(pointers);
      if(ids.length===1&&isPanning&&scale>1){
        tx=startTx+(e.clientX-panStart.x);
        ty=startTy+(e.clientY-panStart.y);
        applyTransform();
      } else if(ids.length===2){
        var pts=ids.map(function(id){return pointers[id];});
        var dist=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);
        if(lastDist>0){ scale=clampScale(scale*(dist/lastDist)); }
        lastDist=dist;
        applyTransform();
      }
    });
    function endPointer(e){
      delete pointers[e.pointerId];
      var ids=Object.keys(pointers);
      if(ids.length<2) lastDist=0;
      if(ids.length===0){ isPanning=false; if(scale<1.02) resetTransform(); }
    }
    img.addEventListener('pointerup',endPointer);
    img.addEventListener('pointercancel',endPointer);

    img.addEventListener('dblclick',function(e){
      e.stopPropagation();
      if(scale>1){ resetTransform(); } else { scale=2.5; applyTransform(); }
    });

    overlay.addEventListener('wheel',function(e){
      e.preventDefault();
      var delta=-e.deltaY*0.0015;
      scale=clampScale(scale+delta*scale);
      if(scale<=1) resetTransform(); else applyTransform();
    },{passive:false});

    overlay.addEventListener('click',function(e){
      if(e.target===overlay) nbCloseLightbox();
    });
    img.addEventListener('click',function(e){
      e.stopPropagation();
      if(scale<=1) nbCloseLightbox();
    });

    document.addEventListener('keydown',function(e){
      if(overlay.style.display==='flex'&&e.key==='Escape') nbCloseLightbox();
    });
  }
  var imgEl=document.getElementById('nb-lightbox-img');
  imgEl.src=src;
  if(overlay._reset) overlay._reset();
  overlay.style.display='flex';
  document.body.style.overflow='hidden';
}

function nbCloseLightbox(){
  var overlay=document.getElementById('nb-lightbox-overlay');
  if(overlay) overlay.style.display='none';
  document.body.style.overflow='';
}

function nbConfirmGeneric(title,messageHtml,confirmText,confirmColor,onConfirm){
  var overlay=document.createElement('div');
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:flex;align-items:center;justify-content:center';

  var modal=document.createElement('div');
  modal.style.cssText='background:#fff;border-radius:16px;padding:28px 24px;max-width:340px;width:90%;font-family:Rubik,sans-serif;direction:rtl;text-align:center';

  var titleEl=document.createElement('div');
  titleEl.style.cssText='font-size:16px;font-weight:700;color:var(--navy);margin-bottom:10px';
  titleEl.textContent=title;

  var msg=document.createElement('div');
  msg.style.cssText='font-size:14px;color:var(--muted);margin-bottom:24px;line-height:1.6';
  msg.innerHTML=messageHtml;

  var btns=document.createElement('div');
  btns.style.cssText='display:flex;gap:10px';

  var yesBtn=document.createElement('button');
  yesBtn.style.cssText='flex:1;height:40px;background:'+confirmColor+';color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
  yesBtn.textContent=confirmText;
  yesBtn.addEventListener('click',function(){ overlay.remove(); onConfirm(); });

  var noBtn=document.createElement('button');
  noBtn.style.cssText='flex:1;height:40px;background:#fff;color:var(--navy);border:2px solid var(--border);border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
  noBtn.textContent='ביטול';
  noBtn.addEventListener('click',function(){ overlay.remove(); });

  btns.appendChild(yesBtn);
  btns.appendChild(noBtn);
  modal.appendChild(titleEl);
  modal.appendChild(msg);
  modal.appendChild(btns);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

function nbConfirmDelete(topicTitle,onConfirm){
  // Build custom confirm modal
  var overlay=document.createElement('div');
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:flex;align-items:center;justify-content:center';

  var modal=document.createElement('div');
  modal.style.cssText='background:#fff;border-radius:16px;padding:28px 24px;max-width:320px;width:90%;font-family:Rubik,sans-serif;direction:rtl;text-align:center';

  var title=document.createElement('div');
  title.style.cssText='font-size:16px;font-weight:700;color:var(--navy);margin-bottom:10px';
  title.textContent='מחיקת פריט ידע';

  var msg=document.createElement('div');
  msg.style.cssText='font-size:14px;color:var(--muted);margin-bottom:24px;line-height:1.6';
  msg.innerHTML='האם ברצונך למחוק את פריט הידע<br><strong style="color:var(--navy)">'+topicTitle+'</strong>?';

  var btns=document.createElement('div');
  btns.style.cssText='display:flex;gap:10px';

  var yesBtn=document.createElement('button');
  yesBtn.style.cssText='flex:1;height:40px;background:var(--red);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
  yesBtn.textContent='כן, מחק';
  yesBtn.addEventListener('click',function(){ overlay.remove(); onConfirm(); });

  var noBtn=document.createElement('button');
  noBtn.style.cssText='flex:1;height:40px;background:#fff;color:var(--navy);border:2px solid var(--border);border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif';
  noBtn.textContent='לא, ביטול';
  noBtn.addEventListener('click',function(){ overlay.remove(); });

  btns.appendChild(yesBtn);
  btns.appendChild(noBtn);
  modal.appendChild(title);
  modal.appendChild(msg);
  modal.appendChild(btns);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

// ── TRASH (soft delete) ──────────────────────────────────────────────────
// Deleted items are snapshotted here instead of being destroyed, so they
// can be restored later. Persisted alongside the rest of the library.
var nbTrash=[];

function nbUpdateTrashBadge(){
  var badge=document.getElementById('nb-trash-count-nav');
  if(!badge) return;
  if(nbTrash.length){ badge.textContent=nbTrash.length; badge.style.display='inline-block'; }
  else{ badge.style.display='none'; }
}

function nbConfirmDeleteDoc(docId,topicTitle){
  nbConfirmDelete(topicTitle,function(){
    var doc=window.dynamicDocs[docId];
    // The item keeps its own topic links (doc.topicIds); the topics stay in
    // the library. Snapshots of the topics are kept in case they're gone by
    // the time the item is restored.
    var linkedTopics=doc?TOPICS.filter(function(x){return doc.topicIds.indexOf(x.id)!==-1;}):[];
    nbTrash.push({
      trashId:'trash-'+Date.now()+'-'+Math.floor(Math.random()*10000),
      type:'doc',
      docId:docId,
      doc:doc?JSON.parse(JSON.stringify(doc)):null,
      topicSnapshots:JSON.parse(JSON.stringify(linkedTopics)),
      title:topicTitle,
      deletedAt:Date.now()
    });
    delete window.dynamicDocs[docId];
    nbRenderSidebar();
    renderLibrary(nbCurrentLibCat||'all');
    if(linkedTopics.length) nbOpenTopic(linkedTopics[0].id); else showView('library');
    nbSaveLibrary('נמחק: '+topicTitle);
    nbUpdateTrashBadge();
  });
}

// Handles delete clicks from any card — active items with a real doc behind
// them go through nbConfirmDeleteDoc; placeholder (non-active) topics that
// have no content yet are simply removed from the list.
function nbConfirmDeleteTopic(topicId){
  var t=TOPICS.find(function(x){return x.id===topicId;});
  if(!t) return;
  var items=nbTopicItems(t.id);
  if(items.length){
    nbConfirmGeneric('לא ניתן למחוק את הנושא',
      'בנושא <strong style="color:var(--navy)">'+t.title+'</strong> יש '+items.length+' פריטי ידע. כדי לא לאבד ידע, יש למחוק את הפריטים או לשייך אותם לנושא אחר לפני מחיקת הנושא.',
      'פתח את הנושא','var(--navy)',function(){ nbOpenTopic(t.id); });
    return;
  }
  nbConfirmDelete(t.title,function(){
    nbTrash.push({
      trashId:'trash-'+Date.now()+'-'+Math.floor(Math.random()*10000),
      type:'topic',
      doc:null,
      topicSnapshot:JSON.parse(JSON.stringify(t)),
      wasPlaceholderTopic:true,
      title:t.title,
      deletedAt:Date.now()
    });
    var idx=TOPICS.indexOf(t);
    if(idx>-1) TOPICS.splice(idx,1);
    nbRenderSidebar();
    renderLibrary(nbCurrentLibCat||'all');
    nbSaveLibrary('נמחק: '+t.title);
    nbUpdateTrashBadge();
  });
}

function nbRestoreFromTrash(trashId){
  var idx=nbTrash.findIndex(function(x){return x.trashId===trashId;});
  if(idx===-1) return;
  var entry=nbTrash[idx];
  if(entry.type==='doc'&&entry.doc){
    window.dynamicDocs=window.dynamicDocs||{};
    var doc=entry.doc;
    var snapshots=(entry.topicSnapshots&&entry.topicSnapshots.length)?entry.topicSnapshots:(entry.topicSnapshot?[entry.topicSnapshot]:[]);
    // Items deleted before the restructure have no topicIds of their own.
    if(!doc.topicIds||!doc.topicIds.length) doc.topicIds=snapshots.map(function(s){return s.id;});
    // Bring back any of its topics that were deleted in the meantime.
    snapshots.forEach(function(snap){
      if(!TOPICS.some(function(x){return x.id===snap.id;})) TOPICS.push(JSON.parse(JSON.stringify(snap)));
    });
    window.dynamicDocs[entry.docId]=doc;
    nbNormalizeModel();
  } else if(entry.type==='topic'&&entry.topicSnapshot){
    if(!TOPICS.some(function(x){return x.id===entry.topicSnapshot.id;})) TOPICS.push(entry.topicSnapshot);
    nbNormalizeModel();
  }
  nbTrash.splice(idx,1);
  nbRenderSidebar();
  renderLibrary(nbCurrentLibCat||'all');
  nbSaveLibrary('שוחזר מסל מיחזור: '+entry.title);
  nbUpdateTrashBadge();
  nbOpenTrash();
}

function nbPermanentlyDeleteFromTrash(trashId){
  var idx=nbTrash.findIndex(function(x){return x.trashId===trashId;});
  if(idx===-1) return;
  if(nbWasPublished(nbTrash[idx].doc)) return; // spec §10: published items are kept for history
  nbTrash.splice(idx,1);
  nbSaveLibrary('נמחק לצמיתות מסל המיחזור');
  nbUpdateTrashBadge();
  nbOpenTrash();
}

function nbOpenTrash(){
  var existing=document.getElementById('nb-trash-overlay');
  if(existing) existing.remove();

  var overlay=document.createElement('div');
  overlay.id='nb-trash-overlay';
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px';

  var modal=document.createElement('div');
  modal.style.cssText='background:#fff;border-radius:16px;padding:22px;max-width:480px;width:100%;max-height:80vh;overflow-y:auto;font-family:Rubik,sans-serif;direction:rtl';

  var head=document.createElement('div');
  head.style.cssText='display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid var(--border)';
  head.innerHTML='<div style="font-size:16px;font-weight:700;color:var(--navy)"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:-3px;margin-left:6px"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>סל מיחזור</div>';

  var headBtns=document.createElement('div');
  headBtns.style.cssText='display:flex;align-items:center;gap:4px';

  var historyBtn=document.createElement('button');
  historyBtn.innerHTML='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:-2px;margin-left:4px"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 3"/></svg>היסטוריה';
  historyBtn.style.cssText='background:none;border:1px solid var(--border);border-radius:20px;font-size:11.5px;color:var(--muted);cursor:pointer;padding:5px 10px;font-family:Rubik,sans-serif';
  historyBtn.addEventListener('click',function(){ overlay.remove(); nbOpenHistory(); });
  headBtns.appendChild(historyBtn);

  var closeBtn=document.createElement('button');
  closeBtn.textContent='✕';
  closeBtn.style.cssText='background:none;border:none;font-size:16px;color:var(--muted);cursor:pointer;padding:4px 8px';
  closeBtn.addEventListener('click',function(){ overlay.remove(); });
  headBtns.appendChild(closeBtn);
  head.appendChild(headBtns);

  var list=document.createElement('div');
  if(!nbTrash.length){
    list.innerHTML='<div style="text-align:center;color:var(--muted);font-size:13.5px;padding:30px 10px">סל המיחזור ריק</div>';
  } else {
    list.innerHTML=nbTrash.slice().reverse().map(function(entry){
      var d=new Date(entry.deletedAt);
      var dateStr=d.toLocaleDateString('he-IL')+' '+d.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
      return '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 4px;border-bottom:1px solid var(--border)">'
        +'<div style="min-width:0"><div style="font-size:13.5px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+entry.title+'</div>'
        +'<div style="font-size:11.5px;color:var(--muted);margin-top:2px">נמחק ב-'+dateStr+'</div></div>'
        +'<div style="display:flex;gap:6px;flex-shrink:0">'
        +'<button onclick="nbRestoreFromTrash(\''+entry.trashId+'\')" style="height:32px;padding:0 12px;background:var(--navy);color:#fff;border:none;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif">↩️ שחזר</button>'
        +(nbWasPublished(entry.doc)
          ?'<span title="פריט שפורסם לא נמחק לצמיתות. אפשר לשחזר אותו ולהעביר לסטטוס \'ארכיון\' או \'לא בתוקף\'" style="font-size:11px;color:var(--muted);align-self:center;max-width:110px;line-height:1.3">פורסם בעבר — נשמר לתיעוד</span>'
          :'<button onclick="nbPermanentlyDeleteFromTrash(\''+entry.trashId+'\')" style="height:32px;padding:0 12px;background:#fff;color:var(--red);border:1.5px solid var(--red);border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif">מחק לצמיתות</button>')
        +'</div></div>';
    }).join('');
  }

  modal.appendChild(head);
  modal.appendChild(list);
  overlay.appendChild(modal);
  overlay.addEventListener('click',function(e){ if(e.target===overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function nbEditDoc(docId){
  try{
    nbEditDocImpl(docId);
  }catch(e){
    console.error('nbEditDoc failed:', e);
    alert('אירעה שגיאה בפתיחת פריט הידע לעריכה: '+e.message+'\n\nנסה לרענן את הדף (ייתכן שנטענת גרסה ישנה מהמטמון של הדפדפן).');
  }
}

function nbEditDocImpl(docId){
  var doc=window.dynamicDocs[docId];
  if(!doc) return;
  nbFillForm(doc,docId);
}

// Loads an item into the "פריט ידע חדש" form. editingId: the item being
// edited, or null for a new item (e.g. a draft converted from a source document).
function nbFillForm(doc,editingId){
  // Reset form state
  NB_STAGES.forEach(function(s){ nbState[s.id]={picked:[],custom:[],applied:false,s1data:{}}; }); nbState._bodies={};
  nbCustomStages=[];
  nbStageOrder=['s1'];

  // Restore s1 data
  nbState['s1'].s1data={topic:doc.topic,desc:doc.desc||'',kind:doc.kind,worlds:(doc.worlds||[]).slice(),
    tags:(doc.tags||[]).join(', '),owner:doc.owner||'',topicId:doc.topicIds&&doc.topicIds.length?String(doc.topicIds[0]):'',cat:doc.cat,
    status:doc.status,trackState:(doc.track||{}).state||'',trackPriority:(doc.track||{}).priority||'',trackGap:(doc.track||{}).gap||'',trackSource:(doc.track||{}).source||'',
    source:doc.source||null,issues:doc._issues||null,fromRevision:!!doc._fromRevision};
  // Typed items: load their content (or a conversion of their old steps) into the editor.
  nbState._bodies={};
  if(!nbIsStageKind(doc.kind)) nbState._bodies[doc.kind]=nbBodyForEditor(doc);
  nbState['s1'].applied=true;

  // Restore stage selections (rebuilding any custom, user-created stages
  // that don't match one of the fixed NB_STAGES definitions), preserving
  // the order the stages were saved in
  (doc.stages||[]).forEach(function(savedStage){
    // Only a stable stage id is trustworthy for matching. "num" alone is NOT
    // reliable: built-in knowledge items number their own content stages
    // starting at "1", which would otherwise collide with Stage 1's num
    // ("1") and duplicate the identification-fields stage on every edit.
    var def=savedStage.id ? NB_STAGES.filter(function(x){return x.id===savedStage.id;})[0] : null;
    if(!def){
      nbCustomStageSeq++;
      var newId=savedStage.id||('cs'+nbCustomStageSeq);
      def={id:newId,num:savedStage.num,req:false,title:savedStage.title,sub:'שלב מותאם אישית',options:[],ph:'הקלד שאלה / פריט...',custom_stage:true};
      nbCustomStages.push(def);
      nbState[def.id]={picked:[],custom:[],applied:false,s1data:{},images:{}};
    }
    nbStageOrder.push(def.id);
    savedStage.items.forEach(function(item){
      var txt=typeof item==='object'?item.text:item;
      var img=typeof item==='object'?item.img:null;
      var optIdx=def.options?def.options.findIndex(function(o){return o.text===txt;}):-1;
      if(optIdx>=0){
        nbState[def.id].picked.push(optIdx);
        if(img){if(!nbState[def.id].images)nbState[def.id].images={};nbState[def.id].images[optIdx]=img;}
      } else {
        nbState[def.id].custom.push(txt);
      }
    });
    if(nbState[def.id].picked.length+nbState[def.id].custom.length>0)
      nbState[def.id].applied=true;
  });

  // Store docId being edited
  window.nbEditingDocId=editingId||null;

  showView('new');
  nbRender();
  nbRenderImportBox();

  // Scroll to top
  window.scrollTo(0,0);

  // Change the "צור" button label to "עדכן"
  setTimeout(function(){
    var sumBox=document.getElementById('nb-summary');
    if(sumBox){
      var createBtn=sumBox.querySelector('button');
      if(createBtn) createBtn.textContent=editingId?'💾 שמור שינויים':'✚ צור פריט ידע חדש';
    }
    nbUpdateSummary();
  }, 100);
}

function catLabel(cat){
  return CAT[cat]||'📄 כללי';
}

function nbExport(){
  var out={};
  nbGetStageOrder().forEach(function(sid){
    if(!nbState[sid].applied) return;
    var def=nbGetAllStages().filter(function(x){return x.id===sid;})[0];
    if(!def) return;
    var st=nbState[sid];
    out['שלב '+nbContentNum(sid)+' – '+def.title]=sid==='s1'?st.s1data:st.picked.map(function(i){return def.options[i].text;}).concat(st.custom);
  });
  var a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([JSON.stringify(out,null,2)],{type:'application/json'}));
  a.download='תדריך-חדש.json';a.click();
}

function nbInit(){
  NB_STAGES.forEach(function(s){nbState[s.id]={picked:[],custom:[],applied:false,s1data:{},images:{}};}); nbState._bodies={};
  nbCustomStages=[];
  nbStageOrder=[];
  nbRender();
}

function nbGoNew(){ nbNewItem(); }

function initObservers(){
  // event delegation for dynamically created buttons
  document.addEventListener('click', function(e){
    var btn=e.target.closest('[data-action="new"]');if(btn) nbNewItem();
  });

  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){
        e.target.querySelectorAll('.fade-in:not(.visible)').forEach(function(el,i){setTimeout(function(){el.classList.add('visible')},i*55)});
        obs.unobserve(e.target);
      }
    });
  },{threshold:0.05});
  document.querySelectorAll('.view').forEach(function(v){obs.observe(v)});
}

var NB_STAGES = [
  {id:'s1',num:'1',req:true,title:'זיהוי ותיאור פריט הידע',sub:'שם, נושא, סוג, עולם תוכן, תגיות, אחראי',type:'fields'},
  {id:'s2',num:'2',req:true,title:'שאלות בירור ראשוניות',sub:'מהות, משך, מיקום',options:[
    {text:'מה בדיוק לא עובד?',hint:'→ מכווין למסלול הנכון'},
    {text:'מתי זה התחיל?',hint:'→ נקודתי vs מתמשך'},
    {text:'זה בכל מקום או רק כאן?',hint:'→ כיסוי vs תקלת מכשיר'},
    {text:'כמה זמן הבעיה קיימת?',hint:'→ דחיפות הטיפול'},
    {text:'האם זה קרה בעבר?',hint:'→ תבנית חוזרת'},
    {text:'מה גרם לזה לדעתך?',hint:'→ context ראשוני'},
  ],ph:'לדוגמה: איזה מכשיר יש לך?'},
  {id:'s3',num:'3',req:true,title:'בדיקות מערכות פנימיות',sub:'CRM, חבילה, אנטנות – ללא לקוח',options:[
    {text:'בדיקת שדה "גלישה בארץ" ב-CRM',hint:'חסום / פעיל'},
    {text:'בדיקת ניצול חבילת גלישה',hint:'אזור אישי ← השימושים שלי'},
    {text:'בדיקת Prepaid / חשד הונאה',hint:'אם כן → פנייה ל-IT'},
    {text:'בדיקת כיסוי אנטנות באזור',hint:'אם אין → תסריט פריסת רשת'},
    {text:'בדיקת תלונות אזוריות',hint:'עוד לקוחות מדווחים?'},
    {text:'בדיקת סטטוס SIM במערכת',hint:'פעיל / חסום / לא מוגדר'},
    {text:'בדיקת חוב פתוח',hint:'חסימה בגלל חוב?'},
  ],ph:'לדוגמה: בדיקת לוג שיחות אחרון'},
  {id:'s4',num:'4',req:false,title:'פעולות בטלפון / מכשיר הלקוח',sub:'הגדרות שהלקוח מבצע',options:[
    {text:'נתונים סלולריים – אם כבוי → להדליק'},
    {text:'Wi-Fi – אם דולק → לכבות'},
    {text:'נקודת גישה אישית – לכבות'},
    {text:'VPN / חוסך נתונים – לכבות'},
    {text:'אפליקציות סינון – להסיר'},
    {text:'סימון רשת → שנה ל-4G/5G אוטומטי'},
    {text:'APN → הגדרה נכונה ל-WE'},
    {text:'איפוס הגדרות רשת'},
    {text:'כיבוי והדלקת מכשיר'},
  ],ph:'לדוגמה: בדיקת עדכון מערכת הפעלה'},
  {id:'s5',num:'5',req:false,title:'פעולות מערכת מצד הנציג',sub:'ריענון, SIM, CRM',options:[
    {text:'ריענון גלישה – מתג "גלישה בארץ" כבה/הפעל'},
    {text:'ריענון SIM – sim block lbl → sim allow lbl'},
    {text:'פתיחת פנייה ל-IT'},
    {text:'פתיחת טופס רדיו + GNETRUCK'},
    {text:'עדכון APN במערכת'},
    {text:'ביצוע זיכוי / החזר'},
    {text:'שינוי מסלול / חבילה'},
  ],ph:'לדוגמה: שליחת SMS מאומת ללקוח'},
  {id:'s6',num:'6',req:false,title:'בדיקת תקינות',sub:'אימות לפני סגירה',options:[
    {text:'Speedtest – מעל 6 מגה = תקין'},
    {text:'SIM במכשיר אחר – בדיקת חומרה'},
    {text:'לקוח מאשר גלישה / שיחה תקינה'},
    {text:'בדיקת קבלת SMS'},
    {text:'בדיקת VoLTE פעיל'},
  ],ph:'לדוגמה: שיחת ביקורת 24 שעות לאחר מכן'},
  {id:'s7',num:'7',req:false,title:'הפניה / אסקלציה',sub:'מתי ולמי',options:[
    {text:'מומחי תמיכה – לאחר מיצוי כל השלבים'},
    {text:'IT – Prepaid / הונאה'},
    {text:'רדיו + GNETRUCK – תקלה אזורית'},
    {text:'מעבדה – בעיית מכשיר'},
    {text:'הום סנטר – החלפת SIM פיזי'},
    {text:'מנהל / שימור – לקוח מתוסכל'},
  ],ph:'לדוגמה: אסקלציה לצוות VoLTE'},
  {id:'s8',num:'8',req:false,title:'שלב שירותי – סגירה',sub:'בירור נוסף, הצעות, תיעוד',options:[
    {text:'Wi-Fi Calling – הצע כפתרון מניעתי'},
    {text:'בדיקת התאמת חבילה'},
    {text:'שאלת שביעות רצון'},
    {text:'תיאום callback / מעקב'},
    {text:'תיעוד כל הפעולות שבוצעו'},
    {text:'הצע שדרוג אם רלוונטי'},
  ],ph:'לדוגמה: שליחת סיכום בוואטסאפ'},
];

// ── CUSTOM (USER-CREATED) STAGES ────────────────────────────────────────
// Lets the person building a knowledge item add a brand-new stage from
// scratch (title + subtitle) and then type its sub-inquiries manually,
// exactly like the "הוסף ידנית" flow on the built-in stages.
var nbCustomStages=[];
var nbCustomStageSeq=0;
function nbGetAllStages(){ return NB_STAGES.concat(nbCustomStages); }

function nbAddCustomStage(){
  var titleInp=document.getElementById('nb-newstage-title');
  var subInp=document.getElementById('nb-newstage-sub');
  var reqInp=document.getElementById('nb-newstage-req');
  var title=(titleInp&&titleInp.value.trim())||'';
  if(!title){ if(titleInp) titleInp.focus(); return; }
  nbCustomStageSeq++;
  var id='cs'+nbCustomStageSeq;
  var num=String(NB_STAGES.length+nbCustomStages.length+1);
  var sub=(subInp&&subInp.value.trim())||'שלב מותאם אישית';
  var req=!!(reqInp&&reqInp.checked);
  var stage={id:id,num:num,req:req,title:title,sub:sub,options:[],ph:'הקלד שאלה / פריט...',custom_stage:true};
  nbCustomStages.push(stage);
  nbState[id]={picked:[],custom:[],applied:false,s1data:{},images:{}};
  titleInp.value='';
  if(subInp) subInp.value='';
  if(reqInp) reqInp.checked=false;
  nbRender();
  var el=document.getElementById('nb-stage-'+id);
  if(el){ el.classList.add('open'); el.scrollIntoView({behavior:'smooth',block:'nearest'}); }
}

function nbRemoveCustomStage(id){
  nbCustomStages=nbCustomStages.filter(function(s){return s.id!==id;});
  delete nbState[id];
  nbRender();
}

// ── DRAG-TO-REORDER STAGES ───────────────────────────────────────────────
var nbStageOrder=[];

function nbGetStageOrder(){
  var allIds=nbGetAllStages().map(function(s){return s.id;});
  var seen={};
  // De-dupe defensively: a stale/corrupted saved order (e.g. from an older
  // version of this file, or a previous bug) must never render a stage twice.
  var order=(nbStageOrder||[]).filter(function(id){
    if(seen[id]||allIds.indexOf(id)===-1) return false;
    seen[id]=true;
    return true;
  });
  allIds.forEach(function(id){ if(order.indexOf(id)===-1) order.push(id); });
  nbStageOrder=order;
  return order;
}

// Renumbers stages according to their current drag order. Stage 1 (the
// identification fields) is always "1"; the rest are numbered 2..N by
// their position among each other, regardless of where s1 physically sits.
// Used for the BUILDER's own UI (badges, apply button, summary headings).
function nbDisplayNum(sid){
  if(sid==='s1') return '1';
  var contentOrder=nbGetStageOrder().filter(function(id){return id!=='s1';});
  var idx=contentOrder.indexOf(sid);
  return String(idx>=0?idx+2:'?');
}

// Numbers only the CONTENT stages, 1..N with no gap. Stage 1 is never a
// step in the finished document (it's just identifying metadata), so the
// saved/exported document should start its step numbering at 1 — not 2 —
// or it looks like the first step is missing.
function nbContentNum(sid){
  var contentOrder=nbGetStageOrder().filter(function(id){return id!=='s1';});
  var idx=contentOrder.indexOf(sid);
  return String(idx>=0?idx+1:'?');
}

// Pointer-based drag (works with mouse AND touch, unlike native HTML5 DnD)
var nbDragState=null;

function nbStageHandlePointerDown(e,sid){
  e.preventDefault();
  var section=document.getElementById('nb-stage-'+sid);
  var container=document.getElementById('nb-stages');
  if(!section||!container) return;
  try{ e.target.setPointerCapture(e.pointerId); }catch(err){}
  var rect=section.getBoundingClientRect();
  var placeholder=document.createElement('div');
  placeholder.className='stage-drag-placeholder';
  placeholder.style.height=rect.height+'px';
  section.parentNode.insertBefore(placeholder,section);
  section.style.position='fixed';
  section.style.zIndex='999';
  section.style.width=rect.width+'px';
  section.style.left=rect.left+'px';
  section.style.top=rect.top+'px';
  section.style.pointerEvents='none';
  section.classList.add('dragging');
  document.body.style.userSelect='none';
  nbDragState={sid:sid,section:section,placeholder:placeholder,container:container,offsetY:e.clientY-rect.top,offsetX:e.clientX-rect.left};
  document.addEventListener('pointermove',nbStageHandlePointerMove);
  document.addEventListener('pointerup',nbStageHandlePointerUp);
  document.addEventListener('pointercancel',nbStageHandlePointerUp);
}

function nbStageHandlePointerMove(e){
  var d=nbDragState;
  if(!d) return;
  d.section.style.top=(e.clientY-d.offsetY)+'px';
  d.section.style.left=(e.clientX-d.offsetX)+'px';
  var siblings=Array.prototype.slice.call(d.container.querySelectorAll('.acc-section')).filter(function(el){return el!==d.section;});
  var placed=false;
  for(var i=0;i<siblings.length;i++){
    var sRect=siblings[i].getBoundingClientRect();
    var sMid=sRect.top+sRect.height/2;
    if(e.clientY<sMid){
      siblings[i].parentNode.insertBefore(d.placeholder,siblings[i]);
      placed=true;
      break;
    }
  }
  if(!placed && siblings.length){
    var last=siblings[siblings.length-1];
    last.parentNode.insertBefore(d.placeholder,last.nextSibling);
  }
}

function nbStageHandlePointerUp(){
  var d=nbDragState;
  document.removeEventListener('pointermove',nbStageHandlePointerMove);
  document.removeEventListener('pointerup',nbStageHandlePointerUp);
  document.removeEventListener('pointercancel',nbStageHandlePointerUp);
  document.body.style.userSelect='';
  if(!d) return;
  d.placeholder.parentNode.insertBefore(d.section,d.placeholder);
  d.placeholder.remove();
  d.section.style.position='';
  d.section.style.zIndex='';
  d.section.style.width='';
  d.section.style.left='';
  d.section.style.top='';
  d.section.style.pointerEvents='';
  d.section.classList.remove('dragging');
  var newOrder=Array.prototype.map.call(d.container.querySelectorAll('.acc-section'),function(el){return el.id.replace('nb-stage-','');});
  nbStageOrder=newOrder;
  nbDragState=null;
  nbRender();
}

function nbRenderAddStageForm(){
  return '<div style="background:var(--white);border:1.5px dashed var(--border-strong);border-radius:var(--r);padding:14px;margin-top:6px">'
    +'<div style="font-size:12.5px;font-weight:700;color:var(--navy);margin-bottom:9px">➕ הוסף שלב חדש משלך</div>'
    +'<div style="display:flex;flex-direction:column;gap:8px">'
    +'<input type="text" id="nb-newstage-title" placeholder="שם השלב (לדוגמה: בדיקת חבילת רומינג)" style="height:36px;padding:0 10px;font-size:13px;border:1.5px solid var(--border);border-radius:var(--rs);background:var(--input-bg);color:var(--text);outline:none;font-family:Rubik,sans-serif;direction:rtl">'
    +'<input type="text" id="nb-newstage-sub" placeholder="תת-כותרת (אופציונלי)" style="height:34px;padding:0 10px;font-size:12.5px;border:1.5px solid var(--border);border-radius:var(--rs);background:var(--input-bg);color:var(--text);outline:none;font-family:Rubik,sans-serif;direction:rtl">'
    +'<div style="display:flex;align-items:center;justify-content:space-between;gap:8px">'
    +'<label style="display:inline-flex;align-items:center;gap:6px;font-size:12.5px;color:var(--text-2);cursor:pointer"><input type="checkbox" id="nb-newstage-req" style="accent-color:var(--red);width:14px;height:14px">שלב חובה</label>'
    +'<button onclick="nbAddCustomStage()" style="height:34px;padding:0 16px;background:var(--navy);color:#fff;border:none;border-radius:var(--rs);font-size:13px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif">✚ צור שלב</button>'
    +'</div></div></div>';
}

var nbState={};
NB_STAGES.forEach(function(s){nbState[s.id]={picked:[],custom:[],applied:false,s1data:{}};}); nbState._bodies={};

function nbRender(){
  var el=document.getElementById('nb-stages');
  if(!el) return;
  nbRenderImportBox();
  var order=nbGetStageOrder();
  var allStages=nbGetAllStages();
  var orderedStages=order.map(function(id){return allStages.filter(function(s){return s.id===id;})[0];}).filter(Boolean);
  // R and S use the step builder; every other type gets its own editor.
  if(!nbIsStageKind(nbCurKind())){
    var s1def=allStages.filter(function(s){return s.id==='s1';})[0];
    el.innerHTML=nbRenderStage(s1def)+'<div id="nb-kind-editor" class="kind-editor">'+nbKindEditorHTML(nbCurKind())+'</div>';
    nbUpdateSummary();
    nbSaveDraft();
    return;
  }
  el.innerHTML=orderedStages.map(nbRenderStage).join('')+nbRenderAddStageForm();
  // Update summary
  nbUpdateSummary();
  nbSaveDraft();
  // Restore image previews from nbState
  nbGetAllStages().forEach(function(s){
    var st=nbState[s.id];
    if(!st||!st.images) return;
    Object.keys(st.images).forEach(function(k){
      var dataUrl=st.images[k];
      var key=parseInt(k);
      if(!isNaN(key)){
        // Option-level image
        var uid='nb-opt-'+s.id+'-'+k;
        var container=document.getElementById('nb-opt-imgs-'+uid);
        if(container && container.children.length===0){
          var wrap=document.createElement('div');
          wrap.style.cssText='position:relative;display:inline-block;margin-top:8px';
          var img=document.createElement('img');
          img.src=dataUrl;
          img.style.cssText='max-width:100%;max-height:180px;width:auto;border-radius:6px;border:1px solid var(--border);display:block';
          nbMakeZoomable(img);
          var del=document.createElement('button');
          del.textContent='×';
          del.style.cssText='position:absolute;top:2px;right:2px;background:var(--red);color:#fff;border:none;border-radius:50%;width:18px;height:18px;font-size:12px;cursor:pointer;line-height:18px;padding:0;text-align:center';
          (function(sid,kk){del.addEventListener('click',function(e){e.stopPropagation();delete nbState[sid].images[kk];wrap.remove();});})(s.id,k);
          wrap.appendChild(img);wrap.appendChild(del);
          container.appendChild(wrap);
        }
      }
    });
  });
}

function nbRenderStage(s){
  var st=nbState[s.id];
  var isOpen=document.getElementById('nb-stage-'+s.id)?document.getElementById('nb-stage-'+s.id).classList.contains('open'):false;
  var openCls=(s.id==='s1'&&!st.applied)?'open':(isOpen?'open':'');

  var tagHtml=st.applied
    ?('<span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;background:var(--ok-bg);color:var(--ok);border:1px solid var(--ok-b)">✓ '+(s.id==='s1'?'הושלם':(st.picked.length+st.custom.length)+' פריטים')+'</span>')
    :('<span style="display:inline-flex;align-items:center;font-size:11px;font-weight:600;padding:2px 8px;border-radius:20px;border:1px solid;'+(s.req?'background:#FFE8E8;color:#C02800;border-color:var(--red-m)':'background:var(--gray);color:var(--muted);border-color:var(--border)')+'">'+( s.req?'חובה':'אופציונלי')+'</span>');

  var bodyHtml='';
  if(s.type==='fields'){
    var d=st.s1data;
    var topicOpts=TOPICS.slice().sort(function(a,b){return String(a.title).localeCompare(String(b.title),'he');}).map(function(t){
      return '<option value="'+t.id+'"'+(String(d.topicId)===String(t.id)?' selected':'')+'>'+nbEsc(String(t.title).replace(/<[^>]*>/g,''))+'</option>';
    }).join('');
    var dWorlds=d.worlds||[];
    bodyHtml='<div class="s1-box">'
      +'<div class="s1-label">שם פריט הידע</div>'
      +'<textarea class="s1-input" style="height:40px;resize:none" id="nb-s1-topic" oninput="nbSyncS1(\'topic\',this.value)" placeholder="לדוגמה: הפעלת eSIM – קוד QR">'+nbEsc(d.topic||'')+'</textarea></div>'
      +'<div class="s1-box">'
      +'<div class="s1-label">נושא</div>'
      +'<div class="s1-help">הנושא שתחתיו יופיע הפריט. בנושא אחד יכולים להיות כמה פריטי ידע (אבחון, טיפול, תפעול…)</div>'
      +'<select class="s1-input" id="nb-s1-topicsel" onchange="nbSyncS1(\'topicId\',this.value);nbRender();">'
      +'<option value="">— בחר נושא —</option>'
      +'<option value="new"'+(d.topicId==='new'?' selected':'')+'>➕ נושא חדש…</option>'
      +topicOpts+'</select>'
      +(d.topicId==='new'
        ?'<input class="s1-input" style="margin-top:8px" id="nb-s1-newtopic" value="'+nbEsc(d.newTopic||'')+'" oninput="nbSyncS1(\'newTopic\',this.value)" placeholder="שם הנושא החדש">'
          +'<div class="s1-sublabel">קטגוריה של הנושא החדש</div>'
          +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">'
          +[['sim',SIM_ICON+' SIM/eSIM'],['data',CAT.data],['signal',CAT.signal],['calls',CAT.calls],['sms',CAT.sms],['tech','🔧 תמיכה טכנית'],['billing','💳 חיובים'],['plans','📋 מסלולים'],['intl','✈️ חו"ל'],['ops','🎧 שיחה'],['hq',CAT.hq]].map(function(r){
            return '<label class="radio-item'+(d.cat===r[0]?' sel':'')+'" data-field="cat" data-val="'+r[0]+'" onclick="nbSelR(this)">'
              +'<input type="radio" name="nb-dcat" '+(d.cat===r[0]?'checked':'')+' style="flex-shrink:0;width:14px;height:14px;margin-top:2px;accent-color:var(--red)">'
              +'<div style="font-size:13px;font-weight:500;color:var(--text)">'+r[1]+'</div></label>';
          }).join('')+'</div>'
        :'')
      +'</div>'
      +'<div class="s1-box">'
      +'<div class="s1-label">סוג פריט הידע</div>'
      +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">'
      +NB_KIND_ORDER.map(function(k){
        var kd=NB_KINDS[k];
        return '<label class="radio-item kind-radio'+(d.kind===k?' sel':'')+'" data-field="kind" data-val="'+k+'" onclick="nbSelR(this)">'
          +'<input type="radio" name="nb-dkind" '+(d.kind===k?'checked':'')+' style="flex-shrink:0;width:14px;height:14px;margin-top:3px;accent-color:var(--red)">'
          +'<div><div style="font-size:13px;font-weight:600;color:var(--text)">'+nbKindBadge(k,true)+' '+kd.full+'</div><div style="font-size:11.5px;color:var(--muted);margin-top:3px;line-height:1.45">'+kd.hint+'</div></div></label>';
      }).join('')+'</div></div>'
      +'<div class="s1-box">'
      +'<div class="s1-label">עולמות תוכן</div>'
      +'<div class="s1-help">אפשר לבחור יותר מאחד – הפריט יופיע בכל העולמות שנבחרו</div>'
      +'<div class="world-pick">'+WORLDS.map(function(w){
        var on=dWorlds.indexOf(w.id)!==-1;
        return '<button type="button" class="world-toggle'+(on?' on':'')+'" data-world="'+nbEsc(w.id)+'" onclick="nbToggleWorld(this)">'+(on?'✓ ':'')+nbEsc(w.name)+'</button>';
      }).join('')+'</div></div>'
      +'<div class="s1-box">'
      +'<div class="s1-label">תיאור קצר</div>'
      +'<textarea class="s1-input" style="resize:vertical;min-height:64px" id="nb-s1-desc" oninput="nbSyncS1(\'desc\',this.value)" placeholder="במה עוסק, מה פותר, מתי להשתמש…">'+nbEsc(d.desc||'')+'</textarea></div>'
      +'<div class="s1-box">'
      +'<div class="s1-label">תגיות לחיפוש</div>'
      +'<input class="s1-input" id="nb-s1-tags" value="'+nbEsc(d.tags||'')+'" oninput="nbSyncS1(\'tags\',this.value)" placeholder="מופרדות בפסיק, לדוגמה: eSIM, QR, הפעלה"></div>'
      +'<div class="s1-box">'
      +'<div class="s1-label">גורם מקצועי אחראי</div>'
      +'<div class="s1-help">מי אחראי לוודא שהתוכן נכון, תקף ועדכני</div>'
      +'<input class="s1-input" id="nb-s1-owner" value="'+nbEsc(d.owner||'')+'" oninput="nbSyncS1(\'owner\',this.value)" placeholder="שם או תפקיד, לדוגמה: מנהל תמיכה טכנית"></div>'
      +'<div class="s1-box">'
      +'<div class="s1-label">סטטוס</div>'
      +'<div class="s1-help">רק פריט במצב "פורסם" מוצג לנציגים</div>'
      +'<select class="s1-input" id="nb-s1-status" onchange="nbSyncS1(\'status\',this.value)">'
      +NB_STATUS_ORDER.map(function(s){return '<option value="'+s+'"'+((d.status||'draft')===s?' selected':'')+'>'+NB_STATUSES[s].label+'</option>';}).join('')
      +'</select></div>'
      +'<div class="s1-box s1-track">'
      +'<div class="s1-label">מעקב עריכה <span class="s1-help" style="display:inline">(לעורכים בלבד)</span></div>'
      +'<div class="s1-row">'
      +'<select class="s1-input" onchange="nbSyncS1(\'trackState\',this.value)"><option value="">מצב התוכן…</option>'
      +NB_TRACK_STATES.map(function(s){return '<option'+(d.trackState===s?' selected':'')+'>'+s+'</option>';}).join('')+'</select>'
      +'<select class="s1-input" onchange="nbSyncS1(\'trackPriority\',this.value)"><option value="">עדיפות…</option>'
      +NB_PRIORITIES.map(function(s){return '<option'+(d.trackPriority===s?' selected':'')+'>'+s+'</option>';}).join('')+'</select>'
      +'</div>'
      +'<textarea class="s1-input" style="resize:vertical;min-height:52px;margin-top:8px" oninput="nbSyncS1(\'trackGap\',this.value)" placeholder="פער / פעולה נדרשת">'+nbEsc(d.trackGap||'')+'</textarea>'
      +'<input class="s1-input" style="margin-top:8px" value="'+nbEsc(d.trackSource||'')+'" oninput="nbSyncS1(\'trackSource\',this.value)" placeholder="מקור ידע עיקרי (מסמך, צ\'קליסט…)"></div>'
      +'<button onclick="nbApplyS1()" style="width:100%;height:38px;background:var(--red);color:#fff;border:none;border-radius:var(--rs);font-size:13.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif">✓ הוסף שלב 1 לפריט הידע</button>';
  } else {
    var optHtml=s.options.map(function(o,i){
      var isPicked=st.picked.indexOf(i)!==-1;
      var uid='nb-opt-'+s.id+'-'+i;
      return '<div id="'+uid+'" class="nb-opt" data-s="'+s.id+'" data-i="'+i+'" style="display:flex;flex-direction:column;background:'+(isPicked?'var(--ok-bg)':'var(--input-bg)')+';border:1px solid '+(isPicked?'var(--ok-b)':'var(--border)')+';border-radius:var(--rs);padding:8px 11px;cursor:pointer;user-select:none;margin-bottom:5px">'
        +'<div style="display:flex;align-items:flex-start;gap:9px">'
        +'<div id="cb-'+uid+'" style="flex-shrink:0;width:16px;height:16px;margin-top:1px;border-radius:3px;border:2px solid '+(isPicked?'var(--ok)':'#ccc')+';background:'+(isPicked?'var(--ok)':'#fff')+';display:flex;align-items:center;justify-content:center;pointer-events:none">'+(isPicked?'&#10003;':'')+'</div>'
        +'<div style="pointer-events:none;flex:1"><div style="font-size:13px;color:var(--text);line-height:1.45">'+o.text+'</div>'+(o.hint?'<div style="font-size:11.5px;color:var(--muted);margin-top:2px">'+o.hint+'</div>':'')+'</div>'
        +'<label style="display:inline-flex;align-items:center;gap:4px;font-size:11px;color:var(--muted);cursor:pointer;border:1px solid #F5D8A5;border-radius:5px;padding:3px 8px;background:#FFF8EE;flex-shrink:0;pointer-events:auto">'
        +'<span style="font-size:11px;color:#E06000">📎 תמונה</span><input type="file" accept="image/*" style="display:none" data-uid="'+uid+'" data-sid="'+s.id+'" data-idx="'+i+'">'
        +'</label>'
        +'</div>'
        +'<div id="nb-opt-imgs-'+uid+'" style="margin-top:4px;display:flex;flex-wrap:wrap;gap:6px"></div>'
        +'</div>';
    }).join('');

    var custHtml=st.custom.length?('<div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);margin-bottom:7px;margin-top:4px">נוסף ידנית</div>'
      +st.custom.map(function(txt,i){
        return '<div style="display:flex;align-items:center;gap:8px;background:#EBF1FF;border:1px solid #B5D4F4;border-radius:var(--rs);padding:6px 10px;font-size:12.5px;color:#1D45B4;margin-bottom:4px">'
          +'<span style="font-size:13px;flex-shrink:0">✏️</span><span>'+txt+'</span>'
          +'<span data-sid="'+s.id+'" data-idx="'+i+'" onclick="nbRemoveCustom(this.dataset.sid,parseInt(this.dataset.idx))" style="margin-right:auto;font-size:14px;color:var(--muted);cursor:pointer;padding:0 2px" title="הסר">×</span></div>';
      }).join('')):'';

    bodyHtml='<div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);margin-bottom:7px">בחר מהרשימה</div>'
      +optHtml+custHtml
      +'<div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);margin-bottom:7px;margin-top:'+(st.custom.length?'4':'0')+'px">הוסף ידנית</div>'
      +'<div style="display:flex;gap:8px;margin-bottom:12px" id="nb-cr-'+s.id+'">'
      +'<input type="text" id="nb-inp-'+s.id+'" data-sid="'+s.id+'" placeholder="'+s.ph+'" onkeydown="if(event.keyCode===13)nbAddCustom(this.dataset.sid)" '
      +'style="flex:1;font-size:13px;height:34px;padding:0 10px;border:1.5px solid var(--border);border-radius:var(--rs);background:var(--input-bg);color:var(--text);outline:none;font-family:Rubik,sans-serif;direction:rtl">'
      +'<label id="nb-img-lbl-'+s.id+'" style="height:34px;padding:0 12px;font-size:12.5px;font-weight:500;background:var(--gray);border:1.5px solid var(--border);border-radius:var(--rs);color:var(--muted);cursor:pointer;white-space:nowrap;font-family:Rubik,sans-serif;display:inline-flex;align-items:center;gap:5px">'
      +'📎 תמונה<input type="file" accept="image/*" style="display:none" data-sid="'+s.id+'"></label>'
      +'<button data-sid="'+s.id+'" onclick="nbAddCustom(this.dataset.sid)" style="height:34px;padding:0 12px;font-size:12.5px;font-weight:500;background:var(--gray);border:1.5px solid var(--border);border-radius:var(--rs);color:var(--muted);cursor:pointer;white-space:nowrap;font-family:Rubik,sans-serif">+ הוסף</button>'
      +'</div>'
      +'<div id="nb-imgs-'+s.id+'" style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px"></div>'
      +'<button id="nb-apply-'+s.id+'" data-sid="'+s.id+'" onclick="nbApplyStage(this.dataset.sid)" '+(st.picked.length+st.custom.length===0?'disabled':'')+' '
      +'style="width:100%;height:38px;background:#FF3D00;color:#fff;border:none;border-radius:var(--rs);font-size:13.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif;opacity:'+(st.picked.length+st.custom.length===0?'0.4':'1')+'">✓ הוסף שלב '+nbDisplayNum(s.id)+' לפריט הידע</button>';
  }

  return '<div class="acc-section '+openCls+'" id="nb-stage-'+s.id+'">'
    +'<div class="acc-head" data-sid="'+s.id+'" onclick="nbToggleStage(this.dataset.sid)">'
    +'<span class="stage-drag-handle" onpointerdown="nbStageHandlePointerDown(event,\''+s.id+'\')" onclick="event.stopPropagation()" title="גרור לסידור מחדש"><svg width="12" height="18" viewBox="0 0 12 18" fill="none"><circle cx="3" cy="3" r="1.6" fill="currentColor"/><circle cx="9" cy="3" r="1.6" fill="currentColor"/><circle cx="3" cy="9" r="1.6" fill="currentColor"/><circle cx="9" cy="9" r="1.6" fill="currentColor"/><circle cx="3" cy="15" r="1.6" fill="currentColor"/><circle cx="9" cy="15" r="1.6" fill="currentColor"/></svg></span>'
    +'<div class="acc-num'+(s.req?' red':'')+'">'+nbDisplayNum(s.id)+'</div>'
    +'<div style="flex:1;min-width:0"><div class="acc-title">'+s.title+'</div><div style="font-size:12px;color:var(--muted);margin-top:1px">'+s.sub+'</div></div>'
    +'<div style="display:flex;align-items:center;gap:8px;flex-shrink:0">'+tagHtml
    +(s.custom_stage?('<span onclick="event.stopPropagation();nbRemoveCustomStage(\''+s.id+'\')" title="מחק שלב" style="font-size:15px;color:var(--muted);cursor:pointer;padding:0 2px">🗑️</span>'):'')
    +'<span class="acc-chev">▼</span></div>'
    +'</div>'
    +(st.applied && !isOpen ? (function(){
      var previewItems = s.id==='s1'
        ? (st.s1data&&st.s1data.topic ? '<div style="font-size:12px;color:var(--muted);padding:6px 16px">נושא: '+st.s1data.topic+'</div>' : '')
        : '<div style="font-size:12px;color:var(--muted);padding:6px 16px">'+(st.picked.length+st.custom.length)+' פריטים נבחרו</div>';
      return previewItems;
    })() : '')
    +'<div class="acc-body" style="padding:'+(openCls==='open'?'16px':'0 16px')+'">'+bodyHtml+'</div>'
    +'</div>';
}

function nbToggleStage(id){
  var el=document.getElementById('nb-stage-'+id);
  if(el) el.classList.toggle('open');
}

function nbSelR(el){
  var field=el.getAttribute('data-field');
  var val=el.getAttribute('data-val');
  nbState['s1'].s1data[field]=val;
  // Update ONLY the radio visuals — no nbRender() to avoid resetting other stages
  var group=el.closest('[style*="grid-template-columns"]')||el.closest('[style*="flex-direction:column"]');
  if(group){
    group.querySelectorAll('.radio-item').forEach(function(r){r.classList.remove('sel');});
  }
  el.classList.add('sel');
  var inp=el.querySelector('input[type=radio]');
  if(inp) inp.checked=true;
  nbSaveDraft();
  // Changing the type swaps the content editor below.
  if(field==='kind') nbRender();
}

function nbPickOpt(sid,idx){
  var st=nbState[sid];
  var pos=st.picked.indexOf(idx);
  if(pos===-1) st.picked.push(idx); else st.picked.splice(pos,1);
  var isPicked=st.picked.indexOf(idx)!==-1;
  var uid='nb-opt-'+sid+'-'+idx;
  var row=document.getElementById(uid);
  if(row){
    row.style.background=isPicked?'var(--ok-bg)':'var(--input-bg)';
    row.style.borderColor=isPicked?'var(--ok-b)':'var(--border)';
    var cb=document.getElementById('cb-'+uid);
    if(cb){cb.style.borderColor=isPicked?'var(--ok)':'#ccc';cb.style.background=isPicked?'var(--ok)':'#fff';cb.innerHTML=isPicked?'&#10003;':'';}
    // Show/hide image button on option
    var optImgLbl=document.getElementById('nb-opt-img-lbl-'+uid);
    if(optImgLbl) optImgLbl.style.display=isPicked?'inline-flex':'none';
  }
  var btn=document.getElementById('nb-apply-'+sid);
  if(btn){btn.disabled=st.picked.length+st.custom.length===0;btn.style.opacity=btn.disabled?'0.4':'1';}
  nbUpdateSummary();
  nbSaveDraft();
}
function nbTP(el){var t=el.closest('[data-idx]');if(t)nbPickOpt(t.getAttribute('data-sid'),parseInt(t.getAttribute('data-idx')));}
function nbRemoveImage(sid,idx){
  if(nbState[sid] && nbState[sid].images) delete nbState[sid].images[idx];
  var container=document.getElementById('nb-opt-imgs-nb-opt-'+sid+'-'+idx);
  if(container) container.innerHTML='';
}


function nbTogglePick(id,idx){ nbPickOpt(id,idx); }

function nbAddCustom(id){
  var inp=document.getElementById('nb-inp-'+id);
  if(!inp||!inp.value.trim()) return;
  nbState[id].custom.push(inp.value.trim());
  var wasOpen=document.getElementById('nb-stage-'+id)&&document.getElementById('nb-stage-'+id).classList.contains('open');
  nbRender();
  if(wasOpen&&document.getElementById('nb-stage-'+id)) document.getElementById('nb-stage-'+id).classList.add('open');
  var newInp=document.getElementById('nb-inp-'+id);
  if(newInp){newInp.value='';newInp.focus();}
  var btn=document.getElementById('nb-apply-'+id);
  if(btn){btn.disabled=false;btn.style.opacity='1';}
}

function nbRemoveCustom(id,idx){
  nbState[id].custom.splice(idx,1);
  var wasOpen=document.getElementById('nb-stage-'+id)&&document.getElementById('nb-stage-'+id).classList.contains('open');
  nbRender();
  if(wasOpen&&document.getElementById('nb-stage-'+id)) document.getElementById('nb-stage-'+id).classList.add('open');
}

function nbEditStage(id){
  nbState[id].applied=false;
  nbRender();
  var el=document.getElementById('nb-stage-'+id);
  if(el){el.classList.add('open');el.scrollIntoView({behavior:'smooth',block:'nearest'});}
}

function nbSyncS1(field,val){
  nbState['s1'].s1data[field]=val;
  nbSaveDraft();
}

function nbToggleWorld(btn){
  var d=nbState['s1'].s1data;
  d.worlds=d.worlds||[];
  var id=btn.getAttribute('data-world');
  var i=d.worlds.indexOf(id);
  if(i===-1) d.worlds.push(id); else d.worlds.splice(i,1);
  var on=i===-1;
  btn.classList.toggle('on',on);
  btn.textContent=(on?'✓ ':'')+nbWorldName(id);
  nbSaveDraft();
}

function nbApplyS1(){
  var d=nbState['s1'].s1data;
  d.topic=(document.getElementById('nb-s1-topic')||{}).value||'';
  d.desc=(document.getElementById('nb-s1-desc')||{}).value||'';
  d.tags=(document.getElementById('nb-s1-tags')||{}).value||'';
  d.owner=(document.getElementById('nb-s1-owner')||{}).value||'';
  var nt=document.getElementById('nb-s1-newtopic');
  if(nt) d.newTopic=nt.value;
  var missing=[];
  if(!d.topic.trim()) missing.push('שם פריט הידע');
  if(!d.topicId||(d.topicId==='new'&&!(d.newTopic||'').trim())) missing.push('נושא');
  if(!d.kind) missing.push('סוג פריט הידע');
  if(!d.worlds||!d.worlds.length) missing.push('עולם תוכן');
  if(missing.length){ alert('יש להשלים: '+missing.join(', ')); return; }
  nbState['s1'].applied=true;
  nbRender();
  nbUpdateSummary();
}

function nbApplyStage(id){
  var st=nbState[id];
  if(st.picked.length+st.custom.length===0) return;
  st.applied=true;
  // images already stored in st.images
  nbRender();
  nbUpdateSummary();
}

function nbUpdateSummary(){
  var box=document.getElementById('nb-summary');
  var allStages=nbGetAllStages();
  var order=nbGetStageOrder();
  var orderedStages=order.map(function(id){return allStages.filter(function(s){return s.id===id;})[0];}).filter(Boolean);
  var sk=nbCurKind(), typed=!nbIsStageKind(sk);
  if(typed) orderedStages=orderedStages.filter(function(s){return s.id==='s1';});
  var html=orderedStages.filter(function(s){
    var st=nbState[s.id];
    return st.applied || (s.id==='s1'&&st.s1data&&st.s1data.topic) || (st.picked&&st.picked.length>0) || (st.custom&&st.custom.length>0);
  }).map(function(s){
    var st=nbState[s.id];
    var def=s;
    var items=[];
    if(s.id==='s1'){
      var d=st.s1data;
      if(d.topic)items.push('שם: '+nbEsc(d.topic));
      var tp=d.topicId==='new'?(d.newTopic||'')+' (חדש)':((TOPICS.find(function(t){return String(t.id)===String(d.topicId);})||{}).title||'');
      if(tp)items.push('נושא: '+tp);
      if(d.kind&&NB_KINDS[d.kind])items.push('סוג: '+nbKindBadge(d.kind,true)+' '+NB_KINDS[d.kind].full);
      if(d.worlds&&d.worlds.length)items.push('עולמות תוכן: '+d.worlds.map(nbWorldName).map(nbEsc).join(', '));
      if(d.desc)items.push('תיאור: '+nbEsc(d.desc));
      if(d.tags)items.push('תגיות: '+nbEsc(d.tags));
      if(d.owner)items.push('גורם אחראי: '+nbEsc(d.owner));
    }
    else{items=st.picked.map(function(i){
        var img=(st.images&&st.images[i])||null;
        return {text:def.options[i].text,img:img};
      }).concat(st.custom.map(function(t){return {text:'[ידני] '+t,img:null};}));}
    return '<div style="margin-bottom:16px">'      +'<div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:8px">שלב '+nbDisplayNum(s.id)+' – '+def.title+'</div>'      +items.map(function(item){
        var txt=typeof item==='object'?item.text:item;
        var img=typeof item==='object'?item.img:null;
        return '<div style="background:var(--input-bg);border:1px solid var(--border);border-radius:var(--rs);padding:8px 10px;margin-bottom:5px">'          +'<div style="display:flex;align-items:flex-start;gap:7px;font-size:13px;color:var(--text)">'          +'<span style="color:var(--red);flex-shrink:0;font-size:10px;margin-top:3px">›</span>'          +'<span>'+txt+'</span></div>'          +(img?'<img src="'+img+'" onclick="event.stopPropagation();nbOpenLightbox(this.src)" style="max-height:160px;width:auto;max-width:100%;border-radius:6px;border:1px solid var(--border);margin-top:6px;display:block;cursor:zoom-in">':'')          +'</div>';
      }).join('')      +'</div>';
  }).join('');
  if(typed&&html) html+=nbBodySummaryHTML(sk);
  var sc=document.getElementById('nb-sum-content');
  if(sc) sc.innerHTML=html;
  if(box) box.style.display=html?'':'none';
}

function nbCreateDoc(){
  try{
    nbCreateDocImpl();
  }catch(e){
    console.error('nbCreateDoc failed:', e);
    alert('אירעה שגיאה בשמירה: '+e.message+'\n\nהשינויים לא נשמרו. נסה שוב, ואם זה חוזר — רענן את הדף (ייתכן שנטענת גרסה ישנה מהמטמון של הדפדפן).');
  }
}

// Puts the typed editor's content on the item (O/I/T/E/M), or keeps the
// steps (R/S). Returns false when a typed item has no content yet.
function nbApplyBodyToDoc(doc,stages){
  var k=doc.kind;
  if(nbIsStageKind(k)){ doc.stages=stages; delete doc.body; return true; }
  var b=nbCleanBody(k,nbBody(k));
  if(!nbBodyHasContent(k,b)){
    alert('יש להזין תוכן ל'+NB_KINDS[k].full+' לפני השמירה.');
    var ed=document.getElementById('nb-kind-editor');
    if(ed) ed.scrollIntoView({behavior:'smooth'});
    return false;
  }
  doc.body=b;
  doc.stages=[];
  return true;
}

function nbCreateDocImpl(){
  var s1=nbState['s1'].s1data;
  var topic=(s1.topic||'').trim();
  var cat=s1.cat||'tech';
  var docType=s1.kind||'R';
  // Every item must live under a topic (spec §2).
  if(topic&&!s1.topicId&&!window.nbEditingDocId){
    alert('יש לבחור נושא לפריט הידע בשלב 1 (נושא קיים או נושא חדש).');
    var elT=document.getElementById('nb-stage-s1');
    if(elT){elT.classList.add('open');elT.scrollIntoView({behavior:'smooth'});}
    return;
  }

  // If editing existing doc — update it
  if(window.nbEditingDocId){
    var docId=window.nbEditingDocId;
    window.nbEditingDocId=null;
    var stages=[];
    nbGetStageOrder().forEach(function(sid){
      var st=nbState[sid];
      if(!st.applied||sid==='s1') return;
      var def=nbGetAllStages().filter(function(x){return x.id===sid;})[0];
      if(!def) return;
      var items=st.picked.map(function(i){
        var img2=(st.images&&st.images[i])||null;
        return {text:def.options[i].text,img:img2};
      }).concat(st.custom.map(function(t){return {text:t,img:null};}));
      var stageImgs2=[];
      if(st.images) Object.keys(st.images).forEach(function(k){if(isNaN(parseInt(k)))stageImgs2.push(st.images[k]);});
      if(items.length) stages.push({num:nbContentNum(sid),id:def.id,title:def.title,items:items,images:stageImgs2});
    });
    var edited=window.dynamicDocs[docId];
    // Check the content before changing anything, so a refused save leaves the item intact.
    var probe={kind:NB_KINDS[s1.kind]?s1.kind:'R'};
    if(!nbApplyBodyToDoc(probe,stages)){ window.nbEditingDocId=docId; return; }
    nbApplyS1Fields(edited,s1);
    nbMarkLocalEdit(edited,docId);
    edited.stages=probe.stages;
    if(probe.body) edited.body=probe.body; else delete edited.body;
    // The form edits the item's main topic; links to other topics are kept.
    var mainTopic=nbResolveTopic(s1);
    if(mainTopic!=null){
      edited.topicIds=[mainTopic].concat((edited.topicIds||[]).slice(1).filter(function(x){return x!==mainTopic;}));
      var mt=TOPICS.find(function(x){return x.id===mainTopic;});
      if(mt) edited.cat=mt.cat;
    }
    nbRenderSidebar();
    renderLibrary(nbCurrentLibCat||'all');
    nbSaveLibrary('עודכן: '+topic);
    showDynamicDoc(docId);
    nbShowSuccessModal(topic+' — עודכן!'+nbStatusNote(edited));
    NB_STAGES.forEach(function(s){nbState[s.id]={picked:[],custom:[],applied:false,s1data:{}};}); nbState._bodies={};
    nbCustomStages=[];
    nbStageOrder=[];
    nbRender();
    var sumEl=document.getElementById('nb-summary');
    if(sumEl) sumEl.style.display='none';
    return;
  }

  if(!topic){
    alert('יש למלא נושא תדריך בשלב 1 לפני יצירה.');
    var el=document.getElementById('nb-stage-s1');
    if(el){el.classList.add('open');el.scrollIntoView({behavior:'smooth'});}
    return;
  }
  // Auto-apply s1 if topic is filled
  if(topic && !nbState['s1'].applied){
    nbState['s1'].applied = true;
    nbState['s1'].s1data.topic = topic;
    nbState['s1'].s1data.cat = cat;
  }
  if(!topic){
    alert('יש למלא נושא תדריך בשלב 1 לפני יצירה.');
    var el2=document.getElementById('nb-stage-s1');
    if(el2){el2.classList.add('open');el2.scrollIntoView({behavior:'smooth'});}
    return;
  }

  var docId='dyn-'+Date.now();
  var stages=[];
  nbGetStageOrder().forEach(function(sid){
    var st=nbState[sid];
    if(!st.applied||sid==='s1') return;
    var def=nbGetAllStages().filter(function(x){return x.id===sid;})[0];
    if(!def) return;
    var items=st.picked.map(function(i){
      var img=(st.images&&st.images[i])||null;
      return {text:def.options[i].text,img:img};
    }).concat(st.custom.map(function(t){return {text:t,img:null};}));
    var stageImgs=[];
    if(st.images) Object.keys(st.images).forEach(function(k){if(isNaN(parseInt(k)))stageImgs.push(st.images[k]);});
    if(items.length) stages.push({num:nbContentNum(sid),id:def.id,title:def.title,items:items,images:stageImgs});
  });

  window.dynamicDocs=window.dynamicDocs||{};
  var newDoc={id:docId,cat:cat,docType:docType,stages:stages,createdAt:Date.now()};
  nbApplyS1Fields(newDoc,s1);
  if(!nbApplyBodyToDoc(newDoc,stages)) return;
  window.dynamicDocs[docId]=newDoc;
  window.nbLinkToTopicId=null;
  var topicId=nbResolveTopic(s1);
  nbAddToLibrary(docId,topic,topicId);
  nbCurrentTopicId=topicId;
  showDynamicDoc(docId);
  nbShowSuccessModal(topic+nbStatusNote(newDoc));

  NB_STAGES.forEach(function(s){nbState[s.id]={picked:[],custom:[],applied:false,s1data:{}};}); nbState._bodies={};
  nbCustomStages=[];
  nbStageOrder=[];
  nbRender();
  var sumEl=document.getElementById('nb-summary');
  if(sumEl) sumEl.style.display='none';
}


// Initialize nbState immediately
var nbState={};
NB_STAGES.forEach(function(s){nbState[s.id]={picked:[],custom:[],applied:false,s1data:{}};}); nbState._bodies={};


// ── PDF KNOWLEDGE ITEMS ─────────────────────────────────────────────────
window.dynamicDocs = window.dynamicDocs || {};












window.dynamicDocs['pdf_011'] = {"id":"pdf_011","topic":"M-00 · תקלות ושירות בחו\"ל - אבחון מרכזי","cat":"intl","docType":"pdf","kind":"M","desc":"זיהוי מהיר של התקלה בחו\"ל והפניה למסלול הטיפול הנכון (R-01 עד R-05)","tags":["חו\"ל","אבחון","נדידה"],"stages":[],"body":{"intro":["מטרת המסמך","לזהות במהירות מה התקלה של הלקוח ולהפנות למסלול הטיפול הנכון.","המסמך מלווה את הנציג בתחילת השיחה בלבד.","ברגע שסוג התקלה ברור - עוברים למסלול הטיפול המתאים."],"questions":[{"title":"להבין מה הלקוח חווה","q":"\"מה לא עובד כרגע - קליטה, גלישה, שיחות או הודעות?\"","hint":"סמן את התיאור הראשוני, אך אל תעבור עדיין למסלול התקלה.\nתחילה יש לוודא שהתנאים הבסיסיים לשירות בחו\"ל תקינים.","answers":[{"text":"התיאור הראשוני סומן","note":"","go":"q:1"}]},{"title":"בדיקות בסיס במערכת","q":"האם הקו פתוח לשירותי חו\"ל / נדידה, והאם קיימת חבילת חו\"ל בתוקף?","hint":"בבדיקת החבילה ודא:\nהחבילה פעילה.\nתאריכי החבילה תקינים.\nהמדינה שבה נמצא הלקוח כלולה בחבילה.\nהחבילה לא נוצלה במלואה.","answers":[{"text":"הקו אינו פתוח לשירותי חו\"ל / נדידה","note":"פתח את השירות בהתאם להרשאות ולתהליך הקיים.","go":"q:4"},{"text":"נמצאה בעיה בחבילת החו\"ל","note":"טפל בהתאם לממצא לפני המשך האבחון.","go":"q:4"},{"text":"הקו פתוח והחבילה תקינה","note":"","go":"q:2"}]},{"title":"האם המכשיר מחובר לרשת בחו\"ל?","q":"\"האם מופיע במכשיר שם של רשת סלולרית?\"","hint":"","answers":[{"text":"לא מופיעה רשת / מופיע \"אין שירות\"","note":"עצור את אבחון הגלישה, השיחות או ההודעות. רק לאחר שהמכשיר נרשם לרשת ניתן להמשיך לבדוק את השירות שאינו עובד.","go":"item:pdf_012"},{"text":"מופיעה רשת סלולרית","note":"המכשיר רשום לרשת.","go":"q:3"}]},{"title":"זיהוי השירות שאינו עובד","q":"\"הגלישה לא עובדת בכלל או שרק אפליקציה מסוימת לא עובדת?\" — ובשיחות והודעות: מה בדיוק לא עובד?","hint":"בתקלת גלישה, בדוק תחילה במכשיר:\nנתונים סלולריים פעילים.\nנדידת נתונים פעילה.\nבמכשיר עם שני קווים – קו wecom נבחר לגלישה.\nאם הגדרה אינה תקינה – תקן בהתאם למסמך התפעול המתאים ובדוק שוב.","answers":[{"text":"אין גלישה בכלל (ההגדרות במכשיר תקינות)","note":"","go":"item:pdf_013"},{"text":"רק אפליקציה מסוימת לא עובדת","note":"","go":"item:pdf_014"},{"text":"לא ניתן להוציא שיחות, אך מתקבלות שיחות","note":"ודא שהמכשיר רשום לרשת ושאל: \"אתה מצליח לקבל שיחות?\"","go":"item:pdf_015"},{"text":"לא מתקבלות שיחות, אך ניתן להוציא שיחות","note":"ודא שהמכשיר רשום לרשת ושאל: \"אתה מצליח להוציא שיחות?\"","go":"item:pdf_015"},{"text":"לא ניתן להוציא וגם לא לקבל שיחות","note":"קיימת תקלה גם בשיחות יוצאות וגם בשיחות נכנסות. המשך למסלול השיחות בהתאם לממצאים.","go":"item:pdf_015"},{"text":"לא נשלחות או לא מתקבלות הודעות SMS","note":"ודא שהמכשיר רשום לרשת ושאל: \"הבעיה היא בשליחה, בקבלה או בשניהם?\" המשך לפי סוג התקלה.","go":"item:pdf_016"}]},{"title":"לאחר שינוי במערכת","q":"","hint":"אם במהלך הטיפול בוצע שינוי בשירותי הקו, הנחה את הלקוח לבצע:\nמצב טיסה והחזרה למצב רגיל, או כיבוי והדלקת המכשיר.\nלאחר מכן בדוק שוב: האם המכשיר נרשם לרשת, והאם השירות שבגינו פנה הלקוח עובד.","answers":[{"text":"המכשיר אינו רשום לרשת","note":"","go":"item:pdf_012"},{"text":"המכשיר רשום לרשת, אך השירות עדיין אינו עובד","note":"","go":"q:3"},{"text":"המכשיר רשום לרשת והשירות עובד","note":"סיום האבחון.","go":""}]}],"outro":["כלל מנחה לנציג: אין לבצע דיבאג של גלישה, שיחות או הודעות לפני שווידאת שהקו פתוח לשירות בחו\"ל ושהמכשיר רשום לרשת זרה."]},"track":{"state":"קיים","source":"4 מסמכי החו\"ל + 22 פריטי הידע","gap":"להוסיף קישורים למסמכי היעד במנהלת","priority":""},"status":"published","source":{"name":"M-00 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/M-00.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793865099045,"originName":"M-00 תקלות ושירות בחול - אבחון מרכזי.docx"};

window.dynamicDocs['pdf_012'] = {"id":"pdf_012","topic":"R-01 · אין קליטה או רישום לרשת בחו\"ל","cat":"intl","docType":"pdf","kind":"R","desc":"הלקוח בחו\"ל והמכשיר אינו מתחבר לרשת סלולרית מקומית: אין שירות, לא מופיע שם מפעיל, או שהמכשיר אינו מצליח להירשם לרשת","tags":["חו\"ל","נדידה","אין קליטה","רישום לרשת"],"stages":[{"num":"1","title":"R-01 אין קליטה או רישום לרשת בחו\"ל","items":[],"images":[]},{"num":"2","title":"מתי משתמשים במסמך?","items":[{"text":"הלקוח נמצא בחו\"ל והמכשיר אינו מתחבר לרשת סלולרית מקומית.","img":null},{"text":"לדוגמה:","img":null},{"text":"אין שירות.","img":null},{"text":"לא מופיע שם של מפעיל.","img":null},{"text":"המכשיר אינו מצליח להירשם לרשת.","img":null}],"images":[]},{"num":"3","title":"שלב 1 - בדיקת שירות נדידה במערכת","items":[{"text":"בדוק במערכת האם שירות נדידה פעיל למנוי.","img":null}],"images":[]},{"num":"4","title":"שירות נדידה לא פעיל","items":[{"text":"טפל בהפעלת השירות בהתאם לתהליך הקיים.","img":null}],"images":[]},{"num":"5","title":"להוסיף לינק לבדיקת האם נדידה פתוחה","items":[{"text":"לאחר השינוי הנחה את הלקוח לבצע:","img":null},{"text":"מצב טיסה והחזרה למצב רגיל.","img":null},{"text":"או כיבוי והדלקת המכשיר.","img":null},{"text":"בדוק האם המכשיר נרשם לרשת.","img":null}],"images":[]},{"num":"6","title":"שירות נדידה פעיל","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"7","title":"שלב 2 - בדיקת נדידת נתונים במכשיר","items":[{"text":"ודא כי נדידת נתונים פעילה במכשיר הלקוח.","img":null}],"images":[]},{"num":"8","title":"נדידת נתונים לא פעילה","items":[{"text":"עבור למסמך \"O-02 - בדיקה והפעלת נדידת נתונים במכשיר\" והפעל את נדידת הנתונים בהתאם לדגם המכשיר.","img":null},{"text":"לאחר ההפעלה בדוק האם המכשיר נרשם לרשת.","img":null}],"images":[]},{"num":"9","title":"המכשיר נרשם לרשת","items":[{"text":"אם הלקוח פנה בגלל גלישה, שיחות או הודעות שאינן עובדות - חזור למסמך האבחון המרכזי והמשך למסלול המתאים.","img":null}],"images":[]},{"num":"10","title":"המכשיר עדיין לא נרשם לרשת","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"11","title":"נדידת נתונים פעילה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"12","title":"שלב 3 - בדיקת בחירת רשת במכשיר","items":[{"text":"ודא שבחירת הרשת מוגדרת למצב אוטומטי.","img":null}],"images":[]},{"num":"13","title":"המכשיר התחבר לרשת","items":[{"text":"התקלה נפתרה.","img":null},{"text":"אם הלקוח פנה בגלל גלישה, שיחות או הודעות שאינן עובדות - חזור למסמך האבחון המרכזי והמשך למסלול המתאים.","img":null}],"images":[]},{"num":"14","title":"המכשיר עדיין לא מתחבר","items":[{"text":"המשך לבחירת רשת ידנית.","img":null}],"images":[]},{"num":"15","title":"שלב 4 - בחירת רשת ידנית","items":[{"text":"בטל את בחירת הרשת האוטומטית.","img":null},{"text":"המתן עד שתופיע רשימת מפעילים זמינים.","img":null},{"text":"בחר מפעיל מתוך \"רשימת המפעילים בחו\"ל\".","img":null}],"images":[]},{"num":"16","title":"הרישום הצליח","items":[{"text":"החזר את בחירת הרשת למצב אוטומטי.","img":null},{"text":"בדוק שהמכשיר נשאר מחובר לרשת.","img":null}],"images":[]},{"num":"17","title":"הרישום לא הצליח","items":[{"text":"נסה מפעיל נוסף מתוך רשימת המפעילים המאושרים.","img":null},{"text":"אם המכשיר אינו מצליח להירשם לאף מפעיל - המשך לשלב הבא.","img":null}],"images":[]},{"num":"18","title":"שלב 5 - הלקוח נמצא בארה\"ב?","items":[{"text":"לא","img":null},{"text":"המשך לשלב 6.","img":null},{"text":"כן","img":null},{"text":"בדוק האם דגם המכשיר נתמך ברשתות בארה\"ב.","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"19","title":"\"תאימות מכשירים ורשתות בארה\"ב\"","items":[],"images":[]},{"num":"20","title":"שלב 6 - בדיקות לפי סוג המכשיר","items":[],"images":[]},{"num":"21","title":"iPhone","items":[{"text":"בדוק:","img":null},{"text":"בחירת רשת מוגדרת לאוטומטי.","img":null},{"text":"אם לא נרשם לרשת - בצע בחירת רשת ידנית.","img":null},{"text":"בחר מפעיל מתוך רשימת המפעילים בחו\"ל.","img":null},{"text":"לאחר רישום תקין החזר את הבחירה לאוטומטי.","img":null},{"text":"בצע כיבוי והדלקה והמתן מספר דקות.","img":null}],"images":[]},{"num":"22","title":"Samsung","items":[{"text":"בדוק:","img":null},{"text":"בחירת הרשת מוגדרת ל-\"בחר באופן אוטומטי\".","img":null},{"text":"אם לא נרשם לרשת - בצע בחירת רשת ידנית.","img":null},{"text":"בחר מפעיל מתוך רשימת המפעילים בחו\"ל.","img":null},{"text":"לאחר רישום תקין החזר את הבחירה לאוטומטי.","img":null},{"text":"בצע כיבוי והדלקה והמתן מספר דקות.","img":null}],"images":[]},{"num":"23","title":"Xiaomi / Huawei / OnePlus / Google Pixel","items":[{"text":"בצע בחירת רשת ידנית.","img":null},{"text":"בחר מפעיל מתוך רשימת המפעילים בחו\"ל.","img":null},{"text":"אם הלקוח נמצא בארה\"ב - פעל בהתאם להנחיות הייעודיות לארה\"ב.","img":null},{"text":"אם המכשיר תומך בדור 4 - ודא שמצב הרשת מתאים.","img":null},{"text":"בצע כיבוי והדלקה.","img":null},{"text":"אם עדיין אין רישום - נסה את כרטיס ה-SIM במכשיר אחר.","img":null}],"images":[]},{"num":"24","title":"Oppo / Realme","items":[{"text":"בצע בחירת רשת ידנית.","img":null},{"text":"ודא שנוסו המפעילים הרלוונטיים מתוך רשימת המפעילים בחו\"ל.","img":null},{"text":"במכשיר תומך דור 5 - המסמך הקיים מנחה להעביר את המכשיר לדור 4.","img":null},{"text":"נסה את כרטיס ה-SIM במכשיר אחר.","img":null}],"images":[]},{"num":"25","title":"שלב 7 - עדיין אין רישום לרשת","items":[{"text":"אם בוצעו הבדיקות הרלוונטיות והמכשיר עדיין אינו נרשם לרשת:","img":null},{"text":"→ העבר למומחה טכני בהתאם למסמך:","img":null}],"images":[]},{"num":"26","title":"\"העברה למומחה בתקלת חו\"ל\"","items":[],"images":[]},{"num":"27","title":"סיום טיפול","items":[{"text":"לאחר שהמכשיר נרשם לרשת:","img":null},{"text":"בדוק עם הלקוח האם השירות שבגינו פנה עובד.","img":null},{"text":"אם לא:","img":null},{"text":"חזור ל - אבחון מרכזי לתקלות ושירות בחו\"ל\".","img":null},{"text":"המשך למסלול גלישה, שיחות או הודעות בהתאם לתקלה.","img":null}],"images":[]}],"track":{"state":"קיים","source":"לקוח לא מוצא רשת בחו\"ל + צ'קליסט Roaming","gap":"להשלים קישורים O-01/O-02/O-05 ומסמכי העזר","priority":""},"status":"published","source":{"name":"R-01 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-01.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-01 אין קליטה אין רישום לרשת בחול.docx"};

window.dynamicDocs['pdf_013'] = {"id":"pdf_013","topic":"R-02 · אין גלישה בחו\"ל","cat":"intl","docType":"pdf","kind":"R","desc":"הלקוח בחו\"ל, המכשיר מחובר לרשת סלולרית, אך אינו מצליח לגלוש","tags":["חו\"ל","גלישה","נדידת נתונים","APN"],"stages":[{"num":"1","title":"מתי משתמשים במסמך?","items":[{"text":"הלקוח נמצא בחו\"ל, המכשיר מחובר לרשת סלולרית, אך אינו מצליח לגלוש.","img":null},{"text":"אם המכשיר אינו מחובר לרשת זרה:","img":null}],"images":[]},{"num":"2","title":"עבור למסלול: R-01 אין קליטה או רישום לרשת בחו\"ל","items":[],"images":[]},{"num":"3","title":"שלב 1 - תיחום התקלה","items":[{"text":"שאל:","img":null},{"text":"\"הגלישה לא עובדת בכלל או שרק אפליקציה מסוימת לא עובדת?\"","img":null}],"images":[]},{"num":"4","title":"רק אפליקציה מסוימת לא עובדת","items":[{"text":"עבור למסלול:","img":null}],"images":[]},{"num":"5","title":"R-03 תקלה באפליקציה מסוימת בחו\"ל","items":[],"images":[]},{"num":"6","title":"אין גלישה בכלל","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"7","title":"שלב 2 - בדיקות מערכת","items":[{"text":"ודא במערכות:","img":null},{"text":"שירותי נדידה פעילים בקו.","img":null},{"text":"אין חסימת גלישה בחו\"ל.","img":null},{"text":"קיימת חבילת חו\"ל בתוקף.","img":null},{"text":"תאריכי החבילה תקינים.","img":null},{"text":"המדינה שבה נמצא הלקוח כלולה בחבילה.","img":null},{"text":"החבילה לא נוצלה במלואה.","img":null}],"images":[]},{"num":"8","title":"נמצאה בעיה","items":[{"text":"טפל בהתאם לממצא.","img":null}],"images":[]},{"num":"9","title":"לאחר שינוי במערכת","items":[{"text":"הנחה את הלקוח לבצע מצב טיסה והחזרה למצב רגיל.","img":null},{"text":"בדוק שוב גלישה.","img":null}],"images":[]},{"num":"10","title":"הכול תקין","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"11","title":"שלב 3 - בדיקות בסיס במכשיר","items":[{"text":"לצורך הבדיקה:","img":null},{"text":"כבה זמנית את הרשת האלחוטית.","img":null},{"text":"ודא שנתונים סלולריים פעילים.","img":null},{"text":"לאחר מכן ודא שנדידת נתונים פעילה.","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"12","title":"O-02 - בדיקה והפעלת נדידת נתונים במכשיר","items":[{"text":"קיימים שני קווים במכשיר?","img":null},{"text":"ודא שקו wecom נבחר לשימוש בנתונים סלולריים.","img":null},{"text":"אם קיימים שני קווים במכשיר, ודא שקו wecom נבחר לגלישה בהתאם להנחיות במסמך בדיקה והפעלת נדידת נתונים במכשיר.","img":null},{"text":"לאחר התיקון בדוק שוב גלישה.","img":null}],"images":[]},{"num":"13","title":"הגלישה עובדת","items":[{"text":"הטיפול הסתיים.","img":null}],"images":[]},{"num":"14","title":"עדיין אין גלישה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"15","title":"שלב 4 - בדיקת הגדרות גלישה","items":[{"text":"בדוק שהגדרת נקודת הגישה במכשיר תקינה.","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"16","title":"O-03 - הגדרת APN בחו\"ל","items":[{"text":"במסמכי המקור מוגדרת נקודת הגישה:","img":null}],"images":[]},{"num":"17","title":"UINTERNET PARTNER","items":[{"text":"לאחר הבדיקה נסה שוב לגלוש.","img":null}],"images":[]},{"num":"18","title":"הגלישה עובדת","items":[{"text":"הטיפול הסתיים.","img":null}],"images":[]},{"num":"19","title":"עדיין אין גלישה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"20","title":"שלב 5 - בדיקת זהות הרשת בחו\"ל","items":[{"text":"בדוק האם קיימת במכשיר זהות פרטנר כנדרש לשירות בחו\"ל.","img":null},{"text":"אם זהות פרטנר תקינה:","img":null},{"text":"אין לבצע שינוי דרך תפריט STK.","img":null},{"text":"אם נדרש שינוי זהות - עבור למסמך:","img":null}],"images":[]},{"num":"21","title":"O-04 - תפעול STK ושינוי זהות רשת בחו\"ל","items":[],"images":[]},{"num":"22","title":"חשוב","items":[{"text":"אם בוצע שינוי ידני, יש להנחות את הלקוח להחזיר את ההגדרה למצב אוטומטי עם החזרה לארץ.","img":null}],"images":[]},{"num":"23","title":"שלב 6 - בחירת רשת אחרת","items":[{"text":"ייתכן שהמכשיר רשום לרשת, אך שירותי הנתונים אינם עובדים בצורה תקינה ברשת שאליה התחבר.","img":null},{"text":"בצע בחירת רשת ידנית.","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"24","title":"O-05 - בחירת רשת ידנית בחו\"ל","items":[{"text":"בחר מפעיל מתוך:","img":null}],"images":[]},{"num":"25","title":"\"רשימת מפעילים ורשתות בחו\"ל\"","items":[{"text":"לאחר ההתחברות בדוק שוב גלישה.","img":null}],"images":[]},{"num":"26","title":"הגלישה עובדת","items":[{"text":"החזר את בחירת הרשת למצב אוטומטי.","img":null},{"text":"הטיפול הסתיים.","img":null}],"images":[]},{"num":"27","title":"עדיין אין גלישה","items":[{"text":"המשך.","img":null}],"images":[]},{"num":"28","title":"שלב 7 - רענון המכשיר","items":[{"text":"בצע:","img":null},{"text":"מצב טיסה למשך מספר שניות ולאחר מכן החזרה למצב רגיל.","img":null},{"text":"אם עדיין לא תקין:","img":null},{"text":"בצע כיבוי והדלקה של המכשיר.","img":null},{"text":"המתן להתחברות מחדש לרשת.","img":null},{"text":"בדוק שוב גלישה.","img":null}],"images":[]},{"num":"29","title":"שלב 8 - עדיין אין גלישה","items":[{"text":"בצע ריענון כרטיס במערכת בהתאם לתהליך המאושר.","img":null},{"text":"לחץ על כפתור ריענון ה-SIM החדש במערכת. אין להשתמש בכפתורים הישנים. לאחר מכן הנחה את הלקוח לבצע מצב טיסה והחזרה למצב רגיל ובדוק שוב גלישה.\"","img":null},{"text":"לאחר הריענון:","img":null},{"text":"הנחה את הלקוח לבצע מצב טיסה או כיבוי והדלקה.","img":null},{"text":"בדוק שוב גלישה.","img":null}],"images":[]},{"num":"30","title":"שלב 9 - איפוס הגדרות רשת","items":[{"text":"אם כל הבדיקות בוצעו ועדיין אין גלישה, ניתן לבצע איפוס הגדרות רשת במכשיר.","img":null},{"text":"יש להסביר ללקוח לפני הפעולה כי האיפוס עשוי למחוק הגדרות רשת שמורות במכשיר.","img":null},{"text":"לאחר האיפוס:","img":null},{"text":"ודא שנתונים סלולריים פעילים.","img":null},{"text":"ודא שנדידת נתונים פעילה.","img":null},{"text":"ודא שהמכשיר נרשם לרשת.","img":null},{"text":"בדוק שוב גלישה.","img":null}],"images":[]},{"num":"31","title":"שלב 10 - התקלה לא נפתרה","items":[{"text":"אם בוצעו כל השלבים ועדיין אין גלישה:","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"32","title":"E-01 - העברה למומחה בתקלת חו\"ל","items":[{"text":"יש להעביר למומחה את תוצאות הבדיקות שכבר בוצעו כדי למנוע ביצוע חוזר של אותו תהליך מול הלקוח.","img":null}],"images":[]},{"num":"33","title":"זרימת הטיפול בקיצור","items":[{"text":"האם המכשיר רשום לרשת?","img":null},{"text":"לא","img":null},{"text":"R-01 ← אין קליטה או רישום לרשת בחו\"ל","img":null},{"text":"כן","img":null},{"text":"↓","img":null},{"text":"האם התקלה רק באפליקציה אחת?","img":null},{"text":"כן","img":null},{"text":"R-03 ← תקלה באפליקציה מסוימת בחו\"ל","img":null},{"text":"לא","img":null},{"text":"↓","img":null},{"text":"בדיקות מערכת וחבילה","img":null},{"text":"↓","img":null},{"text":"נתונים סלולריים + נדידת נתונים + קו נכון לגלישה","img":null},{"text":"↓","img":null},{"text":"בדיקת APN","img":null},{"text":"↓","img":null},{"text":"בדיקת זהות רשת","img":null},{"text":"↓","img":null},{"text":"בחירת רשת ידנית","img":null},{"text":"↓","img":null},{"text":"רענון מכשיר","img":null},{"text":"↓","img":null},{"text":"ריענון SIM במערכת","img":null},{"text":"↓","img":null},{"text":"איפוס הגדרות רשת","img":null},{"text":"↓","img":null},{"text":"עדיין לא עובד","img":null},{"text":"E-01 ← העברה למומחה","img":null}],"images":[]}],"track":{"state":"קיים","source":"תקלת גלישה בחו\"ל + צ'קליסט Roaming","gap":"לתקן הפניה ל-O-03 הישן: בחירת קו כלולה ב-O-02; ריענון SIM ללא מסמך","priority":""},"status":"published","source":{"name":"R-02 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-02.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-02 - אין גלישה בחול.docx"};

window.dynamicDocs['pdf_014'] = {"id":"pdf_014","topic":"R-03 · תקלה באפליקציה מסוימת בחו\"ל.","cat":"intl","docType":"pdf","kind":"R","desc":"הלקוח בחו\"ל, מחובר לרשת ומצליח לגלוש, אך אפליקציה מסוימת אינה עובדת (למשל וואטסאפ או אפליקציית ניווט)","tags":["חו\"ל","אפליקציה","וואטסאפ","חוסך נתונים"],"stages":[{"num":"1","title":"מידע כללי","items":[{"text":"תקלה באפליקציה מסוימת בחו\"ל","img":null}],"images":[]},{"num":"2","title":"מתי משתמשים במסמך?","items":[{"text":"הלקוח נמצא בחו\"ל, מחובר לרשת ומצליח לגלוש, אך אפליקציה מסוימת אינה עובדת.","img":null},{"text":"לדוגמה:","img":null},{"text":"וואטסאפ אינו מתחבר.","img":null},{"text":"אפליקציית ניווט אינה נטענת.","img":null},{"text":"אפליקציה מסוימת אינה מצליחה להשתמש באינטרנט.","img":null},{"text":"שאר האפליקציות והגלישה בדפדפן פועלות.","img":null}],"images":[]},{"num":"3","title":"שלב 1 - ודא שהתקלה אכן נקודתית","items":[{"text":"שאל:","img":null},{"text":"\"האם אתה מצליח לגלוש בדפדפן או להשתמש באפליקציות אחרות?\"","img":null},{"text":"לא","img":null},{"text":"התקלה אינה באפליקציה בלבד.","img":null},{"text":"→ חזור למסלול:","img":null}],"images":[]},{"num":"4","title":"R-02 - אין גלישה בחו\"ל","items":[{"text":"כן","img":null},{"text":"הגלישה הסלולרית פעילה.","img":null},{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"5","title":"שלב 2 - סגור ופתח מחדש את האפליקציה","items":[{"text":"הנחה את הלקוח לסגור את האפליקציה לחלוטין ולפתוח אותה מחדש.","img":null},{"text":"בדוק שוב.","img":null}],"images":[]},{"num":"6","title":"האפליקציה עובדת","items":[{"text":"הטיפול הסתיים.","img":null}],"images":[]},{"num":"7","title":"עדיין לא עובדת","items":[{"text":"המשך.","img":null}],"images":[]},{"num":"8","title":"שלב 3 - בדיקת הרשאת שימוש בנתונים סלולריים","items":[{"text":"ודא שהאפליקציה מורשית להשתמש בנתונים סלולריים.","img":null}],"images":[]},{"num":"9","title":"אייפון","items":[{"text":"הגדרות","img":null},{"text":"סלולרי","img":null},{"text":"אתר את האפליקציה ברשימה.","img":null},{"text":"ודא שהאפשרות לשימוש בנתונים סלולריים פעילה.","img":null}],"images":[]},{"num":"10","title":"אנדרואיד","items":[{"text":"הנתיב עשוי להשתנות לפי יצרן וגרסת מערכת.","img":null},{"text":"היכנס להגדרות האפליקציה ובדוק שהשימוש בנתונים סלולריים אינו חסום.","img":null},{"text":"אם האפשרות קיימת, ודא שאין הגבלה על:","img":null},{"text":"נתונים סלולריים.","img":null},{"text":"שימוש בנתונים ברקע.","img":null}],"images":[]},{"num":"11","title":"נמצאה חסימה","items":[{"text":"הפעל את השימוש בנתונים.","img":null},{"text":"פתח מחדש את האפליקציה ובדוק.","img":null}],"images":[]},{"num":"12","title":"ההרשאות תקינות","items":[{"text":"המשך.","img":null}],"images":[]},{"num":"13","title":"שלב 4 - בדוק האם קיימת מגבלת נתונים במכשיר","items":[{"text":"במכשירי אנדרואיד בדוק האם מופעל:","img":null},{"text":"\"חוסך נתונים\"","img":null},{"text":"או שהוגדרה הגבלת נתונים לאפליקציה.","img":null},{"text":"אם קיימת הגבלה:","img":null},{"text":"בטל אותה זמנית ובדוק שוב את האפליקציה.","img":null}],"images":[]},{"num":"14","title":"שלב 5 - בדוק האם התקלה היא בשירות עצמו","items":[{"text":"בדוק עם הלקוח:","img":null},{"text":"\"האם האפליקציה מציגה הודעת שגיאה מסוימת?\"","img":null},{"text":"אם שאר שירותי הגלישה עובדים ורק האפליקציה אינה מתחברת, ייתכן שמקור התקלה הוא באפליקציה או בשירות שאליו היא מתחברת ולא ברשת wecom","img":null},{"text":"אין לבצע שינויי רשת נוספים כאשר:","img":null},{"text":"הדפדפן גולש.","img":null},{"text":"אפליקציות אחרות עובדות.","img":null},{"text":"המכשיר מחובר לרשת.","img":null},{"text":"נתונים סלולריים פעילים.","img":null}],"images":[]},{"num":"15","title":"שלב 6 - ניסיון נוסף","items":[{"text":"אם ניתן:","img":null},{"text":"סגור ופתח מחדש את האפליקציה.","img":null},{"text":"בדוק אם קיים עדכון לאפליקציה.","img":null},{"text":"בצע כיבוי והדלקה של המכשיר.","img":null},{"text":"נסה שוב.","img":null},{"text":"עדיין לא עובד?","img":null},{"text":"אם הגלישה ושאר האפליקציות תקינות:","img":null},{"text":"הסבר ללקוח:","img":null},{"text":"\"החיבור הסלולרי במכשיר תקין ואפליקציות אחרות מצליחות להתחבר לאינטרנט. נראה שהתקלה ממוקדת באפליקציה הספציפית. מומלץ לבדוק את הגדרות האפליקציה או לפנות לתמיכה של ספק האפליקציה.\"","img":null},{"text":"אין להעביר למומחה תקשורת רק בשל תקלה באפליקציה אחת כאשר יתר שירותי הגלישה פועלים.","img":null}],"images":[]},{"num":"16","title":"זרימת הטיפול בקיצור","items":[{"text":"רק אפליקציה אחת לא עובדת ↓ בדוק גלישה בדפדפן / אפליקציה אחרת","img":null}],"images":[]},{"num":"17","title":"גם הם לא עובדים → R-02 אין גלישה בחו\"ל","items":[{"text":"הם עובדים ↓ סגירה ופתיחה של האפליקציה ↓ בדיקת הרשאת נתונים סלולריים ↓ בדיקת חוסך נתונים / הגבלת אפליקציה ↓ כיבוי והדלקה ↓ עדיין לא עובד ורק האפליקציה מושפעת תקלה נקודתית באפליקציה / הפניה לספק האפליקציה","img":null}],"images":[]}],"track":{"state":"קיים","source":"תקלת גלישה בחו\"ל + השלמה מקצועית","gap":"נדרש אימות תסריט סיום והפניה לספק האפליקציה","priority":""},"status":"published","source":{"name":"R-03 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-03.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-03 - תקלה באפליקציה מסוימת בחול.docx"};

window.dynamicDocs['pdf_015'] = {"id":"pdf_015","topic":"R-04 · תקלות שיחות בחו\"ל","cat":"intl","docType":"pdf","kind":"R","desc":"הלקוח בחו\"ל, המכשיר רשום לרשת סלולרית, אך קיימת תקלה בשיחות יוצאות, בשיחות נכנסות או בשניהם","tags":["חו\"ל","שיחות","VoLTE","קידומת","CSP 19"],"stages":[{"num":"1","title":"מתי משתמשים במסמך?","items":[{"text":"הלקוח נמצא בחו\"ל, המכשיר רשום לרשת סלולרית, אך קיימת תקלה בשיחות.","img":null},{"text":"התקלה יכולה להיות:","img":null},{"text":"שיחות יוצאות בלבד.","img":null},{"text":"שיחות נכנסות בלבד.","img":null},{"text":"שיחות יוצאות ונכנסות.","img":null},{"text":"אם המכשיר אינו רשום לרשת זרה:","img":null},{"text":"עבור למסלול \"אין קליטה או רישום לרשת בחו\"ל\".","img":null}],"images":[]},{"num":"2","title":"שלב 1 - תיחום התקלה","items":[{"text":"שאל:","img":null},{"text":"\"הבעיה היא בהוצאת שיחות, בקבלת שיחות או בשניהם?\"","img":null}],"images":[]},{"num":"3","title":"שיחות יוצאות בלבד","items":[{"text":"עבור למסלול א'.","img":null}],"images":[]},{"num":"4","title":"שיחות נכנסות בלבד","items":[{"text":"עבור למסלול ב'.","img":null}],"images":[]},{"num":"5","title":"גם שיחות יוצאות וגם שיחות נכנסות","items":[{"text":"התחל בבדיקות המשותפות ולאחר מכן בצע את שני המסלולים.","img":null}],"images":[]},{"num":"6","title":"שלב 2 - בדיקות משותפות","items":[{"text":"לפני טיפול בשיחות ודא:","img":null},{"text":"שירותי נדידה פעילים במערכת.","img":null},{"text":"המכשיר רשום לרשת סלולרית בחו\"ל.","img":null},{"text":"הלקוח מחובר למפעיל מאושר במדינה שבה הוא נמצא.","img":null},{"text":"לאחר שינוי שבוצע במערכת, בוצע רענון באמצעות מצב טיסה או כיבוי והדלקה.","img":null},{"text":"אם אחד מהתנאים אינו תקין, טפל בו לפני המשך אבחון השיחות.","img":null}],"images":[]},{"num":"7","title":"מסלול א' - לא ניתן להוציא שיחות","items":[],"images":[]},{"num":"8","title":"שלב 1 - בדיקת אופן החיוג","items":[{"text":"ברר לאיזה יעד הלקוח מנסה לחייג.","img":null},{"text":"אם מדובר בחיוג לישראל, יש לבדוק את סוג הרשת שאליה המכשיר מחובר.","img":null},{"text":"ברשת שתומכת בשיחות על גבי דור רביעי:","img":null},{"text":"VoLTE","img":null},{"text":"לפי מסמך המקור, אין צורך להוסיף קידומת מדינה בחיוג לישראל.","img":null},{"text":"ברשת הפועלת בדור שלישי, מסמך המקור מנחה לבצע חיוג עם קידומת המדינה.","img":null},{"text":"לדוגמה לחיוג לישראל:","img":null},{"text":"+972","img":null},{"text":"אם החיוג בוצע באופן שאינו מתאים לרשת, תקן את אופן החיוג ובדוק שוב.","img":null}],"images":[]},{"num":"9","title":"שלב 2 - בדיקת הרשת המארחת","items":[{"text":"אם עדיין לא ניתן להוציא שיחה:","img":null},{"text":"בדוק האם הרשת שאליה מחובר הלקוח תומכת בשירותי השיחות הנדרשים.","img":null},{"text":"אם קיים חשד שהרשת אינה מתאימה:","img":null},{"text":"עבור למסמך \"בחירת רשת ידנית בחו\"ל\".","img":null},{"text":"נסה מפעיל מאושר נוסף ובדוק שוב.","img":null}],"images":[]},{"num":"10","title":"שלב 3 - בדיקת תאימות המכשיר","items":[{"text":"אם הלקוח נמצא בארצות הברית:","img":null},{"text":"עבור למסמך \"תאימות מכשירים ורשתות בארצות הברית\".","img":null},{"text":"במסמך המקור מצוין שבחלק מהמכשירים קיימת תלות בתמיכה בדור הרשת ובשיחות על גבי דור רביעי.","img":null},{"text":"עדיין לא ניתן להוציא שיחות?","img":null},{"text":"אם:","img":null},{"text":"המכשיר רשום לרשת.","img":null},{"text":"אופן החיוג תקין.","img":null},{"text":"הרשת מתאימה.","img":null},{"text":"המכשיר תואם.","img":null},{"text":"והתקלה נמשכת:","img":null},{"text":"עבור למסמך \"העברה למומחה בתקלת חו\"ל\".","img":null}],"images":[]},{"num":"11","title":"מסלול ב' - לא מתקבלות שיחות","items":[],"images":[]},{"num":"12","title":"שלב 1 - ודא ששיחות יוצאות עובדות","items":[{"text":"שאל:","img":null},{"text":"\"אתה מצליח להוציא שיחות?\"","img":null},{"text":"לא","img":null},{"text":"התקלה אינה מוגבלת לשיחות נכנסות.","img":null},{"text":"בצע גם את מסלול א' - שיחות יוצאות.","img":null},{"text":"כן","img":null},{"text":"המשך.","img":null}],"images":[]},{"num":"13","title":"שלב 2 - רענון ובדיקה חוזרת","items":[{"text":"אם בוצע שינוי במערכת:","img":null},{"text":"הנחה את הלקוח לבצע:","img":null},{"text":"מצב טיסה והחזרה למצב רגיל.","img":null},{"text":"או כיבוי והדלקה.","img":null},{"text":"לאחר מכן בצע שיחת בדיקה נכנסת.","img":null},{"text":"עדיין לא מתקבלות שיחות?","img":null},{"text":"אם:","img":null},{"text":"המכשיר רשום לרשת.","img":null},{"text":"שיחות יוצאות תקינות.","img":null},{"text":"הפרופיל תקין.","img":null},{"text":"בוצע רענון.","img":null},{"text":"והתקלה נמשכת: עבור למסמך \"העברה למומחה בתקלת חו\"ל\".","img":null}],"images":[]},{"num":"14","title":"מסלול ג' - אין שיחות יוצאות וגם אין שיחות נכנסות","items":[{"text":"כאשר שני הכיוונים אינם עובדים:","img":null},{"text":"ודא שהמכשיר רשום לרשת.","img":null},{"text":"בדוק שירותי נדידה.","img":null},{"text":"בצע את מסלול א' - שיחות יוצאות.","img":null},{"text":"בצע את מסלול ב' - שיחות נכנסות.","img":null},{"text":"אם שני הכיוונים עדיין אינם עובדים, העבר למומחה.","img":null}],"images":[]},{"num":"15","title":"זרימת הטיפול בקיצור","items":[{"text":"האם המכשיר רשום לרשת?","img":null},{"text":"לא","img":null},{"text":"→ \"אין קליטה או רישום לרשת בחו\"ל\"","img":null},{"text":"כן","img":null},{"text":"↓","img":null},{"text":"מה לא עובד?","img":null}],"images":[]},{"num":"16","title":"שיחות יוצאות","items":[{"text":"→ בדיקת חיוג → בדיקת סוג רשת → בדיקת מפעיל → בדיקת תאימות מכשיר → הסלמה אם נדרש","img":null}],"images":[]},{"num":"17","title":"שיחות נכנסות","items":[{"text":"→ בדיקת שיחות יוצאות → בדיקת פרופיל → רענון → הסלמה אם נדרש","img":null}],"images":[]},{"num":"18","title":"שני הכיוונים","items":[{"text":"→ ביצוע שני המסלולים","img":null}],"images":[]}],"track":{"state":"קיים","source":"צ'קליסט Roaming + מסמך רישום","gap":"אוחדו שיחות יוצאות ונכנסות; אין מסמך CSP נפרד","priority":""},"status":"published","source":{"name":"R-04 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-04.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-04 תקלת שיחות בחול.docx"};

window.dynamicDocs['pdf_016'] = {"id":"pdf_016","topic":"R-05 · תקלות הודעות בחו\"ל","cat":"intl","docType":"pdf","kind":"R","desc":"הלקוח בחו\"ל, המכשיר רשום לרשת סלולרית, אך קיימת תקלה בשליחה או בקבלה של הודעות, כולל קודי אימות","tags":["חו\"ל","SMS","הודעות","קוד אימות"],"stages":[{"num":"1","title":"מתי משתמשים במסמך?","items":[{"text":"הלקוח נמצא בחו\"ל, המכשיר רשום לרשת סלולרית, אך קיימת תקלה בשליחה או בקבלה של הודעות.","img":null},{"text":"התקלה יכולה להיות:","img":null},{"text":"לא מתקבלות הודעות.","img":null},{"text":"לא ניתן לשלוח הודעות.","img":null},{"text":"לא מתקבלות ולא נשלחות הודעות.","img":null},{"text":"לא מתקבל קוד אימות בהודעה.","img":null},{"text":"אם המכשיר אינו רשום לרשת זרה:","img":null},{"text":"עבור למסלול:","img":null}],"images":[]},{"num":"2","title":"R-01 אין קליטה או רישום לרשת בחו\"ל","items":[],"images":[]},{"num":"3","title":"שלב 1 - תיחום התקלה","items":[{"text":"שאל: \"הבעיה היא בשליחת הודעות, בקבלת הודעות או בשניהם?\"","img":null}],"images":[]},{"num":"4","title":"שליחה בלבד","items":[{"text":"המשך למסלול א'.","img":null}],"images":[]},{"num":"5","title":"קבלה בלבד","items":[{"text":"המשך למסלול ב'.","img":null}],"images":[]},{"num":"6","title":"גם שליחה וגם קבלה","items":[{"text":"בצע את הבדיקות המשותפות ולאחר מכן את שני המסלולים.","img":null}],"images":[]},{"num":"7","title":"שלב 2 - בדיקות בסיס משותפות","items":[{"text":"ודא:","img":null},{"text":"שירותי הנדידה פעילים בקו.","img":null},{"text":"המכשיר רשום לרשת סלולרית בחו\"ל.","img":null},{"text":"המכשיר מחובר למפעיל מאושר במדינה.","img":null}],"images":[]},{"num":"8","title":"לאחר שינוי במערכת בוצע רענון באמצעות מצב טיסה או כיבוי והדלקה.","items":[{"text":"אם אחד מהתנאים אינו תקין:","img":null},{"text":"טפל בו לפני המשך אבחון ההודעות.","img":null}],"images":[]},{"num":"9","title":"שלב 3 - האם שיחות עובדות?","items":[{"text":"שאל:","img":null},{"text":"\"אתה מצליח להוציא ולקבל שיחות?\"","img":null},{"text":"לא","img":null},{"text":"ייתכן שהתקלה אינה מוגבלת להודעות.","img":null},{"text":"עבור למסלול:","img":null}],"images":[]},{"num":"10","title":"R-04 - תקלות שיחות בחו\"ל","items":[{"text":"כן","img":null},{"text":"המשך באבחון ההודעות.","img":null}],"images":[]},{"num":"11","title":"מסלול א' - לא ניתן לשלוח הודעות","items":[],"images":[]},{"num":"12","title":"שלב 1 - בדיקת סוג ההודעה","items":[{"text":"ברר:","img":null},{"text":"\"האם הבעיה קיימת בכל הודעת SMS או רק בהודעה ליעד מסוים?\"","img":null}],"images":[]},{"num":"13","title":"יעד מסוים בלבד","items":[{"text":"נסה לשלוח הודעה למספר נוסף.","img":null},{"text":"אם הודעות למספרים אחרים נשלחות:","img":null},{"text":"התקלה אינה כללית בשירות ההודעות.","img":null}],"images":[]},{"num":"14","title":"כל ההודעות נכשלות","items":[{"text":"המשך.","img":null}],"images":[]},{"num":"15","title":"שלב 2 - בדיקת הרשת המארחת","items":[{"text":"לפי מסמך המקור, יש משמעות לסוג הרשת שאליה מחובר הלקוח ולתמיכה שלה בשירותי שיחות והודעות.","img":null},{"text":"אם קיים חשד שהרשת המארחת אינה מתאימה:","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"16","title":"O-05 בחירת רשת ידנית בחו\"ל","items":[{"text":"נסה מפעיל מאושר נוסף.","img":null},{"text":"לאחר ההתחברות נסה לשלוח הודעה מחדש.","img":null}],"images":[]},{"num":"17","title":"שלב 3 - בדיקה חוזרת לאחר רענון","items":[{"text":"בצע:","img":null},{"text":"מצב טיסה והחזרה למצב רגיל.","img":null},{"text":"אם עדיין לא תקין:","img":null},{"text":"כיבוי והדלקה של המכשיר.","img":null},{"text":"נסה לשלוח הודעה נוספת.","img":null},{"text":"אם התקלה נמשכת לאחר השלמת הבדיקות הרלוונטיות במסלול זה, עבור ל־E-01 — העברה למומחה בתקלת חו״ל. תעד את כיוון התקלה, הרשת שאליה המכשיר מחובר, הבדיקות שבוצעו ותוצאותיהן.","img":null}],"images":[]},{"num":"18","title":"מסלול ב' - לא מתקבלות הודעות","items":[],"images":[]},{"num":"19","title":"שלב 1 - בדיקת הודעה רגילה","items":[{"text":"ברר האם הלקוח אינו מקבל:","img":null},{"text":"כל הודעת SMS","img":null},{"text":"או רק קוד אימות משירות מסוים.","img":null}],"images":[]},{"num":"20","title":"כל ההודעות אינן מתקבלות","items":[{"text":"המשך באבחון.","img":null}],"images":[]},{"num":"21","title":"רק קוד אימות אינו מתקבל","items":[{"text":"אין להסיק מיד שקיימת תקלה בשירות ההודעות.","img":null},{"text":"נסה תחילה לקבל הודעת SMS רגילה ממספר אחר.","img":null}],"images":[]},{"num":"22","title":"הודעה רגילה מתקבלת","items":[{"text":"השירות הסלולרי לקבלת הודעות עובד.","img":null},{"text":"המשך הטיפול בהתאם למסמך הייעודי של קודי אימות. סעיף 1 מסלול ב – נפנה ל","img":null}],"images":[]},{"num":"23","title":"גם הודעה רגילה אינה מתקבלת","items":[{"text":"המשך.","img":null}],"images":[]},{"num":"24","title":"שלב 2 - בדיקת סוג הרשת","items":[{"text":"אם ההודעות אינן מתקבלות:","img":null},{"text":"בדוק את הרשת שאליה המכשיר רשום ואת זהות הרשת בהתאם למסלול הטיפול בחו\"ל.","img":null},{"text":"אם נדרש שינוי מפעיל:","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"25","title":"O-05 בחירת רשת ידנית בחו\"ל","items":[],"images":[]},{"num":"26","title":"שלב 3 - רענון","items":[{"text":"בצע:","img":null},{"text":"מצב טיסה והחזרה למצב רגיל.","img":null},{"text":"אם עדיין לא תקין:","img":null},{"text":"כיבוי והדלקה.","img":null},{"text":"בצע שוב ניסיון לקבל הודעה.","img":null},{"text":"אם התקלה נמשכת לאחר השלמת הבדיקות הרלוונטיות במסלול זה, עבור ל־E-01 — העברה למומחה בתקלת חו״ל. תעד את כיוון התקלה, הרשת שאליה המכשיר מחובר, הבדיקות שבוצעו ותוצאותיהן.","img":null}],"images":[]},{"num":"27","title":"מסלול ג' - לא ניתן לשלוח ולא ניתן לקבל הודעות","items":[{"text":"אם שני הכיוונים אינם עובדים:","img":null},{"text":"ודא שהמכשיר רשום לרשת.","img":null},{"text":"ודא ששירותי נדידה פעילים.","img":null},{"text":"בדוק האם שיחות עובדות.","img":null},{"text":"בצע ניסיון מול מפעיל מאושר נוסף.","img":null},{"text":"בצע רענון למכשיר.","img":null},{"text":"בדוק שוב שליחה וקבלה.","img":null},{"text":"אם התקלה נמשכת:","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"28","title":"E-01 העברה למומחה בתקלת חו\"ל","items":[],"images":[]},{"num":"29","title":"סיום טיפול","items":[{"text":"לאחר שהודעות נשלחות ומתקבלות:","img":null},{"text":"ודא מול הלקוח שהשירות שבגינו פנה חזר לפעול.","img":null},{"text":"אם קיימת עדיין תקלה בשירות אחר:","img":null},{"text":"חזור למסמך:","img":null}],"images":[]},{"num":"30","title":"M-00 אבחון מרכזי לתקלות ושירות בחו\"ל","items":[],"images":[]},{"num":"31","title":"זרימת הטיפול בקיצור","items":[{"text":"המכשיר רשום לרשת?","img":null},{"text":"לא","img":null},{"text":"→ R-01 - אין קליטה או רישום לרשת בחו\"ל","img":null},{"text":"כן","img":null},{"text":"↓","img":null},{"text":"מה לא עובד?","img":null}],"images":[]},{"num":"32","title":"שליחת הודעות","items":[{"text":"→ בדיקת היקף התקלה → בדיקת רשת מארחת → בחירת מפעיל נוסף → רענון → הסלמה","img":null}],"images":[]},{"num":"33","title":"קבלת הודעות","items":[{"text":"→ האם מדובר בכל ההודעות או רק בקוד אימות → בדיקת SMS רגיל → בדיקת רשת וזהות → בחירת מפעיל נוסף → רענון → הסלמה","img":null}],"images":[]},{"num":"34","title":"גם שליחה וגם קבלה","items":[{"text":"→ ביצוע שני המסלולים","img":null}],"images":[]}],"track":{"state":"קיים","source":"צ'קליסט Roaming","gap":"נדרש אימות מקצועי של בדיקות מערכת ייעודיות ל-SMS אם קיימות","priority":""},"status":"published","source":{"name":"R-05 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-05.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-05 - תקלות הודעות בחול.docx"};

window.dynamicDocs['pdf_017'] = {"id":"pdf_017","topic":"O-02 · 3O-02 בדיקה והפעלת נדידת נתונים במכשיר","cat":"intl","docType":"pdf","kind":"O","desc":"וידוא שנדידת נתונים פעילה במכשיר הלקוח בחו\"ל — בנוסף לבדיקת שירותי הנדידה בקו במערכות wecom","tags":["חו\"ל","נדידת נתונים","הגדרות מכשיר"],"stages":[],"body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לוודא שנדידת נתונים פעילה במכשיר הלקוח כאשר הוא נמצא בחו\"ל.","img":null},{"text":"הבדיקה במכשיר מתבצעת בנוסף לבדיקת שירותי הנדידה בקו במערכות wecom.","img":null}]},{"title":"לפני שמתחילים","ordered":false,"steps":[{"text":"ודא שהלקוח בחר את הקו של wecom לשימוש בנתונים סלולריים.","img":null},{"text":"אם קיימים שני קווים במכשיר, יש לבצע את הבדיקה על הקו של wecom","img":null}]},{"title":"אייפון","ordered":false,"steps":[{"text":"ודא שנתונים סלולריים פעילים.","img":null},{"text":"נתיב:","img":null},{"text":"הגדרות","img":null},{"text":"סלולרי נתונים סלולריים","img":null},{"text":"לאחר מכן ודא שנדידת נתונים פעילה.","img":null},{"text":"נתיב:","img":null},{"text":"הגדרות","img":null},{"text":"סלולרי אפשרויות נתונים סלולריים נדידת נתונים","img":null},{"text":"אם קיימים שני קווים:","img":null},{"text":"הגדרות","img":null},{"text":"סלולרי בחר את קו wecom אפשרויות נתונים סלולריים נדידת נתונים","img":null}]},{"title":"נדידת נתונים כבויה","ordered":false,"steps":[{"text":"הפעל את האפשרות.","img":null},{"text":"המתן מספר רגעים ובדוק שוב את הגלישה.","img":null}]},{"title":"נדידת נתונים פעילה","ordered":false,"steps":[{"text":"חזור למסלול התקלה והמשך לבדיקה הבאה.","img":null},{"text":"הנתיב תואם להנחיות העדכניות של אפל.","img":null}]},{"title":"סמסונג","ordered":false,"steps":[{"text":"ודא שנתונים סלולריים/נתונים ניידים פעילים.","img":null},{"text":"לאחר מכן:","img":null},{"text":"הגדרות","img":null},{"text":"חיבורים רשתות תקשורת סלולרית נדידת נתונים","img":null},{"text":"הפעל את \"נדידת נתונים\".","img":null}]},{"title":"האפשרות אפורה ולא ניתן להפעיל אותה","ordered":false,"steps":[{"text":"בדוק תחילה שנתונים סלולריים פעילים.","img":null},{"text":"הגדרות","img":null},{"text":"חיבורים שימוש בנתונים נתונים סלולריים/נתונים ניידים","img":null},{"text":"לאחר מכן חזור ל-\"נדידת נתונים\" והפעל אותה..","img":null}]},{"title":"שיאומי / רדמי / פוקו","ordered":false,"steps":[{"text":"בגרסאות החדשות:","img":null},{"text":"הגדרות","img":null},{"text":"רשתות סלולריות נדידת נתונים נדידה בינלאומית","img":null},{"text":"בחר אפשרות המאפשרת שימוש בנדידה.","img":null},{"text":"בחלק מהגרסאות הנתיב מופיע כך:","img":null},{"text":"הגדרות","img":null},{"text":"כרטיסי SIM ורשתות סלולריות נדידת נתונים","img":null},{"text":"הנתיב משתנה בין גרסאות המערכת, ולכן אם האפשרות אינה מופיעה יש לחפש בהגדרות את המונח \"נדידת נתונים\". ההנחיות הרשמיות של שיאומי מציגות את שני המבנים בהתאם לדגם ולגרסה.","img":null}]},{"title":"וואווי","ordered":false,"steps":[{"text":"הגדרות","img":null},{"text":"רשת סלולרית נתונים סלולריים","img":null},{"text":"בחר את כרטיס ה-SIM של wecom.","img":null},{"text":"הפעל:","img":null},{"text":"\"נדידת נתונים\"","img":null},{"text":"במכשיר עם שני כרטיסים יש לוודא שההגדרה מופעלת עבור הקו הנכון.","img":null},{"text":"הנתיב מאומת בהנחיות וואווי.","img":null}]},{"title":"גוגל פיקסל","ordered":false,"steps":[{"text":"הגדרות","img":null},{"text":"רשת ואינטרנט כרטיסי SIM","img":null},{"text":"בחר את קו wecom.","img":null},{"text":"הפעל:","img":null},{"text":"\"נתונים סלולריים\"","img":null},{"text":"ולאחר מכן:","img":null},{"text":"\"נדידה\"","img":null},{"text":"בחלק מגרסאות המכשיר הנתיב מופיע דרך:","img":null},{"text":"הגדרות","img":null},{"text":"רשת ואינטרנט אינטרנט הגדרות הקו נדידה","img":null},{"text":"הנתיב עשוי להשתנות מעט בין גרסאות אנדרואיד. ההנחיות הרשמיות של גוגל מאשרות שהגדרת הנדידה נמצאת בהגדרות כרטיס ה-SIM או הרשת הסלולרית.","img":null}]},{"title":"מוטורולה","ordered":false,"steps":[{"text":"הגדרות","img":null},{"text":"רשת ואינטרנט כרטיסי SIM ורשת סלולרית","img":null},{"text":"בחר את קו wecom.","img":null},{"text":"הפעל:","img":null},{"text":"\"נתונים סלולריים\"","img":null},{"text":"ולאחר מכן:","img":null},{"text":"\"נדידה\"","img":null},{"text":"בחלק מהדגמים הנתיב מוצג כך:","img":null},{"text":"הגדרות","img":null},{"text":"רשת ואינטרנט רשת סלולרית נדידה","img":null},{"text":"מוטורולה מציינת בהנחיותיה שהאפשרות \"נדידה\" מאפשרת התחברות לשירותי נתונים בעת נדידה.","img":null}]},{"title":"רילמי","ordered":false,"steps":[{"text":"הגדרות","img":null},{"text":"רשת סלולרית בחר את כרטיס ה-SIM של wecom נדידת נתונים","img":null},{"text":"הפעל את האפשרות.","img":null},{"text":"בגרסאות שונות של הממשק שמות התפריטים עשויים להשתנות.","img":null},{"text":"אם \"נדידת נתונים\" אינה מופיעה במסך הראשי של הקו, חפש אותה באמצעות שורת החיפוש בהגדרות.","img":null},{"text":"מקור התמיכה של רילמי מציג את הנתיב דרך הגדרות הרשת הסלולרית ובחירת כרטיס ה-SIM.","img":null}]},{"title":"אופו","ordered":false,"steps":[{"text":"הגדרות המכשירים משתנות בין גרסאות הממשק.","img":null},{"text":"הנתיב הצפוי הוא:","img":null},{"text":"הגדרות","img":null},{"text":"רשת סלולרית בחר את כרטיס ה-SIM של wecom נדידת נתונים","img":null},{"text":"אם האפשרות אינה מופיעה:","img":null},{"text":"חפש בהגדרות:","img":null},{"text":"\"נדידת נתונים\"","img":null},{"text":"אין באפשרותי לאשר נתיב אחיד ועדכני לכל גרסאות מכשירי אופו ממקור רשמי אחד.","img":null},{"text":"לכן אין להציג לנציג נתיב קשיח אם התפריטים במכשיר שונים.","img":null}]},{"title":"וואן פלוס","ordered":false,"steps":[{"text":"במכשירים החדשים מבנה ההגדרות דומה למכשירי אופו.","img":null},{"text":"הנתיב עשוי להופיע דרך:","img":null},{"text":"הגדרות","img":null},{"text":"רשת סלולרית בחר את כרטיס ה-SIM של wecom נדידת נתונים","img":null},{"text":"בגרסאות ישנות יותר ניתן למצוא את ההגדרה תחת הגדרות הרשת וכרטיס ה-SIM.","img":null},{"text":"אין באפשרותי לאשר נתיב אחיד אחד לכל גרסאות מערכת ההפעלה של וואן פלוס.","img":null},{"text":"אם האפשרות אינה מופיעה:","img":null},{"text":"חפש בהגדרות:","img":null},{"text":"\"נדידת נתונים\"","img":null}]},{"title":"מכשיר אנדרואיד אחר","ordered":false,"steps":[{"text":"אם היצרן אינו מופיע במסמך:","img":null},{"text":"פתח \"הגדרות\".","img":null},{"text":"חפש בשורת החיפוש:","img":null},{"text":"\"נדידת נתונים\"","img":null},{"text":"אם לא נמצאה האפשרות, חפש:","img":null},{"text":"\"נדידה\"","img":null},{"text":"ודא שההגדרה מופעלת עבור כרטיס ה-SIM של wecom.","img":null}]},{"title":"לאחר הפעלת נדידת נתונים","ordered":false,"steps":[{"text":"בדוק שוב האם הלקוח מצליח לגלוש.","img":null}]},{"title":"הגלישה תקינה","ordered":false,"steps":[{"text":"הטיפול הסתיים.","img":null}]},{"title":"עדיין אין גלישה","ordered":false,"steps":[{"text":"חזור למסלול:","img":null},{"text":"\"R-02 - אין גלישה בחו\"ל\"","img":null},{"text":"והמשך לבדיקה הבאה.","img":null}]},{"title":"חשוב לנציג","ordered":false,"steps":[{"text":"הפעלת \"נדידת נתונים\" במכשיר מאפשרת שימוש בגלישה סלולרית בזמן שהמכשיר מחובר לרשת זרה.","img":null},{"text":"היא אינה מחליפה את בדיקת שירותי הנדידה בקו במערכות wecom.","img":null},{"text":"לכן סדר הבדיקה הוא:","img":null},{"text":"שירותי נדידה פעילים במערכת ↓ המכשיר רשום לרשת זרה ↓ נתונים סלולריים פעילים ↓ נדידת נתונים פעילה ↓ בדיקת גלישה","img":null}]}]},"track":{"state":"קיים","source":"מסמכי החו\"ל + השלמת תפעול לפי יצרנים","gap":"כולל בחירת קו wecom לגלישה במכשיר עם שני קווים","priority":""},"status":"published","source":{"name":"O-02 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-02.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-02 - בדיקה והפעלת נדידת נתונים במכשיר.docx"};

window.dynamicDocs['pdf_018'] = {"id":"pdf_018","topic":"O-03 · בדיקה והגדרת APN בחו\"ל","cat":"intl","docType":"pdf","kind":"O","desc":"וידוא שהגדרת נקודת הגישה (APN) במכשיר תקינה כשהלקוח בחו\"ל ואינו מצליח לגלוש","tags":["חו\"ל","APN","גלישה","נקודת גישה"],"stages":[],"body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לוודא שהגדרת נקודת הגישה במכשיר תקינה כאשר הלקוח נמצא בחו\"ל ואינו מצליח לגלוש.","img":null},{"text":"יש להשתמש במסמך רק לאחר שווידאת:","img":null},{"text":"המכשיר רשום לרשת זרה.","img":null},{"text":"נתונים סלולריים פעילים.","img":null},{"text":"נדידת נתונים פעילה.","img":null},{"text":"קו wecom נבחר לגלישה.","img":null}]},{"title":"ערך APN נדרש","ordered":false,"steps":[{"text":"לפי מסמך המקור:","img":null}]},{"title":"UINTERNET PARTNER","ordered":false,"steps":[{"text":"אם במכשיר קיימת נקודת גישה אחרת או שאין נקודת גישה פעילה, המשך לפי סוג המכשיר.","img":null}]},{"title":"אייפון","ordered":false,"steps":[]},{"title":"שלב 1 - בדיקת הגדרת APN","ordered":true,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"סלולרי רשת נתונים סלולרית","img":null},{"text":"בדוק את שדה ה־APN.","img":null},{"text":"אם מופיע הערך הנדרש:","img":null}]},{"title":"UINTERNET PARTNER","ordered":false,"steps":[{"text":"חזור למסלול הגלישה והמשך לבדיקה הבאה.","img":null}]},{"title":"הערך אינו תקין","ordered":false,"steps":[{"text":"אם ניתן לערוך את השדה:","img":null},{"text":"הזן את הערך הנדרש ושמור.","img":null},{"text":"לאחר מכן:","img":null},{"text":"הפעל מצב טיסה.","img":null},{"text":"החזר למצב רגיל.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"לא מופיעה אפשרות לעריכת APN","ordered":false,"steps":[{"text":"בחלק ממכשירי האייפון הגדרת ה־APN מנוהלת אוטומטית על ידי המפעיל ולא ניתן לערוך אותה ידנית.","img":null},{"text":"במקרה כזה אין לבצע שינוי ידני.","img":null},{"text":"חזור למסלול הטיפול והמשך לבדיקה הבאה.","img":null}]},{"title":"סמסונג","ordered":false,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"חיבורים רשתות תקשורת סלולרית שמות נקודות גישה","img":null},{"text":"בדוק איזו נקודת גישה מסומנת כפעילה.","img":null}]},{"title":"קיימת נקודת גישה תקינה","ordered":false,"steps":[{"text":"ודא שה־APN תואם לערך:","img":null}]},{"title":"UINTERNET PARTNER","ordered":false,"steps":[{"text":"אם תקין:","img":null},{"text":"חזור למסלול הגלישה.","img":null},{"text":"המשך לבדיקה הבאה.","img":null}]},{"title":"הערך אינו תקין","ordered":false,"steps":[{"text":"בדוק האם קיימת נקודת גישה מתאימה ברשימה.","img":null},{"text":"אם קיימת:","img":null},{"text":"בחר אותה.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"אין נקודת גישה מתאימה","ordered":false,"steps":[{"text":"בצע איפוס לברירת מחדל:","img":null},{"text":"שמות נקודות גישה","img":null},{"text":"תפריט איפוס לברירת מחדל","img":null},{"text":"לאחר האיפוס:","img":null},{"text":"ודא שנקודת הגישה המתאימה הופיעה.","img":null},{"text":"בחר אותה אם נדרש.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"שיאומי / רדמי / פוקו","ordered":false,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"כרטיסי SIM ורשתות סלולריות בחר את קו wecom שמות נקודות גישה","img":null},{"text":"בחלק מהגרסאות הנתיב עשוי להופיע תחת:","img":null},{"text":"הגדרות","img":null},{"text":"רשתות סלולריות קו wecom APN","img":null},{"text":"בדוק האם קיימת נקודת גישה תקינה.","img":null}]},{"title":"קיימת","ordered":false,"steps":[{"text":"בחר אותה ובדוק גלישה.","img":null}]},{"title":"אינה קיימת או ההגדרה אינה תקינה","ordered":false,"steps":[{"text":"בצע איפוס להגדרות ברירת מחדל.","img":null},{"text":"לאחר מכן:","img":null},{"text":"בדוק שה־APN המתאים הופיע.","img":null},{"text":"בחר אותו.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"וואווי","ordered":false,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"רשת סלולרית נתונים סלולריים שמות נקודות גישה","img":null},{"text":"בחר את קו wecom.","img":null},{"text":"בדוק האם קיימת נקודת גישה פעילה ומתאימה.","img":null},{"text":"אם ההגדרה אינה תקינה:","img":null},{"text":"בצע איפוס להגדרות ברירת מחדל אם האפשרות קיימת.","img":null},{"text":"בחר את נקודת הגישה המתאימה.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"גוגל פיקסל","ordered":false,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"רשת ואינטרנט SIM בחר את קו wecom שמות נקודות גישה","img":null},{"text":"בדוק את נקודת הגישה הפעילה.","img":null},{"text":"אם אינה תקינה:","img":null},{"text":"בצע איפוס לברירת מחדל.","img":null},{"text":"ודא שה־APN המתאים מופיע.","img":null},{"text":"בחר אותו.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"אופו / רילמי / וואן פלוס","ordered":false,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"רשת סלולרית בחר את קו wecom שמות נקודות גישה","img":null},{"text":"בחלק מהגרסאות שמות התפריטים שונים.","img":null},{"text":"אם אינך מוצא את האפשרות:","img":null},{"text":"חפש בהגדרות:","img":null},{"text":"\"APN\"","img":null},{"text":"או:","img":null},{"text":"\"שמות נקודות גישה\"","img":null},{"text":"בדוק:","img":null},{"text":"שקיימת נקודת גישה פעילה.","img":null},{"text":"שהערך תואם להגדרת wecom.","img":null},{"text":"אם אינה תקינה:","img":null},{"text":"בצע איפוס לברירת מחדל אם האפשרות קיימת.","img":null},{"text":"בחר את נקודת הגישה המתאימה.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"מכשיר אנדרואיד אחר","ordered":false,"steps":[{"text":"אם היצרן אינו מופיע במסמך:","img":null},{"text":"פתח \"הגדרות\".","img":null},{"text":"חפש: \"APN\"","img":null},{"text":"אם לא נמצא, חפש: \"שמות נקודות גישה\"","img":null},{"text":"בחר את קו wecom","img":null},{"text":"בדוק שקיימת נקודת גישה תקינה.","img":null},{"text":"אם נדרש, בצע איפוס לברירת מחדל.","img":null},{"text":"בדוק שוב גלישה.","img":null}]},{"title":"לאחר שינוי APN","ordered":false,"steps":[{"text":"בצע:","img":null},{"text":"מצב טיסה והחזרה למצב רגיל.","img":null},{"text":"אם עדיין לא תקין:","img":null},{"text":"כיבוי והדלקה של המכשיר.","img":null},{"text":"לאחר מכן בדוק שוב גלישה.","img":null}]},{"title":"הגלישה עובדת","ordered":false,"steps":[{"text":"חזור למסלול R-02 וסיים טיפול.","img":null}]},{"title":"עדיין אין גלישה","ordered":false,"steps":[{"text":"חזור למסלול:","img":null}]},{"title":"R-02 - אין גלישה בחו\"ל","ordered":false,"steps":[{"text":"והמשך לבדיקה הבאה.","img":null}]},{"title":"חשוב לנציג","ordered":false,"steps":[{"text":"אין לשנות ערכי APN שאינם מופיעים במקור המאושר של wecom.","img":null},{"text":"אם הגדרת ה־ APN מנוהלת אוטומטית על ידי המפעיל ואינה ניתנת לעריכה, אין לבצע שינוי ידני.","img":null}]}]},"track":{"state":"קיים","source":"תקלת גלישה בחו\"ל + צ'קליסט Roaming","gap":"לאמת את ערך ה-APN והאם הוא ניתן לעריכה בכל סוג מכשיר","priority":""},"status":"published","source":{"name":"O-03 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-03.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-03 - הגדרת APN בחול.docx"};

window.dynamicDocs['pdf_019'] = {"id":"pdf_019","topic":"O-04 · תפעול STK ושינוי זהות רשת","cat":"intl","docType":"pdf","kind":"O","desc":"מתי נדרש לבצע שינוי זהות רשת באמצעות תפריט ה-SIM (STK), ומתי אין לבצע פעולה זו","tags":["חו\"ל","STK","זהות רשת","פרטנר"],"stages":[],"body":{"groups":[{"title":"מטרת הפעולה","ordered":false,"steps":[{"text":"סיוע למכשיר בהתבייתות על רשת בחו״ל כאשר התפעול הראשוני לא פתר את התקלה, או בחזרה לישראל כאשר הנדידה אינה עוברת לישראל.","img":null}]},{"title":"לפני תחילת התפעול","ordered":false,"steps":[{"text":"לא ניתן לבצע את הפעולה במהלך שיחה. יש לסיים את השיחה בקו המטופל לפני הביצוע.","img":null},{"text":"במסלול טיפול בחו״ל: אם כבר קיימת זהות פרטנר במכשיר, אין לנווט לתפריט STK. יש לחזור למסלול התקלה ולהמשיך לבדיקה הבאה.","img":null}]},{"title":"כניסה לתפריט","ordered":false,"steps":[{"text":"אייפון: הגדרות ← סלולרי ← בחירת ה־SIM או ה־eSIM של wecom ← יישומי סים.","img":null},{"text":"אנדרואיד: פותחים את האפליקציה המובנית של שירותי ה־SIM. היא עשויה להופיע בשם SIM Toolkit, wecom, ערכת סים או we.","img":null}]},{"title":"תפעול בחו״ל","ordered":false,"steps":[{"text":"1. בוחרים MULTI ACCOUNT.","img":null},{"text":"2. בוחרים SELECTION MODE.","img":null},{"text":"3. בוחרים MANUAL.","img":null},{"text":"4. בוחרים ROAMING.","img":null},{"text":"5. חוזרים למסך MULTI ACCOUNT ונכנסים שוב ל־SELECTION MODE.","img":null},{"text":"6. בוחרים AUTOMATIC.","img":null},{"text":"7. מכבים ומפעילים את המכשיר.","img":null}]},{"title":"תפעול בישראל כאשר הנדידה אינה עוברת לישראל","ordered":false,"steps":[{"text":"1. בוחרים MULTI ACCOUNT.","img":null},{"text":"2. בוחרים SELECTION MODE.","img":null},{"text":"3. בוחרים MANUAL.","img":null},{"text":"4. בוחרים WE.","img":null},{"text":"5. חוזרים למסך MULTI ACCOUNT ונכנסים שוב ל־SELECTION MODE.","img":null},{"text":"6. בוחרים AUTOMATIC.","img":null},{"text":"7. מכבים ומפעילים את המכשיר.","img":null}]}]},"track":{"state":"שחר להשלים","source":"צ'קליסט Roaming","gap":"חסרים נתיב STK, ערך לבחירה, חיווי הצלחה ו-SIM מול eSIM","priority":"גבוהה"},"status":"published","owner":"שחר","source":{"name":"O-04 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-04.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-04  תפעול_STK_בחול.docx"};

window.dynamicDocs['pdf_020'] = {"id":"pdf_020","topic":"O-05 · בחירת רשת ידנית בחו\"ל.","cat":"intl","docType":"pdf","kind":"O","desc":"חיבור המכשיר ידנית לרשת סלולרית זמינה כשהוא אינו מתביית אוטומטית, או כשנדרש לעבור לרשת מארחת אחרת","tags":["חו\"ל","בחירת רשת","מפעיל","רשת ידנית"],"stages":[],"body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לחבר את המכשיר ידנית לרשת סלולרית זמינה כאשר הוא אינו מתביית אוטומטית, או כאשר נדרש לעבור לרשת מארחת אחרת.","img":null}]},{"title":"לפני שמתחילים","ordered":false,"steps":[]},{"title":"\"קישור למסמך \"","ordered":false,"steps":[{"text":"ודא:","img":null},{"text":"שירותי נדידה פעילים בקו.","img":null},{"text":"נדידת נתונים פעילה במכשיר.","img":null},{"text":"המכשיר נמצא באזור שבו קיימת קליטה.","img":null},{"text":"קיימת רשימת מפעילים מאושרים למדינה שבה נמצא הלקוח.","img":null}]},{"title":"אייפון","ordered":false,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"סלולרי בחירת רשת","img":null},{"text":"כבה את האפשרות:","img":null},{"text":"\"אוטומטי\"","img":null},{"text":"המתן עד שתופיע רשימת רשתות זמינות.","img":null},{"text":"בחר מפעיל מתוך:","img":null},{"text":"\"רשימת מפעילים ורשתות בחו\"ל\"","img":null}]},{"title":"המכשיר נרשם לרשת","ordered":false,"steps":[{"text":"בדוק שהשירות חזר לפעול.","img":null},{"text":"לאחר רישום תקין החזר את בחירת הרשת למצב:","img":null},{"text":"\"אוטומטי\"","img":null}]},{"title":"הרישום נכשל","ordered":false,"steps":[{"text":"נסה מפעיל מאושר נוסף.","img":null}]},{"title":"סמסונג","ordered":false,"steps":[{"text":"היכנס:","img":null},{"text":"הגדרות","img":null},{"text":"חיבורים רשתות תקשורת סלולרית מפעילי רשת","img":null},{"text":"כבה:","img":null},{"text":"\"בחר באופן אוטומטי\"","img":null},{"text":"המתן להופעת רשימת המפעילים.","img":null},{"text":"בחר מפעיל מתוך רשימת המפעילים המאושרים.","img":null}]},{"title":"הרישום הצליח","ordered":false,"steps":[{"text":"בדוק את השירות.","img":null},{"text":"לאחר הרישום החזר את הבחירה למצב אוטומטי.","img":null}]},{"title":"הרישום נכשל","ordered":false,"steps":[{"text":"נסה מפעיל נוסף.","img":null}]},{"title":"שיאומי / וואווי / וואן פלוס / גוגל פיקסל","ordered":false,"steps":[{"text":"הנתיב עשוי להשתנות מעט בין הדגמים.","img":null},{"text":"חפש בהגדרות:","img":null},{"text":"\"רשת סלולרית\"","img":null},{"text":"או:","img":null},{"text":"\"מפעיל\"","img":null},{"text":"או:","img":null},{"text":"\"בחירת רשת\"","img":null},{"text":"בטל את בחירת הרשת האוטומטית.","img":null},{"text":"המתן להופעת הרשתות הזמינות.","img":null},{"text":"בחר מפעיל מתוך רשימת המפעילים המאושרים.","img":null},{"text":"לאחר רישום תקין החזר את הבחירה למצב אוטומטי.","img":null}]},{"title":"אופו / רילמי","ordered":false,"steps":[{"text":"היכנס להגדרות הקו הסלולרי.","img":null},{"text":"בחר את כרטיס הקו של wecom.","img":null},{"text":"היכנס ל:","img":null},{"text":"\"מפעיל\"","img":null},{"text":"או:","img":null},{"text":"\"בחירת רשת\"","img":null},{"text":"כבה בחירה אוטומטית.","img":null},{"text":"המתן להופעת רשימת המפעילים.","img":null},{"text":"נסה את המפעילים המאושרים הרלוונטיים למדינה.","img":null},{"text":"לאחר רישום תקין החזר את הבחירה למצב אוטומטי.","img":null}]},{"title":"אם אף מפעיל אינו מאפשר רישום","ordered":false,"steps":[{"text":"בצע:","img":null},{"text":"ודא שנוסו כל המפעילים המאושרים במדינה.","img":null},{"text":"בצע מצב טיסה והחזרה למצב רגיל.","img":null},{"text":"אם עדיין אין רישום, בצע כיבוי והדלקה.","img":null},{"text":"נסה שוב בחירת רשת ידנית.","img":null},{"text":"אם המכשיר עדיין אינו מצליח להירשם:","img":null},{"text":"חזור למסלול:","img":null}]},{"title":"R-01 - אין קליטה או רישום לרשת בחו\"ל","ordered":false,"steps":[]},{"title":"הלקוח נמצא בארצות הברית","ordered":false,"steps":[{"text":"אין לבחור מפעיל באופן אקראי.","img":null},{"text":"עבור למסמך:","img":null}]},{"title":"\"תאימות מכשירים בארצות הברית\" O-06","ordered":false,"steps":[{"text":"ובדוק התאמה בין:","img":null},{"text":"דגם המכשיר.","img":null},{"text":"דור הרשת הנתמך.","img":null},{"text":"המפעיל המארח.","img":null},{"text":"במסמך המקור קיימות הנחיות ייעודיות לארצות הברית ולכן הן צריכות להישאר במסמך התאימות ולא להיות משוכפלות כאן.","img":null}]},{"title":"סיום הטיפול","ordered":false,"steps":[]},{"title":"המכשיר התחבר לרשת והשירות עובד","ordered":false,"steps":[{"text":"הטיפול הסתיים.","img":null}]},{"title":"המכשיר התחבר לרשת אך השירות עדיין לא עובד","ordered":false,"steps":[{"text":"חזור למסלול שממנו הופנית:","img":null},{"text":"גלישה.","img":null},{"text":"שיחות.","img":null},{"text":"הודעות.","img":null}]},{"title":"המכשיר אינו מצליח להירשם לאף רשת","ordered":false,"steps":[{"text":"חזור למסלול:","img":null}]},{"title":"R-01 - אין קליטה או רישום לרשת בחו\"ל","ordered":false,"steps":[{"text":"והמשך בהתאם לשלבי ההסלמה.","img":null}]},{"title":"חשוב לנציג","ordered":false,"steps":[{"text":"בחירת רשת ידנית היא כלי אבחון וטיפול.","img":null},{"text":"לאחר שהרישום הושלם בהצלחה יש להחזיר את המכשיר לבחירת רשת אוטומטית, אלא אם קיימת הנחיה מקצועית אחרת במסלול הספציפי.","img":null}]}]},"track":{"state":"קיים","source":"לקוח לא מוצא רשת + תקלת גלישה","gap":"נדרש קישור לרשימת המפעילים המעודכנת","priority":""},"status":"published","source":{"name":"O-05 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-05.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-05 - בחירת רשת ידנית בחול.docx"};

window.dynamicDocs['pdf_021'] = {"id":"pdf_021","topic":"E-01 · העברה למומחה בתקלת חו\"ל","cat":"intl","docType":"pdf","kind":"E","desc":"מתי ואיך מעבירים למומחה תקלה בחו\"ל, ומה חובה לוודא ולתעד לפני ההעברה","tags":["חו\"ל","הסלמה","מומחה","תיעוד"],"stages":[],"body":{"when":["העבר למומחה רק לאחר שבוצעו כל הבדיקות הרלוונטיות למסלול התקלה והשירות עדיין אינו עובד.","אין להעביר למומחה לפני השלמת שלבי האבחון והתפעול הרלוונטיים."],"to":[],"conditions":["שירותי הנדידה פעילים במערכת.","החבילה מתאימה למדינה ובתוקף, אם נדרשת חבילה לשירות.","תועד האם המכשיר רשום לרשת זרה. אם אינו רשום, תועדו הרשתות שנוסו ותוצאות ניסיונות הרישום.","אם המכשיר אינו מצליח להירשם לאף אחת מהרשתות המאושרות לאחר השלמת מסלול R-01, חוסר הרישום אינו מונע העברה למומחה.","בוצעו בדיקות המכשיר הרלוונטיות.","בוצעה בחירת רשת ידנית אם המסלול דרש זאת.","בוצע רענון מכשיר לאחר שינוי במערכת.","אם נדרש במסלול - בוצע ריענון SIM במערכת באמצעות הכפתור החדש בלבד.","במסמכי המקור מצוין שאם כל שלבי הטיפול בוצעו והשירות עדיין אינו עובד, יש לעבור להמשך טיפול מקצועי.","תעד את המידע שכבר נאסף במהלך הטיפול:","המדינה שבה נמצא הלקוח.","סוג התקלה.","האם המכשיר רשום לרשת.","שם הרשת שאליה המכשיר מחובר.","דגם המכשיר.","הבדיקות שכבר בוצעו.","פעולות שבוצעו במערכת.","רשתות שנוסו ידנית.","תוצאת כל פעולה.","המטרה היא שהמומחה לא יחזור עם הלקוח על כל התהליך מההתחלה."],"document":[],"extra":[{"title":"מקרים שמחייבים המשך טיפול מקצועי","lines":[]},{"title":"אין רישום לרשת","lines":["הלקוח אינו מצליח להירשם לאף אחת מהרשתות המאושרות לאחר השלמת מסלול R-01."]},{"title":"אין גלישה","lines":["המכשיר רשום לרשת, וכל שלבי R-02 בוצעו, אך עדיין אין גלישה."]},{"title":"תקלה בשיחות","lines":["בוצעו הבדיקות הרלוונטיות במסלול R-04 והשיחות עדיין אינן פועלות."]},{"title":"תקלה בהודעות","lines":["בוצעו הבדיקות הרלוונטיות במסלול R-05 והודעות עדיין אינן נשלחות או מתקבלות."]},{"title":"מה קורה לאחר ההעברה?","lines":[]},{"title":"חסר מידע להשלמה","lines":["לאיזה תור / גורם מועברת הפנייה.","אילו שדות חובה יש למלא.","זמן הטיפול הצפוי.","מי אחראי לחזור ללקוח."]},{"title":"כלל מנחה לנציג","lines":["העברה למומחה אינה שלב אבחון."]}]},"track":{"state":"קיים","source":"מוזכר במסמכי החו\"ל","gap":"נדרשים תנאי העברה, שדות חובה, זמן טיפול ואחריות לחזרה","priority":"גבוהה"},"status":"published","owner":"שחר","source":{"name":"E-01 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/E-01.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"E-01 - העברה למומחה בתקלת חול.docx"};
window.dynamicDocs['kb_o01'] = {"id":"kb_o01","topic":"O-01 · בדיקות שירותי נדידה וחבילת חול במערכת","cat":"intl","docType":"pdf","kind":"O","desc":"פריט תפעול קצר: איך בודקים במערכת ששירותי הנדידה פתוחים לקו — עם צילום מסך","tags":["חו\"ל","נדידה","מערכת"],"stages":[],"body":{"groups":[{"title":"מידע כללי","ordered":false,"steps":[{"text":"שלחתי לבת אל","img":null}]}]},"track":{"state":"חסר חלקית","source":"מסמכי החו\"ל","gap":"להוסיף צילום מסך בלבד וקישור ממסלולים","priority":"גבוהה"},"status":"published","publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-01 - בדיקות שירותי נדידה וחבילת חול במערכת.docx"};
window.dynamicDocs['kbd_o10'] = {"id":"kbd_o10","topic":"O-50 · הפעלת SIM פיזי חדש","cat":"sim","docType":"pdf","kind":"O","desc":"איך מפעילים כרטיס SIM פיזי חדש – בהפעלה עצמית באתר או בליווי נציג – ומה לבדוק אחרי ההפעלה.","tags":["SIM"],"owner":"","stages":[],"track":{"state":"חסר","priority":"","gap":"טיוטת Word לבדיקה: 2 פערים מסומנים ⚠ חסר + 1 הערות לבדיקה","source":"O-50 הפעלת SIM פיזי חדש.docx"},"status":"published","source":{"name":"O-50 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-50.docx?web=1"},"body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"תהליך זה מיועד ללקוח שקיבל SIM פיזי חדש של wecom ויש לבצע לו הפעלה.","img":null},{"text":"אם מדובר במנוי קיים שמחליפים בו SIM או eSIM מכל סיבה — מעבר למכשיר חדש, שינוי סוג הכרטיס, תקלה, אובדן, גניבה או החלפה לאחר חסימה קודמת — עבור ל־ O-52. O-50 מיועד להפעלה ראשונה במכר חדש או בניוד מחברה אחרת.","img":null},{"text":"O-52 — החלפה ומעבר SIM/eSIM במנוי קיים. במסמך זה נבחרים סיבת ההחלפה וסוג המעבר.","img":null}]},{"title":"לפני שמתחילים","ordered":false,"steps":[{"text":"מבצעים נוהל הונאות מול הלקוח כדי לוודא שלא מדובר בגניבת קו:","img":null},{"text":"אם מדובר במכירה חדשה של קו 051 שלא היה קיים לפי:","img":null},{"text":"תעודת זהות/ רישיון נהיגה. (עדיפות לת\"ז)","img":null},{"text":"ניתן לשלוח צד אחד בלבד.","img":null}]},{"title":"הנחיות ללקוח","ordered":false,"steps":[{"text":"המסמך יישלח באמצעות Glassix בלבד.","img":null},{"text":"יש להנחות את הלקוח כי הוא רשאי להסתיר מראש את כל הפרטים שאינם נדרשים לצורך הזיהוי, לדוגמה: תאריך לידה, תאריך הנפקה, כתובת ופרטים נוספים.","img":null},{"text":"הפרטים שצריכים להישאר גלויים בלבד: שם מלא + מספר תעודת זהות.","img":null},{"text":"לאחר קבלת המסמך יש לוודא התאמה בין הפרטים במסמך לבין פרטי הלקוח והחשבון שנפתח.","img":null},{"text":"במקרה של חוסר התאמה או חשד להתחזות – אין להמשיך בהקמת המנוי ויש להעביר לבדיקה.","img":null},{"text":"יש לוודא שה־SIM החדש נמצא פיזית אצל הלקוח.","img":null},{"text":"בניוד של המספר מהחברה הקודמת, אין להוציא את הכרטיס הקודם מראש; ממתינים שהשירות בו ייפסק לפני המעבר לכרטיס החדש. בקו 051 חדש אין להמתין להפסקת השירות בקו אחר שנמצא במכשיר.","img":null}]},{"title":"תהליך (מתאים גם לניוד וגם להפעלה)","ordered":false,"steps":[]},{"title":"הפעלת ה־ SIM באזור האישי","ordered":false,"steps":[{"text":"נכנסים לאזור האישי.","img":null},{"text":"לוחצים על \"הפעלת SIM\"","img":null},{"text":"בוחרים \"כרטיס SIM\"","img":null},{"text":"מקלידים את מספר הטלפון שאותו רוצים להפעיל.","img":null},{"text":"מקלידים את מספר תעודת הזהות שהוזן בעת ההצטרפות.","img":null},{"text":"מקלידים 4 ספרות אחרונות של אמצעי התשלום.","img":null},{"text":"מזינים את מספר ה־SIM המלא.","img":null},{"text":"בהפעלת מספר 051 חדש ההפעלה מיידית. בניוד בלבד בוחרים אחת מהאפשרויות הבאות:","img":null},{"text":"אני מעוניין/ת לבצע את הניוד המנוי באופן מיידי","img":null},{"text":"או אני מעוניין/ת לבחור מועד עתידי לניוד המנוי","img":null},{"text":"משלימים את ההפעלה.","img":null}]},{"title":"מה הלקוח עושה לאחר ההפעלה?","ordered":false,"steps":[]},{"title":"בהפעלת מספר 051 חדש","ordered":false,"steps":[{"text":"יש לכבות את המכשיר, להכניס את ה־SIM החדש ולהדליק אותו מחדש.","img":null}]},{"title":"אם מתבצע ניוד של המספר מהחברה הקודמת","ordered":false,"steps":[{"text":"לא מוציאים את ה־SIM הישן מיד.","img":null}]},{"title":"סדר הפעולות","ordered":false,"steps":[{"text":"מפעילים את ה־ SIM החדש במערכת - ממתינים שהקליטה ב־SIM הישן תיפול - מוציאים את ה־SIM הישן - מכניסים את ה SIM החדש - מפעילים מחדש את המכשיר.","img":null},{"text":"ההמתנה להפסקת השירות בכרטיס הקודם מתייחסת למספר המתנייד. אין לדרוש הפסקת שירות בקו אחר שאינו חלק מהניוד.","img":null}]},{"title":"בדיקות סיום לאחר הפעלת מספר חדש או השלמת ניוד","steps":[{"text":"מכר - במספר 051 חדש — בצע את הבדיקות לאחר הפעלת הכרטיס והכנסת ה־SIM החדש למכשיר.","img":null},{"text":"בניוד — בצע את הבדיקות לאחר השלמת הניוד, הפסקת השירות בכרטיס הקודם והכנסת ה־SIM החדש למכשיר. אין להתייחס להזמנת ניוד למועד עתידי כהשלמת ההפעלה.","img":null}]},{"title":"לאחר הפעלה מחדש של המכשיר, בדוק:","ordered":false,"steps":[{"text":"המכשיר נרשם לרשת.","img":null},{"text":"ניתן להוציא שיחה.","img":null},{"text":"ניתן לקבל שיחה.","img":null},{"text":"ניתן לשלוח SMS רגיל.","img":null},{"text":"ניתן לקבל SMS רגיל.","img":null},{"text":"ניתן לגלוש באמצעות נתונים סלולריים כשה־Wi-Fi כבוי.","img":null}]},{"title":"","ordered":false,"steps":[{"text":"אם כל הבדיקות תקינות — תעד וסיים טיפול.","img":null},{"text":"אם אין שירות או אין גלישה לאחר ההפעלה — עבור ל־R-50 — תקלה לאחר הפעלת SIM או eSIM עם פירוט הבדיקות שכבר בוצעו.","img":null},{"text":"אם לאחר ניוד ניתן להוציא שיחות אך לא ניתן לקבל שיחות, או שהקבלה נכשלת מחלק מהמספרים — עבור ל־ R-44 — לא מתקבלות שיחות לאחר ניוד.","img":null},{"text":"במידה ומדובר במנוי שמתנייד – יש לציין ללקוח מתי הלקוח מתחיל לפעול על רשת וויקום ובאותה שעה להכניס את הסים החדש ולהוציא את הישן.","img":null}]}]},"publishedAt":1793886901290,"updatedAt":1793886901290,"originName":"O-50 הפעלת SIM פיזי חדש.docx"};
window.dynamicDocs['kbd_o11'] = {"id":"kbd_o11","topic":"O-51 · הפעלת eSIM באמצעות קוד QR","cat":"sim","docType":"pdf","kind":"O","desc":"דרישות מקדימות, התקנת פרופיל ה-eSIM בסריקת QR, הפעלת הקו באתר, וטעויות נפוצות.","tags":["SIM"],"owner":"","stages":[],"track":{"state":"חסר","priority":"","gap":"טיוטת Word לבדיקה: 2 פערים מסומנים ⚠ חסר + 1 הערות לבדיקה","source":"O-51 __הפעלת_eSIM באמצעות_קוד_QR.docx"},"status":"published","source":{"name":"O-51 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-51.docx?web=1"},"body":{"groups":[{"title":"מטרת המסמך להנחות את הנציג בתהליך תקין של התקנה והפעלה של eSIM חדש באמצעות קוד QR","ordered":false,"steps":[{"text":"אם מדובר בלקוח פעיל שכבר יש לו SIM או eSIM ויש לבצע מעבר מ-SIM פיזי ל-eSIM או מעבר למכשיר חדש - יש לעבוד לפי O-52","img":null}]},{"title":"לפני שמתחילים","ordered":false,"steps":[{"text":"יש לוודא:","img":null},{"text":"המכשיר תומך ב eSIM (לינק האם מכשיר תומך - esim- מסמך O-44","img":null},{"text":"המכשיר מחובר לאינטרנט פעיל.","img":null},{"text":"לא מתבצעת שיחת טלפון בזמן הסריקה.","img":null},{"text":"קוד ה-QR שייך למספר שאותו רוצים להפעיל.","img":null},{"text":"קוד ה-QR נפתח במסך אחר מהמכשיר שעליו מתקינים את ה eSIM","img":null},{"text":"מומלץ לוודא שמערכת ההפעלה מעודכנת.","img":null}]},{"title":"סדר הפעולות","ordered":false,"steps":[{"text":"הסדר הוא:","img":null}]},{"title":"שליחת QR -> סריקת QR והתקנת הפרופיל -> וידוא שה-eSIM הותקן -> הפעלה באזור האישי","ordered":false,"steps":[]},{"title":"חשוב: קודם מתקינים את פרופיל ה eSIM במכשיר ורק לאחר מכן מבצעים את ההפעלה באזור האישי.","ordered":false,"steps":[]},{"title":"שלב 1 - קבלת קוד QR","ordered":true,"steps":[{"text":"קוד ה-QR נשלח למייל המוגדר במערכת.","img":null},{"text":"יש להנחות את הלקוח:","img":null},{"text":"לפתוח את המייל במחשב, טאבלט או מכשיר נוסף.","img":null},{"text":"במכשיר שבו רוצים להתקין את ה eSIM להיכנס להגדרות.","img":null},{"text":"לבחור \"הוספת eSIM \"","img":null},{"text":"לסרוק את הקוד שמוצג במסך האחר.","img":null},{"text":"הסריקה מתבצעת מהמכשיר שעליו רוצים להתקין את ה eSIM","img":null}]},{"title":"שלב 2 - סריקת QR לפי סוג מכשיר","ordered":true,"steps":[]},{"title":"iPhone","ordered":false,"steps":[{"text":"הגדרות -> סלולרי -> הוספת eSIM / הגדרת שירות סלולרי -> שימוש בקוד QR.","img":null}]},{"title":"Samsung Galaxy","ordered":false,"steps":[{"text":"הגדרות -> חיבורים -> מנהל SIM -> הוספת eSIM -> סריקת קוד QR.","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[{"text":"הגדרות -> רשת ואינטרנט -> SIMs -> הוספת SIM -> הגדרת eSIM.","img":null}]},{"title":"Xiaomi / HyperOS","ordered":false,"steps":[{"text":"במכשירים תומכים:","img":null},{"text":"הגדרות -> רשתות סלולריות / SIM cards & mobile networks -> eSIM / Manage eSIM -> Add eSIM / Add mobile plan.","img":null},{"text":"שמות התפריטים עשויים להשתנות לפי דגם וגרסת מערכת ההפעלה.","img":null}]},{"title":"שלב 3 - וידוא שה eSIM הותקן","ordered":true,"steps":[{"text":"לאחר הסריקה:","img":null},{"text":"יש להמתין עד שה-eSIM מופיע ברשימת ה-SIMים במכשיר.","img":null},{"text":"במידת הצורך יש לבדוק את ה-ICCID במכשיר.","img":null},{"text":"יש לוודא שה-ICCID תואם ל-ICCID שמופיע ב-CRM.","img":null}]},{"title":"שלב 4 - הפעלת eSIM באזור האישי","ordered":true,"steps":[{"text":"רק לאחר שווידאנו שהפרופיל הותקן:","img":null},{"text":"נכנסים לאזור האישי.","img":null},{"text":"בוחרים \"הפעלת SIM\".","img":null},{"text":"בוחרים eSIM","img":null},{"text":"מזינים את מספר הטלפון.","img":null},{"text":"מזינים את מספר תעודת הזהות שהוזן בעת ההצטרפות.","img":null},{"text":"מזינים 4 ספרות אחרונות של אמצעי התשלום.","img":null},{"text":"אם קיימת בחירת מועד ניוד - בוחרים בהתאם לבקשת הלקוח.","img":null},{"text":"משלימים את ההפעלה.","img":null},{"text":"ב-eSIM אין צורך להזין מספר SIM מלא במסך ההפעלה.","img":null}]},{"title":"שלב 5 - הגדרת הקו במכשיר","ordered":true,"steps":[{"text":"לאחר ההפעלה יש לוודא שה-eSIM פעיל ומוגדר לשימוש.","img":null}]},{"title":"iPhone","ordered":false,"steps":[{"text":"לוודא \"הפעל קו זה\".","img":null},{"text":"לבחור את ה-eSIM כקו הקולי המתאים.","img":null},{"text":"לבחור אותו תחת \"נתונים סלולריים\".","img":null},{"text":"אם קיימים מספר קווים - לוודא שהמספר הנכון מוגדר גם לשירותים הרלוונטיים.","img":null}]},{"title":"Samsung","ordered":false,"steps":[{"text":"להיכנס למנהל SIM.","img":null},{"text":"לוודא שה-eSIM מופעל.","img":null},{"text":"לבחור אותו לשיחות, הודעות ונתונים לפי הצורך.","img":null}]},{"title":"Pixel / Android","ordered":false,"steps":[{"text":"לבחור את ה eSIM","img":null},{"text":"להפעיל שימוש ב SIM","img":null},{"text":"להפעיל נתונים סלולריים.","img":null},{"text":"להגדיר אותו כקו המועדף לפי הצורך.","img":null}]},{"title":"בדיקת סיום","ordered":false,"steps":[{"text":"יש לוודא:","img":null},{"text":"• ה-eSIM מופיע במכשיר.","img":null},{"text":"• ה-eSIM פעיל.","img":null},{"text":"• ה-ICCID תואם ל-CRM.","img":null},{"text":"• ניתן להוציא שיחה ולקבל שיחה.","img":null},{"text":"• ניתן לשלוח ולקבל SMS.","img":null},{"text":"• ניתן לגלוש באמצעות נתונים סלולריים בקו wecom, כשה־ Wi-Fi כבוי.","img":null}]},{"title":"אם התהליך לא הושלם","ordered":false,"steps":[]},{"title":"קוד QR לא התקבל, לא נסרק או שההתקנה לא הושלמה","ordered":false,"steps":[]},{"title":"-> מעבר ל-R-51","ordered":false,"steps":[]},{"title":"ה-eSIM הותקן והופעל, אבל אין קליטה או אין גלישה","ordered":false,"steps":[{"text":"-> מעבר ל-R-50.","img":null}]}]},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-51 __הפעלת_eSIM באמצעות_קוד_QR.docx"};
window.dynamicDocs['kbd_o12'] = {"id":"kbd_o12","topic":"O-52 · החלפה ומעבר SIM eSIM במנוי קיים","cat":"sim","docType":"pdf","kind":"O","desc":"מעבר מכרטיס פיזי ל-eSIM ולהפך, והעברת eSIM למכשיר חדש – כולל סדר הפעולות המחייב בהחלפת סים.","tags":["SIM"],"owner":"","stages":[],"track":{"state":"חסר","priority":"","gap":"טיוטת Word לבדיקה: 3 פערים מסומנים ⚠ חסר","source":"O-52   מעבר מסים פיזי לאיסים או מעבר למכשיר חדש.docx"},"status":"published","source":{"name":"O-52 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-52.docx?web=1"},"body":{"groups":[{"title":"מתי משתמשים במסמך","ordered":false,"steps":[{"text":"לכל החלפת SIM או eSIM במנוי קיים בוויקום: מעבר למכשיר חדש, שינוי סוג הכרטיס, תקלה, אובדן, גניבה או החלפה לאחר חסימה קודמת כגון חסימה בעקבות גבייה. סיבת ההחלפה קובעת את הטיפול בכרטיס הקיים; סוג המעבר קובע את ההזמנה, ההתקנה וההפעלה.","img":null},{"text":"בחר את סוג המעבר: SIM פיזי ל־SIM פיזי; SIM פיזי ל־eSIM; eSIM ל־eSIM במכשיר חדש; או eSIM ל־SIM פיזי. גם בעקבות אובדן או גניבה ניתן לבחור SIM פיזי או eSIM בהתאם למכשיר ולבקשת הלקוח.","img":null},{"text":"להצטרפות חדשה או ניוד מחברה אחרת באמצעות SIM פיזי עבור ל־O-50 — הפעלת SIM פיזי חדש. להפעלת eSIM בהצטרפות חדשה השתמש ב־O-51 — הפעלת eSIM באמצעות קוד QR.","img":null}]},{"title":"שלב 1 זיהוי ואימות בעל המנוי","ordered":true,"steps":[{"text":"לפני כל החלפה במנוי קיים, יש להשלים זיהוי ואימות של בעל המנוי. קבל צילום תעודת זהות של בעל המנוי באמצעות Glassix; אין לקבלו בערוץ אחר. יש לוודא את מספר תעודת הזהות ואת ארבע הספרות האחרונות של אמצעי התשלום המעודכן בחשבון.","img":null},{"text":"אם הפונה אינו בעל החשבון, יש להעלות את בעל החשבון לשיחה ולקבל ממנו אישור מפורש לביצוע הפעולה. אין לבצע החלפה ללא זיהוי ואישור של בעל החשבון. אם הזיהוי הושלם כבר במהלך אותו טיפול, אין לבצעו שוב; יש לוודא שהמידע והאישור מתועדים.","img":null}]},{"title":"שלב 2 טיפול בכרטיס הקיים לפי סיבת ההחלפה","ordered":true,"steps":[]},{"title":"אובדן","ordered":false,"steps":[{"text":"לאחר השלמת הזיהוי, סווג את הכרטיס הקיים ב־ CRM כ־״נאבד״. ודא שנבחר הכרטיס הנכון. לאחר הסיווג המשך לשלב 3; אין לבצע בנוסף את שלב שינוי הסטטוס ל־״מושהה״ של ההחלפה הרגילה.","img":null}]},{"title":"גניבה","ordered":false,"steps":[{"text":"לאחר השלמת הזיהוי, סווג את הכרטיס הקיים ב־CRM כ־״נגנב״. ודא שנבחר הכרטיס הנכון. לאחר הסיווג המשך לשלב 3; אין לבצע בנוסף את שלב שינוי הסטטוס ל־״מושהה״ של ההחלפה הרגילה.","img":null}]},{"title":"מעבר רגיל - החלפה עקב תקלה או החלפה לאחר חסימה קודמת","ordered":false,"steps":[{"text":"בצע את תפעול ההחלפה הרגיל: היכנס לכרטיס הקיים ב־ CRM במצב עריכה ושנה את הסטטוס מ־״בשימוש״ ל־״מושהה״ לפני הזמנת החלופי. אם סטטוס הכרטיס שונה עקב חסימה קודמת או שהפעולה אינה זמינה, יש לפעול לפי תפעול ההחלפה המאושר והרשאות הנציג; אין להניח שהכרטיס כבר במצב המתאים או לשנות סטטוס אחר על סמך ניחוש.","img":null},{"text":"לפני ההפעלה יש לוודא שמצב המנוי מאפשר שימוש בשירות. אם קיימת עדיין חסימה על שירותי הקו, יש לטפל בה לפי הנוהל המאושר ובהרשאות הנציג, בעזרת O-40 — בדיקת סטטוס קו וחסימות שיחה במערכת. יש לתעד בנפרד את מצב המנוי ואת סטטוס הכרטיס.","img":null}]},{"title":"שלב 3 בחירת הכרטיס החלופי והזמנתו","ordered":true,"steps":[{"text":"היכנס לאזור האישי: ניהול הקו שלי > תפעול SIM > הזמן כרטיס SIM. בחר את מספר הטלפון של המנוי הקיים ואת סוג הכרטיס לפי בקשת הלקוח ותמיכת המכשיר.","img":null}]},{"title":"בחירת SIM פיזי","ordered":false,"steps":[{"text":"בחר כתובת ושיטת קבלה: משלוח, איסוף Home Center או כרטיס wecom שכבר נמצא אצל הלקוח, לפי האפשרויות באזור האישי. השלם הזמנה והמתן שהכרטיס יהיה פיזית אצל הלקוח לפני ההפעלה.","img":null},{"text":"לתפעול משלוח השתמש ב־O-56 — הזמנה משלוח ובדיקת סטטוס משלוח SIM.","img":null},{"text":"בחירת eSIM","img":null},{"text":"ודא שהמכשיר תומך ב־eSIM. בחר eSIM והשלם הזמנה. יש להתקין את הפרופיל במכשיר ורק לאחר שהוא מופיע בהגדרות להשלים הפעלה באזור האישי. אין לבצע הפעלה לפני ההתקנה.","img":null}]},{"title":"שלב 4 תפעול לפי סוג המעבר","ordered":true,"steps":[{"text":"SIM פיזי ל SIM פיזי","img":null},{"text":"לאחר שהכרטיס החלופי נמצא אצל הלקוח, השלם הפעלה באזור האישי לפי שלב 5. אם הכרטיס הישן נמצא אצל הלקוח, פועל ונגיש, יש להמתין לנפילת הקליטה בו ורק אז להחליף את הכרטיס ולהפעיל מחדש את המכשיר. אם הישן אבד, נגנב, תקול או כבר אינו פועל, אין לדרוש בדיקה או הוצאה של כרטיס שאינו זמין; לאחר הפעלת החלופי יש להשתמש בו ולבדוק את השירות.","img":null},{"text":"SIM פיזי ל eSIM","img":null},{"text":"חבר את המכשיר שבו יותקן הפרופיל ל־Wi-Fi או לאינטרנט פעיל. הצג את ה־QR על מחשב, טאבלט או טלפון נוסף, הוסף eSIM בהגדרות המכשיר וסרוק. המתן שהפרופיל יופיע ורק אז השלם הפעלה לפי שלב 5. אם הכרטיס הישן נמצא אצל הלקוח ופועל, אל תוציא אותו לפני הפעלת החדש ונפילת הקליטה בישן. במקרה של אובדן או גניבה מבצעים את ההתקנה במכשיר הזמין ללקוח לאחר הטיפול בישן בשלב 2.","img":null},{"text":"eSIM ל eSIM במכשיר חדש","img":null},{"text":"התקן את הפרופיל החדש במכשיר החדש באמצעות QR כשהוא מחובר לאינטרנט. לאחר שהפרופיל מופיע, השלם הפעלה לפי שלב 5. אם המכשיר הישן זמין, אין למחוק ממנו את הפרופיל בתחילת התהליך. רק לאחר שהחדש הותקן והופעל והקו הישן הפסיק לעבוד, ניתן להסיר את הפרופיל הישן. אם המכשיר הישן אבד או נגנב, אין לדרוש גישה אליו או מחיקה ממנו כתנאי להפעלת החדש.","img":null},{"text":"eSIM ל SIM פיזי","img":null},{"text":"הזמן כרטיס פיזי לפי שלב 3 והמתן לקבלתו. השלם הפעלה לפי שלב 5. אם הפרופיל הישן זמין ופועל, אין למחוק אותו בתחילת התהליך; לאחר הפעלת החלופי והפסקת השירות בישן, ניתן להסירו ולהשתמש בכרטיס הפיזי. אם המכשיר הישן אינו זמין, אין לדרוש מחיקה ממנו כתנאי להפעלה. הפעל מחדש את המכשיר ובצע בדיקות סיום.","img":null}]},{"title":"שלב 5 הפעלת הכרטיס החלופי","ordered":true,"steps":[{"text":"באזור האישי בחר הפעלת SIM ואת סוג הכרטיס. הזן את מספר הטלפון, מספר תעודת הזהות שהוזן בעת ההצטרפות וארבע הספרות האחרונות של אמצעי התשלום. ב־SIM פיזי הזן גם את מספר הכרטיס המלא. ב־eSIM השלם את ההפעלה רק לאחר שהפרופיל הותקן ומופיע במכשיר.","img":null},{"text":"לאחר שהכרטיס החדש שהוזמן דרך האזור האישי הופעל בהצלחה, הכרטיס הקודם מוסר אוטומטית מהמנוי. אין לבצע הסרה נוספת ידנית במערכת. באובדן או גניבה יש לתעד את הסיווג שבוצע ואת תוצאת הפעלת החלופי. אין להבטיח מועד חסימה מוקדם יותר מזה שנקבע בנוהל החברה.","img":null}]},{"title":"שלב 6 בדיקת הקו במכשיר","ordered":true,"steps":[{"text":"ב־eSIM ודא שהפרופיל מופיע, שהקו מופעל ושהקו הנכון מוגדר לשיחות, SMS ונתונים סלולריים. במכשיר עם שני קווים ודא שהבחירה מתייחסת לקו wecom.","img":null}]},{"title":"iPhone","ordered":false,"steps":[{"text":"הגדרות > סלולרי > בחר את הקו החדש והפעל אותו. בחר אותו בקו הקולי ובנתונים הסלולריים. במכשיר עם שני קווים בדוק גם את המספר שנבחר ב־iMessage וב־FaceTime.","img":null}]},{"title":"Samsung","ordered":false,"steps":[{"text":"הגדרות > חיבורים > מנהל SIM. ודא שה־eSIM פעיל ובחר את הקו החדש לשיחות, הודעות ונתונים סלולריים.","img":null},{"text":"Pixel ו Android","img":null},{"text":"הגדרות > רשת ואינטרנט > SIMs. בחר את הקו החדש, הפעל שימוש ב־SIM ונתונים סלולריים והגדר את הקו לשיחות ול־SMS, בהתאם לאפשרויות המכשיר.","img":null},{"text":"למחיקת פרופיל ישן ממכשיר זמין לאחר השלמת המעבר: ב־iPhone דרך הגדרות > סלולרי > הקו הישן > מחיקת eSIM; ב־Samsung דרך מנהל SIM > הפרופיל הישן > הסרה; ב־Pixel דרך SIMs > הפרופיל הישן > מחיקת eSIM. מחיקה מהמכשיר אינה מנתקת את המנוי במערכת.","img":null}]},{"title":"שלב 7 בדיקות חובה וסיום","ordered":true,"steps":[{"text":"בצע בדיקת קליטה, שיחה יוצאת ושיחה נכנסת, שליחה וקבלה של SMS רגיל וגלישה סלולרית. ב־eSIM ודא גם התאמת ICCID בין המכשיר ל־CRM, בחירת הקו הנכון והיעדר שיוך כפול שגוי. תעד זיהוי ואישור, סיבת החלפה, סטטוס הכרטיס הישן, סוג המעבר, ההזמנה, ההפעלה ותוצאות הבדיקות.","img":null},{"text":"ההתקנה או סריקת ה QR נכשלו","img":null},{"text":"אין להתקדם להפעלה כל עוד הפרופיל אינו מופיע. עבור ל־R-51 — תקלה בסריקת QR או בהורדת פרופיל eSIM. אין לשנות סטטוס או להפיק פרופיל נוסף ללא הוראה במסלול המאושר.","img":null},{"text":"ההפעלה הושלמה אך אין שירות או אין גלישה","img":null},{"text":"עבור ל־R-50 — תקלה לאחר הפעלת SIM eSIM אין קליטה או אין גלישה, עם פרטי ההחלפה והבדיקות שכבר בוצעו.","img":null},{"text":"הכרטיס החדש והשירותים תקינים","img":null},{"text":"תעד וסיים טיפול. אין לחזור על בדיקות שכבר הושלמו ונמצאו תקינות.","img":null}]}]},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-52   מעבר מסים פיזי לאיסים או מעבר למכשיר חדש.docx"};
window.dynamicDocs['kbd_r12'] = {"id":"kbd_r12","topic":"O-55 · נוהל החלפת SIM בעקבות גניבה או אובדן","cat":"sim","docType":"pdf","kind":"O","desc":"חסימה מיידית של קו ומכשיר שאבדו או נגנבו, והנפקת סים חלופי לפי סדר הפעולות המחייב.","tags":["SIM"],"owner":"שחר","stages":[],"track":{"state":"קיים חלקית","priority":"","gap":"טיוטת Word לבדיקה: 4 פערים מסומנים ⚠ חסר + 1 הערות לבדיקה","source":"החלפת SIM אבוד, גנוב או תקול וחסימת קו O 55.docx"},"status":"published","source":{"name":"O-55 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-55.docx?web=1"},"body":{"groups":[{"title":"מטרת הנוהל","ordered":false,"steps":[{"text":"להבטיח זיהוי מלא של בעל החשבון, חסימת כרטיס ה־ SIM שנגנב או אבד, והנפקת SIM או eSIM חלופי באופן מאובטח.","img":null}]},{"title":"שלב 1 – זיהוי ואימות הלקוח","ordered":true,"steps":[{"text":"בכל בקשה להחלפת SIM בעקבות גניבה או אובדן, חובה לקבל את הפרטים הבאים:","img":null},{"text":"מספר תעודת הזהות של בעל החשבון.","img":null},{"text":"ארבע הספרות האחרונות של אמצעי התשלום המעודכן בחשבון.","img":null},{"text":"צילום תעודת הזהות של בעל החשבון.","img":null}]},{"title":"כאשר הפונה אינו בעל החשבון","ordered":false,"steps":[{"text":"במידה שהלקוח המשוחח עם הנציג אינו בעל החשבון, חובה להעלות את בעל החשבון לשיחה ולקבל ממנו אישור מפורש לביצוע הפעולה.","img":null},{"text":"אין לבצע החלפת SIM ללא זיהוי ואישור של בעל החשבון.","img":null}]},{"title":"שלב 2 – קבלת צילום תעודת הזהות","ordered":true,"steps":[{"text":"לצורך קבלת צילום תעודת הזהות, יש להעביר את הטיפול ל־Glassix ולשלוח ללקוח הודעת WhatsApp ייעודית.","img":null},{"text":"נוסח מוצע להודעה:","img":null},{"text":"\"שלום, לצורך המשך טיפול בהחלפת ה־SIM בעקבות גניבה או אובדן, יש להשיב להודעה זו בצילום ברור של תעודת הזהות של בעל החשבון. יש לוודא שכל הפרטים בתמונה ברורים וקריאים.\"","img":null},{"text":"רק לאחר קבלת התמונה וביצוע אימות מלא ניתן להמשיך בתהליך.","img":null}]},{"title":"שלב 3 – סיווג כרטיס ה־SIM","ordered":true,"steps":[{"text":"לאחר השלמת הזיהוי, יש להיכנס למנוי ולסווג את כרטיס ה־SIM הקיים בהתאם למקרה:","img":null},{"text":"במקרה של גניבה – \"נגנב\".","img":null},{"text":"במקרה של אובדן – \"נאבד\".","img":null},{"text":"יש לוודא שהסיווג מתבצע על כרטיס ה־SIM הנכון לפני המשך הטיפול.","img":null}]},{"title":"שלב 4 – הזמנת SIM או eSIM חלופי","ordered":true,"steps":[{"text":"לאחר סיווג הכרטיס, יש להזמין באזור האישי של הלקוח:","img":null},{"text":"כרטיס SIM נוסף למשלוח.","img":null},{"text":"או eSIM נוסף, בהתאם לתמיכת המכשיר ולבקשת הלקוח.","img":null}]},{"title":"SIM פיזי","ordered":false,"steps":[{"text":"ניתן להפעיל את הכרטיס החדש לאחר קבלתו באחת מהדרכים הבאות:","img":null},{"text":"הלקוח יפעיל את ה־ SIM באופן עצמאי דרך האזור האישי.","img":null},{"text":"הנציג יפעיל את ה־ SIM עבור הלקוח לאחר קבלתו ובהתאם לבקשתו.","img":null},{"text":"בעת הפעלת כרטיס ה־SIM החדש, כרטיס ה־ SIM שסווג כגנוב או כאבוד יוסר ויוחלף בכרטיס החדש.","img":null}]},{"title":"eSIM","ordered":false,"steps":[{"text":"כאשר הלקוח בוחר ב־eSIM וציוד הקצה שלו תומך בכך, ניתן לבצע את ההנפקה וההפעלה באופן מיידי, בהתאם לבקשת הלקוח.","img":null}]},{"title":"דגשים חשובים לנציג","ordered":false,"steps":[{"text":"אין להסתפק בזיהוי טלפוני בלבד – צילום תעודת זהות הוא חובה.","img":null},{"text":"אין לקבל צילום תעודת זהות בערוץ שאינו Glassix.","img":null},{"text":"כאשר הפונה אינו בעל החשבון, חובה לקבל אישור מבעל החשבון במהלך השיחה.","img":null},{"text":"יש לוודא שכרטיס ה־SIM הישן סווג כ־\"נגנב\" או \"נאבד\" לפני הנפקת הכרטיס החדש.","img":null},{"text":"יש להסביר ללקוח שכרטיס ה־SIM הישן יפסיק לפעול לאחר הפעלת הכרטיס החדש.","img":null},{"text":"במקרה של eSIM, יש לוודא מראש שהמכשיר תומך ב־eSIM.","img":null},{"text":"חובה לתעד במערכת את תהליך הזיהוי, קבלת האישור, קבלת צילום תעודת הזהות והפעולה שבוצעה.","img":null}]}]},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"החלפת SIM אבוד, גנוב או תקול וחסימת קו O 55.docx"};
window.dynamicDocs['kbd_o13'] = {"id":"kbd_o13","topic":"O-56 · תיאום שליחות ובירור סטטוס משלוח SIM","cat":"sim","docType":"pdf","kind":"O","desc":"בדיקת סטטוס הזמנה ומשלוח של כרטיס SIM, ומה עושים כשהמשלוח מתעכב.","tags":["SIM"],"owner":"שחר","stages":[],"track":{"state":"קיים חלקית","priority":"","gap":"טיוטת Word לבדיקה: 5 פערים מסומנים ⚠ חסר + 2 הערות לבדיקה","source":"תיאום שליחות ובירור סטטוס משלוח SIM  O 56.docx"},"status":"published","source":{"name":"O-56 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-56.docx?web=1"},"body":{"groups":[{"title":"הזנת הזמנת המשלוח","ordered":false,"steps":[{"text":"בעת הזנת משלוח סים, חובה לוודא שכל הפרטים הוזנו באופן מלא ומדויק:","img":null},{"text":"כתובת למשלוח – יש לוודא שהכתובת נכונה ומלאה, כולל עיר, רחוב, מספר בית, מספר דירה ופרטים נוספים הנדרשים לצורך המסירה.","img":null},{"text":"מספר טלפון ליצירת קשר – יש להזין מספר טלפון נכון ועדכני, שבו ניתן להשיג את הלקוח לצורך תיאום המסירה.","img":null},{"text":"כמות הסימים במשלוח – יש לוודא שכמות הסימים שהוזמנה תואמת לכמות הנדרשת ללקוח.","img":null},{"text":"מספרי המנויים – בעת הזמנת הסימים באזור האישי, יש להזין את כל מספרי הטלפון שעבורם מיועדים הסימים.","img":null},{"text":"יש לבצע בדיקה נוספת של כל הפרטים לפני אישור ההזמנה.","img":null}]},{"title":". תיקון טעות בפרטי המשלוח","ordered":false,"steps":[{"text":"במקרה שבו התגלתה טעות בפרטי השליחות, או שהפרטים הנכונים לא הוזנו בזמן:","img":null},{"text":"יש לעדכן את האחמ״ש באופן מיידי ולמסור לו את הפרטים הנכונים.","img":null},{"text":"אין לפתוח או להעלות הזמנה נוספת, כדי למנוע יצירת משלוחים כפולים.","img":null}]},{"title":"זמני אספקה","ordered":false,"steps":[{"text":"זמן האספקה הרגיל הוא עד שני ימי עסקים.","img":null},{"text":"באזורים מרוחקים זמני האספקה עשויים להיות ארוכים יותר ובהתאם לימי הכניסה של חברת השליחויות לאותו אזור.","img":null},{"text":"רשימת האזורים המרוחקים וימי הכניסה המעודכנים נמצאת ב״מנהלת״. יש לבדוק ברשימה את יום הכניסה הרלוונטי ולמסור ללקוח צפי אספקה בהתאם.","img":null}]},{"title":"בדיקת סטטוס משלוח","ordered":false,"steps":[{"text":"לצפייה במצב השליחות יש להיכנס לאתר חברת Zig-Zag:","img":null},{"text":"https://www.zig-zag.co.il/?login=1","img":null}]},{"title":"פרטי כניסה פנימיים - גינריים","ordered":false,"steps":[{"text":"שם משתמש: 28212 סיסמה : WECOM1234","img":null},{"text":"לאחר הכניסה:","img":null},{"text":"יש להיכנס לעמוד ״חיפוש משלוח״.","img":null},{"text":"ב-CRM, בעמוד לוח הבקרה, יש לאתר את מספר השליחות.","img":null},{"text":"יש להעתיק ולהזין בחיפוש את מספר השליחות המלא.","img":null},{"text":"יש לבדוק את סטטוס המשלוח ואת העדכונים המופיעים במערכת.","img":null},{"text":"אין להעביר ללקוחות את פרטי הכניסה למערכת השליחויות.","img":null}]},{"title":"5. טיפול במקרים חריגים","ordered":false,"steps":[{"text":"יש לעדכן אחמ״ש באופן מיידי בכל מקרה חריג הקשור למשלוח, לרבות:","img":null},{"text":"עיכוב במסירת המשלוח.","img":null},{"text":"טעות בהזמנה או בפרטי המשלוח שבוצעה על ידי נציג.","img":null},{"text":"משלוח שלא ניתן למסור בעקבות פרטים שגויים או חסרים.","img":null},{"text":"שליח שדיווח כי השאיר את המשלוח בתיבת הדואר, אך הלקוח אינו מאתר אותו.","img":null},{"text":"מסירת סימים של חברה מתחרה.","img":null},{"text":"כמות סימים שגויה או סימים שאינם תואמים להזמנה.","img":null},{"text":"משלוח שסומן כנמסר, אך הלקוח טוען שלא קיבל אותו.","img":null},{"text":"כל כשל אחר התלוי בחברה או בחברת השליחויות.","img":null},{"text":"אין להבטיח ללקוח זיכוי, משלוח חלופי או פתרון אחר לפני קבלת הנחיה ואישור מהאחמ״ש.","img":null}]},{"title":"דגש חשוב","ordered":false,"steps":[{"text":"אחריות הנציג היא לוודא את תקינות פרטי המשלוח כבר בשלב ההזמנה. הזנה נכונה ומדויקת מונעת עיכובים, משלוחים כפולים, אובדן סימים וחוויית שירות לקויה.","img":null}]}]},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"תיאום שליחות ובירור סטטוס משלוח SIM  O 56.docx"};
window.dynamicDocs['kbm_m10'] = {"id":"kbm_m10","topic":"M-10 · בעיות קליטה בארץ אבחון מרכזי","cat":"tech","docType":"pdf","kind":"M","desc":"בעיות קליטה בארץ - אבחון מרכזי","tags":["קליטה בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"intro":["מטרת המסמך","לברר למה הלקוח מתכוון כשהוא מתאר בעיית קליטה, ולנתב אותו למסלול המתאים לפי השירות שנפגע, חיווי הרשת, התלות במיקום והשינוי ביחס לעבר. זהו מסמך אבחון וניתוב; את התפעול מבצעים במסלול שאליו הופנה הנציג.","המסמך מיועד ללקוח הנמצא בארץ. אם הלקוח בחו״ל, עבור ל־M‑00 — תקלות ושירות בחו״ל אבחון מרכזי."],"questions":[{"title":"תיאור התקלה והמיקום","q":"״מה בדיוק לא עובד — אין שירות בקו, קליטה חלשה, שיחות שלא מתחברות, ניתוקים בשיחה, גלישה או הודעות? האם זה קורה במקום מסוים, בזמן נסיעה או גם במקומות אחרים?״","hint":"תעד את החיווי המדויק בקו wecom, את השירותים שנפגעו ואת מועד תחילת התקלה. ברר אם התקלה קבועה או מופיעה לסירוגין, ובאילו מקומות היא מתרחשת. ברר גם אם בוצעו ניוד, החלפת SIM או eSIM או החלפת מכשיר סמוך להופעת התקלה.","answers":[{"text":"התקלה מוגבלת למקום מסוים או למסלול נסיעה מוגדר","note":"","go":"q:1"},{"text":"התקלה מתרחשת במקומות שונים ואינה מוגבלת למיקום מסוים","note":"","go":"q:2"},{"text":"התלות במיקום אינה ברורה","note":"המשך לבירור השירות שנפגע וחיווי הרשת; אין לקבוע שמדובר בבעיית כיסוי ללא ממצא מתאים.","go":"q:2"}]},{"title":"תקלה הקשורה למיקום","q":"״האם בעבר השירות במקום הזה היה תקין והבעיה התחילה או החמירה לאחרונה?״","hint":"","answers":[{"text":"הרעה חדשה באזור או במסלול מוגדר","note":"תעד מה השתנה, ממתי, ואת הכתובת או מסלול הנסיעה. מסלול זה מתאים גם להרעה חדשה שזוהתה במסלול נסיעה מוגדר.","go":"item:kbm_r13"},{"text":"קליטה חלשה או ניתוקים בזמן נסיעה, ללא הרעה חדשה מזוהה","note":"תעד כביש או רחוב, כיוון נסיעה והמקטע שבו התופעה חוזרת.","go":"item:kbm_r12"},{"text":"תקלה מתמשכת במקום מסוים","note":"ברר אם התופעה קיימת בכל הבית או המשרד או רק בחלק פנימי, כגון ממ״ד, חדר פנימי, מרתף, חניון או מעלית. במסלול זה נבדקים הכיסוי והמיסוך בעזרת O-10 — בדיקת מפת כיסוי ואנטנות.","go":"item:kbm_r11"},{"text":"הבירור מראה שהתקלה אינה מוגבלת לאזור שנבדק","note":"אין להמשיך במסלול בדיקת כיסוי רק משום שהלקוח השתמש במילה ״קליטה״.","go":"q:2"}]},{"title":"תקלה בכל מקום או ללא קשר ברור למיקום","q":"","hint":"ברר איזה שירות אינו עובד ומהו החיווי בקו wecom. במכשיר עם שני קווים, בדוק את הקו הרלוונטי. התחל בבירור חוסר שירות או כשל בהפעלת הכרטיס; אם יש רשת, בחר את הענף לפי השירות שנפגע. אם נפגעו כמה שירותים, תעד את כולם והעבר את הממצאים למסלול שנבחר.","answers":[{"text":"אין שירות, או מופיע \"אין רשת\", SOS או \"שיחות חירום בלבד\"","note":"כאשר אין אינדיקציה לבעיה התלויה במיקום או לאירוע אזורי. המסלול כולל בדיקות קו, שיוך SIM והגדרות מכשיר. אם במהלך הבירור מתגלה תלות במיקום — עבור לשלב 2.","go":"item:kbnew_r14"},{"text":"חוסר השירות החל לאחר הפעלת SIM או eSIM שהושלמה","note":"אין לבצע במקביל את מסלולי R-50 ו-R-51. אם מתברר שהתופעה תלויה במיקום — עבור לשלב 2.","go":"item:kbnew_r50"},{"text":"קוד QR לא התקבל, אינו נסרק, או שהתקנת פרופיל eSIM טרם הושלמה","note":"אין לבצע במקביל את מסלולי R-50 ו-R-51.","go":"item:kbnew_r51"},{"text":"יש רשת אך אין גלישה או שהגלישה איטית","note":"המסמך מבחין בין חוסר גלישה, איטיות, תקלה במקום מסוים ותקלה במהלך שיחה. אין להפנות מראש ל-R-33 בלי להשלים את האבחון.","go":"item:kbm_m30"},{"text":"יש רשת אך לא ניתן להוציא או לקבל שיחות","note":"האבחון ינתב ל-R-40 כאשר שני כיווני השיחה אינם עובדים, ל-R-41 בשיחות יוצאות בלבד, ל-R-42 בשיחות נכנסות בלבד, או ל-R-43 כאשר התקלה מול מספרים מסוימים.","go":"item:kbm_m40"},{"text":"השיחה מתחברת אך מתנתקת או שאיכות השמע אינה תקינה — במקום מסוים או במסלול נסיעה","note":"","go":"q:1"},{"text":"השיחה מתחברת אך מתנתקת או שאיכות השמע אינה תקינה — במקומות שונים","note":"בצע את האבחון לפי סדר השלבים במסמך. אין לחזור ל-M-40 שלב 2 עבור אותו תרחיש. אין לקבוע שהתקלה נובעת מכיסוי רדיו, מ-VoLTE או מהמכשיר לפני ביצוע הבדיקות; O-43 הוא מסמך תפעול ואינו מחליף את מסלול האבחון לניתוקים ולאיכות שמע.","go":"","ext":"מסמך ״בעיות VoLTE ומכשירים ישנים״ (עדיין לא באפליקציה)"},{"text":"הבעיה בשליחה או בקבלה של הודעות SMS","note":"יש להבחין בין הודעות רגילות לקודי אימות. אם גם שיחות או שירותים אחרים נפגעו, תעד זאת; אין לסווג את התקלה כמבודדת ל-SMS.","go":"item:kbm_m60"},{"text":"הגלישה במכשיר הראשי תקינה, אך נקודת הגישה האישית (Hotspot) אינה עובדת","note":"כאשר התקלה מוגבלת לשיתוף החיבור, אין להתחיל בבדיקת כיסוי כברירת מחדל.","go":"item:kbnew_o36"},{"text":"לא ברור מה נפגע","note":"בקש מהלקוח לתאר ניסיון שימוש שנכשל: שיחה יוצאת או נכנסת, שיחה שמתחברת ומתנתקת, גלישה כשהרשת האלחוטית כבויה, הודעת SMS רגילה או קוד אימות. תעד את החיווי וההודעה שהופיעה. אין להכריז על בעיית כיסוי ללא תיאור התופעה והמיקום.","go":"","ext":"חזרה לבחירת הענף בשלב זה"}]},{"title":"העברה להמשך טיפול","q":"","hint":"לאחר השלמת מסלול הטיפול שנבחר, פעל לפי תנאי ההעברה וההנחיות שבו. מסמך האבחון אינו מחליף את מסלול הטיפול, ואין להפנות ממנו ישירות למסמכי S של טיפול המומחים.\nבעת ההעברה צרף את תיאור התקלה, מועד תחילתה, מיקום אם רלוונטי, חיווי הרשת בקו, השירותים שנפגעו, שינויים אחרונים, הבדיקות שבוצעו ותוצאותיהן.\nציין בנפרד בדיקות שלא ניתן היה להשלים. אין לחזור על בדיקה שכבר בוצעה ונמצאה תקינה.","answers":[{"text":"בעיית קליטה התלויה במיקום","note":"","go":"item:kbm_e10"},{"text":"תקלה בשיחות","note":"","go":"item:kbm_e40"},{"text":"תקלה בגלישה","note":"","go":"item:kbm_e30"},{"text":"תקלה ב-SMS","note":"","go":"item:kbm_e60"},{"text":"חוסר שירות, כשל הפעלה, או ניתוקים ואיכות שמע","note":"","go":"","ext":"פעל לפי הוראות ההמשך במסלול שאליו הופנית"}]}],"outro":["״בעיית קליטה״ היא תיאור של הלקוח ולא אבחנה. בחר מסלול לפי השירות שאינו עובד, חיווי הרשת, התלות במיקום והשינוי ביחס לעבר. אין לקבוע את מקור התקלה לפני ביצוע הבדיקות, ואין להפנות למסמך שאינו מתאים לתרחיש.","חשד למכשיר או לכרטיס אינו אבחנה סופית. אם אין שירות — R-14. אם התקלה החלה לאחר הפעלה או שהתקנת eSIM לא הושלמה — R-50 או R-51 בהתאם למצב. אם יש רשת ונפגע שירות מסוים — בחר את ענף השיחות, איכות השמע, הגלישה או ה-SMS המתאים. אין לדלג ישירות למסמך טיפול מומחים."]},"source":{"name":"M-10 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/M-10.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793865099048,"originName":"M-10_אבחון_מרכזי_קליטה_בארץ_מתוקן.docx"};
window.dynamicDocs['kbm_r11'] = {"id":"kbm_r11","topic":"R-11 · קליטה חלשה במקום מסוים","cat":"tech","docType":"pdf","kind":"R","desc":"קליטה חלשה במקום מסוים","tags":["קליטה בארץ"],"owner":"","stages":[{"num":"1","title":"מטרת המסמך","items":[{"text":"לטפל במקרה שבו בעיית הקליטה מתרחשת במקום מוגדר, כגון בית, משרד או אזור מסוים.","img":null},{"text":"המסלול מתחיל לאחר הפניה מ:","img":null}],"images":[]},{"num":"2","title":"M-10 - בעיות קליטה בארץ - אבחון מרכזי","items":[],"images":[]},{"num":"3","title":"שלב 1 - ודא שמדובר בבעיה במקום מסוים","items":[{"text":"שאל:","img":null},{"text":"\"הבעיה קיימת רק במקום הזה, וכשאתה יוצא לאזור אחר הקליטה משתפרת?\"","img":null},{"text":"כן","img":null},{"text":"המשך לשלב 2.","img":null},{"text":"לא","img":null},{"text":"אם הבעיה מתרחשת גם במקומות שונים, חזור ל:","img":null}],"images":[]},{"num":"4","title":"M-10 - בעיות קליטה בארץ - אבחון מרכזי","items":[{"text":"ובצע ניתוב מחדש.","img":null}],"images":[]},{"num":"5","title":"שלב 2 - האם מדובר בהרעה חדשה?","items":[{"text":"שאל:","img":null},{"text":"\"האם בעבר הקליטה במקום הזה הייתה טובה יותר והבעיה התחילה לאחרונה?\"","img":null},{"text":"כן","img":null},{"text":"עבור למסלול:","img":null}],"images":[]},{"num":"6","title":"R-13 - הרעה חדשה בקליטה באזור","items":[{"text":"לא","img":null},{"text":"המשך לשלב 3.","img":null}],"images":[]},{"num":"7","title":"שלב 3 - בדיקת הכיסוי באזור","items":[{"text":"בצע בדיקה בהתאם למסמך:","img":null}],"images":[]},{"num":"8","title":"O-10 בדיקת מפת כיסוי ואנטנות","items":[],"images":[]},{"num":"9","title":"הכיסוי באזור אינו מספק","items":[{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"10","title":"הכיסוי באזור תקין","items":[{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"11","title":"שלב 4 - הכיסוי באזור אינו מספק","items":[{"text":"כאשר בדיקת מפת הכיסוי מצביעה על כיסוי לא מספק:","img":null},{"text":"הסבר ללקוח שמדובר במגבלת כיסוי באזור.","img":null},{"text":"במידת הצורך השתמש ב:","img":null}],"images":[]},{"num":"12","title":"T-10 תיאום ציפיות רשת סלולארית","items":[{"text":"אם קיימת רשת אלחוטית זמינה, ניתן להציע פתרון משלים:","img":null}],"images":[]},{"num":"13","title":"O-12 הפעלת שיחות ברשת אלחוטית","items":[{"text":"לאחר תיאום הציפיות והצעת הפתרון המשלים, סכם את הטיפול.","img":null}],"images":[]},{"num":"14","title":"שלב 5 - הכיסוי באזור תקין","items":[{"text":"שאל:","img":null},{"text":"\"הקליטה חלשה בכל הבית או המשרד, או רק בחלק מסוים?\"","img":null}],"images":[]},{"num":"15","title":"הבעיה קיימת רק בחלק מסוים בתוך המבנה","items":[{"text":"לדוגמה:","img":null},{"text":"חדר פנימי.","img":null},{"text":"ממ\"ד.","img":null},{"text":"מרתף.","img":null},{"text":"חניון.","img":null},{"text":"מעלית.","img":null},{"text":"קיים חשד להשפעת המבנה או למיסוך על הקליטה.","img":null},{"text":"הסבר ללקוח בהתאם ל:","img":null}],"images":[]},{"num":"16","title":"T-10 - תיאום ציפיות רשת סלולארית","items":[{"text":"אם קיימת רשת אלחוטית זמינה, ניתן להציע:","img":null}],"images":[]},{"num":"17","title":"O-12 - הפעלת שיחות ברשת אלחוטית","items":[{"text":"לאחר מכן סכם את הטיפול.","img":null}],"images":[]},{"num":"18","title":"הבעיה קיימת בכל הבית או המשרד","items":[{"text":"אם הכיסוי באזור תקין והבעיה קיימת בכל המקום:","img":null},{"text":"העבר את הפנייה ל:","img":null}],"images":[]},{"num":"19","title":"S-10 מסלול טיפול מומחה","items":[{"text":".","img":null}],"images":[]},{"num":"20","title":"סיום הטיפול","items":[],"images":[]},{"num":"21","title":"הכיסוי באזור אינו מספק","items":[{"text":"בצע תיאום ציפיות והצע פתרון משלים אם רלוונטי.","img":null}],"images":[]},{"num":"22","title":"הבעיה קיימת רק באזור פנימי בתוך המבנה","items":[{"text":"בצע תיאום ציפיות בנושא מיסוך והצע שיחות ברשת אלחוטית אם מתאים.","img":null}],"images":[]},{"num":"23","title":"הכיסוי באזור תקין והבעיה קיימת בכל המקום","items":[{"text":"העבר להמשך טיפול מומחה.","img":null}],"images":[]},{"num":"24","title":"כלל מנחה לנציג","items":[{"text":"בבעיה במקום מסוים סדר העבודה הוא:","img":null},{"text":"מיקום מוגדר ↓ בדיקת כיסוי ↓ כיסוי לא מספק → תיאום ציפיות ופתרון משלים","img":null},{"text":"כיסוי תקין ↓ בדיקה האם הבעיה בכל המקום או רק באזור פנימי ↓ אזור פנימי בלבד → חשד למיסוך","img":null},{"text":"כל המקום → S-10 - מסלול טיפול מומחה","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-11 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-11.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-11 - קליטה חלשה במקום מסוים.docx"};
window.dynamicDocs['kbm_r12'] = {"id":"kbm_r12","topic":"R-12 · קליטה חלשה או ניתוקים בנסיעה","cat":"tech","docType":"pdf","kind":"R","desc":"קליטה חלשה או ניתוקים בנסיעה","tags":["קליטה בארץ"],"owner":"","stages":[{"num":"1","title":"מטרת המסמך","items":[{"text":"לטפל במקרה שבו בעיית הקליטה, ניתוקי השיחות או חוסר הקליטה מתרחשים בעיקר בזמן נסיעה.","img":null},{"text":"המסלול מתחיל לאחר הפניה מ:","img":null}],"images":[]},{"num":"2","title":"M-10 בעיות קליטה בארץ - אבחון מרכזי","items":[],"images":[]},{"num":"3","title":"שלב 1 - ודא שהבעיה קשורה לנסיעה","items":[{"text":"שאל:","img":null},{"text":"\"הבעיה מתרחשת בעיקר בזמן נסיעה, וכשאתה נמצא במקום קבוע השירות בדרך כלל תקין?\"","img":null},{"text":"כן","img":null},{"text":"המשך לשלב 2.","img":null},{"text":"לא","img":null},{"text":"אם הבעיה קיימת גם במקומות קבועים או במקומות שונים:","img":null},{"text":"חזור ל:","img":null}],"images":[]},{"num":"4","title":"M-10 בעיות קליטה בארץ - אבחון מרכזי","items":[{"text":"ובצע ניתוב מחדש.","img":null}],"images":[]},{"num":"5","title":"שלב 2 - מה הלקוח חווה בזמן הנסיעה?","items":[{"text":"שאל:","img":null},{"text":"\"מה קורה בזמן הנסיעה - הקליטה נחלשת, אין קליטה בכלל או שהשיחות מתנתקות?\"","img":null},{"text":"תעד את תיאור הלקוח.","img":null},{"text":"אם מתברר שהבעיה היא בעיקר גלישה איטית:","img":null},{"text":"עבור למסמך:","img":null}],"images":[]},{"num":"6","title":"M-30 איטיות או חוסר גלישה בישראל","items":[{"text":"אם מדובר בקליטה או בניתוקי שיחות:","img":null},{"text":"המשך לשלב 3.","img":null}],"images":[]},{"num":"7","title":"שלב 3 - איפה הבעיה מתרחשת?","items":[{"text":"שאל:","img":null},{"text":"\"האם הבעיה חוזרת בדרך כלל באותו אזור או באותו מסלול?\"","img":null},{"text":"כן","img":null},{"text":"אסוף מהלקוח פרטים מדויקים ככל האפשר:","img":null},{"text":"כביש או רחוב.","img":null},{"text":"כיוון נסיעה.","img":null},{"text":"האזור שבו מתרחשת הבעיה.","img":null},{"text":"נקודת התחלה וסיום של המקטע, ככל שניתן.","img":null},{"text":"האם מדובר בניתוקים, קליטה חלשה או חוסר קליטה.","img":null},{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"8","title":"שלב 4 - האם מדובר בשינוי ביחס לעבר?","items":[{"text":"שאל:","img":null},{"text":"\"האם בעבר הקליטה במסלול הזה הייתה תקינה והבעיה התחילה לאחרונה?\"","img":null},{"text":"כן","img":null},{"text":"תעד שמדובר בהרעה חדשה.","img":null},{"text":"לא","img":null},{"text":"תעד שמדובר במצב מתמשך.","img":null},{"text":"בשני המקרים המשך לשלב 5.","img":null}],"images":[]},{"num":"9","title":"שלב 5 - העברה למומחה","items":[{"text":"כאשר הלקוח מוסר פרטים מספקים על האזור או המסלול שבו מתרחשים ניתוקים, קליטה חלשה או חוסר קליטה:","img":null},{"text":"העבר את הפנייה ל:","img":null}],"images":[]},{"num":"10","title":"S-10 מסלול טיפול מומחה","items":[{"text":"יש להעביר למומחה את כל הפרטים שנאספו במסלול.","img":null},{"text":"מטרת ההעברה היא לאפשר בדיקה מקצועית של האזור והאירוע.","img":null}],"images":[]},{"num":"11","title":"שלב 6 - תיאום ציפיות מול הלקוח","items":[{"text":"בכל מקרה שבו הפנייה מועברת למומחה, יש לבצע תיאום ציפיות לפני סיום השיחה.","img":null},{"text":"יש להסביר ללקוח:","img":null},{"text":"שהפנייה תועבר לבדיקה.","img":null},{"text":"שהבדיקה אינה מבטיחה שיימצא ממצא הניתן לטיפול.","img":null},{"text":"שבזמן נסיעה איכות הקליטה עשויה להשתנות עקב מאפייני הרשת והמעבר בין אזורי כיסוי.","img":null},{"text":"ייתכן שההתנהגות שהלקוח חווה נובעת ממגבלות הרשת באזור או במסלול.","img":null},{"text":"השתמש בתסריט המתאים מתוך:","img":null}],"images":[]},{"num":"12","title":"T-10 תיאום ציפיות רשת סלולארית","items":[],"images":[]},{"num":"13","title":"לפני העברה למומחה","items":[{"text":"ודא שתועד:","img":null},{"text":"סוג הבעיה: ניתוקים / קליטה חלשה / חוסר קליטה.","img":null},{"text":"כביש או רחוב.","img":null},{"text":"כיוון נסיעה.","img":null},{"text":"אזור או מקטע מדויק ככל האפשר.","img":null},{"text":"האם הבעיה חדשה או מתמשכת.","img":null},{"text":"האם הבעיה חוזרת באותו מקום.","img":null},{"text":"כל פרט נוסף שיכול לסייע בזיהוי המיקום.","img":null}],"images":[]},{"num":"14","title":"סיום הטיפול","items":[{"text":"לאחר איסוף הפרטים:","img":null},{"text":"העבר את הפנייה ל S-10","img":null},{"text":"בצע תיאום ציפיות לפי T-10","img":null},{"text":"סכם ללקוח שהפנייה הועברה לבדיקה ושייתכן שהממצא קשור למגבלות הכיסוי או מאפייני הרשת באזור.","img":null}],"images":[]},{"num":"15","title":"כלל מנחה לנציג","items":[{"text":"בבעיית קליטה או ניתוקים בזמן נסיעה, תפקיד הנציג הוא לזהות את המיקום בצורה מדויקת ככל האפשר ולהעביר את המידע למומחה.","img":null},{"text":"אין להתחייב ללקוח שהבדיקה תוביל לפתרון.","img":null},{"text":"יש להסביר מראש כי גם לאחר בדיקה ייתכן שמדובר במגבלת רשת ולא בתקלה הניתנת לטיפול.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-12 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-12.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-12 - קליטה חלשה או ניתוקים בנסיעה.docx"};
window.dynamicDocs['kbm_r13'] = {"id":"kbm_r13","topic":"R-13 · הרעה חדשה בקליטה באזור","cat":"tech","docType":"pdf","kind":"R","desc":"הרעה חדשה בקליטה באזור","tags":["קליטה בארץ"],"owner":"","stages":[{"num":"1","title":"מטרת המסמך","items":[{"text":"לטפל במקרה שבו הלקוח מדווח שבעבר הקליטה באזור הייתה תקינה, וכעת קיימת הרעה חדשה.","img":null},{"text":"ההרעה יכולה להתבטא ב:","img":null},{"text":"קליטה חלשה יותר.","img":null},{"text":"ניתוקי שיחות.","img":null},{"text":"חוסר קליטה בחלק מהזמן.","img":null},{"text":"שינוי באיכות השירות באזור שהיה תקין בעבר.","img":null},{"text":"המסלול מתחיל לאחר הפניה מ:","img":null}],"images":[]},{"num":"2","title":"M-10 בעיות קליטה בארץ - אבחון מרכזי","items":[{"text":"או ממסלול קליטה אחר שבו זוהה שינוי חדש ביחס לעבר.","img":null}],"images":[]},{"num":"3","title":"שלב 1 - ודא שמדובר בהרעה חדשה","items":[{"text":"שאל:","img":null},{"text":"\"האם בעבר הקליטה באזור הזה הייתה תקינה והבעיה התחילה רק לאחרונה?\"","img":null},{"text":"כן","img":null},{"text":"המשך לשלב 2.","img":null},{"text":"לא","img":null},{"text":"אין מדובר בהרעה חדשה.","img":null},{"text":"חזור למסלול המתאים לפי סוג הבעיה:","img":null}],"images":[]},{"num":"4","title":"R-11 קליטה חלשה במקום מסוים","items":[],"images":[]},{"num":"5","title":"R-12 קליטה חלשה או ניתוקים בנסיעה","items":[],"images":[]},{"num":"6","title":"שלב 2 - מה השתנה?","items":[{"text":"שאל:","img":null},{"text":"\"מה השתנה לעומת המצב שהיה קודם?\"","img":null},{"text":"ברר האם מדובר ב:","img":null},{"text":"ירידה בעוצמת הקליטה.","img":null},{"text":"ניתוקי שיחות שלא היו בעבר.","img":null},{"text":"חוסר קליטה לפרקי זמן.","img":null},{"text":"החמרה באזור מסוים בתוך הבית או המשרד.","img":null},{"text":"החמרה באזור גיאוגרפי או במסלול נסיעה.","img":null},{"text":"תעד את תיאור הלקוח.","img":null}],"images":[]},{"num":"7","title":"שלב 3 - מתי התחילה ההרעה?","items":[{"text":"שאל:","img":null},{"text":"\"ממתי אתה מרגיש את השינוי?\"","img":null},{"text":"תעד ככל האפשר:","img":null},{"text":"מועד תחילת הבעיה.","img":null},{"text":"האם הבעיה קיימת מאז באופן רציף או לסירוגין.","img":null}],"images":[]},{"num":"8","title":"שלב 4 - איפה ההרעה מתרחשת?","items":[{"text":"יש לאסוף מיקום מדויק ככל האפשר.","img":null}],"images":[]},{"num":"9","title":"מקום קבוע","items":[{"text":"תעד:","img":null},{"text":"כתובת מלאה.","img":null},{"text":"קומה, אם רלוונטי.","img":null},{"text":"האם הבעיה בכל המבנה או רק בחלק ממנו.","img":null}],"images":[]},{"num":"10","title":"אזור פתוח","items":[{"text":"תעד:","img":null},{"text":"רחוב / אזור.","img":null},{"text":"נקודת ציון ככל שניתן.","img":null}],"images":[]},{"num":"11","title":"בזמן נסיעה","items":[{"text":"תעד:","img":null},{"text":"כביש או רחוב.","img":null},{"text":"כיוון נסיעה.","img":null},{"text":"נקודת התחלה וסיום של המקטע שבו קיימת הבעיה.","img":null}],"images":[]},{"num":"12","title":"שלב 5 - האם לקוחות נוספים חווים את אותה ההרעה?","items":[{"text":"שאל:","img":null},{"text":"\"יש עוד אנשים באזור שחווים שינוי דומה בקליטה?\"","img":null},{"text":"כן","img":null},{"text":"תעד זאת בפנייה.","img":null}],"images":[]},{"num":"13","title":"לא / לא ידוע","items":[{"text":"המשך בטיפול.","img":null},{"text":"אין לעכב את ההעברה רק משום שאין ללקוח מידע על משתמשים נוספים.","img":null}],"images":[]},{"num":"14","title":"שלב 6 - העברה למומחה","items":[{"text":"כאשר קיימת הרעה חדשה ביחס לעבר ונאסף מיקום מדויק ככל האפשר:","img":null},{"text":"העבר את הפנייה ל:","img":null}],"images":[]},{"num":"15","title":"S-10 מסלול טיפול מומחה","items":[{"text":"יש להעביר למומחה את כל המידע שנאסף.","img":null},{"text":"הנציג אינו מעביר את הפנייה ישירות להנדסה.","img":null}],"images":[]},{"num":"16","title":"שלב 7 - תיאום ציפיות מול הלקוח","items":[{"text":"לפני סיום השיחה יש להסביר ללקוח שהפנייה מועברת לבדיקה.","img":null},{"text":"אין להתחייב:","img":null},{"text":"שיימצא ממצא.","img":null},{"text":"שהבעיה ניתנת לתיקון.","img":null},{"text":"למועד שבו הקליטה תשתפר.","img":null},{"text":"יש לבצע תיאום ציפיות בהתאם ל:","img":null}],"images":[]},{"num":"17","title":"T-10 תיאום ציפיות רשת סלולארית","items":[{"text":"יש להסביר כי הרשת הסלולרית מושפעת מגורמים שונים, ולכן גם כאשר קיימת הרעה ביחס לעבר נדרשת בדיקה לפני שניתן לקבוע את הסיבה או את אפשרות הטיפול.","img":null}],"images":[]},{"num":"18","title":"לפני העברה למומחה","items":[{"text":"ודא שתועד:","img":null},{"text":"מה השתנה ביחס לעבר.","img":null},{"text":"ממתי קיימת ההרעה.","img":null},{"text":"סוג הבעיה.","img":null},{"text":"כתובת / אזור / מסלול מדויק ככל האפשר.","img":null},{"text":"האם הבעיה קבועה או לסירוגין.","img":null},{"text":"האם ידוע על לקוחות נוספים שחווים את אותה תופעה.","img":null}],"images":[]},{"num":"19","title":"סיום הטיפול","items":[{"text":"לאחר איסוף המידע:","img":null},{"text":"העבר את הפנייה ל S-10","img":null},{"text":"בצע תיאום ציפיות לפי T-10","img":null},{"text":"תעד את כל פרטי האירוע בצורה שתאפשר למומחה להמשיך את הבדיקה ללא תשאול חוזר של הלקוח.","img":null}],"images":[]},{"num":"20","title":"כלל מנחה לנציג","items":[{"text":"הרעה חדשה פירושה שינוי ביחס למצב שהיה תקין בעבר.","img":null},{"text":"תפקיד הנציג הוא לזהות את השינוי, לאסוף מיקום ומועד מדויקים ככל האפשר ולהעביר את המידע למומחה.","img":null},{"text":"אין לקבוע בשלב זה מה מקור ההרעה ואין להתחייב לפתרון.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-13 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-13.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-13 - הרעה חדשה בקליטה באזור.docx"};
window.dynamicDocs['kbm_o10'] = {"id":"kbm_o10","topic":"O-10 · בדיקת מפת כיסוי ואנטנות","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקת מפת כיסוי ואנטנות","tags":["קליטה בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לבדוק את מצב הכיסוי הסלולרי באזור שבו הלקוח מדווח על בעיית קליטה, ולהחזיר את תוצאת הבדיקה למסלול הטיפול שממנו הופנה הנציג.","img":null},{"text":"המסמך משמש בעיקר מתוך:","img":null}]},{"title":"R-11 קליטה חלשה במקום מסוים","ordered":false,"steps":[]},{"title":"לפני הבדיקה","ordered":false,"steps":[{"text":"ודא שיש ברשותך מיקום מדויק ככל האפשר.","img":null},{"text":"בקש מהלקוח:","img":null},{"text":"יישוב.","img":null},{"text":"רחוב.","img":null},{"text":"מספר בית, ככל שקיים.","img":null},{"text":"מיקום נוסף או נקודת ציון אם הכתובת אינה מספיקה.","img":null}]},{"title":"שלב 1 - איתור המיקום במפת הכיסוי","ordered":true,"steps":[{"text":"פתח את מפת הכיסוי וחפש את הכתובת שמסר הלקוח.","img":null}]},{"title":"נדרש להשלים","ordered":false,"steps":[{"text":"שם המערכת.","img":null},{"text":"נתיב הכניסה למפה.","img":null},{"text":"אופן חיפוש כתובת.","img":null},{"text":"משמעות הסימונים והצבעים במערכת.","img":null}]},{"title":"שלב 2 - בדיקת מצב הכיסוי","ordered":true,"steps":[{"text":"בדוק את רמת הכיסוי המוצגת באזור הרלוונטי.","img":null}]},{"title":"הכיסוי באזור תקין","ordered":false,"steps":[{"text":"חזור למסלול:","img":null}]},{"title":"R-11 - קליטה חלשה במקום מסוים","ordered":false,"steps":[{"text":"והמשך לבדוק האם הבעיה קיימת בכל המקום או רק בחלק מסוים בתוך המבנה.","img":null}]},{"title":"הכיסוי באזור אינו מספק","ordered":false,"steps":[{"text":"חזור למסלול:","img":null}]},{"title":"R-11 - קליטה חלשה במקום מסוים","ordered":false,"steps":[{"text":"והמשך למסלול של מגבלת כיסוי.","img":null},{"text":"אין להמשיך בבדיקות מכשיר במסגרת מסמך זה.","img":null}]},{"title":"שלב 3 - בדיקת מיקום הלקוח ביחס לאזור הכיסוי","ordered":true,"steps":[{"text":"כאשר הכתובת נמצאת בסמוך לגבול בין אזורי כיסוי שונים, יש להתייחס לכך במסגרת תוצאת הבדיקה.","img":null},{"text":"אין לקבוע על סמך המפה בלבד שהלקוח אמור לקבל קליטה מלאה בתוך מבנה.","img":null},{"text":"מפת הכיסוי היא כלי עזר להערכת הכיסוי באזור ואינה מבטיחה איכות קליטה זהה בכל נקודה או בתוך כל מבנה.","img":null}]},{"title":"תוצאת הבדיקה","ordered":false,"steps":[{"text":"בסיום הבדיקה יש להחזיר למסלול הטיפול אחת משתי תוצאות:","img":null}]},{"title":"\"כיסוי תקין באזור\"","ordered":false,"steps":[]},{"title":"המשך טיפול ב־R-11","ordered":false,"steps":[]},{"title":"\"כיסוי אינו מספק באזור\"","ordered":false,"steps":[]},{"title":"המשך טיפול ב־R-11 תיאום ציפיות בהתאם ל־T-10 - תיאום ציפיות רשת סלולארית","ordered":false,"steps":[]},{"title":"כלל מנחה לנציג","ordered":false,"steps":[{"text":"מפת הכיסוי אינה מסמך אבחון בפני עצמו.","img":null},{"text":"מטרתה לענות על שאלה אחת:","img":null},{"text":"האם באזור שבו הלקוח נמצא קיימת אינדיקציה לכיסוי מספק או למגבלת כיסוי?","img":null},{"text":"לאחר קבלת התוצאה יש לחזור למסלול הטיפול שממנו הופנית.","img":null}]}]},"source":{"name":"O-10 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-10.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-10 - בדיקת מפת כיסוי ואנטנות.docx"};
window.dynamicDocs['kbm_o12'] = {"id":"kbm_o12","topic":"O-12 · הפעלת שיחות ברשת אלחוטית","cat":"tech","docType":"pdf","kind":"O","desc":"הפעלת שיחות ברשת אלחוטית","tags":["קליטה בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"להנחות את הנציג כיצד להפעיל שיחות ברשת אלחוטית במכשיר הלקוח, כפתרון משלים במקרים של קליטה סלולרית חלשה במקום מסוים.","img":null},{"text":"השירות מאפשר לבצע ולקבל שיחות באמצעות רשת אלחוטית כאשר הקליטה הסלולרית חלשה. במסמך ההשוואה הקיים אצלכם מוגדר השירות כפתרון למצב שבו אין קליטה סלולרית מספקת אך קיימת רשת אלחוטית זמינה.","img":null}]},{"title":"מתי משתמשים במסמך?","ordered":false,"steps":[{"text":"השתמש במסמך כאשר:","img":null},{"text":"בעיית הקליטה מתרחשת במקום מסוים.","img":null},{"text":"קיימת מגבלת כיסוי או חשד למיסוך בתוך מבנה.","img":null},{"text":"קיימת במקום רשת אלחוטית פעילה.","img":null},{"text":"המכשיר תומך בשירות.","img":null}]},{"title":"שלב 1 - ודא שהלקוח מחובר לרשת אלחוטית","ordered":true,"steps":[{"text":"שאל:","img":null},{"text":"\"האם המכשיר מחובר כרגע לרשת האלחוטית במקום?\"","img":null},{"text":"לא","img":null},{"text":"הנחה את הלקוח להתחבר לרשת האלחוטית.","img":null},{"text":"לאחר החיבור המשך לשלב 2.","img":null},{"text":"כן","img":null},{"text":"המשך לשלב 2.","img":null}]},{"title":"שלב 2 - הפעלת השירות לפי סוג מכשיר","ordered":true,"steps":[]},{"title":"iPhone","ordered":false,"steps":[{"text":"הנחה את הלקוח:","img":null},{"text":"הגדרות ↓ סלולרי ↓ אם קיימים מספר קווים - לבחור את הקו הרלוונטי ↓ שיחות ברשת אלחוטית ↓ להפעיל \"שיחות ברשת אלחוטית ב-iPhone זה\"","img":null},{"text":"הנתיב מבוסס על הנחיות Apple העדכניות.","img":null},{"text":"אם האפשרות אינה מופיעה, אין להניח שמדובר בתקלה. הזמינות תלויה גם בתמיכת המפעיל ובמכשיר.","img":null}]},{"title":"Samsung","ordered":false,"steps":[{"text":"הנחה את הלקוח:","img":null},{"text":"הגדרות ↓ חיבורים ↓ שיחות ברשת אלחוטית ↓ הפעלה","img":null},{"text":"בחלק ממכשירי Samsung ניתן להפעיל גם דרך:","img":null},{"text":"טלפון ↓ שלוש נקודות ↓ הגדרות ↓ שיחות ברשת אלחוטית","img":null},{"text":"בחלק מהדגמים קיימת גם אפשרות דרך לוח הקיצורים.","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[{"text":"הנחה את הלקוח:","img":null},{"text":"הגדרות ↓ רשת ואינטרנט ↓ כרטיסי SIM ↓ בחירת הקו ↓ שיחות ברשת אלחוטית ↓ הפעלה","img":null},{"text":"Google מציינת שאם האפשרות אינה מופיעה, ייתכן שהמפעיל אינו תומך בשירות עבור המכשיר או הקו.","img":null}]},{"title":"Xiaomi / Redmi","ordered":false,"steps":[{"text":"הנחה את הלקוח:","img":null},{"text":"הגדרות ↓ כרטיסי SIM ורשתות סלולריות ↓ בחירת כרטיס ה SIM ↓ ביצוע שיחות באמצעות רשת אלחוטית ↓ הפעלה","img":null},{"text":"הנתיב מופיע בתיעוד הרשמי של Xiaomi.","img":null},{"text":"אין להשתמש בקודי חיוג מוסתרים במסגרת טיפול נציג, אלא אם הוגדרו ואושרו בתהליך העבודה של החברה.","img":null}]},{"title":"שלב 3 - ודא שהשירות פעיל","ordered":true,"steps":[{"text":"לאחר ההפעלה:","img":null},{"text":"ודא שהמכשיר עדיין מחובר לרשת האלחוטית.","img":null},{"text":"המתן מספר רגעים.","img":null},{"text":"בצע בדיקת שיחה.","img":null}]},{"title":"השיחה יוצאת ונכנסת באופן תקין","ordered":false,"steps":[{"text":"המשך לשלב 4.","img":null}]},{"title":"השירות אינו עובד","ordered":false,"steps":[{"text":"בדוק:","img":null},{"text":"שהמכשיר מחובר לרשת אלחוטית יציבה.","img":null},{"text":"שהאפשרות עדיין פעילה במכשיר.","img":null},{"text":"שהמכשיר תומך בשירות.","img":null},{"text":"שהשירות זמין אצל המפעיל.","img":null}]},{"title":"Samsung ו -Xiaomi מציינות במפורש שהשירות תלוי גם בתמיכת המפעיל ובחיבור תקין לרשת אלחוטית.","ordered":false,"steps":[{"text":"אם הכול תקין והשירות עדיין אינו עובד, חזור למסלול הטיפול שממנו הופנית.","img":null}]},{"title":"שלב 4 - הסבר ללקוח","ordered":true,"steps":[{"text":"הסבר:","img":null},{"text":"\"שיחות ברשת אלחוטית מאפשרות לבצע ולקבל שיחות דרך רשת ה-Wi-Fi במקום שבו הקליטה הסלולרית חלשה. כל עוד אתה מחובר לרשת אלחוטית יציבה והשירות פעיל במכשיר, ניתן להשתמש בשיחות גם כאשר הקליטה הסלולרית במקום נמוכה.\"","img":null},{"text":"אם נדרש תיאום ציפיות נוסף:","img":null},{"text":"עבור ל:","img":null}]},{"title":"T-10 תיאום ציפיות רשת סלולארית","ordered":false,"steps":[{"text":"מתי לא להשתמש במסמך?","img":null},{"text":"אין להשתמש במסמך כאשר:","img":null},{"text":"הבעיה מתרחשת בכל מקום.","img":null},{"text":"הלקוח אינו מחובר לרשת אלחוטית.","img":null},{"text":"הבעיה היא גלישה איטית ולא שיחות.","img":null},{"text":"אין קליטה או אין שירות באופן כללי ויש צורך באבחון נפרד.","img":null},{"text":"הבעיה אינה קשורה למיקום.","img":null},{"text":"במקרים אלה יש לחזור למסלול האבחון או הטיפול המתאים.","img":null}]},{"title":"תוצאת הטיפול","ordered":false,"steps":[]},{"title":"השירות הופעל והשיחות תקינות","ordered":false,"steps":[{"text":"סכם את הטיפול.","img":null}]},{"title":"האפשרות אינה קיימת במכשיר","ordered":false,"steps":[{"text":"אין באפשרותי לאשר מהחומרים הקיימים האם כל דגם נתמך ברשת החברה.","img":null},{"text":"יש לבדוק מול רשימת המכשירים הנתמכים של החברה, אם קיימת.","img":null}]},{"title":"השירות פעיל אך אינו עובד","ordered":false,"steps":[{"text":"חזור למסלול הטיפול שממנו הופנית.","img":null},{"text":"אין לבצע שינויי מערכת או הגדרות נוספות שאינן מוגדרות במסלול.","img":null}]},{"title":"כלל מנחה לנציג","ordered":false,"steps":[{"text":"שיחות ברשת אלחוטית הן פתרון משלים לבעיית קליטה במקום מסוים.","img":null},{"text":"השירות אינו משפר את הכיסוי הסלולרי עצמו.","img":null},{"text":"הוא מאפשר לבצע ולקבל שיחות באמצעות רשת אלחוטית כאשר הקליטה הסלולרית במקום אינה מספקת.","img":null}]},{"title":"מקורות תפעול","ordered":false,"steps":[{"text":"Apple https://support.apple.com/en-il/108066","img":null}]},{"title":"Samsung https://www.samsung.com/us/support/answer/ANS10001348/","ordered":false,"steps":[{"text":"Google https://support.google.com/phoneapp/answer/2811843","img":null}]},{"title":"Xiaomi https://www.mi.com/global/support/faq/details/KA-92582/","ordered":false,"steps":[]}]},"source":{"name":"O-12 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-12.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-12 - הפעלת שיחות ברשת אלחוטית  wifiCalling.docx"};
window.dynamicDocs['kbm_o13'] = {"id":"kbm_o13","topic":"O-13 · איפוס הגדרות רשת","cat":"tech","docType":"pdf","kind":"O","desc":"איפוס הגדרות רשת","tags":["קליטה בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"להנחות את הנציג כיצד לבצע איפוס הגדרות רשת במכשיר הלקוח כחלק מתהליך טיפול בתקלה סלולרית.","img":null},{"text":"איפוס הגדרות רשת אינו איפוס מלא של המכשיר ואינו מוחק תמונות, קבצים או אפליקציות. ההגדרות שמתאפסות משתנות לפי סוג המכשיר והפעולה שנבחרה.","img":null}]},{"title":"לפני ביצוע האיפוס","ordered":false,"steps":[{"text":"יש להסביר ללקוח מה צפוי להתאפס.","img":null},{"text":"במכשירים שבהם מבוצע איפוס משולב של Wi-Fi, רשת סלולרית ו-Bluetooth, כגון Xiaomi - Huawei, יימחקו גם הגדרות Wi-Fi וBluetooth","img":null},{"text":"ייתכן שיימחקו:","img":null},{"text":"רשתות אלחוטיות שמורות וסיסמאות.","img":null},{"text":"התקני Bluetooth שהותאמו למכשיר.","img":null},{"text":"הגדרות סלולריות מסוימות.","img":null}]},{"title":"תסריט","ordered":false,"steps":[{"text":"\"הפעולה אינה מוחקת תמונות או אפליקציות, אבל היא עשויה למחוק רשתות אלחוטיות שמורות והתקני Bluetooth. לאחר האיפוס ייתכן שתצטרך להתחבר אליהם מחדש.\"","img":null}]},{"title":"הגדרות גלישה","ordered":false,"steps":[{"text":"בחלק מהמכשירים האיפוס עשוי להחזיר הגדרות סלולריות או APN לברירת המחדל.","img":null},{"text":"לאחר האיפוס יש לוודא שהלקוח מצליח לגלוש.","img":null},{"text":"אם אין גלישה:","img":null},{"text":"עבור למסמך התפעול המתאים להגדרת APN O-32","img":null},{"text":"ב־iPhone, Apple מציינת במפורש שאיפוס הגדרות רשת מאפס גם הגדרות סלולריות, VPN וAPN","img":null}]},{"title":"מדריכים לפי סוג מכשיר","ordered":false,"steps":[]},{"title":"Samsung","ordered":false,"steps":[{"text":"במכשירי Galaxy חדשים ניתן לבצע איפוס ממוקד של הרשת הסלולרית.","img":null},{"text":"עברית:","img":null},{"text":"הגדרות ↓ ניהול כללי ↓ איפוס ↓ איפוס הגדרות רשת סלולרית","img":null},{"text":"English:","img":null},{"text":"Settings General management Reset Reset mobile network settings","img":null},{"text":"בגרסאות או בדגמים אחרים עשויה להופיע האפשרות:","img":null},{"text":"Reset network settings","img":null},{"text":"כאשר מטרת הטיפול היא תקלה סלולרית, יש להעדיף את איפוס הרשת הסלולרית אם אפשרות זו קיימת.","img":null}]},{"title":"iPhone","ordered":false,"steps":[{"text":"עברית:","img":null},{"text":"הגדרות ↓ כללי ↓ העברה או איפוס iPhone ↓ איפוס ↓ איפוס הגדרות רשת","img":null},{"text":"English:","img":null},{"text":"Settings General Transfer or Reset iPhone Reset Reset Network Settings","img":null},{"text":"האיפוס מוחק רשתות אלחוטיות וסיסמאות שמורות ומאפס הגדרות סלולריות, VPN ו־APN.","img":null}]},{"title":"Xiaomi / Redmi / POCO","ordered":false,"steps":[{"text":"בגרסאות חדשות:","img":null},{"text":"עברית:","img":null},{"text":"הגדרות ↓ אפשרויות קישוריות נוספות ↓ איפוס Wi-Fi, רשתות סלולריות ו־Bluetooth ↓ איפוס הגדרות","img":null},{"text":"English:","img":null},{"text":"Settings More connectivity options Reset Wi-Fi, mobile networks, and Bluetooth Reset settings","img":null},{"text":"בגרסאות ישנות יותר ייתכן שיופיע:","img":null},{"text":"Connection & sharing","img":null},{"text":"במקום:","img":null},{"text":"More connectivity options","img":null},{"text":"פעולה זו מאפסת יחד את הגדרות הרשת האלחוטית, הרשת הסלולרית ו־Bluetooth.","img":null}]},{"title":"Huawei","ordered":false,"steps":[{"text":"עברית:","img":null},{"text":"הגדרות ↓ מערכת ועדכונים ↓ איפוס ↓ איפוס הגדרות רשת","img":null},{"text":"English:","img":null},{"text":"Settings System & updates Reset Reset network settings","img":null},{"text":"האיפוס מאפס הגדרות רשת אלחוטית, נתונים סלולריים ו־ Bluetooth, אך אינו מוחק מידע אישי מהמכשיר.","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[{"text":"כאשר מטפלים בתקלה סלולרית:","img":null},{"text":"עברית:","img":null},{"text":"הגדרות ↓ מערכת ↓ אפשרויות איפוס ↓ איפוס הגדרות רשת סלולרית","img":null},{"text":"English:","img":null},{"text":"Settings System Reset options Reset mobile network settings","img":null},{"text":"אין צורך לאפס רשת אלחוטית ו־Bluetooth כאשר התקלה היא סלולרית בלבד.","img":null},{"text":"Google מציעה איפוס נפרד לרשת האלחוטית ול־Bluetooth.","img":null}]},{"title":"Realme","ordered":false,"steps":[{"text":"בגרסאות שבהן קיים איפוס רשת ייעודי:","img":null},{"text":"עברית:","img":null},{"text":"הגדרות ↓ הגדרות נוספות ↓ איפוס הטלפון ↓ איפוס הגדרות רשת","img":null},{"text":"English:","img":null},{"text":"Settings Additional settings Reset phone Reset network settings","img":null},{"text":"שם התפריט עשוי להשתנות בין גרסאות מערכת. הנתיב מבוסס על התמיכה הרשמית של Realme.","img":null}]},{"title":"Oppo","ordered":false,"steps":[{"text":"תפריטי Oppo משתנים בין גרסאות ColorOS.","img":null},{"text":"אין באפשרותי לאשר נתיב אחיד ועדכני לכל הדגמים מהמקור הרשמי שנמצא.","img":null},{"text":"יש לחפש בהגדרות המכשיר:","img":null},{"text":"\"Reset network settings\"","img":null},{"text":"או:","img":null},{"text":"\"איפוס הגדרות רשת\"","img":null},{"text":"אין לבצע איפוס מלא של המכשיר.","img":null}]},{"title":"Vivo","ordered":false,"steps":[{"text":"עברית:","img":null},{"text":"הגדרות ↓ ניהול מערכת / מערכת ↓ גיבוי ואיפוס / אפשרויות איפוס ↓ איפוס הגדרות רשת","img":null},{"text":"English:","img":null},{"text":"Settings System management / System Backup & reset / Reset options Reset network settings","img":null},{"text":"שמות התפריטים משתנים לפי גרסת המערכת.","img":null}]},{"title":"Nothing Phone","ordered":false,"steps":[{"text":"עברית:","img":null},{"text":"הגדרות ↓ מערכת ↓ אפשרויות איפוס ↓ איפוס Wi-Fi, Bluetooth ורשת סלולרית","img":null},{"text":"English:","img":null},{"text":"Settings System Reset options Reset Wi-Fi, Bluetooth & Mobile","img":null},{"text":"הפעולה מאפסת את שלושת סוגי החיבור.","img":null}]},{"title":"OnePlus","ordered":false,"steps":[{"text":"שמות התפריטים משתנים בין גרסאות OxygenOS.","img":null},{"text":"אין באפשרותי לאשר מהמקור הרשמי שנמצא נתיב אחיד ועדכני לכל הגרסאות.","img":null},{"text":"אין להסתמך במסמך נציג על נתיב קבוע עד שנקבל תיעוד מאומת לדגמים הרלוונטיים.","img":null}]},{"title":"לאחר האיפוס","ordered":false,"steps":[{"text":"לאחר ביצוע האיפוס:","img":null},{"text":"המתן לחיבור מחדש לרשת הסלולרית.","img":null},{"text":"ודא שמופיע חיווי רשת.","img":null},{"text":"בצע בדיקת שיחה בהתאם לתקלה.","img":null},{"text":"ודא שהלקוח מצליח לגלוש.","img":null},{"text":"אם נדרש, חבר מחדש את הלקוח לרשת האלחוטית או להתקני Bluetooth שהתאפסו.","img":null},{"text":"אם הגלישה אינה עובדת לאחר האיפוס:","img":null},{"text":"עבור למסמך הגדרת APN המתאים.","img":null}]},{"title":"אם הלקוח שואל למה צריך לבצע איפוס","ordered":false,"steps":[]},{"title":"תסריט","ordered":false,"steps":[{"text":"\"איפוס הגדרות הרשת מחזיר את הגדרות החיבור לברירת המחדל ויכול לפתור תקלות שנגרמות מהגדרה או חיבור שלא נטענו בצורה תקינה. הפעולה אינה מוחקת תמונות, קבצים או אפליקציות.\"","img":null}]},{"title":"כלל מנחה לנציג","ordered":false,"steps":[{"text":"אין לבצע איפוס רחב יותר מהנדרש.","img":null},{"text":"אם המכשיר מאפשר איפוס של הרשת הסלולרית בלבד והתקלה היא סלולרית, יש להשתמש באפשרות זו.","img":null},{"text":"אין לבצע איפוס להגדרות יצרן כחלק מתהליך זה.","img":null}]},{"title":"מקורות","ordered":false,"steps":[{"text":"Apple https://support.apple.com/en-us/111786","img":null}]},{"title":"Samsung https://www.samsung.com/us/support/answer/ANS10002030/","ordered":false,"steps":[]},{"title":"Google Pixel https://support.google.com/pixelphone/answer/14116080","ordered":false,"steps":[]},{"title":"Xiaomi https://www.mi.com/global/support/faq/details/KA-507651/","ordered":false,"steps":[{"text":"Huawei https://consumer.huawei.com/en/support/content/en-us15915333/","img":null}]},{"title":"Realme https://www.realme.com/global/support/faq","ordered":false,"steps":[{"text":"Vivo https://www.vivo.com/ae/en/support/questionList?categoryId=54260","img":null},{"text":"Nothing https://support.nothing.tech/hc/en-us/articles/24505189737745-How-to-reset-phone-1-to-factory-settings","img":null}]}]},"source":{"name":"O-13 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-13.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"איפוס הגדרות רשת O-13.docx"};
window.dynamicDocs['kbm_e10'] = {"id":"kbm_e10","topic":"E-10 · הסלמה למומחה – בעיות קליטה בארץ","cat":"tech","docType":"pdf","kind":"E","desc":"הסלמה למומחה - בעיות קליטה בארץ","tags":["קליטה בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"when":[],"to":[],"conditions":["לפני העברה למומחה ודא שתועד:","מה הלקוח חווה בפועל.","איפה הבעיה מתרחשת.","כתובת / אזור / מסלול מדויק ככל האפשר.","ממתי קיימת הבעיה.","האם מדובר במצב מתמשך או בהרעה חדשה.","האם הבעיה קבועה או לסירוגין.","האם ידוע על לקוחות נוספים שחווים את אותה תופעה.","אילו בדיקות בוצעו על ידי הנציג.","תוצאות הבדיקות.","אין להעביר פנייה כללית כגון:","\"לקוח מתלונן על בעיית קליטה.\"","על הפנייה לאפשר למומחה להמשיך את הטיפול ללא חזרה על כל שלב התשאול מול הלקוח.","לפני סיום השיחה יש להסביר ללקוח שהפנייה מועברת להמשך בדיקה מקצועית.","אין להתחייב:","מה מקור הבעיה.","שהבדיקה תוביל לפתרון.","לשיפור בכיסוי.","למועד טיפול שאינו מוגדר.","במקרים של בעיות רשת השתמש ב:"],"document":[],"extra":[{"title":"מטרת המסמך","lines":["להגדיר לנציג מתי יש להעביר פנייה בנושא קליטה להמשך טיפול מומחה, ואיזה מידע חייב לעבור עם הפנייה.","הנציג אינו מבצע בדיקות מומחה ואינו מעביר פנייה ישירות להנדסה.","מתי מסלימים למומחה?","יש להעביר למומחה כאשר מסלול הטיפול של הנציג הסתיים והבעיה עדיין דורשת המשך בדיקה."]},{"title":"בעיית קליטה במקום מסוים","lines":["העבר למומחה כאשר:","מפת הכיסוי מצביעה על כיסוי תקין באזור.","הבעיה אינה מוגבלת לחדר פנימי, ממ\"ד, מרתף, חניון או מקום ממוסך אחר.","הבעיה קיימת בכל הבית, המשרד או המקום שנבדק."]},{"title":"קליטה חלשה / ניתוקים בזמן נסיעה","lines":["העבר למומחה כאשר:","הלקוח מתאר קליטה חלשה, חוסר קליטה או ניתוקים בזמן נסיעה.","ניתן לזהות אזור, כביש או מסלול שבו התופעה מתרחשת.","נאספו פרטי מיקום מדויקים ככל האפשר.","גם אם מדובר במצב מתמשך ולא בהרעה חדשה, הפנייה מועברת למומחה לצורך בדיקה."]},{"title":"T-10 תיאום ציפיות רשת סלולארית","lines":[]},{"title":"הרעה חדשה בקליטה באזור","lines":["העבר למומחה כאשר:","בעבר הקליטה באזור הייתה תקינה.","הלקוח מתאר שינוי או החמרה ביחס לעבר.","קיים מיקום, אזור או מסלול שניתן לזהות.","מתי לא מסלימים למומחה בנושא רדיו?","אין להסלים כבעיית רדיו כאשר:","קיימת מגבלת כיסוי ברורה באזור.","הבעיה קיימת רק בחדר פנימי, ממ\"ד, חניון, מרתף או מקום ממוסך.","הבעיה אינה קשורה למיקום מסוים.","מדובר בגלישה איטית ויש מסלול גלישה ייעודי.","מדובר ב\"אין קליטה / אין שירות\" ויש מסלול אבחון נפרד.","לא בוצע מסלול הטיפול הרלוונטי של הנציג."]},{"title":"T-10 תיאום ציפיות רשת סלולארית","lines":[]},{"title":"סיום טיפול הנציג","lines":["לפני סיום:","ודא שהשלמת את מסלול הטיפול.","ודא שכל המידע הרלוונטי תועד.","בצע תיאום ציפיות מול הלקוח.","העבר את הפנייה להמשך טיפול מומחה."]},{"title":"כלל מנחה לנציג","lines":["הסלמה למומחה אינה תחליף לאבחון.","תפקיד הנציג הוא להשלים את מסלול הטיפול שבתחום אחריותו ולהעביר למומחה פנייה שכבר מכילה אבחון, מיקום ותוצאות בדיקות.","המומחה ממשיך מנקודה זו ואינו אמור להתחיל מחדש את הטיפול."]}]},"source":{"name":"E-10 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/E-10.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"E-10   הסלמה למומחה – בעיות קליטה בארץ .docx"};
window.dynamicDocs['kbm_t10'] = {"id":"kbm_t10","topic":"T-10 · תיאום ציפיות רשת סלולארית","cat":"tech","docType":"pdf","kind":"T","desc":"תיאום ציפיות רשת סלולארית","tags":["קליטה בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"scripts":[{"situation":"מטרת המסמך","lines":["לתת לנציג תסריטי שיחה קצרים וברורים לתיאום ציפיות במקרים של מגבלות קליטה וכיסוי ברשת הסלולרית.","יש להתאים את התסריט לממצא שנקבע במסלול הטיפול.","אין להשתמש בתיאום ציפיות במקום לבצע אבחון."]},{"situation":"מגבלת כיסוי באזור","lines":["כאשר בדיקת הכיסוי מצביעה על כיסוי שאינו מספק באזור:"]},{"situation":"תסריט","lines":["\"ברשת סלולרית רמת הקליטה אינה זהה בכל מקום והיא מושפעת מפריסת הרשת ומהסביבה. לפי הבדיקה שביצעתי, באזור שציינת קיימת מגבלת כיסוי ולכן ייתכנו קליטה חלשה או חוסר קליטה.\""]},{"situation":"אם הלקוח שואל \"אז מה אפשר לעשות?\"","lines":["\"אם קיימת במקום רשת Wi-Fi והמכשיר תומך בשירות, אפשר להשתמש בשיחות ברשת אלחוטית כדי לבצע ולקבל שיחות גם כשהקליטה הסלולרית חלשה.\"","הפניה:"]},{"situation":"O-12 הפעלת שיחות ברשת אלחוטית","lines":[]},{"situation":"מיסוך בתוך מבנה","lines":["כאשר הכיסוי באזור תקין אך הבעיה מתרחשת בחדר פנימי, ממ\"ד, מרתף, חניון או מקום דומה:"]},{"situation":"תסריט","lines":["\"גם כשיש כיסוי באזור, בתוך מבנים הקליטה יכולה להיות מושפעת מקירות, מיקום פנימי, מרתפים, חניונים או מבנה ממוגן. במקרה שאתה מתאר, המיקום בתוך המבנה יכול להסביר את ההבדל בקליטה.\""]},{"situation":"פתרון משלים","lines":["אם קיימת רשת Wi-Fi","\"אם יש במקום Wi-Fi, אפשר להפעיל שיחות ברשת אלחוטית וכך לבצע ולקבל שיחות גם באזור שבו הקליטה הסלולרית חלשה.\""]},{"situation":"קליטה חלשה או ניתוקים בזמן נסיעה","lines":["כאשר הלקוח מתאר בעיה בזמן נסיעה והפנייה מועברת לבדיקה:"]},{"situation":"תסריט","lines":["\"אני מעביר את הפרטים שמסרת להמשך בדיקה. חשוב לדעת שבזמן נסיעה המכשיר עובר בין אזורי כיסוי ואנטנות שונות, ולכן יכולים להיות מקטעים שבהם איכות הקליטה משתנה או שהשיחה מתנתקת. נבדוק את האזור שציינת, אבל ייתכן שהמצב נובע ממאפייני הכיסוי והרשת באזור ולא מתקלה שניתן לתקן.\""]},{"situation":"חשוב","lines":["אין לומר:","\"הבעיה תטופל.\"","\"הנדסה תתקן את האנטנה.\"","\"נחזיר אליך תשובה עם פתרון.\"","אלא אם קיים תהליך מאושר שמבטיח זאת."]},{"situation":"הרעה חדשה באזור שהיה תקין","lines":["כאשר הלקוח מדווח שבעבר הקליטה הייתה טובה וכעת קיימת החמרה:"]},{"situation":"תסריט","lines":["\"מאחר שאתה מתאר שינוי ביחס למצב שהיה בעבר, אני מעביר את הפרטים להמשך בדיקה. חשוב לי לתאם ציפיות - עצם העברת הפנייה לבדיקה אינה אומרת בהכרח שקיימת תקלה או שניתן יהיה לבצע שינוי ברשת. לאחר הבדיקה יהיה ניתן להבין טוב יותר את המצב באזור.\""]},{"situation":"העברה למומחה","lines":["כאשר מסלול הנציג הסתיים ונדרש המשך טיפול:"]},{"situation":"תסריט","lines":["\"סיימתי את הבדיקות שאני יכול לבצע בשלב הזה. אני מעביר את הפנייה להמשך בדיקה מקצועית יחד עם הפרטים שאספנו.\"","אם מדובר בבעיית רשת:","\"הבדיקה תבחן את המצב שתיארת, אבל בשלב הזה עדיין לא ניתן לקבוע מה הסיבה או אם נדרש וניתן לבצע טיפול נוסף.\"","הפניה:"]},{"situation":"E-10 הסלמה למומחה - בעיות קליטה בארץ","lines":[]},{"situation":"הלקוח שואל \"מתי זה ייפתר?\"","lines":["כאשר אין צפי מאומת:"]},{"situation":"תסריט","lines":["\"כרגע אין לי מועד מדויק שאפשר להתחייב עליו. אני מעדיף לא לתת לך צפי שאינו מבוסס.\"","אין להמציא צפי או להעריך זמן טיפול."]},{"situation":"הלקוח שואל \"אתם הולכים לשפר את הקליטה באזור?\"","lines":["כאשר אין מידע מאומת על שינוי מתוכנן:"]},{"situation":"תסריט","lines":["\"אין לי כרגע מידע מאומת על שינוי או שדרוג מתוכנן באזור הזה, ולכן אני לא רוצה להתחייב למשהו שלא מופיע במידע שיש לנו.\""]},{"situation":"הלקוח אומר \"אז אין לכם פתרון בשבילי?\"","lines":[]},{"situation":"במקרה של מגבלת כיסוי","lines":["\"ברמת הכיסוי הסלולרי קיימת באזור מגבלה. אם יש במקום Wi-Fi, אפשר לבדוק שימוש בשיחות ברשת אלחוטית כפתרון לשיחות בתוך המקום.\""]},{"situation":"במקרה שהפנייה עוברת לבדיקה","lines":["\"בשלב הזה השלמנו את הבדיקות הראשוניות והפנייה עוברת להמשך בדיקה. עדיין מוקדם לקבוע אם מדובר במשהו שניתן לפתור באמצעות שינוי ברשת.\""]},{"situation":"הלקוח שואל \"זה אומר שתמיד תהיה לי קליטה חלשה?\"","lines":[]},{"situation":"תסריט","lines":["\"אני לא יכול להתחייב איך הכיסוי באזור ישתנה בעתיד. נכון לעכשיו אני יכול להתייחס למצב שאנחנו רואים בבדיקה ולפתרונות הזמינים כרגע.\""]},{"situation":"כלל מנחה לנציג","lines":["תיאום ציפיות טוב צריך להפריד בין שלושה דברים:","מה אנחנו יודעים - הממצא שנבדק.","מה אנחנו עושים עכשיו - פתרון, סיום טיפול או העברה למומחה.","מה אנחנו לא יכולים להבטיח - פתרון, שינוי ברשת או מועד טיפול שלא אושרו.","אין להציג אפשרות עתידית לשיפור כעובדה ואין להתחייב לפתרון לפני שהבדיקה הסתיימה."]}]},"source":{"name":"T-10 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/T-10.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"T-10 - תיאום ציפיות רשת סלולארית.docx"};
window.dynamicDocs['kbm_m30'] = {"id":"kbm_m30","topic":"M-30 · איטיות או חוסר גלישה בישראל - אבחון מרכזי","cat":"tech","docType":"pdf","kind":"M","desc":"איטיות או חוסר גלישה - אבחון מרכזי","tags":["גלישה"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"intro":["מטרת המסמך","לאבחן במהירות את סוג התקלה ולהפנות את הנציג למסלול הטיפול המתאים.","אין לבצע במסמך זה תפעול מלא של התקלה."],"questions":[{"title":"מה הלקוח חווה?","q":"\"האם אתה לא מצליח לגלוש בכלל, או שהגלישה עובדת אבל איטית?\"","hint":"","answers":[{"text":"הלקוח לא מצליח לגלוש בכלל","note":"","go":"q:1"},{"text":"הלקוח מצליח לגלוש, אבל הגלישה איטית","note":"","go":"q:2"},{"text":"הבעיה מתרחשת בזמן שיחת טלפון","note":"","go":"q:3"},{"text":"נקודה חמה אישית (Hotspot) אינה מופיעה או אינה עובדת","note":"","go":"item:kbnew_o36"}]},{"title":"אין גלישה","q":"\"האם זה קורה בכל מקום או רק במקום מסוים?\"","hint":"אם אין גלישה רק במקום מסוים — לפני מעבר למסלול גלישה, בדוק אם התיאור מצביע על בעיית קליטה או כיסוי. לדוגמה:\nבבית או במשרד בלבד.\nבחדר מסוים.\nבחניון, ממ\"ד, מרתף או מעלית.\nבאזור גיאוגרפי מסוים.\nמחוץ למקום הגלישה חוזרת לעבוד.","answers":[{"text":"אין גלישה בכל מקום","note":"","go":"item:kbm_r31"},{"text":"אין גלישה רק במקום מסוים, ויש אינדיקציה לבעיית קליטה או כיסוי","note":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\".","go":"item:kbm_m10"},{"text":"אין גלישה רק במקום מסוים, ולא זוהתה אינדיקציה ברורה לבעיית קליטה","note":"","go":"item:kbm_r32"}]},{"title":"גלישה איטית","q":"\"האם האיטיות קיימת בכל מקום או רק במקום מסוים?\"","hint":"אם הגלישה איטית במקום מסוים — בדוק אם האיטיות קשורה באופן ברור למיקום. לדוגמה:\nהאיטיות קיימת רק בבית או במשרד.\nהאיטיות קיימת רק בחדר מסוים או בתוך מבנה.\nבמקום פתוח או באזור אחר הגלישה משתפרת.","answers":[{"text":"הגלישה איטית בכל מקום","note":"","go":"item:kbm_r33"},{"text":"הגלישה איטית במקום מסוים, ויש אינדיקציה לבעיית קליטה או כיסוי","note":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\".","go":"item:kbm_m10"},{"text":"הגלישה איטית במקום מסוים, ולא זוהתה אינדיקציה לבעיית קליטה","note":"","go":"item:kbm_r34"}]},{"title":"אין גלישה במהלך שיחה","q":"\"האם הגלישה מפסיקה רק בזמן שיחת טלפון, או שגם כשאינך בשיחה?\"","hint":"","answers":[{"text":"הגלישה אינה עובדת רק במהלך שיחה","note":"","go":"item:kbm_r35"},{"text":"הגלישה אינה עובדת גם ללא שיחה","note":"אין מדובר בתקלה שמוגבלת לזמן השיחה. חזור לאבחון לפי: אין גלישה בכל מקום / אין גלישה במקום מסוים.","go":"q:1"}]}],"outro":[]},"source":{"name":"M-30 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/M-30.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793864694688,"originName":"M-30 - איטיות או חוסר גלישה - אבחון מרכזי.docx"};
window.dynamicDocs['kbm_r31'] = {"id":"kbm_r31","topic":"R-31 · אין גלישה בכל מקום - מסלול טיפול","cat":"tech","docType":"pdf","kind":"R","desc":"אין גלישה בכל מקום","tags":["גלישה"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול?","items":[{"text":"השתמש במסלול כאשר הלקוח אינו מצליח לגלוש באמצעות הרשת הסלולרית והתקלה מתרחשת בכל מקום.","img":null},{"text":"אם התקלה מתרחשת רק במקום מסוים - חזור למסמך האבחון המרכזי.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - בדיקת חסימת גלישה בקו","items":[{"text":"בדוק במערכת האם קיימת חסימה על גלישה בארץ.","img":null}],"images":[]},{"num":"3","title":"קיימת חסימה","items":[{"text":"בטל את החסימה בהתאם להרשאות ולתהליך הקיים.","img":null},{"text":"לאחר השינוי המשך לבדיקת הגלישה.","img":null}],"images":[]},{"num":"4","title":"אין חסימה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"5","title":"שלב 2 - בדיקת חבילת הגלישה","items":[{"text":"בדוק באזור האישי את ניצול חבילת הגלישה.","img":null}],"images":[]},{"num":"6","title":"החבילה נוצלה במלואה","items":[{"text":"הסבר ללקוח כי נפח הגלישה בחבילה הסתיים.","img":null},{"text":"המשך בהתאם לתהליך רכישת נפח גלישה נוסף.","img":null},{"text":"סיים את הטיפול לאחר ביצוע הפעולה הנדרשת.","img":null}],"images":[]},{"num":"7","title":"קיים נפח גלישה זמין","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"8","title":"שלב 3 - בדיקות בסיסיות במכשיר","items":[{"text":"ודא:","img":null},{"text":"נתונים סלולריים פעילים.","img":null},{"text":"הרשת האלחוטית כבויה לצורך הבדיקה.","img":null},{"text":"אם קיימים שני קווים במכשיר - קו החברה מוגדר כקו לגלישה.","img":null},{"text":"לביצוע הפעולות:","img":null},{"text":"עבור למסמך \"הגדרות בסיסיות לגלישה סלולרית\".","img":null},{"text":"לאחר הבדיקה:","img":null}],"images":[]},{"num":"9","title":"הגלישה חזרה","items":[{"text":"סיים טיפול.","img":null}],"images":[]},{"num":"10","title":"עדיין אין גלישה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"11","title":"שלב 4 - בדיקת הגבלות גלישה במכשיר","items":[{"text":"בדוק האם קיימת הגדרה במכשיר שעלולה להגביל את הגלישה.","img":null},{"text":"לדוגמה:","img":null},{"text":"חוסך נתונים.","img":null},{"text":"מגבלת נתונים.","img":null},{"text":"מצב צריכת נתונים נמוכה.","img":null},{"text":"לביצוע הבדיקה:","img":null},{"text":"עבור למסמך \"O-33 - חוסך נתונים ומגבלת נתונים - בדיקה וביטול\".","img":null},{"text":"אם נמצאה הגבלה - בטל אותה ובדוק שוב.","img":null},{"text":"אם התקלה לא נפתרה - המשך.","img":null}],"images":[]},{"num":"12","title":"שלב 5 - בדיקת חיווי הרשת","items":[{"text":"בדוק עם הלקוח איזה חיווי רשת מופיע במכשיר.","img":null}],"images":[]},{"num":"13","title":"אין חיווי רשת / מופיע \"שיחות חירום בלבד\"","items":[{"text":"ייתכן שמדובר בבעיית קליטה או רישום לרשת.","img":null},{"text":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\".","img":null}],"images":[]},{"num":"14","title":"קיים חיווי רשת תקין","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"15","title":"מופיע חיווי של דור רשת ישן","items":[{"text":"נדרש לוודא שמצב הרשת במכשיר מוגדר למצב אוטומטי התומך בדור הרלוונטי.","img":null},{"text":"נדרש להשלים ידע והפניה למסמך תפעול מתאים.","img":null}],"images":[]},{"num":"16","title":"שלב 6 - בדיקת נקודת הגישה","items":[{"text":"בדוק שהגדרת נקודת הגישה במכשיר תקינה.","img":null},{"text":"עבור למסמך \"הגדרת APN במכשיר\".","img":null},{"text":"לאחר התיקון או האימות בדוק שוב גלישה.","img":null}],"images":[]},{"num":"17","title":"הגלישה חזרה","items":[{"text":"סיים טיפול.","img":null}],"images":[]},{"num":"18","title":"עדיין אין גלישה","items":[{"text":"המשך.","img":null}],"images":[]},{"num":"19","title":"שלב 7 - ריענון שירות הגלישה","items":[{"text":"בצע ריענון שירות גלישה במערכת.","img":null},{"text":"כבה את שירות הגלישה בארץ והפעל אותו מחדש.","img":null},{"text":"לאחר הפעולה הנחה את הלקוח להפעיל מצב טיסה ולאחר מכן לבטל אותו.","img":null},{"text":"בדוק גלישה.","img":null}],"images":[]},{"num":"20","title":"הגלישה חזרה","items":[{"text":"סיים טיפול.","img":null}],"images":[]},{"num":"21","title":"עדיין אין גלישה","items":[{"text":"המשך.","img":null}],"images":[]},{"num":"22","title":"שלב 8 - ריענון כרטיס SIM","items":[{"text":"בצע ריענון כרטיס SIM באמצעות הכפתור הייעודי במערכת.","img":null},{"text":"נדרש להשלים: שם הכפתור, מיקום במערכת והנחיות שימוש.","img":null},{"text":"לאחר הריענון המשך לשלב הבא.","img":null}],"images":[]},{"num":"23","title":"שלב 9 - כיבוי והפעלת המכשיר","items":[{"text":"ודא שכל הבדיקות והריענונים הושלמו לפני ביצוע הפעולה.","img":null},{"text":"הנחה את הלקוח לכבות ולהפעיל את המכשיר.","img":null},{"text":"לאחר שהמכשיר עולה:","img":null},{"text":"ודא שהרשת האלחוטית כבויה.","img":null},{"text":"בקש מהלקוח לנסות לגלוש.","img":null}],"images":[]},{"num":"24","title":"הגלישה חזרה","items":[{"text":"סיים טיפול.","img":null}],"images":[]},{"num":"25","title":"עדיין אין גלישה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"26","title":"שלב 10 - מקרי קצה לפני העברה למומחה","items":[{"text":"לפני העברה למומחה יש לבדוק האם מתקיים אחד מהמצבים הבאים:","img":null},{"text":"שני קווים פעילים במכשיר.","img":null},{"text":"רשת פרטית וירטואלית פעילה.","img":null},{"text":"אפליקציית סינון או אבטחה.","img":null},{"text":"קו מנוהל או הגבלה ארגונית.","img":null},{"text":"עבור למסמכי התפעול הרלוונטיים בהתאם למקרה.","img":null},{"text":"אם לא נמצאה סיבה או שהתקלה לא נפתרה:","img":null},{"text":"עבור למסלול \"העברה למומחה בתקלת גלישה\".","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-31 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-31.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R31 - אין גלישה בכל מקום - מסלול טיפול.docx"};
window.dynamicDocs['kbm_r32'] = {"id":"kbm_r32","topic":"R-32 · אין גלישה במקום מסוים - מסלול טיפול","cat":"tech","docType":"pdf","kind":"R","desc":"אין גלישה במקום מסוים","tags":["גלישה"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול?","items":[{"text":"השתמש במסלול כאשר הלקוח אינו מצליח לגלוש במקום מסוים, אך במקומות אחרים הגלישה פועלת.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - בירור המיקום","items":[{"text":"שאל:","img":null},{"text":"\"איפה בדיוק אין גלישה?\"","img":null},{"text":"בדוק האם מדובר במקום כגון:","img":null},{"text":"בית או משרד.","img":null},{"text":"חדר מסוים בתוך מבנה.","img":null},{"text":"ממ\"ד.","img":null},{"text":"חניון.","img":null},{"text":"מרתף.","img":null},{"text":"מעלית.","img":null},{"text":"מבנה עם קירות עבים.","img":null},{"text":"אזור גיאוגרפי מסוים.","img":null}],"images":[]},{"num":"3","title":"תסריט ללקוח","items":[{"text":"\"חשוב לדעת שקליטה סלולרית מושפעת גם מהמבנה ומהסביבה. במקומות כמו ממ\"ד, חניון, מרתף, מעלית או חדר פנימי יכול להיווצר מיסוך שמחליש את הקליטה ולכן גם את הגלישה. במצב כזה לא מדובר בהכרח בתקלה בקו או במכשיר, אלא במגבלה של הקליטה הסלולרית בתוך המקום.\"","img":null}],"images":[]},{"num":"4","title":"שלב 2 - בדיקה מחוץ לנקודה הבעייתית","items":[{"text":"אם ניתן, בקש מהלקוח לבדוק גלישה:","img":null},{"text":"מחוץ למבנה.","img":null},{"text":"ליד חלון.","img":null},{"text":"במקום פתוח סמוך.","img":null}],"images":[]},{"num":"5","title":"הגלישה עובדת במקום אחר","items":[{"text":"קיימת אינדיקציה לכך שהתקלה קשורה לכיסוי או לקליטה במקום.","img":null},{"text":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\".","img":null}],"images":[]},{"num":"6","title":"אין גלישה גם במקום אחר בסביבה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"7","title":"שלב 3 - בדיקת חיווי הרשת","items":[{"text":"בדוק עם הלקוח איזה חיווי רשת מופיע במכשיר במקום שבו קיימת התקלה.","img":null}],"images":[]},{"num":"8","title":"אין חיווי רשת / מופיע \"שיחות חירום בלבד\"","items":[{"text":"קיימת אינדיקציה לבעיית קליטה או רישום לרשת.","img":null},{"text":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\".","img":null}],"images":[]},{"num":"9","title":"קיים חיווי רשת תקין","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"10","title":"שלב 4 - בדיקת כיסוי באזור","items":[{"text":"בדוק האם קיימת בעיית כיסוי, תקלה ידועה או אירוע רשת באזור.","img":null},{"text":"הבדיקה והמשך הטיפול יתבצעו לפי המסמך \"בעיות קליטה בארץ\".","img":null},{"text":"אם לא נמצאה אינדיקציה לבעיית קליטה או כיסוי, המשך לשלב הבא.","img":null}],"images":[]},{"num":"11","title":"שלב 5 - מעבר למסלול חוסר גלישה כללי","items":[{"text":"אם קיימת קליטה תקינה ואין אינדיקציה לתקלה אזורית, עבור למסלול ״אין גלישה בכל מקום״.","img":null},{"text":"אם טרם בוצעו בדיקת חסימת גלישה בקו ובדיקת ניצול חבילת הגלישה, בצע אותן תחילה. אם הבדיקות כבר בוצעו ונמצאו תקינות, המשך לשלב בדיקות המכשיר.","img":null},{"text":"אין צורך לחזור על בדיקות שכבר בוצעו ונמצאו תקינות.","img":null}],"images":[]},{"num":"12","title":"תוצאה אפשרית","items":[{"text":"בסיום המסלול הנציג יגיע לאחד משני כיוונים:","img":null},{"text":"בעיה התלויה במיקום או בכיסוי ← מעבר ל-\"בעיות קליטה בארץ\".","img":null},{"text":"אין אינדיקציה לבעיית קליטה ← המשך טיפול במסלול \"אין גלישה בכל מקום\".","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-32 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-32.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R32 - אין גלישה במקום מסוים - מסלול טיפול.docx"};
window.dynamicDocs['kbm_r33'] = {"id":"kbm_r33","topic":"R-33 · גלישה איטית בכל מקום מסלול טיפול","cat":"tech","docType":"pdf","kind":"R","desc":"גלישה איטית בכל מקום","tags":["גלישה"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול","items":[{"text":"כאשר הלקוח מצליח לגלוש באמצעות הרשת הסלולרית, אך מדווח על איטיות במקומות שונים ולא רק באזור מסוים. אם האיטיות מוגבלת למיקום מסוים, חזור ל־M‑30 — איטיות או חוסר גלישה אבחון מרכזי, ובחר את המסלול המתאים.","img":null}],"images":[]},{"num":"2","title":"שלב 1 בדיקות במערכת","items":[{"text":"בדוק אם קיימת חסימה על גלישה בארץ, אם חבילת הגלישה פעילה, אם נותר נפח גלישה זמין ואם קיימת מגבלה או חריגה המשפיעה על השירות. אם נמצאה בעיה, טפל לפי הרשאות הנציג ובדוק שוב. אם לא נמצאה בעיה, או שטופלה והאיטיות נמשכת, המשך לשלב 2.","img":null}],"images":[]},{"num":"3","title":"שלב 2 הכנת המכשיר לבדיקה","items":[{"text":"בקש מהלקוח לכבות Wi-Fi, לוודא שנתונים סלולריים פעילים ושקו wecom נבחר לגלישה במכשיר עם שני קווים, ולסגור הורדות ושימושים כבדים ברקע. בצע את הבדיקה במקום שבו קיימת קליטה סלולרית.","img":null},{"text":"בדוק אם מצב חיסכון בסוללה פעיל וכבה אותו זמנית לצורך הבדיקה. ברר אם יש VPN פעיל; ניתוק זמני ובדיקת תוצאה מבוצעים לפי O‑34 — VPN פעיל במכשיר, באמצעות לקוח שמורשה לכך וללא מחיקת פרופיל. אם המכשיר נעול על 2G או 3G בלבד, שנה את סוג הרשת לפי ההוראות בשלב 5, ולאחר מכן חזור לבדיקת המהירות.","img":null}],"images":[]},{"num":"4","title":"שלב 3 בדיקת מהירות וקביעת המשך הטיפול","items":[{"text":"בקש מהלקוח לבצע שתי בדיקות באתר Speedtest של Ookla, כשה־Wi-Fi כבוי ובאותם תנאי בדיקה ככל האפשר. המדד הקובע במסלול זה הוא מהירות ההורדה Download, ביחידות Mbps — מגה־ביט לשנייה.","img":null},{"text":"סף התקינות במסלול הוא 6 Mbps ומעלה, גם ב־4G וגם ב־5G. די בכך שאחת משתי הבדיקות עומדת בסף כדי לסווג את תוצאת המדידה כתקינה. אין צורך בבדיקה שלישית רק משום שהתוצאות שונות.","img":null},{"text":"תעד את שתי תוצאות ההורדה, תאריך ושעת הבדיקות, דור הרשת המוצג, דגם המכשיר והמיקום שבו בוצעה הבדיקה. אם לא ניתן להשלים בדיקה, תעד זאת; אין לסמן תוצאה שלא נמדדה כתקינה.","img":null}],"images":[]},{"num":"5","title":"לפחות אחת משתי התוצאות היא 6 Mbps ומעלה","items":[{"text":"הסבר ללקוח: ״לפחות אחת מהמדידות עומדת בסף התקינות שנקבע למסלול זה.״ תעד את שתי התוצאות וסיים את המסלול. אין להסיק ממדידה נקודתית שכל שירותי הרשת תקינים בכל זמן ומקום.","img":null}],"images":[]},{"num":"6","title":"שתי התוצאות נמוכות מ־6 Mbps","items":[{"text":"המשך לשלב 4. אם לא ניתן להשלים שתי בדיקות, תעד את המגבלה והמשך בבדיקות שניתן לבצע; אין להמציא תוצאת מדידה.","img":null}],"images":[]},{"num":"7","title":"שלב 4 בדיקות במכשיר","items":[{"text":"בדוק הגדרות בסיסיות לגלישה באמצעות O‑31; חוסך נתונים ומגבלת נתונים באמצעות O‑33; בחירת קו לנתונים במכשיר עם שני קווים; והגדרת APN באמצעות O‑32. אל תחזור על בדיקה שכבר בוצעה ונמצאה תקינה.","img":null},{"text":"לאחר כל שינוי, בדוק שוב את הגלישה ובצע מדידת מהירות. תוצאת הורדה של 6 Mbps ומעלה מספיקה לסיום לפי הכלל בשלב 3. אם התוצאה נמוכה מהסף, המשך לבדיקה הבאה.","img":null},{"text":"זיהוי המכשיר יכלול דגם וגרסת תוכנה ככל שניתן. אם עולה שאלת תאימות לרשת החברה, בדוק במקור התמיכה של החברה; אין לקבוע שהאיטיות נובעת מיבוא מקביל בלבד.","img":null}],"images":[]},{"num":"8","title":"שלב 5 בדיקת דור הרשת ובחירת סוג רשת מועדף","items":[{"text":"בדוק איזה חיווי מופיע במכשיר: 2G, 3G, 4G/LTE או 5G. ודא שהמכשיר אינו מוגדר לשימוש ב־2G או ב־3G בלבד. בחר בקו wecom סוג רשת הכולל 4G/LTE, או 5G אוטומטי כאשר המכשיר, הקו והכיסוי תומכים בכך. הגדרה המאפשרת 5G אינה מבטיחה שחיווי 5G יופיע בכל מקום.","img":null}],"images":[]},{"num":"9","title":"Samsung Galaxy","items":[{"text":"הגדרות > חיבורים > רשתות תקשורת סלולרית > מצב רשת. במכשיר עם שני קווים בחר את הקו המתאים. בחר מצב חיבור אוטומטי הכולל LTE, כגון 5G/LTE/3G/2G או LTE/3G/2G, לפי האפשרויות המוצגות. מצב אוטומטי שכולל גם דורות ישנים אינו נעילה על דור ישן בלבד.","img":null}],"images":[]},{"num":"10","title":"iPhone","items":[{"text":"הגדרות > סלולרי > בחר את קו wecom אם מוצגים כמה קווים > אפשרויות נתונים סלולריים > קול ונתונים. בחלק מהגרסאות ״קול ונתונים״ מופיע ישירות בהגדרות הקו. בחר 5G אוטומטי כאשר השירות נתמך, או LTE/4G בהתאם לאפשרויות המכשיר והקו.","img":null}],"images":[]},{"num":"11","title":"Xiaomi Redmi ו POCO","items":[{"text":"הגדרות > כרטיסי SIM ורשתות סלולריות > קו wecom > סוג רשת מועדף. בחלק מהגרסאות מופיע שלב ביניים בשם ״רשת סלולרית״. בחר העדפת LTE/4G; אם מוצגת אפשרות העדפת 5G והמכשיר והקו תומכים בה, ניתן לבחור בה. שמות התפריטים משתנים בין דגמים וגרסאות.","img":null}],"images":[]},{"num":"12","title":"Google Pixel","items":[{"text":"הגדרות > רשת ואינטרנט > כרטיסי SIM > קו wecom > סוג רשת מועדף. בחר 5G כאשר נתמך וזמין, או LTE. האפשרויות המוצגות תלויות במפעיל, במכשיר ובגרסת המערכת.","img":null}],"images":[]},{"num":"13","title":"האפשרות אינה מופיעה או שהמכשיר הוא מיצרן אחר","items":[{"text":"חפש בהגדרות ״סוג רשת מועדף״ או ״מצב רשת״. אם אין אפשרות ברורה לבחירה, אל תשתמש בקודי שירות או בתפריטים מוסתרים. תעד שהאפשרות אינה זמינה והמשך לשלב 6. היעדר מתג אינו מוכיח שהמכשיר אינו תומך בשירות.","img":null},{"text":"לאחר שינוי, המתן להתחברות מחדש, ודא שקו wecom פעיל ובדוק שוב מהירות כשה־Wi-Fi כבוי. אם נמדדה מהירות הורדה של 6 Mbps ומעלה, תעד וסיים. אם המהירות עדיין נמוכה מהסף, או שההגדרה כבר הייתה תקינה, המשך לשלב 6. אם אבד השירות, עבור ל־M‑10 לאבחון חוסר שירות.","img":null}],"images":[]},{"num":"14","title":"שלב 6 ריענון שירות הגלישה","items":[{"text":"בצע ריענון שירות גלישה במערכת לפי התהליך הקיים והרשאות הנציג. לאחר הפעולה הנחה את הלקוח להפעיל ולבטל מצב טיסה. לאחר החיבור מחדש, בדוק גלישה ובצע מדידת מהירות כשה־Wi-Fi כבוי.","img":null},{"text":"נמדדה מהירות הורדה של 6 Mbps ומעלה: תעד וסיים טיפול. המהירות עדיין נמוכה מהסף: המשך לשלב 7. אין לסיים רק על סמך שיפור יחסי שנשאר מתחת לסף.","img":null}],"images":[]},{"num":"15","title":"שלב 7 ריענון כרטיס SIM","items":[{"text":"בצע ריענון כרטיס SIM באמצעות הכפתור הייעודי במערכת, בהתאם לתהליך הקיים ולהרשאות הנציג. אין לחזור על ריענון שכבר בוצע במסגרת המסלול ללא צורך חדש. המשך לשלב 8.","img":null}],"images":[]},{"num":"16","title":"שלב 8 הפעלה מחדש ובדיקה חוזרת","items":[{"text":"הנחה את הלקוח לכבות ולהפעיל את המכשיר. לאחר החיבור מחדש ודא שה־Wi-Fi כבוי, שהנתונים הסלולריים פעילים ושקו wecom נבחר לגלישה. בצע בדיקת מהירות נוספת ותעד את מהירות ההורדה.","img":null},{"text":"תוצאה של 6 Mbps ומעלה: תעד וסיים טיפול. תוצאה נמוכה מהסף: השלם את בדיקות מקרי הקצה הרלוונטיות שטרם בוצעו — שני קווים פעילים לפי O‑37, VPN לפי O‑34 וקו מנוהל או הגבלות ארגוניות לפי O‑35. אין לחזור על בדיקות שכבר הושלמו.","img":null},{"text":"אם הבדיקות הרלוונטיות הושלמו והאיטיות נמשכת, או שנדרש טיפול שאינו בסמכות הנציג, עבור ל־E‑30 — העברה למומחה בתקלת גלישה. צרף את תוצאות המדידות, דור הרשת, דגם המכשיר, פעולות שבוצעו ותוצאותיהן, וכן בדיקות שלא ניתן היה להשלים.","img":null}],"images":[]},{"num":"17","title":"מקורות תפעול לבחירת דור הרשת","items":[{"text":"הנתיבים מבוססים על תיעוד היצרנים. שמות התפריטים והאפשרויות עשויים להשתנות לפי דגם, גרסה ומפעיל. סף המהירות וכלל ההכרעה בין המדידות הם כללי העבודה שנקבעו למסלול זה, ואינם ספי תקינות מטעם היצרנים.","img":null}],"images":[]},{"num":"18","title":"Samsung — בחירת מצב רשת אוטומטי — https://www.samsung.com/ph/support/mobile-devices/how-to-optimize-network-connectivity/","items":[{"text":"Apple — אפשרויות 5G וקול ונתונים — https://support.apple.com/en-gb/108383","img":null}],"images":[]},{"num":"19","title":"Xiaomi — בחירת העדפת LTE — https://www.mi.com/global/support/faq/details/KA-06751/","items":[],"images":[]},{"num":"20","title":"Google Pixel — בדיקת סוג הרשת — https://support.google.com/pixelphone/answer/14116080?hl=en","items":[],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-33 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-33.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-33_גלישה_איטית_בכל_מקום_מתוקן.docx"};
window.dynamicDocs['kbm_r34'] = {"id":"kbm_r34","topic":"R-34 · גלישה איטית במקום מסוים - מסלול טיפול","cat":"tech","docType":"pdf","kind":"R","desc":"גלישה איטית במקום מסוים","tags":["גלישה"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול?","items":[{"text":"השתמש במסלול כאשר הלקוח מצליח לגלוש, אך מדווח על איטיות במקום מסוים בלבד.","img":null},{"text":"אם האיטיות קיימת בכל מקום - עבור למסלול \"גלישה איטית בכל מקום\".","img":null}],"images":[]},{"num":"2","title":"שלב 1 - בירור המיקום","items":[{"text":"שאל:","img":null},{"text":"\"איפה בדיוק אתה חווה את האיטיות בגלישה?\"","img":null},{"text":"בדוק האם מדובר במקום כגון:","img":null},{"text":"בית או משרד.","img":null},{"text":"חדר מסוים בתוך מבנה.","img":null},{"text":"ממ\"ד.","img":null},{"text":"חניון.","img":null},{"text":"מרתף.","img":null},{"text":"מעלית.","img":null},{"text":"אזור גיאוגרפי מסוים.","img":null},{"text":"אם מדובר במקום שעלול ליצור מיסוך, בצע תיאום ציפיות לגבי השפעת המבנה והסביבה על הקליטה הסלולרית.","img":null}],"images":[]},{"num":"3","title":"שלב 2 - בדיקת מהירות במקום הבעייתי","items":[{"text":"בקש מהלקוח:","img":null},{"text":"לכבות רשת אלחוטית.","img":null},{"text":"לוודא שנתונים סלולריים פעילים.","img":null},{"text":"לבצע בדיקת מהירות במקום שבו קיימת האיטיות.","img":null},{"text":"תעד את התוצאה.","img":null},{"text":"השתמש במסמך \"בדיקת מהירות גלישה ותיעוד\".","img":null}],"images":[]},{"num":"4","title":"שלב 3 - בדיקה במקום אחר","items":[{"text":"אם ניתן, בקש מהלקוח לבצע בדיקת מהירות נוספת:","img":null},{"text":"מחוץ למבנה.","img":null},{"text":"ליד חלון.","img":null},{"text":"במקום פתוח סמוך.","img":null}],"images":[]},{"num":"5","title":"המהירות משתפרת משמעותית","items":[{"text":"קיימת אינדיקציה לכך שהאיטיות קשורה לקליטה או לכיסוי במקום.","img":null}],"images":[]},{"num":"6","title":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\"","items":[],"images":[]},{"num":"7","title":"המהירות אינה משתפרת","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"8","title":"שלב 4 - בדיקת חיווי הרשת","items":[{"text":"בדוק איזה חיווי רשת מופיע במכשיר.","img":null}],"images":[]},{"num":"9","title":"אין חיווי רשת / חיווי רשת חלש או חריג","items":[{"text":"ייתכן שמדובר בבעיית קליטה.","img":null},{"text":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\".","img":null}],"images":[]},{"num":"10","title":"קיים חיווי רשת תקין","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"11","title":"שלב 5 - המשך טיפול באיטיות","items":[{"text":"אם לא נמצאה אינדיקציה לכך שהבעיה נובעת מהמיקום או מהכיסוי:","img":null},{"text":"עבור למסלול \"גלישה איטית בכל מקום\". אם טרם בוצעו בדיקות הקו והחבילה המפורטות בשלב 1 של אותו מסלול, בצע אותן תחילה והמשך בהתאם לתוצאותיהן ולהוראות המסלול.","img":null},{"text":"אם בדיקות הקו והחבילה כבר בוצעו ונמצאו תקינות, המשך לשלב בדיקות המכשיר. אין צורך לחזור על הכנת המכשיר או על בדיקות שכבר בוצעו ונמצאו תקינות.","img":null},{"text":"אין צורך לחזור על בדיקות שכבר בוצעו במסלול הנוכחי.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-34 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-34.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R34 - גלישה איטית במקום מסוים - מסלול טיפול.docx"};
window.dynamicDocs['kbm_r35'] = {"id":"kbm_r35","topic":"R-35 · אין גלישה במהלך שיחה - מסלול טיפול","cat":"tech","docType":"pdf","kind":"R","desc":"אין גלישה במהלך שיחה","tags":["גלישה"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול?","items":[{"text":"השתמש במסלול כאשר הלקוח מצליח לגלוש באופן רגיל, אך בזמן שיחת טלפון הגלישה מפסיקה.","img":null},{"text":"אם הלקוח אינו מצליח לגלוש גם כאשר אינו בשיחה - חזור למסמך האבחון המרכזי ועבור למסלול המתאים.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - אימות התקלה","items":[{"text":"שאל:","img":null},{"text":"\"האם הגלישה מפסיקה רק במהלך שיחת טלפון?\"","img":null},{"text":"כן","img":null},{"text":"המשך לשלב הבא.","img":null},{"text":"לא","img":null},{"text":"חזור למסמך האבחון המרכזי.","img":null}],"images":[]},{"num":"3","title":"שלב 2 - בדיקת שירות VoLTE בקו","items":[{"text":"בדוק האם שירות VoLTE פעיל במנוי CRM","img":null}],"images":[]},{"num":"4","title":"שלב 3 - בדיקת חיווי הרשת במהלך שיחה","items":[{"text":"בקש מהלקוח להתחיל שיחת טלפון ולבדוק מה קורה לחיווי הרשת בזמן השיחה.","img":null},{"text":"אם לפני השיחה מופיע חיווי של דור 4 או 5 ובמהלך השיחה החיווי יורד לדור ישן יותר או נעלם - קיימת אינדיקציה לכך שהשיחה אינה מתבצעת באמצעות VoLTE","img":null},{"text":"אם חיווי הרשת נשאר על דור 4 או 5 אך אין גלישה - המשך בבדיקת ההגדרות במכשיר.","img":null}],"images":[]},{"num":"5","title":"iPhone","items":[{"text":"היכנס:","img":null},{"text":"\"הגדרות\" > \"סלולרי\" > \"אפשרויות נתונים סלולריים\" > \"קול ונתונים\".","img":null},{"text":"בדוק שהמכשיר מוגדר לשימוש בדור רשת מתאים.","img":null},{"text":"בהתאם לדגם, גרסת מערכת ההפעלה והמפעיל, ייתכן שיופיעו אפשרויות כגון LTE, דור 5 או VoLTE.","img":null},{"text":"אם ההגדרה אינה זמינה או שאינה מתעדכנת:","img":null},{"text":"הפעל מצב טיסה.","img":null},{"text":"המתן כדקה.","img":null},{"text":"בטל מצב טיסה.","img":null},{"text":"חזור ל\"קול ונתונים\" ובדוק שוב.","img":null},{"text":"בצע שיחה ובדוק גלישה במהלך השיחה.","img":null},{"text":"הערה: אפל מציינת שאפשרויות \"קול ונתונים\" ו-VoLTE עשויות להשתנות בהתאם למפעיל ולמכשיר.","img":null}],"images":[]},{"num":"6","title":"Samsung","items":[{"text":"היכנס:","img":null},{"text":"\"הגדרות\" > \"חיבורים\" > \"רשתות סלולריות\".","img":null},{"text":"אם מופיעה האפשרות \"שיחות VoLTE\" - ודא שהיא פעילה.","img":null},{"text":"סמסונג מציינת כי כאשר המכשיר והרשת תומכים ב-VoLTE ניתן להשתמש בשירותי קול ונתונים במקביל.","img":null},{"text":"אם האפשרות אינה מופיעה:","img":null},{"text":"בדוק את חיווי הרשת במהלך שיחה.","img":null},{"text":"המשך בהתאם לתהליך ההסלמה אם התקלה נמשכת.","img":null}],"images":[]},{"num":"7","title":"Xiaomi / Redmi / POCO","items":[{"text":"היכנס:","img":null},{"text":"\"הגדרות\" > \"כרטיסי SIM ורשתות סלולריות\" > בחר את הקו > \"שימוש ב-VoLTE\".","img":null},{"text":"ודא שהאפשרות פעילה.","img":null},{"text":"אם האפשרות אינה מופיעה, ניתן להקליד בחייגן:","img":null},{"text":"*#*#86583#*#*","img":null},{"text":"לאחר מכן חזור להגדרות ובדוק האם אפשרות VoLTE הופיעה.","img":null},{"text":"שיאומי מאשרת שהקוד משמש להפעלה או ביטול של בדיקת VoLTE במכשיר.","img":null},{"text":"בדוק גם שמצב הרשת המועדף כולל דור 4 או LTE.","img":null}],"images":[]},{"num":"8","title":"שלב 4 - בדיקה חוזרת","items":[{"text":"לאחר ביצוע ההגדרה:","img":null},{"text":"בצע שיחת טלפון.","img":null},{"text":"ודא שהמכשיר נשאר מחובר לדור רשת מתאים.","img":null},{"text":"בקש מהלקוח לפתוח אתר או אפליקציה ולבדוק גלישה במהלך השיחה.","img":null}],"images":[]},{"num":"9","title":"הגלישה תקינה","items":[{"text":"סיים טיפול.","img":null}],"images":[]},{"num":"10","title":"עדיין אין גלישה","items":[{"text":"המשך לשלב הבא.","img":null}],"images":[]},{"num":"11","title":"שלב 5 - בדיקת קליטה","items":[{"text":"אם במהלך השיחה:","img":null},{"text":"חיווי הרשת יורד משמעותית.","img":null},{"text":"דור הרשת משתנה.","img":null},{"text":"החיווי נעלם.","img":null},{"text":"מופיעה בעיית קליטה.","img":null},{"text":"עבור למסמך האבחון המרכזי \"בעיות קליטה בארץ\".","img":null},{"text":"אם הקליטה תקינה והתקלה נמשכת - המשך.","img":null}],"images":[]},{"num":"12","title":"ריענון והסלמה","items":[],"images":[]},{"num":"13","title":"נדרש ידע פנימי","items":[{"text":"האם נדרש ריענון VoLTE במערכת.","img":null},{"text":"האם נדרש ריענון SIM.","img":null},{"text":"האם נדרש כיבוי והפעלת המכשיר.","img":null},{"text":"אילו דגמים נתמכים ברשת.","img":null}],"images":[]},{"num":"14","title":"מתי מעבירים למומחה.","items":[{"text":"מה נדרש לתעד לפני ההעברה.","img":null},{"text":"מהו תור ההסלמה.","img":null},{"text":"מהו זמן הטיפול.","img":null},{"text":"אם כל הבדיקות הרלוונטיות בוצעו והתקלה נמשכת:","img":null},{"text":"עבור למסלול \"העברה למומחה בתקלת גלישה\".","img":null}],"images":[]},{"num":"15","title":"הסבר קצר ללקוח","items":[{"text":"\"בעת שיחת טלפון המכשיר צריך להישאר מחובר לרשת שמאפשרת שיחה וגלישה במקביל. אם המכשיר עובר בזמן השיחה לדור רשת אחר, הגלישה עלולה להיפסק. אנחנו בודקים שהשירות והגדרות המכשיר מאפשרים שימוש בשניהם במקביל.\"","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-35 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-35.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R35 - אין גלישה במהלך שיחה - מסלול טיפול.docx"};
window.dynamicDocs['kbm_o31'] = {"id":"kbm_o31","topic":"O-31 · הגדרות בסיסיות לגלישה סלולרית","cat":"tech","docType":"pdf","kind":"O","desc":"הגדרות בסיסיות לגלישה סלולארית","tags":["גלישה"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לבצע את הבדיקות הבסיסיות במכשיר כאשר קיימת תקלה בגלישה סלולרית.","img":null}]},{"title":"שלב 1 - כיבוי רשת אלחוטית","ordered":true,"steps":[{"text":"בקש מהלקוח לכבות את הרשת האלחוטית כדי לוודא שהבדיקה מתבצעת באמצעות הרשת הסלולרית בלבד.","img":null},{"text":"לאחר הכיבוי המשך לבדיקה הבאה.","img":null}]},{"title":"שלב 2 - הפעלת נתונים סלולריים ובחירת הקו לגלישה","ordered":true,"steps":[{"text":"ודא שהנתונים הסלולריים פעילים.","img":null},{"text":"אם במכשיר קיימים שני קווים, ודא שקו wecom מוגדר כקו שמשמש לנתונים סלולריים.","img":null}]},{"title":"iPhone","ordered":false,"steps":[{"text":"\"הגדרות\" > \"סלולרי\"","img":null},{"text":"בדוק:","img":null},{"text":"\"נתונים סלולריים\" פעילים.","img":null},{"text":"אם קיימים שני קווים, היכנס ל\"נתונים סלולריים\" ובחר את קו wecom כקו לגלישה.","img":null},{"text":"מקור: אפל. https://support.apple.com/en-il/109317","img":null}]},{"title":"Samsung","ordered":false,"steps":[{"text":"לבחירת הקו לגלישה:","img":null},{"text":"\"הגדרות\" > \"חיבורים\" > \"מנהל SIM\" > \"נתונים ניידים\"","img":null},{"text":"בחר את קו wecom.","img":null},{"text":"לווידוא שהנתונים הסלולריים פעילים:","img":null},{"text":"\"הגדרות\" > \"חיבורים\" > \"שימוש בנתונים\" > \"נתונים ניידים\"","img":null},{"text":"מקור: סמסונג. https://www.samsung.com/ph/support/mobile-devices/how-to-use-or-manage-dual-sim-cards/","img":null}]},{"title":"Xiaomi / Redmi / POCO","ordered":false,"steps":[{"text":"\"הגדרות\" > \"כרטיסי SIM ורשתות סלולריות\"","img":null},{"text":"או בדגמים מסוימים:","img":null},{"text":"\"הגדרות\" > \"רשתות סלולריות\"","img":null},{"text":"בדוק:","img":null},{"text":"\"נתונים סלולריים\" פעילים.","img":null},{"text":"תחת בחירת SIM לנתונים, בחר את קו wecom.","img":null},{"text":"מקור: שיאומי. https://www.mi.com/global/support/article/KA-36294/","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[{"text":"\"הגדרות\" > \"רשת ואינטרנט\" > \"כרטיסי SIM\"","img":null},{"text":"בדוק:","img":null},{"text":"\"נתונים סלולריים\" פעילים.","img":null},{"text":"בחר את קו wecom כקו לנתונים סלולריים.","img":null},{"text":"מקור: גוגל. https://support.google.com/pixelphone/answer/9449293","img":null}]},{"title":"OnePlus / Oppo / Realme","ordered":false,"steps":[{"text":"במכשירים המבוססים על ממשקי ColorOS / OxygenOS / realme UI, מיקום ההגדרה עשוי להשתנות לפי גרסה.","img":null},{"text":"במכשירי Realme:","img":null},{"text":"\"הגדרות\" > \"רשת סלולרית\" > \"נתונים סלולריים\"","img":null},{"text":"אם קיימים שני קווים:","img":null},{"text":"בחר את הקו המשמש לגלישה תחת הגדרת ברירת המחדל לנתונים.","img":null},{"text":"מקור: realme https://www.realme.com/in/support/kw/doc/2055219","img":null},{"text":"במכשירי OnePlus ו-Oppo לא מצאתי כרגע נתיב אחיד ומאומת ממקור יצרן רשמי שמתאים לכל הגרסאות.","img":null}]},{"title":"Huawei","ordered":false,"steps":[{"text":"\"הגדרות\" > \"רשת סלולרית\" > \"ניהול SIM\"","img":null},{"text":"אם קיימים שני קווים:","img":null},{"text":"בחר SIM 1 או SIM 2 כברירת המחדל לנתונים סלולריים.","img":null},{"text":"ודא שקו wecom מוגדר כקו לגלישה.","img":null},{"text":"מקור: Huawei https://consumer.huawei.com/uk/support/content/en-gb00763941/","img":null}]},{"title":"שלב 3 - שני קווים פעילים","ordered":true,"steps":[{"text":"אם קיים קו נוסף במכשיר:","img":null},{"text":"אין למחוק את הקו.","img":null},{"text":"ודא שקו wecom מוגדר לגלישה.","img":null},{"text":"אם יש חשד שהקו הנוסף משפיע על הגלישה, ניתן לכבות אותו זמנית לצורך בדיקה בלבד.","img":null}]},{"title":"שלב 4 - בדיקת תוצאה","ordered":true,"steps":[{"text":"כאשר הרשת האלחוטית כבויה והנתונים הסלולריים פעילים:","img":null},{"text":"בקש מהלקוח לפתוח אתר או אפליקציה ולבדוק גלישה.","img":null}]},{"title":"הגלישה תקינה","ordered":false,"steps":[{"text":"חזור למסלול הטיפול שממנו הגעת וסיים בהתאם.","img":null}]},{"title":"עדיין קיימת תקלה","ordered":false,"steps":[{"text":"חזור למסלול הטיפול והמשך לשלב הבא.","img":null}]}]},"source":{"name":"O-31 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-31.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-31 הגדרות בסיסיות לגלישה סלולרית.docx"};
window.dynamicDocs['kbm_o32'] = {"id":"kbm_o32","topic":"O-32 · .","cat":"intl","docType":"pdf","kind":"O","desc":"הגדרת APN במכשיר","tags":["גלישה"],"owner":"שחר","stages":[],"worlds":["tech"],"track":{"state":"חסר","priority":"","gap":"סטטוס מנהלת: שחר","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"📶 הגדרת APN במכשיר","ordered":false,"steps":[]},{"title":"מה זה :APN","ordered":false,"steps":[{"text":"APN – Access Point Name הוא ההגדרה שמאפשרת למכשיר להתחבר לרשת האינטרנט הסלולרית דרך המפעיל.","img":null},{"text":"ברוב המכשירים הגדרת ה־ APN מתקבלת באופן אוטומטי, אך במקרים מסוימים נדרש להגדיר או לעדכן אותה באופן ידני.","img":null},{"text":"🧡 חשוב! לא ניתן להגדיר APN בזמן שיחה. יש לבצע את ההגדרה לאחר ניתוק השיחה או להנחות את הלקוח כיצד לבצע אותה.","img":null}]},{"title":"🔎 באילו מקרים נדרש להגדיר APN","ordered":false,"steps":[]},{"title":"נבדוק או נגדיר APN כאשר","ordered":false,"steps":[{"text":"📵 יש קליטה במכשיר אך אין גלישה סלולרית.","img":null},{"text":"🔄 לאחר הפעלת SIM / eSIM או החלפת SIM, הגלישה אינה עובדת.","img":null},{"text":"📱 הלקוח עבר למכשיר חדש והגלישה אינה עובדת.","img":null},{"text":"⚙️ הגדרת ה־ APN במכשיר חסרה או אינה מוגדרת נכון.","img":null},{"text":"🌍 הלקוח נמצא בחו\"ל ונדרש לעדכן את הגדרת ה־APN לצורך גלישה.","img":null},{"text":"📡 באייפון – נקודת גישה אישית / Hotspot אינה מופיעה או אינה עובדת, ונדרש להגדיר APN עבור נקודת הגישה.","img":null},{"text":"לאחר איפוס או עדכון מכשיר, אם הגדרת ה־APN נמחקה או התאפסה.","img":null}]},{"title":"הגדרת APN בארץ","ordered":false,"steps":[{"text":"יש להזין:","img":null},{"text":"שם/APN: we באותיות קטנות.","img":null}]},{"title":"🌍 הגדרת APN בחו\"ל","ordered":false,"steps":[]},{"title":"שם: PARTNER / ORANGE","ordered":false,"steps":[]},{"title":"APN: UINTERNET","ordered":false,"steps":[]},{"title":"📱 סמסונג Samsung –","ordered":false,"steps":[{"text":"היכנסו ל־הגדרות.","img":null},{"text":"בחרו חיבורים.","img":null},{"text":"בחרו רשתות תקשורת סלולרית.","img":null},{"text":"היכנסו ל־שמות נקודות גישה.","img":null},{"text":"לחצו על ➕ / הוסף.","img":null},{"text":"הזינו את פרטי ה־APN:","img":null},{"text":"לחצו על ⋮ בחלק העליון של המסך.","img":null},{"text":"בחרו שמור.","img":null},{"text":"חזרו לרשימת נקודות הגישה.","img":null},{"text":"ודאו שה־APN שהוגדר נבחר ומסומן בעיגול 🔘.","img":null}]},{"title":"🍎 אייפון iPhone –","ordered":false,"steps":[{"text":"היכנסו ל־הגדרות.","img":null},{"text":"בחרו סלולרי.","img":null},{"text":"היכנסו לרובריקה \"כרטיסי SIM\"","img":null},{"text":"בחרו את המספר הרלוונטי","img":null},{"text":"בחלק מגרסאות iOS הנתיב עשוי להשתנות מעט, והאפשרות לעריכת APN תלויה גם בהגדרות המפעיל.","img":null},{"text":"הזינו את ה־ APN בשדות הרלוונטיים:","img":null}]},{"title":"בארץ","ordered":false,"steps":[{"text":"we","img":null}]},{"title":"בחו\"ל","ordered":false,"steps":[{"text":"UINTERNET","img":null},{"text":"אין צורך ללחוץ על \"שמור\" – ההגדרה נשמרת אוטומטית.","img":null},{"text":"צאו ממסך ההגדרות.","img":null},{"text":"💡 כמות שדות ה־ APN המופיעים במסך יכולה להשתנות בין מכשירים וגרסאות iOS ולכן אין להסתמך על כך שיופיעו תמיד 4 שדות.","img":null}]},{"title":"🍎 iPhone עם יותר מ־SIM / eSIM אחד","ordered":false,"steps":[{"text":"כאשר קיימים מספר קווים במכשיר:","img":null},{"text":"היכנסו ל־הגדרות.","img":null},{"text":"בחרו סלולרי.","img":null},{"text":"בחרו את ה־SIM / eSIM של wecom.","img":null},{"text":"היכנסו ל־רשת נתונים סלולרית.","img":null},{"text":"הזינו את ה־APN:","img":null}]},{"title":"בארץ","ordered":false,"steps":[]},{"title":"שם: we APN: we","ordered":false,"steps":[]},{"title":"בחו\"ל","ordered":false,"steps":[]},{"title":"שם: PARTNER / ORANGE APN: UINTERNET","ordered":false,"steps":[{"text":"צאו ממסך ההגדרות לצורך שמירת ההגדרה.","img":null}]},{"title":"iPhone – נקודת גישה אישית / Hotspot 📡","ordered":false,"steps":[{"text":"במקרה שבו נקודת גישה אישית אינה מופיעה או אינה עובדת, ניתן לבדוק את הגדרת ה־APN של נקודת הגישה.","img":null},{"text":"היכנסו ל־הגדרות.","img":null},{"text":"סלולרי.","img":null},{"text":"רשת נתונים סלולרית.","img":null},{"text":"גללו לאזור נקודת גישה אישית / Personal Hotspot.","img":null}]},{"title":"בשדה APN הזינו","ordered":false,"steps":[]},{"title":"בארץ","ordered":false,"steps":[]},{"title":"שם: we APN: we","ordered":false,"steps":[]},{"title":"בחו\"ל","ordered":false,"steps":[]},{"title":"שם: PARTNER / ORANGE APN: UINTERNET","ordered":false,"steps":[{"text":"צאו מההגדרות.","img":null},{"text":"בדקו שוב את האפשרות נקודת גישה אישית.","img":null}]},{"title":"📱 Xiaomi / Redmi / POCO – שיאומי","ordered":false,"steps":[{"text":"שמות התפריטים עשויים להשתנות מעט בין גרסאות MIUI / HyperOS.","img":null},{"text":"היכנסו ל־הגדרות.","img":null},{"text":"בחרו כרטיסי SIM ורשתות סלולריות / רשתות סלולריות.","img":null},{"text":"בחרו את ה־SIM של wecom.","img":null},{"text":"היכנסו ל־שמות נקודות גישה / APN.","img":null},{"text":"לחצו על APN חדש / ➕.","img":null},{"text":"הזינו:","img":null}]},{"title":"בארץ","ordered":false,"steps":[]},{"title":"שם: we APN: we","ordered":false,"steps":[]},{"title":"בחו\"ל","ordered":false,"steps":[]},{"title":"שם: PARTNER / ORANGE APN: UINTERNET","ordered":false,"steps":[]},{"title":"לחצו על עוד ⋮ /","ordered":false,"steps":[{"text":"בחרו שמור.","img":null},{"text":"ודאו שה־APN החדש נבחר ומסומן.","img":null},{"text":"💡 אם שמות התפריטים שונים, ניתן להשתמש בחיפוש בהגדרות ולחפש APN או שמות נקודות גישה.","img":null}]},{"title":"📱 וואווי Huawei –","ordered":false,"steps":[{"text":"בגרסאות החדשות יותר:","img":null},{"text":"היכנסו ל־הגדרות.","img":null},{"text":"בחרו רשת סלולרית.","img":null},{"text":"בחרו נתונים סלולריים.","img":null},{"text":"היכנסו ל־שמות נקודות גישה / APN.","img":null},{"text":"במכשיר עם מספר SIMים – ודאו שנבחר ה־SIM של wecom.","img":null},{"text":"לחצו על ➕ / APN חדש.","img":null},{"text":"הזינו:","img":null}]},{"title":"בארץ","ordered":false,"steps":[]},{"title":"שם: we APN: we","ordered":false,"steps":[]},{"title":"בחו\"ל","ordered":false,"steps":[]},{"title":"שם: PARTNER / ORANGE APN: UINTERNET","ordered":false,"steps":[]},{"title":"לחצו על ⋮","ordered":false,"steps":[{"text":"בחרו שמור.","img":null},{"text":"ודאו שה־APN החדש נבחר.","img":null},{"text":"במכשירי Huawei ישנים יותר שמות התפריטים עשויים להיות שונים. ניתן לחפש APN דרך החיפוש בהגדרות.","img":null}]},{"title":"📱 גוגל פיקסל Google Pixel –","ordered":false,"steps":[{"text":"היכנסו ל־הגדרות.","img":null},{"text":"בחרו רשת ואינטרנט.","img":null},{"text":"בחרו כרטיסי SIM / SIMs.","img":null},{"text":"בחרו את ה־SIM של wecom.","img":null},{"text":"היכנסו ל־שמות נקודות גישה / Access Point Names.","img":null},{"text":"לחצו על ➕ / APN חדש.","img":null},{"text":"הזינו:","img":null}]},{"title":"בארץ","ordered":false,"steps":[]},{"title":"שם: we APN: we","ordered":false,"steps":[]},{"title":"בחו\"ל","ordered":false,"steps":[]},{"title":"שם: PARTNER / ORANGE APN: UINTERNET","ordered":false,"steps":[]},{"title":"לחצו על ⋮","ordered":false,"steps":[{"text":"בחרו שמור.","img":null},{"text":"ודאו שה־APN החדש נבחר ומסומן.","img":null}]},{"title":"📱 כשר Xiaomi 22 F","ordered":false,"steps":[{"text":"היכנסו ל־רשת ואינטרנט.","img":null},{"text":"בחרו רשת סלולרית.","img":null},{"text":"לחצו על מתקדם.","img":null},{"text":"בחרו שמות נקודות גישה.","img":null},{"text":"לחצו על התפריט בפינה ובחרו הוספה.","img":null},{"text":"במסך הגדרת ה־ APN הזינו:","img":null}]},{"title":"בארץ","ordered":false,"steps":[]},{"title":"שם: we APN: we","ordered":false,"steps":[]},{"title":"בחו\"ל","ordered":false,"steps":[]},{"title":"שם: PARTNER / ORANGE APN: UINTERNET","ordered":false,"steps":[{"text":"שמרו את ההגדרה.","img":null},{"text":"ודאו שהאפשרות we נבחרה ומסומנת בנקודה.","img":null},{"text":"⚠️ אם לא קיימת אפשרות להוסיף נקודת גישה – ייתכן שמדובר בחסימה של הדגם הכשר.","img":null}]},{"title":"✉️ שליחת הודעת תצורת APN ללקוח","ordered":false,"steps":[{"text":"ניתן לשלוח ללקוח הודעת תצורה אוטומטית עם הגדרות ה־APN.","img":null},{"text":"הודעה זו נשלחת גם ללקוחות חדשים בהתאם לתהליך הקיים.","img":null},{"text":"לאחר שההודעה מתקבלת:","img":null},{"text":"הלקוח פותח את ההודעה.","img":null},{"text":"לוחץ על \"התקן\".","img":null},{"text":"ממתין לסיום ההתקנה.","img":null},{"text":"לאחר ההתקנה בודקים את הגלישה.","img":null}]},{"title":"חשוב","ordered":false,"steps":[{"text":"הלקוח צריך להיות מחובר ל־Wi-Fi לצורך התהליך.","img":null},{"text":"אם הלקוח אינו רואה את ההודעה, יש לבדוק גם ב־Spam / הודעות חסומות.","img":null},{"text":"אם ההודעה לא נשלחה אוטומטית, ניתן לשלוח אותה באופן ידני דרך המערכת.","img":null}]},{"title":"✅ לאחר הגדרת APN","ordered":false,"steps":[{"text":"בסיום ההגדרה:","img":null},{"text":"ודאו שה־ APN שהוגדר נבחר ומסומן.","img":null},{"text":"במידת הצורך הפעילו וכבו מצב טיסה.","img":null},{"text":"בדקו שוב את הגלישה הסלולרית.","img":null},{"text":"לצורך הבדיקה מומלץ לכבות Wi-Fi ולוודא שהגלישה מתבצעת דרך הרשת הסלולרית.","img":null}]},{"title":"🧠 לזכור","ordered":false,"steps":[{"text":"APN הוא הגדרת החיבור של המכשיר לרשת הגלישה הסלולרית.","img":null}]},{"title":"בארץ: we","ordered":false,"steps":[]},{"title":"בחו\"ל: UINTERNET","ordered":false,"steps":[{"text":"ובכל מכשיר – לאחר יצירת APN חדש, חשוב לא רק לשמור אותו אלא גם לוודא שהוא נבחר בפועל.","img":null}]}]},"source":{"name":"O-32 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-32.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"הגדרת APN במכשיר O-32.docx"};
window.dynamicDocs['kbm_o33'] = {"id":"kbm_o33","topic":"O-33 · חוסך נתונים ומגבלת נתונים - בדיקה וביטול","cat":"tech","docType":"pdf","kind":"O","desc":"חוסך נתונים ומגבלת נתונים - בדיקה וביטול","tags":["גלישה"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מתי משתמשים במסמך?","ordered":false,"steps":[{"text":"השתמש במסמך כאשר קיימת תקלה בגלישה או כאשר הגלישה מוגבלת, ובמסלול הטיפול נדרש לבדוק אם קיימת במכשיר הגדרה שמגבילה שימוש בנתונים.","img":null},{"text":"אם הלקוח מצליח לגלוש בדפדפן אך לא באפליקציה מסוימת, ייתכן שמדובר בהגבלה מקומית באפליקציה ולא בתקלה ברשת.","img":null}]},{"title":"Samsung","ordered":false,"steps":[]},{"title":"חוסך נתונים","ordered":false,"steps":[{"text":"\"הגדרות\" > \"חיבורים\" > \"שימוש בנתונים\" > \"חוסך נתונים\"","img":null},{"text":"ודא שהאפשרות כבויה.","img":null}]},{"title":"מגבלת נתונים","ordered":false,"steps":[{"text":"\"הגדרות\" > \"חיבורים\" > \"שימוש בנתונים\" > \"מחזור חיוב ואזהרת שימוש בנתונים\"","img":null},{"text":"בדוק שלא הוגדרה מגבלת נתונים שחוסמת את המשך הגלישה.","img":null}]},{"title":". iPhone","ordered":false,"steps":[{"text":"\"הגדרות\" > \"סלולרי\" > \"אפשרויות נתונים סלולריים\" > \"מצב נתונים מופחת\"","img":null},{"text":"ודא שהאפשרות כבויה.","img":null}]},{"title":"Xiaomi / Redmi / POCO","ordered":false,"steps":[{"text":"\"הגדרות\" > \"חיבורים ושיתוף\" > \"שימוש בנתונים\" > \"חוסך נתונים\"","img":null},{"text":"ודא שהאפשרות כבויה.","img":null}]},{"title":". OnePlus / Oppo / Realme","ordered":false,"steps":[{"text":"\"הגדרות\" > \"שימוש בנתונים\" > \"חוסך נתונים\"","img":null},{"text":"ודא שהאפשרות כבויה.","img":null}]},{"title":". Google Pixel","ordered":false,"steps":[{"text":"\"הגדרות\" > \"רשת ואינטרנט\" > \"חוסך נתונים\"","img":null},{"text":"ודא שהאפשרות כבויה.","img":null}]},{"title":"הגבלה באפליקציה מסוימת","ordered":false,"steps":[{"text":"השתמש בסעיף זה כאשר הגלישה הכללית עובדת, אך אפליקציה מסוימת אינה גולשת.","img":null},{"text":"במכשירי:","img":null}]},{"title":"Android \"","ordered":false,"steps":[]},{"title":"הגדרות\" > \"אפליקציות\" > בחר את האפליקציה > \"שימוש בנתונים\"","ordered":false,"steps":[{"text":"ודא שהשימוש בנתונים ברקע מותר.","img":null}]},{"title":"ב-iPhone","ordered":false,"steps":[{"text":"\"הגדרות\" > בחר את האפליקציה","img":null},{"text":"ודא שהשימוש בנתונים סלולריים מותר.","img":null}]},{"title":"בדיקת תוצאה","ordered":false,"steps":[{"text":"לאחר שינוי ההגדרה:","img":null},{"text":"ודא שהרשת האלחוטית כבויה.","img":null},{"text":"בקש מהלקוח לבדוק שוב גלישה.","img":null}]},{"title":"הגלישה חזרה","ordered":false,"steps":[{"text":"חזור למסלול הטיפול וסיים בהתאם.","img":null}]},{"title":"עדיין קיימת תקלה","ordered":false,"steps":[{"text":"חזור למסלול הטיפול והמשך לשלב הבא.","img":null}]}]},"source":{"name":"O-33 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-33.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-33 חוסך נתונים ומגבלת נתונים - בדיקה וביטול.docx"};
window.dynamicDocs['kbm_o34'] = {"id":"kbm_o34","topic":"O-34 · VPN פעיל במכשיר בדיקה והמשך טיפול","cat":"tech","docType":"pdf","kind":"O","desc":"מקרי קצה לפני העברה למומחה","tags":["גלישה"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מתי משתמשים במסמך","ordered":false,"steps":[{"text":"השתמש במסמך לאחר השלמת מסלול תקלת הגלישה, כאשר התקלה נמשכת ויש חשד לחיבור VPN שמשפיע על הגלישה.","img":null}]},{"title":"שלב 1 בירור","ordered":true,"steps":[{"text":"שאל: האם מופעל במכשיר שירות או אפליקציה של רשת פרטית וירטואלית VPN? אם אין חיבור פעיל ואין חשד לשירות כזה, עבור לסעיף המשך טיפול.","img":null}]},{"title":"שלב 2 איתור החיבור","ordered":true,"steps":[]},{"title":"iPhone","ordered":false,"steps":[{"text":"בדוק האם קיים חיבור VPN פעיל דרך הגדרות המכשיר או דרך האפליקציה שמפעילה אותו.","img":null},{"text":"אם קיים חיבור פעיל:","img":null},{"text":"כבה אותו זמנית.","img":null},{"text":"אין למחוק את ההגדרה או את האפליקציה.","img":null},{"text":"בדוק שוב גלישה באמצעות הנתונים הסלולריים.","img":null},{"text":"הערה: מיקום הגדרת ה-VPN עשוי להשתנות בהתאם לגרסת מערכת ההפעלה ולסוג האפליקציה.","img":null}]},{"title":"Samsung","ordered":false,"steps":[{"text":"\"הגדרות\" > \"חיבורים\" > \"הגדרות חיבור נוספות\" > \"VPN\"","img":null},{"text":"אם מופיע חיבור פעיל:","img":null},{"text":"היכנס לחיבור.","img":null},{"text":"נתק אותו זמנית.","img":null},{"text":"בדוק שוב גלישה.","img":null},{"text":"מקור: Samsung https://www.samsung.com/uk/support/mobile-devices/what-is-a-vpn-and-how-do-i-add-one-to-my-device/","img":null}]},{"title":"Xiaomi / Redmi / POCO","ordered":false,"steps":[{"text":"\"הגדרות\" > \"חיבור ושיתוף\" > \"VPN\"","img":null},{"text":"בדגמים מסוימים:","img":null},{"text":"\"הגדרות\" > \"אפשרויות קישוריות נוספות\" > \"VPN\"","img":null},{"text":"אם מופיע חיבור פעיל:","img":null},{"text":"כבה אותו זמנית.","img":null},{"text":"בדוק שוב גלישה.","img":null},{"text":"מקור: Xiaomi https://www.mi.com/uk/support/article/KA-36319/","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[{"text":"\"הגדרות\" > \"רשת ואינטרנט\" > \"VPN\"","img":null},{"text":"אם מופיע חיבור פעיל:","img":null},{"text":"בחר את החיבור.","img":null},{"text":"כבה אותו זמנית.","img":null},{"text":"בדוק שוב גלישה.","img":null},{"text":"מקור: Google https://support.google.com/android/answer/9089766","img":null}]},{"title":"OnePlus","ordered":false,"steps":[{"text":"ב־OxygenOS 14: הגדרות > חיבור ושיתוף Connection & sharing > VPN.","img":null},{"text":"מקור: https://service.oneplus.com/content/dam/support/user-manuals/common/OxygenOS_14.0_User_Manual.pdf","img":null}]},{"title":"Oppo","ordered":false,"steps":[{"text":"ב־ColorOS 12.1: הגדרות > חיבור ושיתוף Connection & sharing > VPN.","img":null},{"text":"מקור: https://s3.eu-west-3.amazonaws.com/par-sow-cms-oppo-com/cms/userManual/manual/baf0bf83-423e-4e22-9376-97b651bab096/ColorOS%2012.1%20User%20Manual-EN-20220516.pdf","img":null}]},{"title":"Realme","ordered":false,"steps":[{"text":"לפי מדריך היצרן: הגדרות > חיבור ושיתוף Connection & sharing > VPN.","img":null},{"text":"מקור: https://r1.realme.net/general/20230130/1675070322576.pdf","img":null}]},{"title":"Huawei","ordered":false,"steps":[{"text":"ב־EMUI 10.1.1: הגדרות > חיבורים נוספים More connections > VPN.","img":null},{"text":"מקור: https://consumer.huawei.com/uk/support/content/en-gb04405665/","img":null}]},{"title":"אם הנתיב אינו מופיע","ordered":false,"steps":[{"text":"שמות התפריטים עשויים להשתנות לפי דגם וגרסה. חפש VPN בחיפוש שבהגדרות. אם החיבור מופעל באמצעות אפליקציה, בדוק את מצב החיבור בתוכה.","img":null}]},{"title":"שלב 3 ניתוק זמני ובדיקת גלישה","ordered":true,"steps":[{"text":"אם קיים חיבור פעיל והלקוח מורשה לנתקו, נתק אותו זמנית באמצעות אפשרות הניתוק הזמינה בהגדרות או באפליקציה. אין למחוק את האפליקציה או את פרופיל החיבור. בדוק שוב גלישה באמצעות נתונים סלולריים, כשהרשת האלחוטית כבויה.","img":null},{"text":"אם החיבור מנוהל או שלא ניתן לנתקו, אין לעקוף הגבלה. הפנה לגורם המנהל לצורך הבדיקה ותעד שלא ניתן היה להשלים אותה.","img":null}]},{"title":"שלב 4 תוצאת הבדיקה","ordered":true,"steps":[{"text":"הגלישה חזרה: קיימת אינדיקציה שהתקלה קשורה לשירות VPN. הפנה להמשך טיפול מול ספק השירות או הגורם שמנהל אותו. אם נדרש להחזיר את החיבור, בצע זאת באמצעות הלקוח המורשה; אין לשנות את תצורת השירות.","img":null},{"text":"התקלה נשארה: הפעל מחדש את השירות אם הלקוח זקוק לו והמשך לסעיף הבא.","img":null}]},{"title":"המשך טיפול","ordered":false,"steps":[{"text":"אם התקלה נמשכת, או שלא ניתן היה להשלים את הבדיקה, עבור למסמך ״קו מנוהל והגבלות ארגוניות זיהוי והמשך טיפול״. ציין אילו בדיקות בוצעו ומה היו התוצאות.","img":null}]}]},"source":{"name":"O-34 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-34.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"תקלת גלישה - VPN פעיל במכשיר O-34.docx"};
window.dynamicDocs['kbm_o35'] = {"id":"kbm_o35","topic":"O-35 · קו מנוהל והגבלות ארגוניות זיהוי והמשך טיפול","cat":"tech","docType":"pdf","kind":"O","desc":"קו מנוהל והגבלות ארגוניות","tags":["גלישה"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מתי משתמשים במסמך","ordered":false,"steps":[{"text":"השתמש במסמך כאשר עולה חשד להגבלה חיצונית על הגלישה, או לאחר בדיקות שני קווים פעילים ו־VPN כשהתקלה נמשכת. מסמך זה עוסק בניהול ובסינון; תפעול הקווים וה־VPN נמצא במסמכים הייעודיים.","img":null},{"text":"דוגמאות: בקרת הורים, אפליקציית סינון תוכן או אבטחה, שירות המגביל שימוש בנתונים, פרופיל ניהול ארגוני או מכשיר המנוהל על ידי מקום העבודה.","img":null}]},{"title":"שלב 1 זיהוי הגבלה","ordered":true,"steps":[{"text":"שאל: האם מותקנת במכשיר אפליקציית סינון, אבטחה או בקרת הורים, או שהמכשיר מנוהל על ידי מקום העבודה או גורם אחר?","img":null},{"text":"אם הלקוח אינו יודע, ברר מי מנהל את הרשאות המכשיר, האם קיימות הגבלות על אפליקציות או אתרים, והאם התקלה החלה לאחר התקנה או שינוי בשירות כזה.","img":null},{"text":"לא נמצאה הגבלה ואין חשד להגבלה: עבור לסעיף המשך טיפול.","img":null}]},{"title":"שלב 2 בדיקה באמצעות המשתמש המורשה","ordered":true,"steps":[{"text":"אם נמצאה הגבלה שעשויה להשפיע על הגלישה, בקש מהמשתמש המורשה לבטל אותה זמנית לצורך בדיקה, אם הדבר אפשרי. אין למחוק אפליקציה, להסיר פרופיל ניהול או לעקוף הרשאות. בדוק שוב גלישה כשהרשת האלחוטית כבויה.","img":null},{"text":"הגלישה חזרה: קיימת אינדיקציה שההגבלה משפיעה על הגלישה. הפנה לגורם שמנהל את האפליקציה או השירות לצורך התאמת ההגדרה. אין להשאיר הגבלה מבוטלת באופן קבוע ללא החלטת המשתמש המורשה.","img":null},{"text":"התקלה נשארה: החזר את ההגבלה למצבה הקודם באמצעות המשתמש המורשה והמשך לסעיף המשך טיפול.","img":null}]},{"title":"שלב 3 לא ניתן לבצע את הבדיקה","ordered":true,"steps":[{"text":"אם הלקוח אינו מורשה לשנות את ההגדרה, או שהוא מורשה אך אינו יודע כיצד או אינו מצליח לבטלה, הפנה לגורם המנהל. תעד שהבדיקה לא הושלמה; אין לקבוע שההגבלה אינה גורמת לתקלה.","img":null}]},{"title":"המשך טיפול","ordered":false,"steps":[{"text":"אם לא נמצאה הגבלה, או שנבדקה ולא פתרה את התקלה, חזור למסלול תקלת הגלישה שממנו הופנית. אם המסלול וכל בדיקות מקרי הקצה הרלוונטיות הושלמו והתקלה נמשכת, עבור למסמך ״העברה למומחה בתקלת גלישה״.","img":null},{"text":"אם בדיקה לא הושלמה בשל מגבלה חיצונית, יש להשלים אותה מול הגורם המנהל ולהמשיך לפי תוצאותיה. אין לסמן אותה כתקינה.","img":null}]},{"title":"הסבר ללקוח","ordered":false,"steps":[{"text":"יש במכשיר אפליקציה או הגדרה שעשויה להגביל גלישה. כדי לבדוק אם היא גורמת לתקלה, נדרשת בדיקה באמצעות מי שמורשה לנהל אותה.","img":null}]}]},"source":{"name":"O-35 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-35.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O35 תקלת גלישה קו מנוהל והגבלות ארגוניות.docx"};
window.dynamicDocs['kbm_e30'] = {"id":"kbm_e30","topic":"E-30 · העברה למומחה בתקלת גלישה","cat":"tech","docType":"pdf","kind":"E","desc":"העברה למומחה בתקלת גלישה","tags":["גלישה"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"when":["יש להעביר את הפנייה למומחה כאשר הנציג השלים את מסלול הטיפול הרלוונטי והתקלה לא נפתרה.","ניתן להעביר למומחה גם כאשר נדרש טיפול שאינו בסמכות הנציג."],"to":[],"conditions":["ודא שבוצעו כל הבדיקות הרלוונטיות למסלול:","בדיקות הקו והגלישה במערכת.","בדיקות המכשיר הנדרשות.","בדיקת נקודת הגישה, כאשר רלוונטי.","ריענון שירות הגלישה.","ריענון כרטיס SIM","כיבוי והפעלת המכשיר, כאשר נדרש.","בדיקת \"מקרי קצה לפני העברה למומחה\".","אין לחזור על פעולה שכבר בוצעה במסגרת המסלול.","תעד:","סוג התקלה.","חוסר גלישה או איטיות.","בכל מקום או במקום מסוים.","האם התקלה מתרחשת במהלך שיחה בלבד.","כתובת או אזור התקלה, כאשר רלוונטי.","סוג המכשיר.","מערכת ההפעלה.","מספר הקווים הפעילים במכשיר.","חיווי הרשת.","תוצאת בדיקת מהירות, כאשר בוצעה.","כל הפעולות שבוצעו.","תוצאת כל פעולה.","מקרי הקצה שנבדקו.","סיבת ההעברה למומחה."],"document":[],"extra":[{"title":"מקרים שבהם נדרשת העברה","lines":["העבר למומחה כאשר מתקיים אחד מהמקרים הבאים:","כל שלבי מסלול הטיפול הושלמו והתקלה לא נפתרה.","קיימת אינדיקציה לתקלה בקו, בכרטיס SIM או ברשת שלא ניתן לפתור ברמת הנציג.","נדרש טיפול או שימוש במערכת שאינם בהרשאת הנציג.","מסלול הטיפול מפנה במפורש למומחה.","אם קיים חשד לבעיית קליטה או תקלה אזורית:","עבור תחילה למסמך האבחון המרכזי \"בעיות קליטה בארץ\"."]},{"title":"אופן ההעברה","lines":[]},{"title":"נדרשת השלמה ע\"י שחר/אוריה","lines":["סוג הפנייה שיש לפתוח.","שם התור או הגורם שאליו מעבירים.","זמן הטיפול.","מי אחראי לחזור ללקוח."]},{"title":"תיאום ציפיות ללקוח","lines":["\"השלמנו את הבדיקות שניתן לבצע בשלב הזה והתקלה עדיין דורשת בדיקה נוספת. אני מעביר את הפנייה למומחה יחד עם כל הבדיקות והפעולות שכבר ביצענו, כדי שהטיפול ימשיך מהנקודה שבה עצרנו.\""]}]},"source":{"name":"E-30 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/E-30.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"E-30 העברה למומחה בתקלת גלישה.docx"};
window.dynamicDocs['kbm_s30'] = {"id":"kbm_s30","topic":"S-30 · המשך טיפול מומחה בתקלת גלישה","cat":"tech","docType":"pdf","kind":"S","desc":"המשך טיפול מומחה בתקלת גלישה","tags":["גלישה"],"owner":"אוריה","stages":[{"num":"1","title":"בהכנה","items":[{"text":"⚠ חסר: המסמך טרם הועבר לאפליקציה (במפה: טרם נכתב)","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"חסר","priority":"","gap":"סטטוס מנהלת: אוריה - חדש","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"draft","originName":"S-30 המשך טיפול מומחה בתקלת גלישה - להשלים.docx"};
window.dynamicDocs['kbm_m40'] = {"id":"kbm_m40","topic":"M-40 · אבחון מרכזי קושי בהוצאת או קבלת שיחות","cat":"tech","docType":"pdf","kind":"M","desc":"אבחון מרכזי - קושי בהוצאת או קבלת שיחות","tags":["שיחות"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"intro":["מטרת המסמך","לזהות כיצד תקלה בשיחות מתבטאת אצל הלקוח ולנתב אותו למסלול הטיפול המתאים.","המסמך אינו מיועד לביצוע דיבאג מלא."],"questions":[{"title":"האם הלקוח נמצא בארץ או בחו\"ל?","q":"\"האם התקלה מתרחשת בארץ או בזמן שהייה בחו\"ל?\"","hint":"","answers":[{"text":"הלקוח בחו\"ל","note":"אין להמשיך במסלול זה. הפנה לעולם הידע \"חו\"ל\".","go":"item:pdf_011"},{"text":"הלקוח בארץ","note":"","go":"q:1"}]},{"title":"האם השיחה אינה מתבצעת, או שהבעיה היא באיכות השיחה?","q":"\"האם אינך מצליח להוציא או לקבל את השיחה בכלל, או שהשיחה מתחברת אבל מתנתקת או שאיכות השמע אינה תקינה?\"","hint":"כשהשיחה מתחברת אך מתנתקת או שאיכות השמע ירודה — ברר האם התופעה מתרחשת במקום מסוים, במסלול נסיעה מוגדר או גם במקומות שונים.","answers":[{"text":"השיחה אינה יוצאת או אינה מתקבלת","note":"","go":"q:2"},{"text":"השיחה מתחברת אך מתנתקת או איכות השמע ירודה — במקום מסוים או במסלול נסיעה מוגדר","note":"","go":"item:kbm_m10"},{"text":"השיחה מתחברת אך מתנתקת או איכות השמע ירודה — במקומות שונים","note":"בצע את האבחון לפי סדר השלבים במסמך. אין לקבוע מראש שהגורם לתקלה הוא VoLTE או המכשיר.","go":"","ext":"מסמך ״בעיות VoLTE ומכשירים ישנים״ (עדיין לא באפליקציה)"},{"text":"מופיע \"אין שירות\", \"אין רשת\", SOS או \"שיחות חירום בלבד\", ללא אינדיקציה לבעיה התלויה במיקום","note":"","go":"item:kbnew_r14"},{"text":"חוסר השירות החל לאחר הפעלת SIM או eSIM","note":"","go":"item:kbnew_r50"},{"text":"כשל בסריקת QR, או שהתקנת ה-eSIM טרם הושלמה","note":"","go":"item:kbnew_r51"}]},{"title":"האם התקלה מול כל המספרים או מול מספר מסוים?","q":"\"האם זה קורה מול כל המספרים או רק מול מספר מסוים או כמה מספרים מסוימים?\"","hint":"","answers":[{"text":"מספר מסוים או מספרים מסוימים בלבד","note":"","go":"item:kbm_r43"},{"text":"הלקוח בארץ, מצליח לחייג למספרים בישראל אך לא למספרים בחו\"ל","note":"","go":"item:kbnew_r45"},{"text":"כל המספרים","note":"","go":"q:3"}]},{"title":"האם התקלה תלויה במיקום?","q":"\"האם זה קורה בכל מקום או רק במקום מסוים?\"","hint":"","answers":[{"text":"רק במקום מסוים","note":"הפנה לעולם הידע \"בעיות קליטה בארץ\". אין להמשיך במסלול השיחות לפני שנשללה בעיית קליטה התלויה במיקום.","go":"item:kbm_m10"},{"text":"בכל מקום","note":"","go":"q:4"}]},{"title":"מה בדיוק לא עובד?","q":"\"מה קורה בפועל - אינך מצליח להוציא שיחות, אינך מקבל שיחות, או ששני הכיוונים אינם עובדים?\"","hint":"לפני המעבר למסלול, ברר:\nמתי התחילה התקלה.\nהאם התקלה קבועה או לסירוגין.\nהאם בוצעה לאחרונה החלפת מכשיר.\nהאם בוצעה לאחרונה החלפת כרטיס או מעבר לכרטיס דיגיטלי.\nהאם הלקוח ביצע שינוי כלשהו במכשיר לפני הופעת התקלה.","answers":[{"text":"לא ניתן להוציא וגם לקבל שיחות","note":"","go":"item:kbm_r40"},{"text":"לא ניתן להוציא שיחות בלבד","note":"","go":"item:kbm_r41"},{"text":"לא ניתן לקבל שיחות בלבד","note":"","go":"item:kbm_r42"}]}],"outro":["אין לבצע בשלב האבחון טיפול טכני מלא. המידע שנאסף נועד לתת למסלול הטיפול הבא את ההקשר הדרוש.","כאשר מסלול הטיפול בהמשך דורש פעולות אלה, יש להפנות למסמך הקיים ולא לשכפל את ההנחיות: O-12 — הפעלת שיחות ברשת אלחוטית, O-13 — איפוס הגדרות רשת, O-43 — בדיקה והפעלת VoLTE במכשיר."]},"source":{"name":"M-40 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/M-40.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793865099048,"originName":"M-40 אבחון מרכזי שיחות הפניה לקליטה מעודכן.docx"};
window.dynamicDocs['kbm_r40'] = {"id":"kbm_r40","topic":"R-40 · לא ניתן להוציא ולקבל שיחות","cat":"tech","docType":"pdf","kind":"R","desc":"לא ניתן להוציא ולקבל שיחות","tags":["שיחות"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול","items":[{"text":"הלקוח נמצא בארץ.","img":null},{"text":"התקלה מתרחשת בכל מקום.","img":null},{"text":"הלקוח אינו מצליח גם להוציא וגם לקבל שיחות.","img":null},{"text":"המסלול מיועד לתקלה בשירות השיחות עצמו, למשל חסימה, בעיית SIM, הגדרה במכשיר או תקלה רגעית בקו.","img":null},{"text":"אם התקלה תלויה במיקום או מתבטאת כבעיית רדיו:","img":null}],"images":[]},{"num":"2","title":"M-10 בעיות קליטה בארץ - אבחון מרכזי","items":[],"images":[]},{"num":"3","title":"שלב 1 - בירור ראשוני","items":[{"text":"ברר:","img":null},{"text":"מתי התחילה התקלה.","img":null},{"text":"האם התקלה קבועה או לסירוגין.","img":null},{"text":"האם בוצעה לאחרונה החלפת מכשיר.","img":null},{"text":"האם בוצעה החלפת SIM או מעבר ל eSIM","img":null},{"text":"האם בוצע שינוי במכשיר לפני תחילת התקלה.","img":null}],"images":[]},{"num":"4","title":"שלב 2 - בדיקות במערכת","items":[{"text":"בדוק לפני כל פעולה במכשיר:","img":null},{"text":"שהקו פעיל ואינו מושהה.","img":null},{"text":"שאין חסימה כספית המשפיעה על השירות.","img":null},{"text":"שאין חסימה לשיחות נכנסות או יוצאות.","img":null},{"text":"אם בוצע ניוד - שהניוד הושלם.","img":null},{"text":"שה-SIM הקיים תואם ומזוהה נכון במערכת.","img":null},{"text":"האם בוצעה לאחרונה החלפת SIM או eSIM","img":null},{"text":"ששירות VoLTE מאופשר בקו.","img":null}],"images":[]},{"num":"5","title":"נמצאה בעיה","items":[{"text":"טפל בהתאם להרשאות הנציג.","img":null},{"text":"אם ניתן לבדוק את השירות בלי לנתק את הלקוח - בצע בדיקה.","img":null},{"text":"אם התקלה נמשכת - המשך לשלב 3.","img":null}],"images":[]},{"num":"6","title":"שלב 3 - בדיקות במכשיר","items":[{"text":"בצע את כל הבדיקות האפשריות לפני כיבוי, מצב טיסה או פעולה שמנתקת את הלקוח.","img":null},{"text":"בדוק:","img":null},{"text":"האם המכשיר מזהה את הרשת.","img":null},{"text":"שהמכשיר מוגדר על דור 4 או 5.","img":null},{"text":"שהמכשיר אינו נעול על דור 2 או 3.","img":null},{"text":"ששירות VoLTE מופעל במכשיר.","img":null},{"text":"להנחיות המלאות הפנה אל:","img":null}],"images":[]},{"num":"7","title":"O-43 בדיקה והפעלת VoLTE במכשיר","items":[],"images":[]},{"num":"8","title":"נמצאה הגדרה לא תקינה","items":[{"text":"תקן ובדוק אם ניתן את השירות.","img":null}],"images":[]},{"num":"9","title":"כל ההגדרות תקינות","items":[{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"10","title":"שלב 4 - רענון SIM במערכת","items":[{"text":"אם כל בדיקות הקו, ה- SIM והמכשיר תקינות והתקלה נמשכת – יש לבצע רענון SIM במערכת.","img":null}],"images":[]},{"num":"11","title":"שלב 5 - רענון המכשיר","items":[{"text":"רק לאחר שהושלמו כל הבדיקות שניתן לבצע בזמן שהלקוח על הקו:","img":null},{"text":"הפעל וכבה מצב טיסה.","img":null},{"text":"המתן להתחברות מחדש לרשת.","img":null},{"text":"אם נדרש - בצע כיבוי והדלקה מלאה של המכשיר.","img":null},{"text":"לאחר החיבור מחדש בצע בדיקת שיחה יוצאת ונכנסת.","img":null}],"images":[]},{"num":"12","title":"התקלה נפתרה","items":[{"text":"סיום טיפול.","img":null}],"images":[]},{"num":"13","title":"התקלה לא נפתרה","items":[{"text":"המשך לשלב 6.","img":null}],"images":[]},{"num":"14","title":"שלב 6 - איפוס הגדרות רשת","items":[{"text":"הפנה אל:","img":null}],"images":[]},{"num":"15","title":"O-13 איפוס הגדרות רשת","items":[{"text":"לאחר האיפוס יש לבדוק מחדש שיחה נכנסת ויוצאת.","img":null}],"images":[]},{"num":"16","title":"התקלה נפתרה","items":[{"text":"סיום טיפול.","img":null}],"images":[]},{"num":"17","title":"התקלה עדיין קיימת","items":[{"text":"עבור אל:","img":null}],"images":[]},{"num":"18","title":"E-40 הסלמה למומחה בתקלת שיחות","items":[],"images":[]},{"num":"19","title":"לפני הסלמה","items":[{"text":"יש לתעד:","img":null},{"text":"מועד תחילת התקלה.","img":null},{"text":"סטטוס הקו והחסימות.","img":null},{"text":"סטטוס ניוד, אם רלוונטי.","img":null},{"text":"בדיקת התאמת ה-SIM במערכת.","img":null},{"text":"סוג ה SIM והאם הוחלף לאחרונה.","img":null},{"text":"סטטוס VoLTE בקו ובמכשיר.","img":null},{"text":"מצב הרשת שהוגדר במכשיר.","img":null},{"text":"האם בוצע רענון SIM","img":null},{"text":"האם בוצע מצב טיסה.","img":null},{"text":"האם בוצע כיבוי והדלקה.","img":null},{"text":"האם בוצע איפוס הגדרות רשת.","img":null},{"text":"תוצאת הבדיקה לאחר הפעולות.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-40 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-40.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-40 - לא ניתן להוציא ולקבל שיחות.docx"};
window.dynamicDocs['kbm_r41'] = {"id":"kbm_r41","topic":"R-41 · לא ניתן להוציא שיחות","cat":"tech","docType":"pdf","kind":"R","desc":"לא ניתן להוציא שיחות","tags":["שיחות"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול","items":[{"text":"הלקוח נמצא בארץ.","img":null},{"text":"התקלה מתרחשת בכל מקום.","img":null},{"text":"הלקוח מקבל שיחות, אך אינו מצליח להוציא שיחות.","img":null},{"text":"אם הלקוח בחו\"ל:","img":null}],"images":[]},{"num":"2","title":"M-00 תקלות ושירות בחו\"ל - אבחון מרכזי","items":[{"text":"אם התקלה תלויה במיקום או מתבטאת כבעיית רדיו:","img":null}],"images":[]},{"num":"3","title":"M-10 בעיות קליטה בארץ - אבחון מרכזי","items":[],"images":[]},{"num":"4","title":"שלב 1 - בירור ראשוני","items":[{"text":"ברר:","img":null},{"text":"מתי התחילה התקלה.","img":null},{"text":"האם התקלה קבועה או לסירוגין.","img":null},{"text":"האם הלקוח אינו מצליח להוציא שיחות לכל המספרים.","img":null},{"text":"האם בוצעה לאחרונה החלפת מכשיר.","img":null},{"text":"האם בוצעה החלפת SIM או מעבר ל eSIM","img":null},{"text":"האם בוצע שינוי במכשיר לפני תחילת התקלה.","img":null},{"text":"אם התקלה קיימת רק מול מספר מסוים או מספרים מסוימים:","img":null}],"images":[]},{"num":"5","title":"R-43 קושי בהוצאת או קבלת שיחות מול מספר מסוים או מספרים מסוימים","items":[],"images":[]},{"num":"6","title":"שלב 2 - בדיקות במערכת","items":[{"text":"בדוק:","img":null},{"text":"שהקו פעיל ואינו מושהה.","img":null},{"text":"שאין חסימה כספית המשפיעה על השירות.","img":null},{"text":"שאין חסימה לשיחות יוצאות.","img":null},{"text":"אם בוצע ניוד - שהניוד הושלם.","img":null},{"text":"מהו סוג ה-SIM והאם הוחלף לאחרונה.","img":null},{"text":"ששירות VoLTE מאופשר בקו.","img":null}],"images":[]},{"num":"7","title":"נמצאה חסימה או בעיית סטטוס","items":[{"text":"טפל בהתאם להרשאות הנציג.","img":null},{"text":"לאחר התיקון בצע בדיקת שיחה יוצאת.","img":null},{"text":"אם השיחה יוצאת - סיום טיפול.","img":null},{"text":"אם התקלה נמשכת - המשך לשלב 3.","img":null}],"images":[]},{"num":"8","title":"שלב 3 - בדיקות במכשיר","items":[{"text":"בדוק:","img":null},{"text":"שהמכשיר מזהה רשת.","img":null},{"text":"שהמכשיר מוגדר על דור 4 או 5.","img":null},{"text":"שהמכשיר אינו נעול על דור 2 או 3.","img":null},{"text":"ששירות VoLTE מופעל במכשיר.","img":null},{"text":"להנחיות התפעול:","img":null}],"images":[]},{"num":"9","title":"O-43 בדיקה והפעלת VoLTE במכשיר","items":[],"images":[]},{"num":"10","title":"נמצאה הגדרה לא תקינה","items":[{"text":"תקן בהתאם למסמך התפעול ובצע בדיקת שיחה יוצאת.","img":null},{"text":"אם התקלה נפתרה - סיום טיפול.","img":null},{"text":"אם ההגדרות תקינות והתקלה נמשכת - המשך לשלב 4.","img":null}],"images":[]},{"num":"11","title":"שלב 4 - בדיקת SIM","items":[{"text":"בדוק:","img":null},{"text":"האם ה-SIM מזוהה במכשיר.","img":null},{"text":"האם בוצעה לאחרונה החלפת SIM.","img":null},{"text":"האם מדובר ב-SIM פיזי או eSIM.","img":null},{"text":"פער מקצועי להשלמה: יש להגדיר את בדיקת התאמת ה-SIM למערכת ואת פעולת רענון ה SIM המאושרת לנציג.","img":null}],"images":[]},{"num":"12","title":"שלב 5 - רענון המכשיר","items":[{"text":"לאחר שהושלמו כל הבדיקות שניתן לבצע בזמן שהלקוח על הקו:","img":null},{"text":"בצע כיבוי והדלקה של מצב טיסה.","img":null},{"text":"בדוק מחדש חיבור לרשת.","img":null},{"text":"אם התקלה נמשכת - בצע כיבוי והדלקה מלאה של המכשיר.","img":null},{"text":"לאחר התחברות מחדש בצע בדיקת שיחה יוצאת.","img":null}],"images":[]},{"num":"13","title":"התקלה נפתרה","items":[{"text":"סיום טיפול.","img":null}],"images":[]},{"num":"14","title":"התקלה לא נפתרה","items":[{"text":"המשך לשלב 6.","img":null}],"images":[]},{"num":"15","title":"שלב 6 - איפוס הגדרות רשת","items":[{"text":"הפנה אל:","img":null}],"images":[]},{"num":"16","title":"O-13 איפוס הגדרות רשת","items":[{"text":"לאחר האיפוס בצע בדיקת שיחה יוצאת.","img":null}],"images":[]},{"num":"17","title":"התקלה נפתרה","items":[{"text":"סיום טיפול.","img":null}],"images":[]},{"num":"18","title":"התקלה עדיין קיימת","items":[{"text":"עבור אל:","img":null}],"images":[]},{"num":"19","title":"E-40 הסלמה למומחה בתקלת שיחות","items":[],"images":[]},{"num":"20","title":"לפני הסלמה","items":[{"text":"יש לתעד:","img":null},{"text":"מועד תחילת התקלה.","img":null},{"text":"סטטוס הקו.","img":null},{"text":"חסימות שנבדקו.","img":null},{"text":"סטטוס ניוד, אם רלוונטי.","img":null},{"text":"סוג ה-SIM והאם הוחלף לאחרונה.","img":null},{"text":"סטטוס VoLTE בקו ובמכשיר.","img":null},{"text":"מצב הרשת במכשיר.","img":null},{"text":"האם בוצע מצב טיסה.","img":null},{"text":"האם בוצע כיבוי והדלקה.","img":null},{"text":"האם בוצע איפוס הגדרות רשת.","img":null},{"text":"תוצאת בדיקת השיחה היוצאת.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-41 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-41.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-41 - לא ניתן להוציא שיחות.docx"};
window.dynamicDocs['kbm_r42'] = {"id":"kbm_r42","topic":"R-42 · לא מתקבלות שיחות","cat":"tech","docType":"pdf","kind":"R","desc":"לא מתקבלות שיחות","tags":["שיחות"],"owner":"","stages":[{"num":"1","title":"מתי משתמשים במסלול","items":[{"text":"הלקוח נמצא בארץ.","img":null},{"text":"התקלה מתרחשת בכל מקום.","img":null},{"text":"הלקוח מצליח להוציא שיחות, אך אינו מקבל שיחות.","img":null},{"text":"אם התקלה מתרחשת רק מול מספר מסוים או מספרים מסוימים:","img":null}],"images":[]},{"num":"2","title":"R-43 קושי בהוצאת או קבלת שיחות מול מספר מסוים או מספרים מסוימים","items":[{"text":"אם התקלה תלויה במיקום או מתבטאת כבעיית רדיו:","img":null}],"images":[]},{"num":"3","title":"M-10 בעיות קליטה בארץ - אבחון מרכזי","items":[],"images":[]},{"num":"4","title":"שלב 1 - בירור ראשוני","items":[{"text":"בתחילת הטיפול, חייג ללקוח ובצע בדיקת שיחה נכנסת בפועל.","img":null},{"text":"הקשב למה שמתקבל בחיוג - צליל חיוג, הודעה, מעבר לתא קולי או ניתוק - כדי לאמת את התקלה ולזהות כיצד היא מתבטאת.","img":null},{"text":"ברר:","img":null},{"text":"מתי התחילה התקלה.","img":null},{"text":"האם התקלה קבועה או לסירוגין.","img":null},{"text":"האם הלקוח אינו מקבל שיחות מכל המספרים.","img":null},{"text":"האם השיחות מופיעות ביומן השיחות.","img":null},{"text":"האם המתקשר שומע צליל חיוג, הודעה או מעבר לתא קולי.","img":null},{"text":"האם בוצעה לאחרונה החלפת מכשיר.","img":null},{"text":"האם בוצעה החלפת SIM או מעבר לeSIM","img":null}],"images":[]},{"num":"5","title":"שלב 2 - בדיקות במערכת","items":[{"text":"בדוק:","img":null},{"text":"שהקו פעיל ואינו מושהה.","img":null},{"text":"שאין חסימה המשפיעה על שיחות נכנסות.","img":null},{"text":"שאין הפניית שיחות כללית או הפניה למספר שגוי.","img":null},{"text":"אם בוצע ניוד - שהניוד הושלם.","img":null},{"text":"מהו סוג ה-SIM והאם הוחלף לאחרונה.","img":null},{"text":"ששירות VoLTE מאופשר בקו.","img":null}],"images":[]},{"num":"6","title":"נמצאה בעיה","items":[{"text":"טפל בהתאם להרשאות הנציג.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null},{"text":"אם השיחה מתקבלת - סיום טיפול.","img":null},{"text":"אם התקלה נמשכת - המשך לשלב 3.","img":null}],"images":[]},{"num":"7","title":"שלב 3 - בדיקות במכשיר","items":[{"text":"בדוק:","img":null},{"text":"האם קיימת חסימת שיחות במכשיר.","img":null},{"text":"האם מצב \"נא לא להפריע\" פעיל.","img":null},{"text":"האם קיימת השתקה של שיחות ממספרים לא מזוהים.","img":null},{"text":"האם מותקנת אפליקציה לחסימת או זיהוי שיחות שעלולה להשפיע על קבלת השיחה.","img":null},{"text":"שהמכשיר מוגדר על דור 4 או 5.","img":null},{"text":"ששירות VoLTE מופעל במכשיר.","img":null},{"text":"להנחיות VoLTE:","img":null}],"images":[]},{"num":"8","title":"O-43 בדיקה והפעלת VoLTE במכשיר","items":[{"text":"להנחיות בדיקת חסימות, \"נא לא להפריע\" ואפליקציות חסימה: O-42 - בדיקת חסימות והגדרות שיחה במכשיר.","img":null}],"images":[]},{"num":"9","title":"נמצאה הגדרה שמונעת קבלת שיחות","items":[{"text":"תקן ובצע בדיקת שיחה נכנסת.","img":null},{"text":"אם התקלה נפתרה - סיום טיפול.","img":null},{"text":"אם התקלה נמשכת - המשך לשלב 4.","img":null}],"images":[]},{"num":"10","title":"שלב 4 – בדיקת SIM","items":[{"text":"בדוק:","img":null},{"text":"האם ה-SIM מזוהה במכשיר.","img":null},{"text":"האם בוצעה לאחרונה החלפת SIM .","img":null},{"text":"האם מדובר ב SIM פיזי או eSIM","img":null},{"text":"פער מקצועי להשלמה: יש להגדיר את בדיקת התאמת ה-SIM למערכת ואת פעולת רענון ה SIM המאושרת לנציג.","img":null}],"images":[]},{"num":"11","title":"שלב 5 - רענון המכשיר","items":[{"text":"רק לאחר השלמת הבדיקות שניתן לבצע כאשר הלקוח עדיין על הקו:","img":null},{"text":"בצע כיבוי והדלקה של מצב טיסה.","img":null},{"text":"המתן להתחברות מחדש לרשת.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null},{"text":"אם התקלה נמשכת - בצע כיבוי והדלקה מלאה של המכשיר.","img":null},{"text":"לאחר החיבור מחדש בצע בדיקת שיחה נכנסת נוספת.","img":null}],"images":[]},{"num":"12","title":"התקלה נפתרה","items":[{"text":"סיום טיפול.","img":null}],"images":[]},{"num":"13","title":"התקלה לא נפתרה","items":[{"text":"המשך לשלב 6.","img":null}],"images":[]},{"num":"14","title":"שלב 6 - איפוס הגדרות רשת","items":[{"text":"הפנה אל:","img":null}],"images":[]},{"num":"15","title":"O-13 איפוס הגדרות רשת","items":[{"text":"לאחר האיפוס בצע בדיקת שיחה נכנסת.","img":null}],"images":[]},{"num":"16","title":"התקלה נפתרה","items":[{"text":"סיום טיפול.","img":null}],"images":[]},{"num":"17","title":"התקלה עדיין קיימת","items":[{"text":"עבור אל:","img":null}],"images":[]},{"num":"18","title":"E-40 הסלמה למומחה בתקלת שיחות","items":[],"images":[]},{"num":"19","title":"לפני הסלמה","items":[{"text":"יש לתעד:","img":null},{"text":"מועד תחילת התקלה.","img":null},{"text":"האם התקלה מכל המספרים.","img":null},{"text":"מה שומע המתקשר.","img":null},{"text":"האם השיחה מופיעה ביומן השיחות.","img":null},{"text":"סטטוס הקו והחסימות.","img":null},{"text":"האם נבדקו הפניות שיחה.","img":null},{"text":"סוג ה-SIM והאם הוחלף לאחרונה.","img":null},{"text":"סטטוס VoLTE בקו ובמכשיר.","img":null},{"text":"האם נבדקו חסימות והגדרות שיחה במכשיר.","img":null},{"text":"האם בוצע מצב טיסה.","img":null},{"text":"האם בוצע כיבוי והדלקה.","img":null},{"text":"האם בוצע איפוס הגדרות רשת.","img":null},{"text":"תוצאת בדיקת השיחה הנכנסת.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-42 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-42.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-42 - לא מתקבלות שיחות.docx"};
window.dynamicDocs['kbm_r43'] = {"id":"kbm_r43","topic":"R-43 · קושי בהוצאת או קבלת שיחות מול מספר מסוים או מספרים מסוימים","cat":"tech","docType":"pdf","kind":"R","desc":"קושי בהוצאת או קבלת שיחות מול מספר מסוים","tags":["שיחות"],"owner":"אבי חבה","stages":[{"num":"1","title":"מתי משתמשים במסלול","items":[{"text":"הלקוח נמצא בארץ.","img":null},{"text":"השיחות מול רוב המספרים תקינות.","img":null},{"text":"התקלה מתרחשת מול מספר מסוים או מספרים מסוימים בלבד.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - בירור סוג התקלה","items":[{"text":"ברר:","img":null},{"text":"האם מדובר במספר אחד או בכמה מספרים.","img":null},{"text":"האם הבעיה היא בקבלת שיחה, בהוצאת שיחה או בשני הכיוונים.","img":null},{"text":"האם התקלה מתרחשת בכל מקום ובכל זמן.","img":null},{"text":"האם שיחות מול מספרים אחרים תקינות.","img":null},{"text":"במקרה של שיחה נכנסת - האם השיחה מופיעה ביומן השיחות.","img":null},{"text":"במקרה של שיחה נכנסת - האם הטלפון מצלצל, מצלצל ונפסק או אינו מציג את השיחה כלל.","img":null},{"text":"ברר האם בוצע ניוד, מתי הושלם והאם התקלה בקבלת שיחות החלה לאחריו או שקיימת אינדיקציה לכשל ניוד.","img":null},{"text":"אם מדובר בקושי בקבלת שיחות לאחר ניוד, גם כאשר שיחות מחלק מהמספרים מתקבלות, עבור ל־R-44 — לא מתקבלות שיחות לאחר ניוד. בדיקות חיוג ממנוי וויקום וממפעיל חיצוני והמשך הטיפול בניוד מרוכזים שם. אין להחיל מסלול זה על קושי בהוצאת שיחות בלבד.","img":null},{"text":"אם מתברר שהתקלה היא מול כל המספרים - חזור למסלול המתאים:","img":null}],"images":[]},{"num":"3","title":"R-40 לא ניתן להוציא ולקבל שיחות","items":[],"images":[]},{"num":"4","title":"R-41 לא ניתן להוציא שיחות","items":[],"images":[]},{"num":"5","title":"R-42 לא מתקבלות שיחות","items":[],"images":[]},{"num":"6","title":"שלב 2 - בדיקות במערכת","items":[{"text":"בדוק:","img":null},{"text":"שהקו פעיל.","img":null},{"text":"שאין חסימה כללית על שיחות נכנסות או יוצאות.","img":null},{"text":"שאין הפניית שיחות כללית או הפניה שגויה.","img":null},{"text":"להנחיות המערכת:","img":null}],"images":[]},{"num":"7","title":"O-40 בדיקת סטטוס קו וחסימות שיחה במערכת","items":[],"images":[]},{"num":"8","title":"O-41 בדיקת הפניית שיחות והגדרות שיחה במערכת","items":[{"text":"אם נמצאה בעיה - תקן ובצע בדיקה חוזרת מול המספר הרלוונטי.","img":null},{"text":"אם המערכת תקינה - המשך לשלב 3.","img":null}],"images":[]},{"num":"9","title":"שלב 3 - בדיקות במכשיר","items":[{"text":"בדוק:","img":null},{"text":"האם המספר מופיע ברשימת המספרים החסומים.","img":null},{"text":"האם מצב \"נא לא להפריע\" פעיל.","img":null},{"text":"האם קיימת השתקת שיחות ממספרים לא מזוהים.","img":null},{"text":"האם קיימת אפליקציית צד שלישי לזיהוי או חסימת שיחות.","img":null},{"text":"להנחיות:","img":null}],"images":[]},{"num":"10","title":"O-42 בדיקת חסימות והגדרות שיחה במכשיר","items":[{"text":"אם נמצאה הגדרה המשפיעה על השיחה - תקן ובצע בדיקה חוזרת.","img":null},{"text":"אם התקלה נמשכת - המשך לשלב 4.","img":null}],"images":[]},{"num":"11","title":"שלב 4 - בדיקה חוזרת מול המספר","items":[{"text":"בצע ניסיון נוסף מול המספר הרלוונטי.","img":null},{"text":"בדוק:","img":null},{"text":"האם השיחה יוצאת.","img":null},{"text":"האם השיחה נכנסת.","img":null},{"text":"האם מופיע שינוי בהתנהגות השיחה לאחר תיקון ההגדרות.","img":null}],"images":[]},{"num":"12","title":"התקלה נפתרה","items":[{"text":"סיום טיפול.","img":null}],"images":[]},{"num":"13","title":"התקלה לא נפתרה","items":[{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"14","title":"שלב 5 - המשך טיפול","items":[{"text":"אם כל שאר השיחות תקינות והתקלה נשארת רק מול מספר מסוים או מספרים מסוימים:","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"15","title":"E-40 הסלמה למומחה בתקלת שיחות","items":[],"images":[]},{"num":"16","title":"לפני הסלמה","items":[{"text":"אם במהלך הטיפול התברר שהתקלה בקבלת שיחות קשורה לניוד, המשך ב־R-44 לפני הסלמה כללית לפי מסמך זה. אם אין קשר לניוד, המשך ב־E-40 לאחר הבדיקות הרלוונטיות.","img":null},{"text":"יש לתעד:","img":null},{"text":"המספר או המספרים מולם קיימת התקלה.","img":null},{"text":"האם מדובר בשיחה נכנסת, יוצאת או בשני הכיוונים.","img":null},{"text":"האם שיחות מול מספרים אחרים תקינות.","img":null},{"text":"מה קורה בפועל בעת ניסיון השיחה.","img":null},{"text":"האם השיחה מופיעה ביומן השיחות.","img":null},{"text":"בדיקות חסימה במערכת.","img":null},{"text":"בדיקת הפניית שיחות.","img":null},{"text":"בדיקות חסימה והגדרות במכשיר.","img":null},{"text":"בדיקת אפליקציות צד שלישי.","img":null},{"text":"תוצאת הבדיקה החוזרת.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: אבי חבה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-43 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-43.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"קושי בקבלת הוצאת שיחות מספר מסוים R43.docx"};
window.dynamicDocs['kbm_r44'] = {"id":"kbm_r44","topic":"R-44 · לא מתקבלות שיחות לאחר ניוד","cat":"tech","docType":"pdf","kind":"R","desc":"לא מתקבלות שיחות לאחר ניוד","tags":["שיחות"],"owner":"שחר","stages":[{"num":"1","title":"מתי משתמשים במסלול","items":[{"text":"הלקוח בארץ, מצליח להוציא שיחות אך אינו מקבל שיחות כלל או אינו מקבל שיחות מחלק מהמספרים. התקלה החלה לאחר ניוד או שקיימת אינדיקציה לכשל ניוד. ניתן להגיע למסלול מ־R-42 — לא מתקבלות שיחות, או מ־R-43 — קושי בהוצאת או קבלת שיחות מול מספר מסוים או מספרים מסוימים.","img":null},{"text":"אם התקלה היא בהוצאת שיחות בלבד, המשך במסלול השיחות המתאים; אין להחיל עליו אוטומטית את מסלול קבלת השיחות לאחר ניוד.","img":null},{"text":"אם גם שיחות יוצאות אינן פועלות, בצע אבחון לפי M-40 והעבר אליו את ממצאי הניוד.","img":null}],"images":[]},{"num":"2","title":"שלב 1 אימות הקשר לניוד","items":[{"text":"ברר ותעד מועד ניוד, מועד תחילת התקלה ביחס לניוד, האם שיחות יוצאות תקינות, האם שיחות נכנסות מתקבלות מחלק מהמספרים, מה מפעיל המקור של המספרים הבעייתיים אם ידוע, והאם שירותים נוספים בקו תקינים.","img":null},{"text":"בעת ניסיון החיוג תעד מה נשמע בפועל והאם השיחה מופיעה במכשיר או ביומן. אם בחיוג למנוי וויקום לא נשמעת ההכרזה ״וויקום שלום״ בתחילת השיחה, קיימת אינדיקציה לתקלת ניידות. אין לסיים אבחון על סמך ההכרזה בלבד; המשך בבדיקות המסמך.","img":null}],"images":[]},{"num":"3","title":"שלב 2 בדיקת ניידות ב־CRM","items":[{"text":"בדף מספר הטלפון ב־CRM, פתח את מקטע ״ניידות מספרים״.","img":null},{"text":"תעד את הסטטוס או ההודעה כפי שמופיעים ואת קוד הכשל אם קיים.","img":null},{"text":"בדוק אם הניוד הושלם או שקיימת אינדיקציה לתהליך שלא הושלם או לכשל.","img":null}],"images":[]},{"num":"4","title":"חלון ריק או כשל שמופיע עם failed","items":[{"text":"חלון ריק הוא לרוב סטאק גנרי.","img":null},{"text":"תעד את הממצא והעבר פנייה למרת״מ, שמטפל מול מרת״מ החברה הקודמת. בהודעת failed תעד את ההודעה המלאה וקוד הכשל; פעל לפי הקוד המפורט להלן. אם אינו אחד מהקודים המפורטים, העבר את הממצא למרת״מ לבירור, ללא שינוי על סמך ניחוש.","img":null}],"images":[]},{"num":"5","title":"Chk-02 Chk-03 Chk-07 Chk-04","items":[{"text":"Chk-02: המנוי מנותק בחברה הקודמת.","img":null},{"text":"Chk-03: תהליכי ניוד מול שתי חברות במקביל, לרבות סטאק ישן מול חברה אחרת.","img":null},{"text":"Chk-07 או Chk-04: סטאק גנרי. בכל אחד מהמקרים פתח פנייה למרת״מ עם הקוד וההודעה.","img":null},{"text":"Chk-09 מנוי פריפייד בתהליך הניוד:","img":null},{"text":"יש להעביר חשבונית טעינה בסכום מינימלי של 30 ש״ח לבק אופיס לשחרור הסטאק, לפי ההנחיה שנמסרה. אין לבלבל מקרה זה עם מנוי שהוגדר בטעות כפריפייד אצלנו, המטופל בשלב 3.","img":null}],"images":[]},{"num":"6","title":"Chk-10 או Chk-25","items":[{"text":"המנוי חסום אצל המפעיל הקודם. הנחה את הלקוח לפנות לחברה הקודמת ולבקש לשחרר את הניוד.","img":null},{"text":"כאשר אותר כשל ניוד שהועבר למרת״מ, לבק אופיס או לטיפול מול החברה הקודמת, המשך הטיפול הוא בהתאם לכשל שזוהה. אין לעקוף את הכשל באמצעות החלפת כרטיס או להציג את הניוד כתקין לפני שהושלם הטיפול. לאחר תיקון חזור לבדיקות התקינות.","img":null}],"images":[]},{"num":"7","title":"שלב 3 בדיקות הקו וטיפול בממצאים","items":[{"text":"חבילה וחסימות","img":null},{"text":"בדוק שלא מדובר בחבילת דאטה בלבד. אם הלקוח מעוניין בחבילה הכוללת שיחות, החלף חבילה אונליין בהתאם לבקשתו. מבצע: נציג; SLA לפי ההנחיה שנמסרה: מיידי. בדוק חסימות על שיחות נכנסות ויוצאות; פתיחה באזור האישי מבוצעת על ידי הנציג בהתאם להרשאות. להנחיות ראה O-40 — בדיקת סטטוס קו וחסימות שיחה במערכת.","img":null}],"images":[]},{"num":"8","title":"שיוך המנוי וה־SIM במערכת","items":[{"text":"ודא שהמספר משויך למנוי הנכון. בשדה ״SIMs Inventory״ השווה את ה־SIM/eSIM המשויך במערכת לכרטיס הפיזי שהלקוח הכניס בפועל או לפרופיל שסָרק והתקין במכשיר, באמצעות פרטי ה־SIM במכשיר.","img":null},{"text":"אם נמצא חוסר התאמה, תיקון השיוך או החלפת ה־SIM מתבצעים במערכת לפי הכרטיס או הפרופיל שבשימוש בפועל. הכוונה כאן לתיקון במערכת, ולא להחלפת כרטיס פיזי אצל הלקוח. מבצע: נציג בהתאם להרשאות; SLA שנמסר: מיידי. אין לעדכן שיוך ללא אימות פרטי הכרטיס או הפרופיל.","img":null}],"images":[]},{"num":"9","title":"סימון פריפייד שגוי אצלנו","items":[{"text":"הנציג בודק אם המנוי הוגדר בטעות כפריפייד. אם כן, מעביר למרת״מ להסרת סימון הפריפייד ולבדיקת התאמה לחבילה הנכונה. נציג קו ראשון אינו מבצע שינוי זה ללא הרשאה מפורשת. מבצע השינוי: מרת״מ; SLA שנמסר: מיידי.","img":null}],"images":[]},{"num":"10","title":"VoLTE והפצה","items":[{"text":"בדוק ששירות VoLTE פעיל במנוי ב־CRM. אם אינו פעיל, הנציג מפעיל בהתאם להרשאות ולתהליך המאושר; SLA שנמסר: מיידי. לבדיקת השירות במכשיר השתמש ב־O-43 — בדיקה והפעלת VoLTE במכשיר כאשר נדרש.","img":null},{"text":"אם קיים חשד לתקלת הפצה, העבר לבדיקה מול מרת״מ. מבצע: מרת״מ; SLA שנמסר: 30 דקות.","img":null}],"images":[]},{"num":"11","title":"הגדרות המכשיר","items":[{"text":"בדוק חסימת שיחות במכשיר, חסימת המספר הרלוונטי, וקו SIM/eSIM שאינו מופעל במכשיר. השתמש ב־O-42 — בדיקת חסימות והגדרות שיחה במכשיר. הטיפול מבוצע על ידי הנציג בהתאם לתפעול המתאים; SLA שנמסר: מיידי.","img":null},{"text":"לאחר תפעול במכשיר, שינוי ב־SIM או שינוי בסטטוס המנוי יש לבצע הפעלה מחדש של המכשיר ולבדוק שוב את קבלת השיחות, לפי הנחיית שחר.","img":null}],"images":[]},{"num":"12","title":"שלב 4 בדיקת חיוג ממנוי וויקום","items":[{"text":"בצע ניסיון חיוג למספר הלקוח ממנוי וויקום ותעד אם השיחה מתקבלת ומה נשמע בתחילתה.","img":null}],"images":[]},{"num":"13","title":"השיחה אינה מתקבלת","items":[{"text":"בדוק שהמנוי מאוקטב. אם אינו מאוקטב, השלם הפעלה בהתאם להרשאות ולתהליך המאושר. במקרה של eSIM בדוק ב־THALES את מצב סריקת והתקנת הפרופיל. ודא שהפרופיל הרלוונטי מופעל במכשיר ושיוכו תואם לבדיקה בשלב 3.","img":null},{"text":"ב־SIM פיזי בצע בדיקה בכרטיס במכשיר אחר, אם ניתן. בדיקת eSIM במכשיר אחר תבוצע רק בתהליך מאושר; אין למחוק או להנפיק פרופיל במסגרת ניסיון לא מאושר. תעד אם לא ניתן היה לבצע את הבדיקה.","img":null},{"text":"לאחר הטיפול והרענון בצע ניסיון חיוג חוזר ממנוי וויקום. אם אינו מתקבל, השלם את יתר הבדיקות הרלוונטיות במסמך. אם התקלה נשארת לאחריהן, עבור לשלב 6 למומחה תמיכה; אין להפעיל את ענף ה־NOC כאילו החיוג מוויקום תקין.","img":null},{"text":"השיחה מתקבלת","img":null},{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"14","title":"שלב 5 בדיקת חיוג ממפעיל חיצוני","items":[{"text":"לאחר שחיוג ממנוי וויקום תקין, בצע ניסיון חיוג ממנוי של מפעיל חיצוני, ובמידת האפשר מהמפעיל או מהמספר שביחס אליו דווחה התקלה. תעד מספר מחייג, מפעיל מקור, מספר יעד, תאריך ושעה מדויקים ומה נשמע בפועל.","img":null},{"text":"השיחה ממפעיל חיצוני אינה מתקבלת והניידות אצלנו תקינה","img":null},{"text":"לאחר אימות תקינות הניידות אצלנו ובדיקות הקו הרלוונטיות, העבר דרך ה־NOC בקשה לשליחת מייל לסלקום בנושא אי־קבלת שיחות ממפעילים אחרים. צרף את פרטי ניסיון החיוג ואת העובדה שחיוג ממנוי וויקום לאותו יעד התקבל. זהו ענף ההעברה שנמסר על ידי אבי למקרה זה.","img":null},{"text":"נוסח לתיעוד: ״בתאריך [תאריך], בשעה [שעה], בוצע ניסיון שיחה ממנוי [מפעיל מקור ומספר מחייג] למנוי וויקום [מספר יעד]. השיחה לא התקבלה. בחיוג נשמע [תיאור]. שיחה ממנוי וויקום לאותו יעד התקבלה. הניידות אצלנו נבדקה ונמצאה תקינה.״","img":null},{"text":"הניידות אינה תקינה או שלא ניתן לקבוע את תקינותה","img":null},{"text":"חזור לממצאי שלב 2 והשלם בירור וטיפול מול הגורם המתאים. אין לשלוח לסלקום תיאור שהניידות אצלנו תקינה כאשר הבדיקה לא הושלמה או אינה תקינה.","img":null},{"text":"השיחה מתקבלת","img":null},{"text":"ודא שגם התרחיש המקורי מול המספרים הבעייתיים תקין. אם התקלה נפתרה, תעד וסיים טיפול. אם הבדיקה הנוכחית תקינה אך התקלה המקורית עדיין משתחזרת, תעד את ההבדל והמשך לשלב 6 לאחר השלמת הבדיקות הרלוונטיות.","img":null}],"images":[]},{"num":"15","title":"שלב 6 המשך טיפול ותיעוד","items":[{"text":"אם הנציג ביצע את כל הבדיקות הרלוונטיות ועדיין קיימת תקלה, ואין ענף כשל מזוהה שמועבר למרת״מ, לבק אופיס, לחברה הקודמת או ל־NOC לפי המסמך, העבר למומחה תמיכה לפי E-40 — הסלמה למומחה בתקלת שיחות. אין להעביר פנייה ללא פירוט הבדיקות ותוצאותיהן.","img":null},{"text":"תעד: מועד הניוד; מועד תחילת התקלה; סטטוס והודעת ניידות וקוד כשל; תקינות שיחות יוצאות; אילו שיחות נכנסות מתקבלות; פרטי כל ניסיון חיוג ומפעיל המקור; ההכרזה או ההודעה שנשמעה; בדיקות הקו וה־SIMs Inventory; פעולות הנציג ומרת״מ; רענון והפעלה מחדש; בדיקות במכשיר; תוצאות הבדיקה החוזרת; וכל בדיקה שלא ניתן היה לבצע.","img":null},{"text":"אם הועבר הטיפול דרך ה־NOC, תעד את ההעברה ואת פרטי הניסיון; אם הועבר למרת״מ או לבק אופיס, תעד את הממצא והפנייה; ואם הועבר למומחה תמיכה, צרף את מלוא התיעוד לפי E-40. סיום פעולת הנציג או פתיחת פנייה אינם אישור שהתקלה נפתרה.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים חלקית","priority":"","gap":"סטטוס מנהלת: שחר","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-44 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-44.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-44  לא מתקבלות שיחות לאחר ניוד.docx"};
window.dynamicDocs['kbm_o40'] = {"id":"kbm_o40","topic":"O-40 · בדיקת סטטוס קו וחסימות שיחה במערכת","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקת סטטוס קו וחסימות שירות במערכת","tags":["שיחות"],"owner":"שחר","stages":[],"worlds":["tech"],"track":{"state":"קיים חלקית","priority":"","gap":"סטטוס מנהלת: שחר","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לבדוק האם קיימת במערכת הגדרה, חסימה או סטטוס שמונעים מהלקוח להוציא או לקבל שיחות.","img":null},{"text":"המסמך משמש להפניה מתוך מסלולי הטיפול בתקלות שיחה.","img":null}]},{"title":"שלב 1 - בדיקת סטטוס הקו","ordered":true,"steps":[{"text":"בדוק שהקו:","img":null},{"text":"פעיל.","img":null},{"text":"אינו מושהה.","img":null},{"text":"אינו חסום.","img":null},{"text":"אם נמצא שהקו אינו פעיל או קיימת מגבלה על השירות - טפל בהתאם להרשאות הנציג.","img":null}]},{"title":"שלב 2 - בדיקת חסימה כספית","ordered":true,"steps":[{"text":"בדוק האם קיימת חסימה הקשורה לתשלום או למצב החשבון ומשפיעה על שירותי השיחה.","img":null},{"text":"אם קיימת חסימה - טפל בהתאם לתהליך המאושר.","img":null},{"text":"להוסיף צילום מסך","img":null}]},{"title":"שלב 3 - בדיקת חסימות שיחה","ordered":true,"steps":[{"text":"בדוק האם קיימת חסימה על:","img":null},{"text":"שיחות יוצאות.","img":null},{"text":"שיחות נכנסות.","img":null},{"text":"התאם את הבדיקה לסוג התקלה שעליה דיווח הלקוח.","img":null},{"text":"אם נמצאה חסימה שאינה אמורה להיות קיימת - הסר אותה בהתאם להרשאות הנציג ובצע בדיקה חוזרת.","img":null},{"text":"לבדוק מול שחר אם קיים בCRM","img":null}]},{"title":"שלב 4 - בדיקת ניוד","ordered":true,"steps":[{"text":"אם בוצע לאחרונה ניוד של המספר:","img":null},{"text":"בדוק שהניוד הושלם.","img":null},{"text":"ודא שאין סטטוס בתהליך שעלול להשפיע על שירותי השיחה.","img":null}]},{"title":"שלב 5 – בדיקת SIM","ordered":true,"steps":[{"text":"בדוק:","img":null},{"text":"איזה SIM משויך לקו.","img":null},{"text":"האם מדובר ב-SIM פיזי או eSIM","img":null},{"text":"האם בוצעה לאחרונה החלפת SIM","img":null},{"text":"שה SIM המשויך במערכת תואם ל SIM שבו הלקוח משתמש בפועל.","img":null}]},{"title":"להוסיף צילום מסך","ordered":false,"steps":[]},{"title":"שלב 6 - בדיקת VoLTE בקו","ordered":true,"steps":[{"text":"בדוק ששירות VoLTE מאופשר בקו.","img":null},{"text":"אם השירות אינו פעיל - הפעל בהתאם להרשאות ולתהליך המאושר.","img":null},{"text":"להוסיף צילום מסך","img":null},{"text":"לביצוע הבדיקה וההפעלה בצד המכשיר:","img":null}]},{"title":"O-43 בדיקה והפעלת VoLTE במכשיר","ordered":false,"steps":[]},{"title":"לאחר תיקון במערכת","ordered":false,"steps":[{"text":"אם בוצע שינוי שמשפיע על שירותי הקו:","img":null},{"text":"בצע בדיקת שיחה בהתאם לתקלה.","img":null},{"text":"אם נדרש רענון לצורך קליטת השינוי - פעל בהתאם לתהליך הרענון המאושר.","img":null},{"text":"להוסיף צילום מסך – לינק חדש","img":null}]},{"title":"תוצאה","ordered":false,"steps":[{"text":"אם אותרה בעיה במערכת ותוקנה - חזור למסלול הטיפול ובדוק אם השירות חזר לפעול.","img":null},{"text":"אם כל הבדיקות תקינות - חזור למסלול הטיפול והמשך לבדיקות המכשיר.","img":null}]}]},"source":{"name":"O-40 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-40.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"אצל שחר O-40 - בדיקת סטטוס קו וחסימות שיחה במערכת.docx"};
window.dynamicDocs['kbm_o41'] = {"id":"kbm_o41","topic":"O-41 · בדיקת הפניית שיחות והגדרות שיחה במערכת","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקת הפניית שיחות והגדרות שיחה במערכת","tags":["שיחות"],"owner":"שחר","stages":[],"worlds":["tech"],"track":{"state":"קיים חלקית","priority":"","gap":"סטטוס מנהלת: שחר","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לבדוק האם קיימת במערכת הפניית שיחות או הגדרה שמשפיעה על קבלת שיחות אצל הלקוח.","img":null},{"text":"המסמך משמש בעיקר מתוך:","img":null}]},{"title":"R-42 לא מתקבלות שיחות","ordered":false,"steps":[]},{"title":"R-43 קושי בהוצאת או קבלת שיחות מול מספר מסוים או מספרים מסוימים","ordered":false,"steps":[]},{"title":"שלב 1 - בדיקת הפניית שיחות","ordered":true,"steps":[{"text":"בדוק האם מוגדרת על הקו הפניית שיחות.","img":null},{"text":"יש לבדוק במיוחד:","img":null},{"text":"האם קיימת הפניה באין מענה","img":null},{"text":"האם השיחות מופנות למספר אחר – עקוב אחרי","img":null},{"text":"האם המספר שאליו מוגדרת ההפניה תקין.","img":null}]},{"title":"נמצאה הפניה שאינה אמורה להיות פעילה","ordered":false,"steps":[{"text":"בטל או תקן אותה בהתאם להרשאות הנציג.","img":null},{"text":"לאחר השינוי בצע בדיקת שיחה נכנסת.","img":null}]},{"title":"לא קיימת הפניה או שההגדרה תקינה","ordered":false,"steps":[{"text":"חזור למסלול הטיפול והמשך לבדיקה הבאה.","img":null},{"text":"שחר להוסיף צילום מסך והנחיות איפה בודקים הפניות","img":null},{"text":"אילו סוגי הפניות קיימים במערכת?","img":null},{"text":"איך מבטלים","img":null},{"text":"אילו הפניות הנציג רשאי לבטל או לשנות בעצמו? אם בכלל","img":null}]},{"title":"שלב 2 - אימות לאחר שינוי","ordered":true,"steps":[{"text":"לאחר תיקון ההגדרה:","img":null},{"text":"חייג למספר הלקוח.","img":null},{"text":"ודא שהשיחה מגיעה למכשיר.","img":null},{"text":"בדוק שהשיחה אינה מועברת למספר אחר.","img":null}]},{"title":"השיחה מתקבלת","ordered":false,"steps":[{"text":"סיום הבדיקה וחזרה למסלול הטיפול.","img":null}]},{"title":"השיחה עדיין אינה מתקבלת","ordered":false,"steps":[{"text":"חזור למסלול הטיפול והמשך לשלבים הבאים.","img":null}]}]},"source":{"name":"O-41 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-41.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"אצל שחר O-41 - בדיקת הפניית שיחות והגדרות שיחה במערכת.docx"};
window.dynamicDocs['kbm_o42'] = {"id":"kbm_o42","topic":"O-42 · בדיקת חסימות והגדרות שיחה במכשיר","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקת חסימות והגדרות שיחה במכשיר","tags":["שיחות"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לבדוק האם קיימת במכשיר הגדרה או אפליקציה שמונעת קבלת שיחות או משפיעה על שיחות מול מספר מסוים.","img":null},{"text":"המסמך משמש בעיקר מתוך:","img":null}]},{"title":"R-42 לא מתקבלות שיחות","ordered":false,"steps":[]},{"title":"R-43 קושי בהוצאת או קבלת שיחות מול מספר מסוים או מספרים מסוימים","ordered":false,"steps":[]},{"title":"iPhone","ordered":false,"steps":[]},{"title":"בדיקת אנשי קשר חסומים","ordered":false,"steps":[{"text":"בגרסאות iOS עדכניות:","img":null},{"text":"הגדרות > יישומים > טלפון > אנשי קשר חסומים","img":null},{"text":"בדוק האם המספר מופיע ברשימה.","img":null},{"text":"אם כן:","img":null},{"text":"הסר את החסימה.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null},{"text":"ב iOS 26 ניתן לנהל אנשי קשר חסומים גם דרך:","img":null},{"text":"הגדרות < פרטיות ואבטחה < אנשי קשר חסומים","img":null}]},{"title":"בדיקת מצב ריכוז / \"נא לא להפריע\"","ordered":false,"steps":[{"text":"פתח את מרכז הבקרה.","img":null},{"text":"בדוק האם מצב ריכוז כלשהו פעיל, לדוגמה:","img":null},{"text":"נא לא להפריע","img":null},{"text":"שינה","img":null},{"text":"עבודה","img":null},{"text":"אם פעיל:","img":null},{"text":"כבה זמנית.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null}]},{"title":"בדיקת מתקשרים לא מוכרים","ordered":false,"steps":[{"text":"הגדרות < יישומים < טלפון","img":null},{"text":"בדוק את הגדרת הטיפול במתקשרים לא מוכרים.","img":null},{"text":"לצורך בדיקה, יש לוודא שמתקשרים שאינם שמורים אינם מוגדרים להשתקה.","img":null}]},{"title":"בדיקת אפליקציות זיהוי וחסימת שיחות","ordered":false,"steps":[{"text":"הגדרות < יישומים <טלפון < חסימת שיחות וזיהוי","img":null},{"text":"בדוק האם מופעלת אפליקציית זיהוי שיחות חיצונית.","img":null},{"text":"אם קיימת:","img":null},{"text":"השבת זמנית לצורך בדיקה.","img":null},{"text":"בצע שיחה נכנסת נוספת.","img":null}]},{"title":"Samsung Galaxy","ordered":false,"steps":[]},{"title":"בדיקת מספרים חסומים","ordered":false,"steps":[{"text":"טלפון > שלוש נקודות > הגדרות > חסימת מספרים","img":null},{"text":"בדוק:","img":null},{"text":"האם המספר הרלוונטי מופיע ברשימה.","img":null},{"text":"האם מופעלת חסימה של מספרים לא ידועים או פרטיים.","img":null},{"text":"אם נמצא:","img":null},{"text":"הסר את המספר מהרשימה או בטל זמנית את החסימה.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null}]},{"title":"בדיקת \"נא לא להפריע\"","ordered":false,"steps":[{"text":"הגדרות > התראות > נא לא להפריע","img":null},{"text":"או דרך לוח ההגדרות המהירות.","img":null},{"text":"בדוק האם המצב פעיל או מתוזמן.","img":null},{"text":"אם כן:","img":null},{"text":"כבה זמנית.","img":null},{"text":"בצע בדיקת שיחה.","img":null}]},{"title":"בדיקת זיהוי וחסימת ספאם","ordered":false,"steps":[{"text":"במכשירים שבהם האפשרות קיימת:","img":null},{"text":"טלפון > שלוש נקודות > הגדרות","img":null},{"text":"בדוק הגדרות חסימה וזיהוי שיחות ספאם.","img":null},{"text":"זמינות האפשרויות עשויה להשתנות לפי דגם, גרסת תוכנה ומפעיל.","img":null},{"text":"מקור: Samsung Support.","img":null}]},{"title":"Xiaomi / Redmi / POCO","ordered":false,"steps":[]},{"title":"בדיקת מספרים חסומים","ordered":false,"steps":[{"text":"טלפון > שלוש נקודות > הגדרות > מספרים חסומים","img":null},{"text":"בדוק:","img":null},{"text":"האם המספר מופיע ברשימת החסומים.","img":null},{"text":"האם האפשרות לחסימת מתקשרים לא מזוהים פעילה.","img":null},{"text":"אם כן:","img":null},{"text":"הסר את החסימה.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null}]},{"title":"בדיקת \"נא לא להפריע\"","ordered":false,"steps":[{"text":"הגדרות > צליל ורטט > נא לא להפריע","img":null},{"text":"בדוק:","img":null},{"text":"האם המצב פעיל.","img":null},{"text":"האם קיימת הפעלה מתוזמנת.","img":null},{"text":"אילו שיחות מותרות בזמן שהמצב פעיל.","img":null},{"text":"כבה זמנית ובצע בדיקת שיחה.","img":null}]},{"title":"בדיקת חסימת ספאם","ordered":false,"steps":[{"text":"טלפון > שלוש נקודות > הגדרות > זיהוי מתקשר וספאם","img":null},{"text":"בדוק האם מופעל סינון שיחות ספאם.","img":null},{"text":"לצורך בדיקה:","img":null},{"text":"בטל זמנית.","img":null},{"text":"בצע שיחה נכנסת.","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[]},{"title":"בדיקת מספר חסום","ordered":false,"steps":[{"text":"פתח את אפליקציית הטלפון.","img":null},{"text":"היכנס להגדרות הטלפון ובדוק את רשימת המספרים החסומים.","img":null},{"text":"אם המספר חסום:","img":null},{"text":"הסר אותו.","img":null},{"text":"בצע בדיקת שיחה.","img":null}]},{"title":"בדיקת \"נא לא להפריע\"","ordered":false,"steps":[{"text":"הגדרות > מצבים > נא לא להפריע","img":null},{"text":"בדוק תחת הגדרות האנשים אילו שיחות מורשות ואילו נחסמות.","img":null},{"text":"לצורך הבדיקה:","img":null},{"text":"כבה את המצב או אפשר שיחות.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null},{"text":"בדוק גם האם מוגדרת אפשרות המאפשרת שיחות חוזרות בלבד, מאחר שהגדרה זו יכולה לגרום להתנהגות שונה בין ניסיון ראשון לשני.","img":null},{"text":"מקור: Google Pixel Help.","img":null}]},{"title":"Huawei","ordered":false,"steps":[]},{"title":"בדיקת \"נא לא להפריע\"","ordered":false,"steps":[{"text":"הגדרות > צלילים ורטט > נא לא להפריע","img":null},{"text":"בדוק:","img":null},{"text":"האם המצב פעיל.","img":null},{"text":"האם קיימת הפעלה מתוזמנת.","img":null},{"text":"מי מורשה להתקשר בזמן שהמצב פעיל.","img":null},{"text":"האם מופעלת אפשרות לשיחות חוזרות.","img":null},{"text":"כבה זמנית ובצע בדיקת שיחה נכנסת.","img":null}]},{"title":"בדיקת חסימות מספרים","ordered":false,"steps":[{"text":"הנתיב המדויק משתנה בין גרסאות EMUI ומכשירים.","img":null},{"text":"יש לבדוק באפליקציית הטלפון את הגדרות החסימה או סינון השיחות.","img":null},{"text":"פער: אין באפשרותי לאשר כרגע נתיב אחיד ורשמי לכל דגמי Huawei.","img":null},{"text":"מקור: Huawei Support.","img":null}]},{"title":"OnePlus","ordered":false,"steps":[]},{"title":"בדיקת \"נא לא להפריע\"","ordered":false,"steps":[{"text":"בדוק האם מצב \"נא לא להפריע\" פעיל דרך ההגדרות או דרך לוח הקיצורים.","img":null},{"text":"בדוק גם אילו שיחות מורשות בזמן שהמצב פעיל.","img":null}]},{"title":"בדיקת חסימות מספרים","ordered":false,"steps":[{"text":"הנתיב משתנה בין גרסאות OxygenOS ובין גרסאות אפליקציית הטלפון.","img":null},{"text":"פער: אין באפשרותי לאשר נתיב אחיד ועדכני לכל דגמי OnePlus על בסיס מקור רשמי מספיק.","img":null}]},{"title":"OPPO / Realme","ordered":false,"steps":[]},{"title":"בדיקת \"נא לא להפריע\"","ordered":false,"steps":[{"text":"ב-Realme:","img":null},{"text":"הגדרות > צליל ורטט > נא לא להפריע","img":null},{"text":"בדוק:","img":null},{"text":"האם המצב פעיל.","img":null},{"text":"האם קיימת הפעלה מתוזמנת.","img":null},{"text":"אילו שיחות מורשות.","img":null},{"text":"כבה זמנית ובצע בדיקת שיחה.","img":null}]},{"title":"בדיקת מספרים חסומים","ordered":false,"steps":[{"text":"נתיבי החסימה משתנים לפי גרסת מערכת ואפליקציית הטלפון.","img":null},{"text":"פער: אין באפשרותי לאשר כרגע נתיב אחיד ורשמי לכל דגמי OPPO ו-Realme.","img":null},{"text":"מקור: Realme Support.","img":null}]},{"title":"אפליקציות צד שלישי","ordered":false,"steps":[{"text":"בכל סוגי המכשירים בדוק האם מותקנת אפליקציה לזיהוי או חסימת שיחות.","img":null},{"text":"לדוגמה:","img":null},{"text":"Truecaller","img":null},{"text":"CallApp","img":null},{"text":"אם קיימת אפליקציה כזו:","img":null},{"text":"השבת אותה זמנית.","img":null},{"text":"בצע בדיקת שיחה נכנסת.","img":null},{"text":"אם לאחר ההשבתה השיחה מתקבלת, התקלה קשורה ככל הנראה להגדרות האפליקציה.","img":null},{"text":"אין לבצע תפעול מתקדם בתוך אפליקציית צד שלישי במסגרת מסלול התמיכה.","img":null},{"text":"המשך הטיפול באפליקציה יתבצע על ידי הלקוח.","img":null}]},{"title":"סדר הבדיקה המומלץ","ordered":false,"steps":[{"text":"כדי לזהות את הבעיה במהירות:","img":null},{"text":"בדוק קודם אם המספר עצמו חסום.","img":null},{"text":"בדוק \"נא לא להפריע\" או מצב ריכוז.","img":null},{"text":"בדוק חסימה או השתקה של מתקשרים לא מזוהים.","img":null},{"text":"בדוק אפליקציות צד שלישי.","img":null},{"text":"לאחר כל שינוי בצע שיחה נכנסת ובדוק אם התקלה נפתרה.","img":null},{"text":"אין צורך לבצע כיבוי והדלקה של המכשיר במסגרת מסמך זה אלא אם מסלול הטיפול מפנה לכך בהמשך.","img":null}]}]},"source":{"name":"O-42 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-42.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-42 - בדיקת חסימות והגדרות שיחה במכשיר.docx"};
window.dynamicDocs['kbm_o43'] = {"id":"kbm_o43","topic":"O-43 · בדיקה והפעלת VoLTE במכשיר","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקה והפעלת VoLTE במכשיר","tags":["שיחות"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לבדוק שהמכשיר תומך בשיחות VoLTE, מוגדר לרשת מתאימה ושירות VoLTE פעיל במכשיר.","img":null},{"text":"המסמך משמש מתוך מסלולי הטיפול בתקלות שיחה.","img":null}]},{"title":"לפני שמתחילים","ordered":false,"steps":[{"text":"ודא במערכת ששירות VoLTE מאופשר בקו.","img":null},{"text":"אם השירות אינו פעיל בקו - יש לטפל תחילה בצד המערכת.","img":null}]},{"title":"שלב 1 - בדיקת סוג הרשת","ordered":true,"steps":[{"text":"בדוק שהמכשיר מוגדר לשימוש בדור 4 או 5.","img":null},{"text":"אין להשאיר את המכשיר נעול על דור 2 או 3.","img":null}]},{"title":"Samsung","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > חיבורים > רשתות תקשורת סלולרית > מצב רשת","img":null},{"text":"בחר אפשרות הכוללת דור 4 או 5.","img":null}]},{"title":"iPhone","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > סלולרי > אפשרויות נתונים סלולריים > קול ונתונים","img":null},{"text":"בחר דור 4 או 5 בהתאם לאפשרויות המכשיר.","img":null}]},{"title":"Xiaomi / Redmi / POCO","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > כרטיסי SIM ורשתות סלולריות > בחר את הקו > סוג רשת מועדף","img":null},{"text":"בחר אפשרות הכוללת דור 4 או 5.","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת ואינטרנט > SIM > סוג רשת מועדף","img":null},{"text":"בחר אפשרות הכוללת דור 4 או 5.","img":null}]},{"title":"OnePlus","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת סלולרית > בחר את ה-SIM > סוג רשת מועדף","img":null},{"text":"בחר אפשרות הכוללת דור 4 או 5.","img":null}]},{"title":"OPPO / Realme","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת סלולרית / כרטיס SIM ונתונים ניידים > בחר את ה-SIM > סוג רשת מועדף","img":null},{"text":"בחר אפשרות הכוללת דור 4 או 5.","img":null}]},{"title":"Huawei","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת סלולרית > נתונים ניידים > מצב רשת מועדף","img":null},{"text":"בחר אפשרות הכוללת דור 4.","img":null}]},{"title":"שלב 2 - בדיקת VoLTE במכשיר","ordered":true,"steps":[]},{"title":"Samsung","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > חיבורים > רשתות תקשורת סלולרית","img":null},{"text":"בדוק אם קיימת אפשרות \"שיחות VoLTE\" ושהיא פעילה.","img":null}]},{"title":"iPhone","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > סלולרי > אפשרויות נתונים סלולריים > קול ונתונים","img":null},{"text":"בדוק שהמכשיר מוגדר לדור 4 או 5.","img":null},{"text":"בדגמים ובגרסאות מסוימות אין מתג VoLTE נפרד והשירות מנוהל אוטומטית.","img":null}]},{"title":"Xiaomi / Redmi / POCO","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > כרטיסי SIM ורשתות סלולריות > בחר את הקו","img":null},{"text":"בדוק אם קיימת אפשרות \"שימוש ב-VoLTE\" או \"שיחות באמצעות 4G\" ושהיא פעילה.","img":null}]},{"title":"Google Pixel","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת ואינטרנט > SIM","img":null},{"text":"בדוק שהשימוש בדור 4 או 5 פעיל.","img":null},{"text":"בגרסאות מסוימות אין מתג VoLTE נפרד.","img":null}]},{"title":"OnePlus","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת סלולרית > בחר את ה-SIM","img":null},{"text":"בדוק אם קיימת אפשרות VoLTE או שיחות 4G ושהיא פעילה.","img":null}]},{"title":"OPPO / Realme","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת סלולרית > בחר את ה-SIM","img":null},{"text":"בדוק אם קיימת אפשרות VoLTE או שיחות 4G ושהיא פעילה.","img":null}]},{"title":"Huawei","ordered":false,"steps":[{"text":"היכנס אל:","img":null},{"text":"הגדרות > רשת סלולרית > נתונים ניידים","img":null},{"text":"בדוק אם קיימת אפשרות \"שיחות VoLTE\" ושהיא פעילה.","img":null}]},{"title":"אם אפשרות VoLTE אינה מופיעה","ordered":false,"steps":[{"text":"בדוק:","img":null}]},{"title":"שהמכשיר תומך ב-VoLTE. O-44 בדיקת תאימות מכשיר ל VoLTE","ordered":false,"steps":[{"text":"שהמכשיר מעודכן לגרסת תוכנה מתאימה.","img":null}]},{"title":"ששירות VoLTE פעיל בקו. O-40 בדיקת סטטוס קו וחסימות שיחה במערכת","ordered":false,"steps":[]},{"title":"לאחר שינוי הגדרה","ordered":false,"steps":[{"text":"אם בוצע שינוי שניתן לבדוק בלי לנתק את הלקוח - בצע בדיקת שיחה.","img":null},{"text":"אם נדרש רענון של המכשיר, חזור למסלול הטיפול ובצע את שלב הרענון רק לאחר השלמת יתר הבדיקות.","img":null}]},{"title":"תוצאה","ordered":false,"steps":[{"text":"אם VoLTE היה כבוי והופעל - חזור למסלול הטיפול ובצע בדיקת שיחה.","img":null},{"text":"אם ההגדרה תקינה והתקלה נמשכת - חזור למסלול הטיפול והמשך לשלב הבא.","img":null}]}]},"source":{"name":"O-43 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-43.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-43 -VoLTE בדיקה והפעלת וולטה במכשיר.docx"};
window.dynamicDocs['kbm_o44'] = {"id":"kbm_o44","topic":"O-44 · בדיקת תאימות מכשיר ל-VoLTE","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקת תאימות מכשיר ל-VoLTE","tags":["שיחות"],"owner":"שחר","stages":[],"worlds":["tech"],"track":{"state":"קיים חלקית","priority":"","gap":"סטטוס מנהלת: שחר - החזירה - לבדוק","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לוודא שהמכשיר שבו משתמש הלקוח נתמך ומאושר לשימוש ב-VoLTE ברשת החברה.","img":null},{"text":"אין להסתפק בכך שהיצרן מצהיר שהמכשיר תומך טכנולוגית ב-VoLTE. התמיכה בפועל תלויה גם בהתאמה לרשת הסלולרית.","img":null}]},{"title":"מתי משתמשים במסמך","ordered":false,"steps":[{"text":"הפנה למסמך כאשר במהלך טיפול בתקלת שיחות נדרש לוודא שהמכשיר תומך ב-VoLTE.","img":null},{"text":"המסמך משמש בעיקר יחד עם:","img":null}]},{"title":"O-43 בדיקה והפעלת VoLTE במכשיר","ordered":false,"steps":[]},{"title":"שלב 1 - זיהוי המכשיר","ordered":true,"steps":[{"text":"ברר את:","img":null},{"text":"יצרן המכשיר.","img":null},{"text":"דגם מדויק.","img":null},{"text":"אם נדרש - גרסת המכשיר או גרסת התוכנה.","img":null},{"text":"אין להסתמך על שם סדרת המכשירים בלבד.","img":null}]},{"title":"שלב 2 - בדיקה ברשימת המכשירים המאושרים","ordered":true,"steps":[{"text":"חפש את הדגם ברשימת המכשירים המאושרים ל-VoLTE ברשת החברה.","img":null}]},{"title":"שחר להוסיף את הרשימה","ordered":false,"steps":[]},{"title":"המכשיר מופיע ברשימה","ordered":false,"steps":[{"text":"המשך לבדיקה ולהפעלת השירות:","img":null}]},{"title":"O-43 בדיקה והפעלת VoLTE במכשיר","ordered":false,"steps":[]},{"title":"המכשיר אינו מופיע ברשימה","ordered":false,"steps":[{"text":"אין להניח שהוא נתמך רק משום שקיימת בו אפשרות VoLTE","img":null},{"text":"המשך בהתאם למדיניות התמיכה של החברה.","img":null}]},{"title":"לא ניתן לזהות בוודאות את הדגם","ordered":false,"steps":[{"text":"אין לקבוע שהמכשיר תומך.","img":null},{"text":"יש להשלים זיהוי מדויק לפני המשך הטיפול.","img":null}]},{"title":"תוצאה","ordered":false,"steps":[]},{"title":"המכשיר מאושר ותומך","ordered":false,"steps":[{"text":"חזור אל:","img":null}]},{"title":"O-43 בדיקה והפעלת VoLTE במכשיר","ordered":false,"steps":[{"text":"והמשך בבדיקת ההגדרות בפועל.","img":null}]},{"title":"המכשיר אינו מאושר או אינו נתמך","ordered":false,"steps":[{"text":"חזור למסלול הטיפול והמשך בהתאם לתהליך שנקבע למכשיר שאינו תומך ב-VoLTE.","img":null}]}]},"source":{"name":"O-44 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-44.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"אצל שחר  O-44 - בדיקת תאימות מכשיר וולטה-VoLTE.docx"};
window.dynamicDocs['kbm_e40'] = {"id":"kbm_e40","topic":"E-40 · הסלמה למומחה בתקלת שיחות","cat":"tech","docType":"pdf","kind":"E","desc":"הסלמה למומחה בתקלת שיחות","tags":["שיחות"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"when":["העבר למומחה כאשר:","בוצע מסלול הטיפול המתאים לתקלה.","בדיקות המערכת תקינות או שטופלו בהתאם.","בדיקות המכשיר הרלוונטיות הושלמו.","נבדקה התאמת המכשיר ל-VoLTE, כאשר רלוונטי.","נבדקה והופעלה הגדרת VoLTE, כאשר רלוונטי.","נבדקו SIM והחלפות אחרונות, כאשר רלוונטי.","בוצעו פעולות הרענון שנדרשו במסלול.","בוצע איפוס הגדרות רשת כאשר המסלול מחייב זאת.","התקלה עדיין קיימת."],"to":[],"conditions":["תעד:","סוג התקלה: נכנסות, יוצאות או שתיהן.","האם התקלה מול כל המספרים או מספרים מסוימים.","מועד תחילת התקלה.","האם התקלה קבועה או לסירוגין.","חסימות שנבדקו במערכת.","הפניית שיחות / עקוב אחרי, אם רלוונטי.","סטטוס ניוד, אם רלוונטי.","סוג SIM והאם בוצעה החלפה לאחרונה.","התאמת SIM למערכת, אם נבדקה.","סטטוס VoLTE בקו.","סטטוס VoLTE במכשיר.","תאימות המכשיר ל-VoLTE.","חסימות והגדרות שיחה במכשיר, אם רלוונטי.","האם בוצע מצב טיסה.","האם בוצע כיבוי והדלקה.","האם בוצע איפוס הגדרות רשת.","מה שומעים בפועל בחיוג.","תוצאת בדיקת השיחה האחרונה."],"document":[],"extra":[{"title":"מטרת המסמך","lines":["להגדיר מתי הנציג מסיים את תחום הטיפול שלו ומעביר את הפנייה למומחה, ומה חייב להיות מתועד לפני ההעברה."]},{"title":"אין להעביר למומחה לפני השלמת בדיקות הנציג","lines":["אין להסלים רק משום שהתקלה לא נפתרה בשלב הראשון.","יש להשלים תחילה את כל הבדיקות והפעולות שבתחום האחריות של הנציג."]}]},"source":{"name":"E-40 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/E-40.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"E-40 - הסלמה למומחה בתקלת שיחות.docx"};
window.dynamicDocs['kbm_s40'] = {"id":"kbm_s40","topic":"S-40 · המשך טיפול מומחה בתקלת שיחות","cat":"tech","docType":"pdf","kind":"S","desc":"המשך טיפול מומחה בתקלת שיחות","tags":["שיחות"],"owner":"אוריה","stages":[{"num":"1","title":"בהכנה","items":[{"text":"⚠ חסר: המסמך טרם הועבר לאפליקציה (במפה: טרם נכתב)","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"חסר","priority":"","gap":"סטטוס מנהלת: אוריה - חדש","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"draft","originName":"S-40 - מסלול טיפול מומחה בתקלת שיחות. להשלים.docx"};
window.dynamicDocs['kbm_m60'] = {"id":"kbm_m60","topic":"M-60 · אבחון מרכזי תקלות SMS בארץ","cat":"tech","docType":"pdf","kind":"M","desc":"אבחון מרכזי - תקלות מסר בארץ","tags":["סמס בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"intro":["מטרת המסמך","לזהות כיצד תקלה בהודעות SMS מתבטאת אצל הלקוח ולנתב אותו למסלול הטיפול המתאים.","המסמך אינו מיועד לביצוע דיבאג מלא.","מתי משתמשים במסמך","כאשר לקוח הנמצא בארץ מדווח שאינו מצליח לשלוח או לקבל הודעות SMS.","המסמך מיועד לתקלות SMS בלבד.","אם מדובר בהודעת מולטימדיה או בקובץ מצורף, אין להמשיך במסלול זה."],"questions":[{"title":"מה בדיוק לא עובד?","q":"\"האם אינך מצליח לשלוח הודעות, לקבל הודעות, או ששני הכיוונים אינם עובדים?\"","hint":"","answers":[{"text":"לא ניתן לשלוח הודעות","note":"","go":"q:1"},{"text":"לא ניתן לקבל הודעות","note":"","go":"q:1"},{"text":"לא ניתן גם לשלוח וגם לקבל הודעות","note":"","go":"q:1"}]},{"title":"האם מדובר בתקלה בקבלת קוד אימות בלבד?","q":"\"האם אינך מקבל הודעות SMS בכלל, או שהבעיה היא רק בקבלת קוד אימות מאפליקציה, אתר, בנק או שירות מסוים?\"","hint":"ההפרדה חלה גם לאחר ניוד: הודעות רגילות שאינן מתקבלות מכל המספרים מטופלות ב-R-61; הודעות רגילות שנפגעו מול מספרים מסוימים — ב-R-62; קודי אימות בלבד כש-SMS רגילים מתקבלים — ב-R-63. בכל מסלול יש לתעד ניוד ולהמשיך לפי הענף המתאים שבו.","answers":[{"text":"הבעיה רק בקבלת קוד אימות, והודעות SMS רגילות מתקבלות","note":"ודא שהלקוח מצליח לקבל הודעות SMS רגילות.","go":"item:kbm_r63"},{"text":"הלקוח אינו מקבל SMS בכלל","note":"","go":"q:2"},{"text":"התקלה היא בשליחת הודעות","note":"","go":"q:2"}]},{"title":"האם התקלה מול כל המספרים או מול מספר מסוים?","q":"\"האם זה קורה מול כל המספרים או רק מול מספר מסוים או כמה מספרים מסוימים?\"","hint":"","answers":[{"text":"מספר מסוים או מספרים מסוימים בלבד","note":"","go":"item:kbm_r62"},{"text":"כל המספרים","note":"","go":"q:3"}]},{"title":"ניתוב לפי סוג התקלה","q":"","hint":"במסגרת מסלול הטיפול יש לבדוק גם האם התקלה מצביעה על בעיה רחבה יותר בשירותי הקו. אם מתברר שגם שירותים נוספים אינם עובדים, יש לצאת מעולם ה-SMS ולעבור למסמך האבחון המתאים.","answers":[{"text":"לא ניתן לשלוח SMS לכל המספרים","note":"","go":"item:kbm_r60"},{"text":"לא ניתן לקבל SMS מכל המספרים","note":"","go":"item:kbm_r61"},{"text":"לא ניתן גם לשלוח וגם לקבל SMS","note":"התחל במסלול R-60. לאחר טיפול בשליחה בצע בדיקת שליחה ובדיקת קבלה של SMS רגיל; אין לסיים טיפול רק משום שהשליחה חזרה לעבוד. אם השליחה תקינה אך הקבלה עדיין אינה תקינה — המשך ל-R-61. סיים טיפול רק לאחר שאומת ששני הכיוונים תקינים.","go":"item:kbm_r60"}]}],"outro":["מידע שיש לאסוף לפני המעבר למסלול: מתי התחילה התקלה; האם היא קבועה או לסירוגין; האם מול כל המספרים או מול מספרים מסוימים; האם בוצעה לאחרונה החלפת מכשיר, החלפת SIM או מעבר ל-eSIM; האם בוצע ניוד, מתי הושלם והאם התקלה החלה לאחריו; האם הלקוח ביצע שינוי כלשהו במכשיר לפני הופעת התקלה.","אין לבצע בשלב זה טיפול טכני מלא. המידע נועד לתת למסלול הטיפול הבא את ההקשר הדרוש.","אם במהלך האבחון מתברר שהתקלה אינה תקלה מבודדת של SMS, יש לצאת מעולם ה-SMS ולהפנות לעולם הידע המתאים."]},"source":{"name":"M-60 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/M-60.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793865099049,"originName":"M-60 - אבחון מרכזי תקלות סמס בארץ.docx"};
window.dynamicDocs['kbm_r60'] = {"id":"kbm_r60","topic":"R-60 · לא ניתן לשלוח SMS בכלל","cat":"tech","docType":"pdf","kind":"R","desc":"לא ניתן לשלוח SMS בכלל","tags":["סמס בארץ"],"owner":"אבי חבה","stages":[{"num":"1","title":"מטרת המסמך","items":[{"text":"לטפל במקרה שבו לקוח בארץ אינו מצליח לשלוח הודעות SMS לכל המספרים.","img":null},{"text":"יש להשתמש במסלול זה לאחר שב M-60 נקבע כי התקלה אינה מוגבלת למספר מסוים.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - אימות התקלה","items":[{"text":"בקש מהלקוח לשלוח הודעת SMS רגילה למספר נוסף.","img":null},{"text":"יש לבצע את הבדיקה באמצעות הודעת טקסט בלבד.","img":null},{"text":"אם ההודעה נשלחת למספרים אחרים:","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"3","title":"R-62 תקלה בשליחה או קבלה מול מספר מסוים","items":[{"text":"אם לא ניתן לשלוח הודעות לכל המספרים:","img":null},{"text":"המשך לשלב 2.","img":null}],"images":[]},{"num":"4","title":"שלב 2 - בדיקת שירותי הקו","items":[{"text":"בדוק עם הלקוח:","img":null},{"text":"האם קיימת קליטה במכשיר.","img":null},{"text":"האם הלקוח מצליח להוציא שיחות.","img":null},{"text":"האם הלקוח מצליח לקבל שיחות.","img":null},{"text":"אם גם שירותי השיחות אינם עובדים:","img":null},{"text":"אין להמשיך בדיבאג SMS כתקלה מבודדת.","img":null},{"text":"עבור לעולם הידע המתאים של שיחות או קליטה בארץ.","img":null},{"text":"אם השיחות תקינות:","img":null},{"text":"המשך לשלב 3.","img":null}],"images":[]},{"num":"5","title":"שלב 3 - בדיקה במערכות החברה","items":[{"text":"בדוק במערכת:","img":null},{"text":"שהקו פעיל.","img":null},{"text":"שאין חסימה על שירותי הודעות.","img":null},{"text":"שאין מגבלה הקשורה לסטטוס הקו או לחוב.","img":null},{"text":"אם נמצאה חסימה או מגבלה:","img":null},{"text":"טפל בהתאם להרשאות הנציג ובצע ניסיון שליחה נוסף.","img":null},{"text":"אם לא נמצאה בעיה:","img":null},{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"6","title":"שלב 4 - בדיקת מרכז הודעות במכשיר","items":[{"text":"במכשירים שבהם ניתן לבדוק את מרכז ההודעות:","img":null},{"text":"בדוק שמרכז שירות ההודעות מוגדר בצורה תקינה.","img":null}],"images":[]},{"num":"7","title":"Samsung: Messages → Settings → More settings → Text messages → Message center → להזין +972510000030","items":[],"images":[]},{"num":"8","title":"Android כללי: לחייג *#*#4636#*#* → Phone Information → SMSC → להזין +972510000030 → Update לא זמין בכל הדגמים.","items":[],"images":[]},{"num":"9","title":"Xiaomi / Redmi / POCO: אפשר דרך הגדרות ה־SMS אם קיימת אפשרות SMS Center, או דרך: *#*#4636#*#* → Phone Information → SMSC → +972510000030 → Update","items":[],"images":[]},{"num":"10","title":"iPhone: בדרך כלל אין אפשרות לשנות SMSC ידנית דרך המכשיר. ההגדרה מנוהלת דרך הגדרות המפעיל / Carrier Settings.","items":[{"text":"במכשיר עם Dual SIM, חשוב לוודא שמעדכנים את ה־SIM הרלוונטי.","img":null},{"text":"יש לבדוק בCRM ששליחת סמס פתוחה","img":null},{"text":"במכשיר עם שני קווים, ודא שנבחר קו wecom לפני בדיקה או עדכון של מרכז ההודעות. אם תפריט השירות אינו נפתח או שלא ניתן לעדכן את הערך, אין לחזור שוב ושוב על הפעולה","img":null},{"text":"אם מרכז ההודעות תקין או שהבדיקה אינה זמינה במכשיר:","img":null},{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"11","title":"שלב 5 - איפוס הגדרות רשת","items":[{"text":"בצע:","img":null}],"images":[]},{"num":"12","title":"O-13 איפוס הגדרות רשת","items":[{"text":"לאחר האיפוס בצע ניסיון נוסף לשליחת SMS.","img":null},{"text":"אם התקלה נפתרה:","img":null},{"text":"סיים טיפול.","img":null},{"text":"אם התקלה נמשכת:","img":null},{"text":"המשך לשלב7 - העברת טיפול למומחה .","img":null}],"images":[]},{"num":"13","title":"שלב 7 - הסלמה למומחה","items":[{"text":"אם בוצעו כל הבדיקות במסלול והלקוח עדיין אינו מצליח לשלוח SMS:","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"14","title":"E-60 הסלמה למומחה - תקלות SMS בארץ","items":[{"text":"אין להעביר ישירות להנדסה.","img":null}],"images":[]},{"num":"15","title":"תוצאת המסלול","items":[{"text":"בסיום הטיפול יש להגיע לאחת מהתוצאות הבאות:","img":null},{"text":"התקלה נפתרה.","img":null},{"text":"התקלה התבררה כתקלה מול מספר מסוים - מעבר ל R-62","img":null},{"text":"התקלה קשורה לשירות אחר בקו - מעבר לעולם הידע המתאים.","img":null},{"text":"נמצא חשד לתקלה במכשיר.","img":null},{"text":"התקלה נמשכת לאחר השלמת הדיבאג - מעבר ל E-60","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים חלקית","priority":"","gap":"סטטוס מנהלת: אבי חבה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-60 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-60.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-60 - לא ניתן לשלוח  סמס בכלל.docx"};
window.dynamicDocs['kbm_r61'] = {"id":"kbm_r61","topic":"R-61 · לא ניתן לקבל SMS בכלל","cat":"tech","docType":"pdf","kind":"R","desc":"לא ניתן לקבל SMS בכלל","tags":["סמס בארץ"],"owner":"אבי חבה","stages":[{"num":"1","title":"מטרת המסמך","items":[{"text":"לטפל במקרה שבו לקוח בארץ אינו מצליח לקבל הודעות SMS רגילות מכל המספרים, לרבות כאשר התקלה החלה לאחר ניוד. אם גם SMS רגילים וגם קודי אימות אינם מתקבלים, מתחילים במסלול זה.","img":null},{"text":"יש להשתמש במסלול זה לאחר שב M-60 נקבע כי מדובר בתקלה כללית בקבלת SMS ולא בתקלה מול מספר מסוים או בקבלת קוד אימות בלבד.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - אימות התקלה","items":[{"text":"שאל:","img":null},{"text":"\"האם אינך מקבל הודעות מכל המספרים, או רק ממספר מסוים או משירות מסוים?\"","img":null},{"text":"אם התקלה מוגבלת לקודי אימות ו־SMS רגילים מתקבלים:","img":null},{"text":"אין לבצע את מסלול הקבלה הכללי. עבור ל־R-63 - לא מתקבלות הודעות OTP, כולל במקרה של ניוד.","img":null},{"text":"אם התקלה בהודעות רגילות מול מספר מסוים או מספרים מסוימים בלבד:","img":null},{"text":"עבור ל־R-62 - תקלה בשליחה או קבלה מול מספר מסוים. אם התקלה החלה לאחר ניוד, תעד זאת והמשך בענף הניוד שבמסמך זה.","img":null},{"text":"אם הלקוח אינו מקבל SMS רגילים מכל המספרים:","img":null},{"text":"המשך לשלב 2, גם אם התקלה החלה לאחר ניוד.","img":null},{"text":"ענף ניוד - הודעות רגילות","img":null},{"text":"ברר האם בוצע ניוד, מתי הושלם והאם התקלה החלה לאחריו. תעד אם ההודעות אינן מתקבלות מכל המספרים או רק ממספרים המשויכים למפעיל מסוים. במקרה האחרון עבור ל־R-62; בתקלה כללית המשך לשלב 2. אין להשתמש כאן בענף ההסלמה של OTP.","img":null},{"text":"אם לאחר טיפול חזרו הודעות רגילות להתקבל אך קודי האימות עדיין אינם מתקבלים, עבור ל־R-63.","img":null}],"images":[]},{"num":"3","title":"שלב 2 - בדיקת שירותי הקו","items":[{"text":"בדוק:","img":null},{"text":"האם קיימת קליטה במכשיר.","img":null},{"text":"האם הלקוח מצליח להוציא שיחות.","img":null},{"text":"האם הלקוח מצליח לקבל שיחות.","img":null},{"text":"אם גם שירותי השיחות אינם עובדים:","img":null},{"text":"אין להמשיך בדיבאג SMS כתקלה מבודדת.","img":null},{"text":"עבור לעולם הידע המתאים של שיחות או קליטה בארץ.","img":null},{"text":"אם שירותי השיחות תקינים:","img":null},{"text":"המשך לשלב 3.","img":null}],"images":[]},{"num":"4","title":"שלב 3 - בדיקה במערכות החברה","items":[{"text":"בדוק:","img":null},{"text":"שהקו פעיל.","img":null},{"text":"שאין חסימה על שירותי הודעות.","img":null},{"text":"שאין מגבלה הקשורה לסטטוס הקו.","img":null},{"text":"אם נמצאה חסימה או מגבלה:","img":null},{"text":"טפל בהתאם להרשאות הנציג ובצע בדיקת קבלת SMS נוספת.","img":null},{"text":"אם לא נמצאה בעיה:","img":null},{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"5","title":"יש לבדוק בCRM בפתח כלקוח האם ניהול הקו – במסרונים פתוח לקבלת הודעות","items":[],"images":[]},{"num":"6","title":"שלב 4 - בדיקת חסימות וסינון במכשיר","items":[],"images":[]},{"num":"7","title":"מכשירי iPhone","items":[{"text":"בדוק אם ההודעה הגיעה למסנן שולחים לא מוכרים:","img":null},{"text":"הודעות > מסננים > שולחים לא מוכרים.","img":null},{"text":"בגרסאות החדשות ניתן גם לבדוק:","img":null},{"text":"הגדרות > יישומים > הודעות > שולחים לא מוכרים.","img":null},{"text":"אם השולח מופיע שם, ההודעה התקבלה למכשיר אך סוננה מתצוגת השיחות הראשית.","img":null},{"text":"בדוק גם אם המספר שממנו מנסים לשלוח ללקוח חסום במכשיר.","img":null},{"text":"אם נמצאה חסימה:","img":null},{"text":"הסר אותה ובצע ניסיון קבלה נוסף.","img":null},{"text":"אם לא נמצאה בעיה:","img":null},{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"8","title":"מכשירי Android עם Google Messages","items":[{"text":"פתח:","img":null},{"text":"Google Messages > תמונת פרופיל > Spam & blocked.","img":null},{"text":"בדוק אם השולח מופיע ברשימת החסומים או בתיקיית הספאם.","img":null},{"text":"אם נמצא:","img":null},{"text":"בחר את השיחה ובצע Unblock","img":null},{"text":"Google מציינת ששולח שנחסם או סומן כספאם מועבר לתיקיית \"Spam & blocked\"","img":null},{"text":"אם לא נמצאה בעיה:","img":null},{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"9","title":"מכשירי Samsung עם Samsung Messages","items":[{"text":"פתח:","img":null},{"text":"הודעות > שלוש נקודות > הגדרות > חסימת מספרים וספאם > מספרים חסומים.","img":null},{"text":"בדוק אם המספר שממנו מנסים לשלוח ללקוח מופיע ברשימה.","img":null},{"text":"אם נמצא:","img":null},{"text":"הסר את החסימה ובצע ניסיון קבלה נוסף.","img":null},{"text":"אם לא נמצאה בעיה:","img":null},{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"10","title":"שלב 5 - בדיקה לאחר אתחול מכשיר","items":[{"text":"בצע כיבוי והדלקה של המכשיר.","img":null},{"text":"לאחר שהמכשיר חזר לרשת:","img":null},{"text":"בקש לבצע ניסיון נוסף של שליחת SMS ללקוח.","img":null},{"text":"אם ההודעה התקבלה:","img":null},{"text":"סיים טיפול.","img":null},{"text":"אם התקלה נמשכת:","img":null},{"text":"המשך לשלב 6.","img":null}],"images":[]},{"num":"11","title":"שלב 6 - איפוס הגדרות רשת","items":[{"text":"בצע:","img":null}],"images":[]},{"num":"12","title":"O-13 איפוס הגדרות רשת","items":[{"text":"לאחר האיפוס:","img":null},{"text":"המתן לרישום מחדש לרשת.","img":null},{"text":"בצע ניסיון נוסף של קבלת SMS.","img":null},{"text":"אם התקלה נפתרה:","img":null},{"text":"סיים טיפול.","img":null},{"text":"אם התקלה נמשכת: יש להעביר למומחה","img":null}],"images":[]},{"num":"13","title":"שלב 7 - הסלמה למומחה","items":[{"text":"אם בוצעו כל הבדיקות במסלול והלקוח עדיין אינו מקבל SMS:","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"14","title":"E-60 הסלמה למומחה - תקלות SMS בארץ","items":[{"text":"אין להעביר ישירות להנדסה.","img":null}],"images":[]},{"num":"15","title":"תוצאת המסלול","items":[{"text":"בסיום הטיפול יש להגיע לאחת מהתוצאות הבאות:","img":null},{"text":"התקלה נפתרה.","img":null},{"text":"התקלה מול מספר מסוים בלבד - מעבר ל-R-62.","img":null},{"text":"התקלה היא רק בקבלת OTP - מעבר ל-R-63.","img":null},{"text":"התקלה קשורה לשירות אחר בקו - מעבר לעולם הידע המתאים.","img":null},{"text":"התקלה קשורה למכשיר.","img":null},{"text":"התקלה נשארת עם הקו לאחר השלמת הדיבאג - מעבר ל-E-60.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים חלקית","priority":"","gap":"סטטוס מנהלת: אבי חבה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-61 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-61.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-61 - לא ניתן לקבל סמס בכלל.docx"};
window.dynamicDocs['kbm_r62'] = {"id":"kbm_r62","topic":"R-62 · תקלה בשליחה או קבלה מול מספר מסוים","cat":"tech","docType":"pdf","kind":"R","desc":"תקלה בשליחה או קבלה מול מספר מסוים","tags":["סמס בארץ"],"owner":"","stages":[{"num":"1","title":"מטרת המסמך","items":[{"text":"לטפל בתקלה בשליחה או בקבלה של הודעות SMS רגילות מול מספר מסוים או מספרים מסוימים, כאשר השירות עובד מול מספרים אחרים. המסלול אינו מיועד לתקלה המוגבלת לקודי אימות OTP.","img":null},{"text":"יש להשתמש במסלול זה לאחר שב M-60 נקבע כי התקלה אינה כללית.","img":null},{"text":"אם SMS רגילים מתקבלים ורק קוד אימות אינו מתקבל משירות אחד או יותר, עבור ל־R-63 - לא מתקבלות הודעות OTP. אם גם הודעות רגילות אינן מתקבלות, אבחן את התקלה בהודעות הרגילות לפי תוצאות הבדיקה בשלבים הבאים.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - הבנת כיוון התקלה","items":[{"text":"שאל:","img":null},{"text":"\"האם אינך מצליח לשלוח הודעה למספר הזה, אינך מצליח לקבל ממנו הודעה, או ששני הכיוונים אינם עובדים?\"","img":null},{"text":"יש לתעד:","img":null},{"text":"כיוון התקלה.","img":null},{"text":"המספר או המספרים הרלוונטיים.","img":null},{"text":"האם התקלה קבועה או לסירוגין.","img":null},{"text":"ענף ניוד - הודעות רגילות מול מספרים מסוימים","img":null},{"text":"ברר האם בוצע ניוד, מתי הושלם והאם התקלה החלה לאחריו. תעד אם המספרים הבעייתיים משויכים למפעיל מסוים, ככל שהמידע ידוע. המשך בשלבי מסמך זה; אם נדרשת הסלמה בשלב 8, צרף את פרטי הניוד. אין להחיל כאן את ענף OTP לאחר ניוד.","img":null}],"images":[]},{"num":"3","title":"שלב 2 - אימות שהשירות הכללי תקין","items":[{"text":"בקש מהלקוח לבצע בדיקה מול מספר אחר.","img":null}],"images":[]},{"num":"4","title":"SMS מול מספר אחר עובד","items":[{"text":"המשך לשלב 3.","img":null}],"images":[]},{"num":"5","title":"SMS אינו עובד גם מול מספרים אחרים","items":[{"text":"אין להמשיך במסלול זה.","img":null},{"text":"אם הבעיה בשליחה:","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"6","title":"R-60 לא ניתן לשלוח SMS בכלל","items":[{"text":"אם הבעיה בקבלה:","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"7","title":"R-61 לא ניתן לקבל SMS בכלל","items":[{"text":"אם גם השליחה וגם הקבלה אינן עובדות מול מספרים אחרים, התחל ב־R-60. לאחר הטיפול בדוק את שני הכיוונים; אם הקבלה עדיין אינה תקינה, המשך ל־R-61.","img":null}],"images":[]},{"num":"8","title":"שלב 3 - בדיקת המספר","items":[{"text":"ודא:","img":null},{"text":"שהמספר הוזן בצורה תקינה.","img":null},{"text":"שאין טעות בספרות.","img":null},{"text":"שמדובר במספר שאליו ניתן לשלוח SMS רגיל.","img":null},{"text":"אם מדובר במספר בינלאומי או במספר שירות מיוחד, יש לזהות זאת לפני המשך הטיפול.","img":null},{"text":"אם המספר תקין:","img":null},{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"9","title":"שלב 4 - בדיקת חסימה או סינון במכשיר","items":[{"text":"אם התקלה היא בקבלת SMS מהמספר:","img":null},{"text":"בדוק האם המספר חסום או שההודעה מסוננת.","img":null}],"images":[]},{"num":"10","title":"iPhone","items":[{"text":"בדוק:","img":null},{"text":"האם המספר מופיע ברשימת המספרים החסומים.","img":null},{"text":"האם ההודעה נמצאת תחת \"שולחים לא מוכרים\".","img":null},{"text":"אם נמצאה חסימה:","img":null},{"text":"הסר את החסימה ובצע ניסיון נוסף.","img":null},{"text":"אם ההודעה נמצאה תחת \"שולחים לא מוכרים\":","img":null},{"text":"ההודעה התקבלה למכשיר ואין מדובר בכשל בקבלת SMS ברשת.","img":null}],"images":[]},{"num":"11","title":"Android","items":[{"text":"בדוק באפליקציית ההודעות:","img":null},{"text":"מספרים חסומים.","img":null},{"text":"תיקיית \"ספאם וחסומים\".","img":null},{"text":"סינון הודעות ספאם.","img":null},{"text":"אם נמצאה ההודעה בתיקיית ספאם:","img":null},{"text":"ההודעה התקבלה למכשיר.","img":null},{"text":"יש להסיר את הסינון או לסמן את השולח כתקין ולבצע בדיקה נוספת.","img":null}],"images":[]},{"num":"12","title":"Samsung Messages","items":[{"text":"בדוק:","img":null},{"text":"הודעות > הגדרות > חסימת מספרים וספאם.","img":null},{"text":"בדוק גם את תיקיית הודעות הספאם אם קיימת.","img":null},{"text":"אם לא נמצאה חסימה או הודעה מסוננת:","img":null},{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"13","title":"שלב 5 - בדיקה מול הצד השני","items":[{"text":"אם ניתן, בקש מהצד השני לבצע ניסיון נוסף של שליחה או קבלה.","img":null},{"text":"ברר:","img":null},{"text":"האם הצד השני מצליח לשלוח SMS למספרים אחרים.","img":null},{"text":"האם הצד השני מצליח לקבל SMS ממספרים אחרים.","img":null},{"text":"האם התקלה קיימת רק מול לקוח wecom.","img":null}],"images":[]},{"num":"14","title":"הצד השני חווה תקלה גם מול מספרים נוספים","items":[{"text":"ייתכן שמקור התקלה בצד השני.","img":null},{"text":"אין לקבוע שמדובר בתקלה בקו של לקוח wecom ללא בדיקה נוספת.","img":null}],"images":[]},{"num":"15","title":"שני הצדדים עובדים תקין מול מספרים אחרים","items":[{"text":"והתקלה קיימת רק ביניהם:","img":null},{"text":"המשך לשלב 6.","img":null}],"images":[]},{"num":"16","title":"שלב 6 - איסוף פרטי האירוע","items":[{"text":"יש לאסוף:","img":null},{"text":"מספר השולח.","img":null},{"text":"מספר המקבל.","img":null},{"text":"כיוון התקלה.","img":null},{"text":"תאריך ושעה מדויקים ככל האפשר של ניסיון אחרון.","img":null},{"text":"האם התקבלה הודעת שגיאה.","img":null},{"text":"נוסח הודעת השגיאה, אם קיימת.","img":null},{"text":"האם התקלה קבועה או לסירוגין.","img":null},{"text":"האם בעבר היה ניתן לשלוח ולקבל SMS בין המספרים.","img":null},{"text":"האם בוצע ניוד ומועד השלמתו, אם ידוע; האם התקלה החלה לאחריו והאם זוהה מפעיל משותף למספרים הבעייתיים.","img":null},{"text":"אין לבצע איפוס הגדרות רשת או החלפת SIM כברירת מחדל כאשר SMS עובד מול מספרים אחרים.","img":null}],"images":[]},{"num":"17","title":"שלב 7 - ניסיון נוסף לאחר אתחול","items":[{"text":"אם לא בוצע במהלך השיחה:","img":null},{"text":"בצע כיבוי והדלקה של המכשיר.","img":null},{"text":"לאחר שהמכשיר חזר לרשת:","img":null},{"text":"בצע ניסיון SMS נוסף מול המספר הרלוונטי.","img":null},{"text":"אם התקלה נפתרה:","img":null},{"text":"סיים טיפול.","img":null},{"text":"אם התקלה נמשכת:","img":null},{"text":"המשך לשלב 8.","img":null}],"images":[]},{"num":"18","title":"שלב 8 - הסלמה למומחה","items":[{"text":"אם:","img":null},{"text":"השירות עובד מול מספרים אחרים.","img":null},{"text":"המספר תקין.","img":null},{"text":"לא קיימת חסימה במכשיר.","img":null},{"text":"ההודעה אינה נמצאת בספאם או בסינון.","img":null},{"text":"התקלה משתחזרת רק מול המספר או המספרים המסוימים.","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"19","title":"E-60 הסלמה למומחה - תקלות SMS בארץ","items":[{"text":"יש להעביר בהסלמה את כל פרטי האירוע שנאספו.","img":null},{"text":"אין להעביר ישירות להנדסה.","img":null}],"images":[]},{"num":"20","title":"תוצאת המסלול","items":[{"text":"בסיום המסלול יש להגיע לאחת מהתוצאות הבאות:","img":null},{"text":"נמצאה טעות במספר והתקלה נפתרה.","img":null},{"text":"נמצאה חסימה במכשיר והתקלה נפתרה.","img":null},{"text":"ההודעה נמצאה בתיקיית ספאם או בסינון.","img":null},{"text":"התברר שמדובר בתקלה כללית - מעבר ל R-60 או R-61","img":null},{"text":"נמצא חשד שהתקלה בצד השני.","img":null},{"text":"התקלה קיימת רק בין המספרים המסוימים - מעבר ל E-60","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-62 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-62.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-62 - תקלה בשליחה או קבלה מול מספר מסוים.docx"};
window.dynamicDocs['kbm_r63'] = {"id":"kbm_r63","topic":"R-63 · לא מתקבלות הודעות OTP","cat":"tech","docType":"pdf","kind":"R","desc":"הודעות OTP אינן מתקבלות","tags":["סמס בארץ"],"owner":"אבי חבה","stages":[{"num":"1","title":"מטרת המסמך","items":[{"text":"לטפל במקרה שבו לקוח בארץ מקבל הודעות SMS רגילות, אך אינו מקבל קוד אימות משירות, אתר, אפליקציה, בנק או ספק מסוים.","img":null},{"text":"יש להשתמש במסלול זה רק לאחר שב-M-60 אומת כי קבלת SMS רגילה תקינה.","img":null}],"images":[]},{"num":"2","title":"שלב 1 - אימות שהתקלה היא ב OTP בלבד","items":[{"text":"שאל:","img":null},{"text":"\"האם אתה מקבל הודעות SMS רגילות מאנשים אחרים?\"","img":null}],"images":[]},{"num":"3","title":"הלקוח אינו מקבל גם SMS רגילים","items":[{"text":"אין להמשיך במסלול זה.","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"4","title":"R-61 לא ניתן לקבל SMS בכלל","items":[],"images":[]},{"num":"5","title":"SMS רגילים מתקבלים","items":[{"text":"המשך לשלב 2.","img":null}],"images":[]},{"num":"6","title":"שלב 2 - זיהוי מקור ההודעה","items":[{"text":"ברר:","img":null},{"text":"מאיזה שירות אמור להגיע הקוד.","img":null},{"text":"האם מדובר בבנק, אפליקציה, אתר או שירות אחר.","img":null},{"text":"האם התקלה קיימת מול שירות אחד בלבד או מול מספר שירותים.","img":null},{"text":"האם בעבר התקבלו קודים מאותו שירות.","img":null},{"text":"ברר האם מדובר בלקוח חדש, האם בוצע ניוד ומתי הושלם. תעד את המידע.","img":null}],"images":[]},{"num":"7","title":"ענף ניוד - קודי אימות בלבד","items":[{"text":"אם המנוי התנייד – ברר האם קודי אימות מאותו שירות התקבלו לפני הניוד ואינם מתקבלים בניסיונות שבוצעו לאחריו, בעוד שהודעות SMS רגילות מתקבלות.","img":null},{"text":"SMS רגילים מתקבלים אך קודי אימות אינם מתקבלים משירות אחד או יותר, העבר פנייה מסוג \"תקלת SMS\" למומחה בהתאם להוראת הניוד הקיימת.","img":null},{"text":"תעד בפנייה: מספר המנוי, שם השירות או השירותים שמהם לא מתקבל הקוד, תאריך ושעה של ניסיון הקבלה, מועד השלמת הניוד אם ידוע, והאימות ש־SMS רגילים מתקבלים.","img":null},{"text":"לאחר ההעברה המשך הטיפול בענף זה הוא אצל המומחה.","img":null}],"images":[]},{"num":"8","title":"אם ענף הניוד אינו חל","items":[{"text":"התקלה מול שירות OTP אחד בלבד: המשך לשלב 3.","img":null},{"text":"התקלה מול מספר שירותי OTP: המשך לשלב 4.","img":null},{"text":"עצם היות הלקוח חדש ללא ניוד אינה מפעילה את חריג הניוד; המשך לפי מספר שירותי ה־OTP שבהם התקלה קיימת.","img":null}],"images":[]},{"num":"9","title":"שלב 3 - בדיקה מול השירות המסוים","items":[{"text":"בקש מהלקוח לוודא:","img":null},{"text":"שמספר הטלפון המעודכן בשירות נכון.","img":null},{"text":"שנבחרה מדינת ישראל וקידומת המספר הוזנה בצורה תקינה, אם נדרש.","img":null},{"text":"שהקוד נשלח באמצעות SMS ולא בערוץ אחר.","img":null},{"text":"שלא בוצעו ניסיונות רבים ברצף שיכולים לגרום להגבלת שליחה זמנית מצד השירות.","img":null},{"text":"בקש מהלקוח לבצע ניסיון שליחה נוסף אחד בלבד.","img":null},{"text":"אם הקוד התקבל:","img":null},{"text":"סיים טיפול.","img":null},{"text":"אם הקוד עדיין אינו מתקבל:","img":null},{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"10","title":"שלב 4 - בדיקת ספאם, חסימות וסינון","items":[{"text":"בדוק במכשיר:","img":null},{"text":"האם ההודעה נמצאת בתיקיית ספאם.","img":null},{"text":"האם השולח חסום.","img":null},{"text":"האם מופעל סינון שולחים לא מוכרים.","img":null},{"text":"האם אפליקציית ההודעות מסננת הודעות באופן אוטומטי.","img":null}],"images":[]},{"num":"11","title":"ההודעה נמצאה בספאם או בסינון","items":[{"text":"ההודעה התקבלה למכשיר.","img":null},{"text":"יש להסיר את החסימה או הסינון בהתאם ולהנחות את הלקוח לבצע ניסיון נוסף.","img":null}],"images":[]},{"num":"12","title":"ההודעה אינה נמצאת במכשיר","items":[{"text":"המשך לשלב 5.","img":null}],"images":[]},{"num":"13","title":"שלב 5 - בדיקת זמן וניסיונות שליחה","items":[{"text":"ברר:","img":null},{"text":"מתי בוצע ניסיון השליחה האחרון.","img":null},{"text":"האם הלקוח ביצע מספר ניסיונות ברצף.","img":null},{"text":"האם התקבל קוד באיחור.","img":null},{"text":"אם מתקבלות מספר הודעות באיחור:","img":null},{"text":"יש להתייחס לכך כתקלה של עיכוב בקבלת OTP ולא כאי קבלה מוחלטת.","img":null},{"text":"יש לתעד את זמני השליחה והקבלה ככל שניתן.","img":null},{"text":"אם לא התקבלה הודעה כלל:","img":null},{"text":"המשך לשלב 6.","img":null}],"images":[]},{"num":"14","title":"שלב 6 - בדיקה במערכות החברה","items":[{"text":"בדוק:","img":null},{"text":"שהקו פעיל.","img":null},{"text":"שאין חסימה על שירותי SMS.","img":null},{"text":"שאין מגבלה במנוי שיכולה להשפיע על קבלת הודעות.","img":null},{"text":"אם נמצאה חסימה:","img":null},{"text":"טפל בהתאם להרשאות הנציג ובצע ניסיון נוסף.","img":null},{"text":"אם לא נמצאה בעיה:","img":null},{"text":"המשך לשלב 7.","img":null}],"images":[]},{"num":"15","title":"שלב 7 - אתחול המכשיר ובדיקה חוזרת","items":[{"text":"בצע כיבוי והדלקה של המכשיר.","img":null},{"text":"לאחר שהמכשיר חזר לרשת:","img":null},{"text":"בקש לשלוח קוד חדש אחד.","img":null},{"text":"אם הקוד התקבל:","img":null},{"text":"סיים טיפול.","img":null},{"text":"אם הקוד עדיין אינו מתקבל:","img":null},{"text":"המשך לשלב 8.","img":null}],"images":[]},{"num":"16","title":"שלב 8 - איסוף פרטי האירוע","items":[{"text":"יש לאסוף:","img":null},{"text":"מספר המנוי.","img":null},{"text":"שם השירות שממנו אמור להגיע הקוד.","img":null},{"text":"תאריך ושעה מדויקים של ניסיון השליחה.","img":null},{"text":"האם התקלה קיימת מול שירות אחד או מספר שירותים.","img":null},{"text":"האם SMS רגילים מתקבלים.","img":null},{"text":"האם התקבלו בעבר הודעות מאותו שירות.","img":null},{"text":"האם התקבל קוד באיחור.","img":null},{"text":"צילום מסך של הודעת האישור או השגיאה בשירות, אם קיימת ואפשרית.","img":null},{"text":"אין לבקש מהלקוח למסור את קוד האימות עצמו.","img":null}],"images":[]},{"num":"17","title":"שלב 9 - הסלמה למומחה","items":[{"text":"אם:","img":null},{"text":"SMS רגילים מתקבלים.","img":null},{"text":"לא קיימת חסימה במכשיר.","img":null},{"text":"ההודעה אינה נמצאת בספאם.","img":null},{"text":"פרטי מספר הטלפון בשירות תקינים.","img":null},{"text":"התקלה עדיין משתחזרת.","img":null},{"text":"עבור אל:","img":null}],"images":[]},{"num":"18","title":"E-60 - הסלמה למומחה - תקלות SMS בארץ","items":[{"text":"אין להעביר ישירות להנדסה.","img":null}],"images":[]},{"num":"19","title":"תוצאת המסלול","items":[{"text":"בסיום המסלול יש להגיע לאחת מהתוצאות הבאות:","img":null},{"text":"התקלה נפתרה.","img":null},{"text":"נמצאה בעיה בפרטי המספר אצל ספק השירות.","img":null},{"text":"ההודעה נמצאה בספאם או בסינון.","img":null},{"text":"קיימת מגבלה או חסימה במנוי.","img":null},{"text":"נמצא עיכוב בקבלת OTP.","img":null},{"text":"התקלה קיימת בשירות מסוים בלבד.","img":null},{"text":"התקלה קיימת מול מספר שירותי OTP ונדרש המשך טיפול מומחה.","img":null}],"images":[]},{"num":"20","title":"פערים להשלמה מול הנדסה","items":[{"text":"כיצד מזהים במערכות החברה הודעות OTP","img":null},{"text":"האם קיימות חסימות ייעודיות להודעות ממספרים מקוצרים או משולחים מסחריים.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"קיים חלקית","priority":"","gap":"סטטוס מנהלת: אבי חבה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"R-63 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-63.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-63 - לא מתקבלות הודעות OTP  .docx"};
window.dynamicDocs['kbm_o60'] = {"id":"kbm_o60","topic":"O-60 · בדיקת חסימות, ספאם והגדרות SMS במכשיר","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקת חסימות, ספאם והגדרות מסר במכשיר","tags":["סמס בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מטרת המסמך","ordered":false,"steps":[{"text":"לבדוק האם הודעת SMS התקבלה למכשיר אך נחסמה, סוננה או הועברה לתיקייה אחרת.","img":null},{"text":"יש להשתמש במסמך זה מתוך מסלולי הטיפול:","img":null},{"text":"R-61 - לא ניתן לקבל SMS בכלל.","img":null},{"text":"R-62 - תקלה בשליחה או קבלה מול מספר מסוים.","img":null},{"text":"R-63 - לא מתקבלות הודעות OTP.","img":null}]},{"title":"iPhone","ordered":false,"steps":[]},{"title":"1. בדיקת שולחים לא מוכרים","ordered":false,"steps":[{"text":"פתח:","img":null},{"text":"הודעות < מסננים < שולחים לא מוכרים","img":null},{"text":"בדוק האם ההודעה מופיעה שם.","img":null},{"text":"אם נמצאה ההודעה:","img":null},{"text":"ההודעה התקבלה למכשיר.","img":null},{"text":"אין מדובר בכשל בקבלת SMS ברשת.","img":null},{"text":"ניתן לסמן את השולח כידוע כדי שהודעות עתידיות יוצגו ברשימת השיחות הרגילה.","img":null},{"text":"בגרסאות העדכניות ניתן לנהל את ההגדרה גם דרך:","img":null},{"text":"הגדרות > יישומים > הודעות < שולחים לא מוכרים.","img":null}]},{"title":"2. בדיקת תיקיית ספאם","ordered":false,"steps":[{"text":"פתח:","img":null},{"text":"הודעות < מסננים < ספאם","img":null},{"text":"אם ההודעה נמצאה:","img":null},{"text":"בחר בה וסמן שאינה ספאם כדי להעבירה חזרה לרשימת ההודעות.","img":null}]},{"title":"3. בדיקת מספר חסום","ordered":false,"steps":[{"text":"פתח:","img":null},{"text":"הגדרות > פרטיות ואבטחה > אנשי קשר חסומים","img":null},{"text":"בדוק האם המספר שממנו אמורה להגיע ההודעה נמצא ברשימה.","img":null},{"text":"אם נמצא:","img":null},{"text":"הסר את החסימה ובצע ניסיון קבלה נוסף.","img":null},{"text":"כאשר מספר חסום, הודעות ממנו אינן נמסרות למכשיר.","img":null}]},{"title":"Android - Google Messages","ordered":false,"steps":[]},{"title":"1. בדיקת ספאם ומספרים חסומים","ordered":false,"steps":[{"text":"פתח:","img":null},{"text":"Google Messages > תמונת הפרופיל > ספאם וחסומים","img":null},{"text":"בדוק האם ההודעה או המספר מופיעים ברשימה.","img":null},{"text":"אם נמצאו:","img":null},{"text":"פתח את השיחה ובחר ביטול חסימה.","img":null},{"text":"השיחה תחזור לרשימת ההודעות הרגילה.","img":null}]},{"title":"2. בדיקת הגנת ספאם","ordered":false,"steps":[{"text":"פתח:","img":null},{"text":"Google Messages > תמונת הפרופיל > הגדרות הודעות > הגנה ובטיחות > הגנת ספאם","img":null},{"text":"Google Messages עשויה לזהות הודעות כספאם ולהסתיר אותן בתיקיית \"ספאם וחסומים\".","img":null},{"text":"אין צורך לכבות את מנגנון ההגנה באופן קבוע.","img":null},{"text":"אם נמצאה הודעה תקינה שסוננה בטעות:","img":null},{"text":"הסר את סימון הספאם או בטל את חסימת השולח.","img":null}]},{"title":"Samsung Messages","ordered":false,"steps":[]},{"title":"1. בדיקת מספרים חסומים","ordered":false,"steps":[{"text":"פתח:","img":null},{"text":"הודעות > שלוש נקודות > הגדרות > חסימת מספרים וספאם","img":null},{"text":"בדוק את רשימת המספרים החסומים.","img":null},{"text":"אם המספר נמצא:","img":null},{"text":"הסר אותו ובצע ניסיון קבלה נוסף.","img":null}]},{"title":"2. בדיקת הודעות מסוננות","ordered":false,"steps":[{"text":"במסך \"חסימת מספרים וספאם\" בדוק אם קיימות הודעות שסוננו או נחסמו.","img":null},{"text":"אם נמצאה ההודעה:","img":null},{"text":"הסר את החסימה בהתאם ובצע ניסיון נוסף.","img":null}]},{"title":"בדיקה לאחר שינוי","ordered":false,"steps":[{"text":"לאחר הסרת חסימה או סינון:","img":null},{"text":"חזור למסך ההודעות הראשי.","img":null},{"text":"בקש לבצע שליחת SMS חדשה ללקוח.","img":null},{"text":"ודא שההודעה מופיעה ברשימת ההודעות הרגילה.","img":null},{"text":"אם ההודעה התקבלה:","img":null},{"text":"חזור למסלול הטיפול וסיים בהתאם.","img":null},{"text":"אם ההודעה אינה מתקבלת:","img":null},{"text":"חזור לשלב הבא במסלול R שממנו הגעת.","img":null}]},{"title":"כלל מנחה לנציג","ordered":false,"steps":[{"text":"הודעה שנמצאה בתיקיית ספאם, תחת שולחים לא מוכרים או ברשימת הודעות מסוננות היא הודעה שהגיעה למכשיר.","img":null},{"text":"במצב זה אין להתייחס לאירוע ככשל רשת בקבלת SMS לפני שטופלה הגדרת הסינון במכשיר.","img":null}]}]},"source":{"name":"O-60 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-60.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-60 - בדיקת חסימות, ספאם והגדרות  סמס במכשיר.docx"};
window.dynamicDocs['kbm_o61'] = {"id":"kbm_o61","topic":"O-61 · בדיקת מרכז הודעות SMS במכשיר","cat":"tech","docType":"pdf","kind":"O","desc":"בדיקת מרכז הודעות SMS במכשיר","tags":["סמס בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"groups":[{"title":"מרכז ההודעות התקין והמאושר","ordered":false,"steps":[{"text":"מספר מרכז ההודעות של wecom הוא:","img":null}]},{"title":"+972510000030","ordered":false,"steps":[{"text":"זהו הערך שיש להשוות אליו את שדה SMSC או Message Centre. המספר וקוד השירות המפורטים במסמך נבדקו ואושרו מול דקל. אין להזין ערך ממפעיל אחר, מהאינטרנט או ממכשיר של לקוח אחר.","img":null},{"text":"קוד השירות המאושר לבדיקת מרכז ההודעות במכשירי Android שבהם הוא זמין:","img":null}]},{"title":"*#*#4636#*#*","ordered":false,"steps":[]},{"title":"מתי משתמשים במסמך","ordered":false,"steps":[{"text":"כאשר לקוח אינו מצליח לשלוח הודעות SMS רגילות, ובמסלול R‑60 — לא ניתן לשלוח SMS בכלל, נדרשת בדיקת מרכז ההודעות. המסמך מיועד לבדיקת הגדרה זו בלבד; לאחר הבדיקה חוזרים למסלול R‑60.","img":null}]},{"title":"שלב 1 בחירת הקו ובדיקת ההגדרה","ordered":true,"steps":[{"text":"במכשיר עם שני קווים, ודא שנבחר קו wecom לפני בדיקת הערך או עדכונו. מיקום ההגדרה וזמינות קוד השירות משתנים לפי דגם, גרסת מערכת ואפליקציית הודעות.","img":null},{"text":"אם מוצג שדה SMSC או Message Centre, בדוק שאינו ריק ושהוא תואם למספר המאושר בראש המסמך. אם הערך כבר תואם, אל תשנה אותו; חזור ל־R‑60 והמשך לשלב הבא. אם הוא שגוי או חסר, עדכן אותו לפי הוראות המכשיר להלן.","img":null}]},{"title":"שלב 2 בדיקה מתוך הגדרות ההודעות","ordered":true,"steps":[]},{"title":"Samsung","ordered":false,"steps":[{"text":"פתח: הודעות > הגדרות > הגדרות נוספות > הודעות טקסט > מרכז הודעות. בגרסאות מסוימות הכניסה להגדרות נעשית באמצעות תפריט שלוש הנקודות באפליקציית ההודעות.","img":null},{"text":"אם השדה ניתן לעריכה והערך שגוי או חסר, הזן את המספר המאושר בראש המסמך ושמור. לאחר עדכון עבור לשלב 4. אם האפשרות אינה מופיעה, עבור לשלב 3.","img":null}]},{"title":"Xiaomi Redmi POCO ומכשירי Android אחרים","ordered":false,"steps":[{"text":"בדוק בהגדרות אפליקציית ההודעות אם קיימת אפשרות SMS Center או מרכז הודעות. אם קיימת, בדוק ועדכן רק אם נדרש, ולאחר עדכון עבור לשלב 4. אם האפשרות אינה קיימת או אינה ניתנת לעריכה, עבור לשלב 3.","img":null}]},{"title":"iPhone","ordered":false,"steps":[{"text":"הגדרת מרכז ההודעות מנוהלת באמצעות הגדרות המפעיל ואינה מוצגת בדרך כלל בתפריט רגיל לעריכה. קוד ה־Android שבמסמך אינו מיועד ל־iPhone. אין לבצע שינוי באמצעות קוד אחר; חזור ל־R‑60 והמשך לשלב הבא.","img":null}]},{"title":"שלב 3 בדיקה באמצעות קוד השירות המאושר ב Android","ordered":true,"steps":[{"text":"השתמש בשלב זה רק אם לא ניתן לבצע את הבדיקה מתוך הגדרות ההודעות. אין צורך לבצע את שתי דרכי התפעול כאשר ההגדרה כבר נבדקה ונמצאה תקינה או עודכנה בהצלחה.","img":null},{"text":"1. פתח את החייגן והזן את קוד השירות המאושר המופיע בראש המסמך.","img":null},{"text":"2. אם תפריט השירות נפתח, בחר Phone Information — פרטי הטלפון. אם מוצגים כמה קווים או כרטיסים, ודא שנבחר הקו של wecom.","img":null},{"text":"3. אתר את שדה SMSC. אם הערך מוצג ותואם למספר המאושר, אין לשנותו. חזור ל־R‑60 והמשך לשלב הבא.","img":null},{"text":"4. אם הערך חסר או שגוי והשדה ניתן לעריכה, הזן את המספר המאושר ולחץ Update לעדכון.","img":null},{"text":"5. אם העדכון הצליח, המשך לשלב 4. אם התפריט אינו נפתח, השדה אינו זמין או שלא ניתן להשלים את העדכון, תעד זאת וחזור ל־R‑60 לשלב הבא. אין לחזור שוב ושוב על ניסיון שנכשל או להשתמש בקודים אחרים.","img":null}]},{"title":"שלב 4 בדיקה לאחר עדכון מרכז ההודעות","ordered":true,"steps":[{"text":"לאחר עדכון הערך, הנחה את הלקוח לכבות ולהפעיל את המכשיר. המתן לרישום מחדש לרשת ובקש לשלוח SMS רגיל למספר נוסף. בדוק את תוצאת השליחה ותעד אם התקבלה הודעת שגיאה.","img":null}]},{"title":"ההודעה נשלחה בהצלחה","ordered":false,"steps":[{"text":"חזור ל־R‑60 וסיים בהתאם לתנאי המסלול. אם התקלה המקורית הייתה גם בשליחה וגם בקבלה, בדוק גם קבלת SMS רגיל לפני סיום הטיפול.","img":null}]},{"title":"ההודעה עדיין אינה נשלחת","ordered":false,"steps":[{"text":"חזור לשלב הבא ב־R‑60. העבר את תוצאת הבדיקה ואת העובדה שמרכז ההודעות נבדק או עודכן, בלי לבצע שוב את אותו תפעול.","img":null}]},{"title":"דגשים לנציג","ordered":false,"steps":[{"text":"השתמש רק במספר ובקוד המאושרים המופיעים בראש מסמך זה. אין לשנות הגדרות אחרות בתפריט השירות. היעדר אפשרות בדיקה או כשל עדכון אינם תוצאה תקינה — יש לתעד אותם ולהמשיך במסלול R‑60.","img":null}]}]},"source":{"name":"O-61 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-61.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-61 - בדיקת מרכז הודעות סמס במכשיר.docx + O-61_בדיקת_מרכז_הודעות_SMS.docx"};
window.dynamicDocs['kbm_e60'] = {"id":"kbm_e60","topic":"E-60 · העברה למומחה: תקלות SMS בארץ","cat":"tech","docType":"pdf","kind":"E","desc":"הסלמה למומחה בתקלות מסר בארץ","tags":["סמס בארץ"],"owner":"","stages":[],"worlds":["tech"],"track":{"state":"קיים","priority":"","gap":"סטטוס מנהלת: מוכן לפרסום · להעביר את התוכן הקיים לאפליקציה","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","body":{"when":["מעבירים רק לאחר שבוצע מסלול הטיפול הרלוונטי והתקלה לא נפתרה:","R-60 - לא ניתן לשלוח SMS בכלל.","R-61 - לא ניתן לקבל SMS בכלל.","R-62 - תקלה מול מספר מסוים.","R-63 - לא מתקבלות הודעות OTP.","חריג ניוד ב־OTP: כאשר R-63 מורה להעביר למומחה לקוח שהתנייד לאחרונה, ולקוח שקיבל קודי אימות לפני הניוד ואינו מקבל אותם לאחריו, בעוד ש־SMS רגילים מתקבלים","SMS רגילים מתקבלים ורק קודי אימות אינם מתקבלים, ההעברה מתבצעת לפי ענף הניוד של R-63. אין לדרוש במקרה זה השלמת יתר מסלול ה־OTP כתנאי להעברה."],"to":[],"conditions":["סוג התקלה: שליחה / קבלה / OTP.","האם התקלה מול כולם או מול מספר מסוים.","מתי התחילה התקלה.","האם התקלה קבועה או לסירוגין.","תאריך ושעה של ניסיון אחרון שבו התקלה שוחזרה.","הבדיקות שבוצעו ותוצאותיהן.","הודעת שגיאה, אם קיימת."],"document":[],"extra":[{"title":"מטרת המסמך","lines":["להנחות את הנציג מתי ואיך להעביר תקלה למומחה טכני."]},{"title":"אם התקלה מול מספר מסוים","lines":["יש לצרף גם:","מספר השולח.","מספר המקבל."]},{"title":"אם התקלה היא OTP","lines":["אם בוצע ניוד, יש לתעד גם את מועד השלמתו אם ידוע, האם התקלה החלה לאחריו והאם ההעברה נעשית לפי חריג הניוד ב־R-63. חריג זה אינו חל אוטומטית על תקלה בהודעות רגילות ב־R-61 או ב־R-62.","יש לצרף גם:","שם השירות שממנו אמורה להגיע ההודעה.","האם SMS רגילים מתקבלים."]},{"title":"העברה","lines":["לאחר השלמת המידע:","עבור אל:"]},{"title":"S-60 מסלול טיפול מומחה: תקלות SMS בארץ","lines":["אין להעביר תקלה ללא השלמת פרטי האירוע הנדרשים."]}]},"source":{"name":"E-60 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/E-60.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"E-60 - הסלמה למומחה תקלות סמס בארץ.docx"};
window.dynamicDocs['kbm_s60'] = {"id":"kbm_s60","topic":"S-60 · האם קיימות חסימות רשת ייעודיות לקבלת SMS -תקלת ניידות או אפללו- ל2 המקרים צריך לפנות לסלקום","cat":"tech","docType":"pdf","kind":"S","desc":"מסלול טיפול מומחה בתקלות מסר בארץ","tags":["סמס בארץ"],"owner":"אוריה","stages":[{"num":"1","title":"שלב 7 - בידוד מכשיר או SIM","items":[{"text":"בצע בדיקת בידוד באמצעות SIM ומכשיר חלופי בהתאם לפריטי הידע הקיימים בעולם SIM/eSIM","img":null},{"text":"מטרת הבדיקה היא לזהות האם התקלה קשורה למכשיר או נשארת עם הקו.","img":null},{"text":"המשך לשלב 7.","img":null}],"images":[]},{"num":"2","title":"אם SMS מתקבל כאשר ה SIM נמצא במכשיר אחר","items":[{"text":"התקלה מצביעה על מכשיר הלקוח או על הגדרה מקומית במכשיר.","img":null},{"text":"אין להסלים כתקלה רשתית לפני השלמת טיפול במכשיר.","img":null}],"images":[]},{"num":"3","title":"אם SMS אינו מתקבל גם במכשיר אחר","items":[{"text":"התקלה נשארת עם הקו.","img":null},{"text":"המשך לשלב 8.","img":null}],"images":[]},{"num":"4","title":"שלב 6 - בידוד מכשיר או SIM","items":[{"text":"בצע בדיקת בידוד בהתאם למסמכי SIM/eSIM הקיימים.","img":null},{"text":"מטרת הבדיקה היא לזהות האם התקלה נשארת עם הקו או קשורה למכשיר.","img":null},{"text":"אם השירות עובד במכשיר אחר:","img":null},{"text":"התקלה מצביעה על מכשיר הלקוח.","img":null},{"text":"אם התקלה נשארת גם במכשיר אחר:","img":null},{"text":"המשך להסלמה.","img":null}],"images":[]}],"worlds":["tech"],"track":{"state":"חסר","priority":"","gap":"סטטוס מנהלת: אוריה - חדש","source":"מפת מסמכים (רשימת מסמכים וסטטוס) – גיליון טכני"},"status":"published","source":{"name":"S-60 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/S-60.docx?web=1"},"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"להשלים S-60    מסלול טיפול מומחה תקלות סמס בארץ.docx"};

// BEGIN GENERATED SOURCE REVISIONS



























































// END GENERATED SOURCE REVISIONS

// BEGIN GENERATED SOURCE ITEMS
window.dynamicDocs['kbnew_o06'] = {"kind":"O","topic":"O-06 · תאימות מכשירים בארה\"ב","desc":"בדיקת תאימות מכשירים לשימוש בארה״ב.","tags":["תאימות מכשיר","ארה״ב"],"stages":[],"body":{"groups":[{"title":"מידע כללי","ordered":false,"steps":[{"text":"פניית לקוח בעל מכשיר סמסונג המעוניין לרכוש חבילת חו\"ל לארה\"ב:","img":null},{"text":"עדכן את הלקוח שלפני הטיסה עליו לבצע עדכון גרסה למכשיר הסמסונג שברשותו לגרסה החדשה ביותר למכשיר (על פי רשימת הדגמים)","img":null},{"text":"בפניית מנוי לקוח שלא מצליח לגלוש - יש לראות אם המנוי אכן רשום לVolte Roaming, ולוודא תקינות מול הלקוח.","img":null}]},{"title":"מכשירי Samsung","ordered":false,"steps":[{"text":"Galaxy S22 תת דגם SM-S901E/DS החל מגרסה XXS2AVDD","img":null},{"text":"Galaxy S22 Plus תת דגם SM-S9061E/DS החל מגרסה XXS2AVDD","img":null},{"text":"Galaxy S22 Ultra תת דגם SM-S908E/DS החל מגרסה XXS2AVDD","img":null},{"text":"Galaxy Note10 Lite תת דגם SM-N770F החל מגרסה XXU8GVD5","img":null},{"text":"Galaxy S21 5G תת דגם SM-G991B-DS החל מגרסה XXU5CVDD","img":null},{"text":"Galaxy S21 Plus תת דגם SM-G996B-DS החל מגרסה XXU5CVDD","img":null},{"text":"Galaxy S21 Ultra 5G תת דגם SM-G998B-DS החל מגרסה XXU5CVDD","img":null},{"text":"Galaxy S21 FE תת דגם SM-G990E-DS החל מגרסה XXU2CVDA","img":null},{"text":"Galaxy A32 תת דגם A325F/DS החל מגרסה XXU2BVD6","img":null},{"text":"Galaxy Note10 תת דגם SM-N970F החל מגרסה XXU8HVE5","img":null},{"text":"Galaxy Note10 Plus תת דגם SM-N975F החל מגרסה XXU8HVE5","img":null},{"text":"Galaxy S20 FE תת דגם SM-G781B/DS החל מגרסה XXS4FVD9","img":null},{"text":"Galaxy Note20 תת דגם SM-N980F-DS החל מגרסה XXU4FVE7","img":null},{"text":"Galaxy Note20 Ultra תת דגם SM-N985F החל מגרסה XXU4FVE7","img":null},{"text":"Galaxy NOTE 20 ULTRA 5G תת דגם SM-N986B-DS החל מגרסה XXU4FVE7","img":null},{"text":"Galaxy S20 תת דגם SM-G980F-DS החל מגרסה XXUEFVDB","img":null},{"text":"Galaxy S20 Plus תת דגם SM-G985F-DS החל מגרסה XXUEFVDB","img":null},{"text":"Galaxy S20 Ultra תת דגם SM-G988B-DS -DS החל מגרסה XXUEFVDB","img":null},{"text":"Galaxy Z Flip3 5G תת דגם SM-F711B - החל מגרסה XXU2CVEB","img":null},{"text":"GALAXY A71 תת דגם SM-A715F החל מגרסה XXU8CVD1","img":null},{"text":"X COVER PRO תת דגם SM-G715FN החל מגרסה XXSADVE2","img":null},{"text":"Galaxy Z FOLD 3 5G תת דגם SM-F926B-DS החל מגרסה XXU1CVEB","img":null},{"text":"Galaxy M52 5G תת דגם SM-M526BR-DS החל מגרסה XXU1BVD4","img":null},{"text":"GALAXY A52 5G תת דגם SM-A526B-DS החל מגרסה XXU1CVD9","img":null},{"text":"GALAXY A52s 5G תת דגם SM-A528B -DS החל מגרסה XXU1CVE2","img":null},{"text":"GALAXY A33 5G תת דגם SM-A336B החל מגרסה DXU2AVD7","img":null},{"text":"GALAXY A23 תת דגם SM-A235F-DS החל מגרסה XXU1AVE5","img":null},{"text":"Galaxy S10 תת דגם SM-G973F החל מגרסה XXUFHVE1","img":null},{"text":"Galaxy S10e תת דגם SM-G970F החל מגרסה XXUFHVE1","img":null},{"text":"Galaxy S10 Plus תת דגם SM-G975F החל מגרסה XXUFHVE1","img":null},{"text":"GALAXY A52 LTE תת דגם SM-A525F החל מגרסה XXU4BVE2","img":null},{"text":"GALAXY A51 תת דגם SM-A515F החל מגרסה XXU5FVE2","img":null},{"text":"Galaxy A31 תת דגם SM-A315F/DS החל מגרסה XXU1DVD8","img":null},{"text":"GALAXY Z FLIP תת דגם SM-F700F-DS החל מגרסה XXU8GVF3","img":null},{"text":"GALAXY A13 תת דגם SM-A135F-DS החל מגרסה XXU1AVF1","img":null},{"text":"GALAXY A50 תת דגם SM-A505F החל מגרסה DDU9CVF2","img":null},{"text":"GALAXY A73 תת דגם SM-A736B-DS החל מגרסה XXU1AVF3","img":null},{"text":"Galaxy A03s תת דגם SM-A037F-DS החל מגרסה XXU1BVFB","img":null},{"text":"Galaxy A53 5G תת דגם SM-A536E-DS החל מגרסה XXU2AVF2","img":null},{"text":"GALAXY A72 תת דגם SM-A725F -DS החל מגרסה XXU4BVE3","img":null},{"text":"Galaxy Z Flip4 5G תת דגם SM-F721B החל מגרסה XXU1AVGA","img":null},{"text":"Galaxy Z Fold 4 5G תת דגם SM-F936B/DS החל מגרסה XXU1AVGA","img":null},{"text":"Galaxy A13 תת דגם SM-A137F-DS החל מגרסה XXU1AVH1","img":null},{"text":"Galaxy XCover6 Pro תת דגם SM-G736B/DS החל מגרסה XXS1AVH5","img":null},{"text":"Galaxy A04e תת דגם SM-A042F/DS החל מגרסה XXU1AVJ2","img":null},{"text":"Samsung Galaxy A04 תת דגם SM-A045F/DS החל מגרסה XXU1AVL2","img":null},{"text":"Samsung Galaxy S23 תת דגם SM-S911B/DS החל מגרסה XXU1AWA6","img":null},{"text":"Samsung Galaxy S23 Plus תת דגם SM-S916B/DS החל מגרסה XXU1AWA6","img":null},{"text":"Samsung Galaxy S23 Ultra תת דגם SM-S918B/DS החל מגרסה XXU1AWA6","img":null},{"text":"Samsung Galaxy A14 תת דגם SM-A145P/DS החל מגרסה XXU1AWA3","img":null},{"text":"Samsung Galaxy A54 5G תת דגם SM-A546E/DS החל מגרסה XXU1AWC4","img":null},{"text":"Samsung Galaxy M54 5G תת דגם SM-M546B/DSהחל מגרסה XXU1AWB3","img":null},{"text":"Galaxy A24 תת דגם SM-A245F/DSN החל מגרסה XXU1AWC3","img":null},{"text":"Galaxy A14F תת דגם SM-A145F/DS החל מגרסה XXS2AWF3","img":null},{"text":"Galaxy Z Fold5 5G תת דגם SM-F946B/DS החל מגרסה XXU1AWG4","img":null},{"text":"Galaxy Z Flip5 5G תת דגם SM-F31B החל מגרסה XXU1AWG3","img":null},{"text":"Samsung Galaxy A34 5G תת דגם SM-A346E/DSN החל מגרסה XXU1AWB9","img":null},{"text":"Galaxy A15 תת דגם SM-A155F/DSN החל מגרסה XXU1AWKA","img":null},{"text":"Galaxy A05 תת דגם SM-A055F/DS החל מגרסה XXU2AWK1","img":null},{"text":"Galaxy S24 5G תת דגם SM-S921B/DS החל מגרסה XXU1AWM9","img":null},{"text":"Galaxy S24 Plus 5G תת דגם SM-S926B/DS החל מגרסה XXU1AWM9","img":null},{"text":"Galaxy S24 Ultra 5G תת דגם SM-S928B/DS החל מגרסה XXU1AWM9","img":null},{"text":"Galaxy A25 5G תת דגם SM-A256E/DSN החל מגרסה XXU1AWL1","img":null},{"text":"Galaxy S23 FE 5G תת דגם SM-S711B/DSהחל מגרסה XXU1AWI7","img":null},{"text":"Galaxy Tab A9 תת דגם SM-X115 החל מגרסה XXU1AWI2","img":null},{"text":"Galaxy Tab A9 Plus תת דגם SM-X216B החל מגרסה XXU1AWI7","img":null},{"text":"Galaxy Tab S9 FE 5G תת דגם SM-X516B החל מגרסה XXU1AWHK","img":null},{"text":"Galaxy S25 Ultra 5G תת דגם SM-S938B/DS החל מגרסה XXU1AYA1","img":null},{"text":"Galaxy S25 5G תת דגם SM-S931B/DS החל מגרסה XXU1AYA1","img":null},{"text":"Galaxy S25 Plus 5G תת דגם SM-S936B/DS החל מגרסה XXU1AYA1","img":null},{"text":"Galaxy XCover 7 5G תת דגם SM-G556B החל מגרסה XXU7BXL3","img":null},{"text":"Galaxy A06 תת דגם SM-A065F/DS החל מגרסה XXU1AXG8","img":null},{"text":"Galaxy S24 FE 5G תת דגם SM-S721B/DS החל מגרסה XXU1AXI3","img":null},{"text":"Galaxy A16 תת דגם SM-A165F/DS החל מגרסה XXU1AXJ6","img":null},{"text":"Galaxy A36 5G תת דגם SM-A366B/DS החל מגרסה XXU1AYB9","img":null},{"text":"Galaxy A56 5G תת דגם SM-A566B/DS החל מגרסה XXU1AYB7","img":null},{"text":"Galaxy A26 5G תת דגם SM-A266B/DS החל מגרסה XXU1AYB5.","img":null},{"text":"Galaxy Tab S10 FE Plus 5G תת דגם SM-X526B החל מגרסה XXU1AYC5","img":null},{"text":"Samsung Galaxy Z Fold7 5G תת דגם SM-F966B/DS החל מגרסה XXU1AYFJ","img":null},{"text":"Samsung Galaxy Z Flip7 5G תת דגם SM-F66B החל מגרסה XXU1AYFP","img":null},{"text":"Galaxy S25 Edge 5G תת דגם SM-S937B/DS החל מגרסה XXU1AYD","img":null},{"text":"Galaxy XCover7 Pro 5G תת דגם SM-G766B החל מגרסה XXS2AYG1","img":null},{"text":"Galaxy S25 FE 5G תת דגם SM-S731B/DS החל מגרסה XXU1AYH9","img":null},{"text":"Galaxy A17 תת דגם SM-A175F/DS החל מגרסה XXU1AYH4","img":null},{"text":"Galaxy Tab S10 Lite 5G תת דגם SM-X406B החל מגרסה XXU1AYG7","img":null}]},{"title":"מכשירי Apple","ordered":false,"steps":[]},{"title":"החל מדגם iPhone 7 ומעלה מגרסה IOS 15.0 ומעלה","ordered":false,"steps":[{"text":"iPhone 14 תת דגם A2882 החל מגרסה: IOS 16.0-20A357 גרסת מפעיל Partner 51.0","img":null},{"text":"iPhone 14 Plus תת דגם A2886 החל מגרסה: IOS 16.0-20A357 גרסת מפעיל Partner 51.0","img":null},{"text":"iPhone 14 Pro תת דגם A2890 החל מגרסה: IOS 16.0-20A357 גרסת מפעיל Partner 51.0","img":null},{"text":"iPhone 14 Pro Max תת דגם A2894 החל מגרסה: IOS 16.0-20A357 גרסת מפעיל Partner 51.0","img":null},{"text":"iPhone 16 תת דגם A3287 החל מגרסה IOS 18.","img":null},{"text":"iPhone 16 Pro תת דגם A3293 החל מגרסה IOS 18.","img":null},{"text":"iPhone 16 Pro max תת דגם A3296 החל מגרסה IOS 18.","img":null},{"text":"iPhone 16e תת דגם A3409 החל מגרסה IOS 18.","img":null}]},{"title":"יתר המכשירים","ordered":false,"steps":[{"text":"PhoneLine F33 החל מגרסת תוכנה: SHB_T117","img":null},{"text":"Nothing phone 1 - תת דגם A063 החל מגרסת תוכנה: spacewar-s1.1-221022-1221","img":null},{"text":"Redmi12C תת דגם 2212RN86G החל מגרסה 13.0.7.0(SCVMIXM)","img":null},{"text":"OnePlus 11 5G תת דגם CPH2449 החל מגרסה 11_A.09","img":null},{"text":"Alcatel 3080V -Kosher-01-08-2023 החל מגרסה V1.6_20230309","img":null},{"text":"Redmi 13 תת דגם 24040RN64Y החל מגרסה 1.0.3.0.UNTMIXM.","img":null},{"text":"Redmi 14C תת דגם 2409BRN2CY החל מגרסה 1.0.9.0.UGTMIXM.","img":null},{"text":"POCO X7 PRO 5G תת דגם 2412DPC0AGS החל מגרסה 2.0.7.0.VOJMIXM.","img":null},{"text":"POCO X7 5G תת דגם 24095PCADG החל מגרסה 1.0.7.0.UOOMIXM.","img":null},{"text":"Redmi Note 14 PRO 5G תת דגם 24090RA29G החל מגרסה 1.0.7.0.UOOMIXM.","img":null},{"text":"Redmi Note 14 תת דגם 24117RN760 החל מגרסה 1.0.4.0.UOGMIXM.","img":null},{"text":"BlackView Hero 10 החל מגרסה Build V1.0_20240918V01","img":null},{"text":"Pixel 9 PRO XL 5G החל מגרסה AP3A.241105.008","img":null},{"text":"Pixel 9 PRO 5G החל מגרסה AP4A.241205.013.","img":null},{"text":"EasyPhone דגם מכשיר NP-01 - 4G החל מגרסה L666_YF_E241_IL_V17 -תומך ב VOLTE בלבד.","img":null},{"text":"Normande דגם מכשיר Normande N1 Kosher החל מגרסה V28_20241112 תומך בVOLTE+VOLTE Roaming בלבד.","img":null},{"text":"יצרן Xiaomi דגם מכשיר 15 5G תת דגם 24129PN74G החל מגרסה 2.0.106.0.VOCMIXM.","img":null},{"text":"יצרן Xiaomi דגם מכשיר 15 Ultra 5G תת דגם 25010PN30G החל מגרסה 2.0.106.0.VOCMIXM.","img":null},{"text":"יצרן Xiaomi דגם טאבלט Redmi Pad SE 8.7 4G תת דגם 24076RP19G החל מגרסה 2.0.1.0.VHYMIXM.","img":null},{"text":"יצרן Escolls דגם מכשיר 4X4 Kosher S החל מגרסה V14. תומך בVOLTE בלבד (!)","img":null},{"text":"Pixel 10 Pro XL מתוצרת Google תת דגם G45RY החל מגרסה BD1A.250702.001","img":null}]}]},"id":"kbnew_o06","cat":"sim","topicIds":[9],"worlds":["tech"],"status":"published","source":{"name":"O-06 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-06.docx?web=1"},"reviewNotes":["יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום.","שם המקור מתחיל ב־0-06; יש לאמת את הקוד מול הגורם המקצועי."],"track":{"state":"טיוטה חדשה","source":"0-06 תאימות מכשירים  בארהב.docx","gap":"יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום. שם המקור מתחיל ב־0-06; יש לאמת את הקוד מול הגורם המקצועי."},"createdAt":1793532360000,"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"0-06 תאימות מכשירים  בארהב.docx"};
window.dynamicDocs['kbnew_o36'] = {"kind":"O","topic":"O-36 · נקודת גישה אישית / Hotspot לא עובד – זיהוי ותפעול","desc":"תפעול ובדיקות לתקלת נקודה חמה אישית: זיהוי הבעיה, בדיקת APN ב-iPhone, בדיקת הגלישה הסלולרית והמשך טיפול מתאים.","tags":["Hotspot","נקודה חמה אישית","APN","גלישה סלולרית"],"stages":[],"body":{"groups":[{"title":"מטרת המסמך","steps":[{"text":"לזהות אם התקלה קשורה להגדרת נקודה חמה אישית (Hotspot), לבצע את הבדיקות המתאימות ולהחליט על המשך טיפול. המסמך מיועד לטיפול בלקוח שנמצא בארץ, לא בנדידה.","img":null}]},{"title":"מהי נקודה חמה אישית?","steps":[{"text":"Hotspot מאפשר להשתמש בטלפון כמקור אינטרנט למכשירים אחרים, כגון מחשב, טאבלט או טלפון נוסף.","img":null},{"text":"הגלישה במכשירים המחוברים מתבצעת על חשבון חבילת הגלישה הסלולרית של המכשיר המשתף.","img":null}]},{"title":"תחילה: זהו מה בדיוק לא עובד","steps":[{"text":"האפשרות ״נקודה חמה אישית״ אינה מופיעה או מאופשרת ב-iPhone.","img":null},{"text":"האפשרות קיימת, אבל אי אפשר להפעיל אותה.","img":null},{"text":"הנקודה החמה פעילה, אבל המכשיר השני לא מצליח להתחבר.","img":null},{"text":"המכשיר השני מתחבר לנקודה החמה, אבל אין בו אינטרנט.","img":null}]},{"title":"iPhone: האפשרות ״נקודה חמה אישית״ אינה מופיעה","steps":[{"text":"פתח הגדרות > סלולרי (Settings > Cellular) > הקו הרלוונטי > רשת נתונים סלולריים (Cellular Data Network).","img":null},{"text":"גלול לאזור Personal Hotspot (נקודה חמה אישית). בשדה APN הזן we באותיות קטנות.","img":null},{"text":"חזור למסך ההגדרות ובדוק אם האפשרות ״נקודה חמה אישית״ הופיעה.","img":null}]},{"title":"הנקודה החמה קיימת אך אינה עובדת: בדיקות בסיסיות","steps":[{"text":"בדוק שהגלישה הסלולרית עובדת במכשיר הראשי, שהנתונים הסלולריים מופעלים, שאין חסימת גלישה ושהלקוח לא ניצל את מלוא החבילה.","img":null},{"text":"ודא שה-SIM או ה-eSIM הנכון מוגדר לנתונים סלולריים.","img":null},{"text":"כבה והפעל מחדש את הנקודה החמה.","img":null},{"text":"כבה והדלק Wi-Fi במכשיר שמנסה להתחבר. במידת הצורך, הפעל מחדש את שני המכשירים.","img":null}]},{"title":"המכשיר השני אינו מצליח להתחבר","steps":[{"text":"ודא שה-Hotspot מופעל ושהמכשיר השני מזהה את שם הרשת.","img":null},{"text":"בדוק שהסיסמה הוזנה נכון.","img":null},{"text":"אם החיבור נכשל, מחק את הרשת השמורה במכשיר השני ונסה להתחבר מחדש.","img":null},{"text":"ודא שהטלפון המשתף והמכשיר השני נמצאים בטווח סביר זה מזה.","img":null}]},{"title":"המכשיר התחבר אך אין אינטרנט: בדוק גלישה סלולרית","steps":[{"text":"כבה את ה-Wi-Fi במכשיר הראשי ונסה לגלוש באמצעות נתונים סלולריים.","img":null},{"text":"אם הגלישה הסלולרית במכשיר הראשי אינה תקינה, עבור ל-M-30 והמשך במסלול תקלת הגלישה המתאים. בדוק APN אם נדרש.","img":null},{"text":"אם הגלישה הסלולרית במכשיר הראשי תקינה, השלם את בדיקות ה-Hotspot והחיבור בין המכשירים שבמסמך זה.","img":null}]},{"title":"החלטה והמשך טיפול","steps":[{"text":"אם האפשרות לנקודה חמה אינה מופיעה ב-iPhone, בדוק את הגדרת ה-APN לפי ההנחיות לעיל.","img":null},{"text":"אם הגלישה הסלולרית במכשיר הראשי אינה תקינה, המשך במסלול תקלת הגלישה דרך M-30. יש לבדוק כשה-Wi-Fi במכשיר הראשי כבוי.","img":null},{"text":"אם ה-Hotspot חזר לעבוד, ודא שהמכשיר הנוסף מתחבר ויכול לגלוש, תעד וסיים טיפול.","img":null},{"text":"אם הגלישה הסלולרית תקינה אך ה-Hotspot עדיין אינו מופיע, אינו ניתן להפעלה, אינו מאפשר חיבור או אינו מספק אינטרנט, הפנה לבדיקה פיזית של המכשיר במעבדת שירות או אצל גורם שירות למכשיר. אין להמשיך לטפל בכך כתקלה בגלישה בקו ואין להעביר ל-E-30 כתקלה בגלישה בקו.","img":null}]},{"title":"מה לתעד לפני הפניה לבדיקה פיזית","steps":[{"text":"תעד את דגמי שני המכשירים, אישור שהגלישה הסלולרית במכשיר הראשי תקינה כשה-Wi-Fi כבוי, מה בדיוק לא עובד, האם המכשיר הנוסף מזהה את הרשת ומתחבר, הודעת שגיאה אם קיימת, ואת הבדיקות שבוצעו ותוצאותיהן.","img":null},{"text":"אין לקבוע איזה משני המכשירים תקול ללא בדיקה פיזית. מסור לגורם הבודק אם התקלה היא בהפעלת הנקודה החמה במכשיר הראשי, בחיבור המכשיר הנוסף או בגלישה לאחר החיבור.","img":null}]},{"title":"נוסח מוצע ללקוח","steps":[{"text":"״הגלישה הסלולרית בקו שלך תקינה. לאחר בדיקות הנקודה החמה והחיבור, ה-Hotspot עדיין אינו עובד. בשלב הזה נדרשת בדיקה פיזית של המכשיר אצל גורם שירות למכשיר, כדי לבדוק את התקלה בשיתוף האינטרנט.״","img":null}]}]},"id":"kbnew_o36","cat":"tech","topicIds":[19],"worlds":["tech"],"status":"published","source":{"name":"O-36 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-36.docx?web=1"},"reviewNotes":[],"track":{"state":"טיוטה חדשה","source":"נקודת גישה אישית Hotspot לא עובד O-36.docx","gap":"יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום. יש לאמת אם התוכן שייך להוראת O-36 או למסלול הטיפול R-36; לא לשנות סיווג ללא אישור."},"createdAt":1793532360000,"publishedAt":1793612878318,"updatedAt":1793618413029,"originName":"נקודת גישה אישית Hotspot לא עובד O-36.docx"};
window.dynamicDocs['kbnew_o37'] = {"kind":"O","topic":"O-37 · תקלת גלישה שני קווים פעילים במכשיר","desc":"בדיקות גלישה כאשר שני קווים פעילים במכשיר.","tags":["גלישה","שני קווים"],"stages":[],"body":{"groups":[{"title":"מתי משתמשים במסמך","ordered":false,"steps":[{"text":"השתמש במסמך לאחר השלמת מסלול תקלת הגלישה, כאשר התקלה נמשכת ויש במכשיר שני קווים או שנעשה לאחרונה שימוש בקו נוסף.","img":null}]},{"title":"שלב 1 בירור ובחירת הקו לגלישה","ordered":true,"steps":[{"text":"שאל: האם יש במכשיר שני קווים פעילים או שהשתמשת לאחרונה בקו נוסף?","img":null},{"text":"אם כן, ודא שקו wecom מוגדר כקו לנתונים סלולריים. לבחירת הקו, השתמש במסמך ״הגדרות בסיסיות לגלישה סלולרית״.","img":null},{"text":"אם אין קו נוסף, עבור לסעיף המשך טיפול בסוף מסמך זה.","img":null}]},{"title":"שלב 2 בדיקה עם הקו הנוסף כבוי","ordered":true,"steps":[{"text":"אין למחוק את הקו הנוסף. כבה אותו זמנית לצורך הבדיקה בלבד ובדוק שוב גלישה באמצעות נתונים סלולריים, כשהרשת האלחוטית כבויה.","img":null},{"text":"אם לא ניתן לבצע את הבדיקה, תעד זאת והמשך לסעיף המשך טיפול.","img":null}]},{"title":"שלב 3 תוצאת הבדיקה","ordered":true,"steps":[{"text":"הגלישה חזרה: קיימת אינדיקציה שהגדרת הקווים משפיעה על הגלישה. ודא שקו wecom נבחר לגלישה. אם הקו הנוסף נדרש ללקוח, הפעל אותו מחדש ובדוק שוב. אם הגלישה נשארת תקינה, סיים טיפול; אם התקלה חוזרת, תעד את התלות בקו הנוסף והמשך במסלול תקלת הגלישה.","img":null},{"text":"התקלה נשארה: הפעל מחדש את הקו הנוסף והמשך לבדיקות הבאות.","img":null}]},{"title":"המשך טיפול","ordered":false,"steps":[{"text":"אם התקלה נמשכת, השלם את בדיקת ״VPN פעיל במכשיר בדיקה והמשך טיפול״ אם טרם בוצעה. לאחר מכן עבור למסמך ״קו מנוהל והגבלות ארגוניות זיהוי והמשך טיפול״. אם בדיקת VPN כבר בוצעה, עבור ישירות למסמך הקו המנוהל. אין לחזור על בדיקות שכבר הושלמו.","img":null}]}]},"id":"kbnew_o37","cat":"tech","topicIds":[11],"worlds":["tech"],"status":"published","source":{"name":"O-37 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-37.docx?web=1"},"reviewNotes":["יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."],"track":{"state":"טיוטה חדשה","source":"O-37 תקלת גלישה שני קווים פעילים במכשיר.docx","gap":"יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."},"createdAt":1793532360000,"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"O-37 תקלת גלישה שני קווים פעילים במכשיר.docx"};
window.dynamicDocs['kbnew_r14'] = {"kind":"R","topic":"R-14 · אין קליטה אין שירות בארץ","desc":"מסלול טיפול במקרה של אין קליטה או אין שירות בארץ.","tags":["קליטה","אין שירות","ישראל"],"stages":[{"num":"1","title":"מתי משתמשים במסמך","items":[{"text":"כאשר לקוח בארץ רואה בקו wecom חיווי ״אין שירות״, ״אין רשת״, ״שיחות חירום בלבד״ או SOS, ואין אינדיקציה שהתופעה נובעת ממיקום, ממיסוך או מתקלה אזורית.","img":null},{"text":"המסלול בודק את מצב הקו, שיוך ה־ SIM והגדרות המכשיר; הוא אינו מסלול בדיקת כיסוי רדיו.","img":null},{"text":"הפניה למסמך זה מתקבלת מ־M-10 — בעיות קליטה בארץ אבחון מרכזי.","img":null},{"text":"תיאור ״אין קליטה״ לבדו אינו מוכיח שהבעיה במכשיר או בכרטיס, ולכן יש לאמת את התרחיש לפני התפעול.","img":null}],"images":[]},{"num":"2","title":"שלב 1 אימות התקלה ובחירת המסלול","items":[{"text":"ברר ותעד: מה החיווי המדויק בקו wecom; מתי התחילה התקלה; האם קבועה או לסירוגין; האם מתרחשת גם במקומות אחרים; האם בוצעו ניוד, החלפת מכשיר, החלפת SIM או התקנת eSIM סמוך להופעתה.","img":null},{"text":"התקלה רק במקום מסוים או מופיע חשד לאירוע אזורי","img":null},{"text":"חזור ל־M-10 — בעיות קליטה בארץ אבחון מרכזי. אין להמשיך במסלול הנוכחי כאילו בעיית כיסוי נשללה.","img":null}],"images":[]},{"num":"3","title":"הלקוח נמצא בחו״ל","items":[{"text":"עבור ל־M-00 — תקלות ושירות בחו״ל אבחון מרכזי. אין להשתמש במסלול הארץ.","img":null}],"images":[]},{"num":"4","title":"התקלה התחילה לאחר הפעלת SIM או eSIM","items":[{"text":"עבור ל־R-50 — תקלה לאחר הפעלת SIM eSIM אין קליטה או אין גלישה. אם הבעיה היא סריקת QR או התקנת פרופיל שטרם הושלמה, השתמש ב־R-51 — תקלה בסריקת QR או בהורדת פרופיל eSIM. אין לבצע במקביל את שני מסלולי התפעול.","img":null}],"images":[]},{"num":"5","title":"אין קשר להפעלה חדשה ואין חשד לבעיית רדיו","items":[{"text":"המשך לשלב 2.","img":null}],"images":[]},{"num":"6","title":"שלב 2 בדיקת הקו במערכת","items":[{"text":"השתמש ב־O-40 — בדיקת סטטוס קו וחסימות שיחה במערכת. בדוק שהמנוי פעיל, אינו מושהה או חסום; בדוק אם יש מגבלה על השירות; ואם בוצע ניוד, בדוק שהושלם ושאין סטטוס בתהליך.","img":null},{"text":"בדוק איזה SIM או eSIM משויך לקו ושהוא תואם לכרטיס או לפרופיל שבו הלקוח משתמש. תעד החלפה אחרונה וחוסר התאמה אם נמצאו. אין לשנות שיוך, להחליף כרטיס או לשנות סטטוס ללא התהליך המאושר והרשאת ביצוע.","img":null}],"images":[]},{"num":"7","title":"נמצאה מגבלה או אי התאמה","items":[{"text":"טפל רק לפי התהליך המאושר ובהרשאות הנציג. לאחר תיקון בצע בדיקה חוזרת של חיווי הרשת והשירות. אם הפעולה אינה בהרשאת הנציג או שלא ניתן להשלים את הבדיקה, תעד את הממצא ואת הסיבה ועבור לשלב 6; אין לסמן את הבדיקה כתקינה.","img":null}],"images":[]},{"num":"8","title":"בדיקות הקו והשיוך תקינות","items":[{"text":"המשך לשלב 3. אין להסיק שכל תקלה ב־VoLTE היא הסיבה לחיווי אין שירות; בדיקת התאימות והשירות תתבצע במסלול השיחות אם נדרש בהמשך.","img":null}],"images":[]},{"num":"9","title":"שלב 3 בדיקת הקו במכשיר","items":[{"text":"ודא שמצב טיסה כבוי. במכשיר עם שני קווים, ודא שהחיווי שנבדק הוא של קו wecom ולא של הקו השני. בדוק שהקו הרלוונטי מופעל בהגדרות המכשיר.","img":null}],"images":[]},{"num":"10","title":"SIM פיזי","items":[{"text":"בדוק שהכרטיס נמצא במכשיר ושהמכשיר מזהה אותו. תעד אם מופיעה הודעת ״אין SIM״ או שהכרטיס אינו מזוהה. אין להתייחס למצב זה כאל כרטיס מזוהה עם בעיית שירות.","img":null}],"images":[]},{"num":"11","title":"eSIM","items":[{"text":"בדוק שהפרופיל מופיע בהגדרות הסלולר ושהקו מופעל. אם הקו כבוי, הפעל אותו ובדוק שוב. אין למחוק פרופיל או להנפיק eSIM חדש במסגרת מסמך זה. אם הפרופיל חסר או שהתקנתו לא הושלמה, עבור ל־R-51; אם מדובר בתקלה לאחר ההפעלה, עבור ל־R-50.","img":null},{"text":"הקו או הכרטיס אינם מזוהים ולא ניתן להשלים את הבדיקה","img":null},{"text":"תעד את החיווי, סוג הכרטיס והבדיקות שבוצעו, ועבור לשלב 6. לא מבצעים החלפת SIM כברירת מחדל בלי זיהוי סיבת התקלה והנוהל המאושר.","img":null}],"images":[]},{"num":"12","title":"הכרטיס או הפרופיל מזוהים והקו מופעל","items":[{"text":"המשך לשלב 4.","img":null}],"images":[]},{"num":"13","title":"שלב 4 ריענון במכשיר ובדיקה חוזרת","items":[{"text":"אם לא בוצע כבר במהלך הטיפול, הפעל ובטל מצב טיסה ובדוק שוב את חיווי הקו. אם עדיין אין שירות, בצע כיבוי והדלקה של המכשיר ובדוק שוב. אין לחזור על פעולה שכבר בוצעה ללא שינוי בתנאי הבדיקה.","img":null},{"text":"רענון SIM או שינוי במערכת מבוצעים רק כאשר המסלול המאושר מורה עליהם ובהרשאות הנציג; אין לבצע רענון מערכת נוסף על סמך מסמך זה בלבד.","img":null},{"text":"הרישום לרשת חזר","img":null},{"text":"המשך לשלב 5.","img":null},{"text":"עדיין מופיע אין שירות למרות כרטיס מזוהה וקו פעיל","img":null},{"text":"המשך לשלב 6. אין לעבור לבדיקת APN כל עוד התקלה היא היעדר שירות ולא תקלה בגלישה בקו שנרשם לרשת.","img":null}],"images":[]},{"num":"14","title":"שלב 5 בדיקת השירות לאחר חזרת הרשת","items":[{"text":"בדוק שיחה יוצאת ושיחה נכנסת, שליחה וקבלה של SMS רגיל וגלישה סלולרית כשהרשת האלחוטית כבויה. חיווי רשת שחזר אינו מספיק לבדו לסיום טיפול.","img":null},{"text":"כל השירותים שנבדקו תקינים","img":null},{"text":"תעד את הפעולה שפתרה ואת תוצאות הבדיקות וסיים טיפול.","img":null},{"text":"יש רשת אך שני כיווני השיחות אינם עובדים","img":null},{"text":"עבור ל־R-40 — לא ניתן להוציא ולקבל שיחות. אם רק כיוון אחד אינו עובד, עבור ל־M-40 — אבחון מרכזי קושי בהוצאת או קבלת שיחות. בצע רק בדיקות שטרם הושלמו.","img":null},{"text":"יש רשת אך הגלישה אינה תקינה","img":null},{"text":"עבור ל־M-30 — איטיות או חוסר גלישה אבחון מרכזי. אין להמשיך לסווג את המקרה כחוסר שירות מלא.","img":null},{"text":"יש רשת אך SMS אינו תקין","img":null},{"text":"עבור ל־M-60 — אבחון מרכזי תקלות SMS בארץ. אם גם שירותים אחרים נפגעו, ציין זאת ואל תציג את התקלה כמבודדת ל־SMS.","img":null}],"images":[]},{"num":"15","title":"שלב 6 המשך טיפול כאשר אין שירות","items":[{"text":"אם בדיקות הקו, שיוך ה־SIM, זיהוי הכרטיס או הפרופיל והבדיקות הרלוונטיות במכשיר הושלמו ועדיין אין שירות, עבור ל־E-40 — הסלמה למומחה בתקלת שיחות, משום ששירותי השיחה בקו אינם זמינים. אין להעביר ישירות להנדסה.","img":null},{"text":"אם נמצא ממצא שהנציג אינו מורשה לתקן, או שלא ניתן להשלים בדיקה, ציין זאת כסיבת ההעברה והפרד בין בדיקות תקינות לבין בדיקות שלא הושלמו. אין להצהיר שכל הבדיקות תקינות או שכל המסלול הושלם כאשר הדבר אינו נכון.","img":null},{"text":"בהעברה יש לצרף: מספר המנוי; דגם המכשיר; סוג SIM או eSIM; חיווי הרשת המדויק; מועד תחילת התקלה; תוצאות בדיקת הקו והשיוך; סטטוס ניוד אם רלוונטי; האם הכרטיס או הפרופיל מזוהים והקו מופעל; האם התקלה קיימת גם במקומות אחרים; הפעולות שבוצעו ותוצאותיהן; אילו שירותים נבדקו ואילו אינם זמינים; ממצא שנותר או בדיקה שלא ניתן להשלים.","img":null}],"images":[]},{"num":"16","title":"תסריט שיחה","items":[{"text":"״אנחנו בודקים מדוע הקו אינו מקבל שירות, דרך מצב המנוי, הכרטיס והגדרות המכשיר. אם הבדיקות לא יחזירו את השירות, נעביר את המקרה להמשך בדיקה עם כל הממצאים שכבר אספנו.״","img":null}],"images":[]}],"id":"kbnew_r14","cat":"tech","topicIds":[14],"worlds":["tech"],"status":"published","source":{"name":"R-14 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-14.docx?web=1"},"reviewNotes":["יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."],"track":{"state":"טיוטה חדשה","source":"R-14 אין קליטה אין שירות בארץ - מסלול טיפול.docx","gap":"יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."},"createdAt":1793532360000,"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-14 אין קליטה אין שירות בארץ - מסלול טיפול.docx"};
window.dynamicDocs['kbnew_r45'] = {"kind":"R","topic":"R-45 · 📞 תקלה בחיוג בינלאומי","desc":"מסלול טיפול בתקלה בחיוג בינלאומי.","tags":["חו״ל","שיחות","חיוג בינלאומי"],"stages":[{"num":"1","title":"מידע כללי","items":[{"text":"לקוח מדווח שאינו מצליח לחייג למספר בחו״ל? יש לבצע את הבדיקות לפי הסדר הבא.","img":null}],"images":[]},{"num":"2","title":"1️⃣ בדיקות ראשוניות במערכת","items":[],"images":[]},{"num":"3","title":"לפני שמתחילים בתפעול מול הלקוח","items":[{"text":"לוודא שהשירות חיוג ליעדים בינלאומיים פתוח ופעיל במנוי.","img":null},{"text":"לבדוק שאין חסימה לשיחות יוצאות / שיחות בינלאומיות.","img":null}],"images":[]},{"num":"4","title":"לבצע רענון למפעיל בינלאומי באיזור האישי. (החלפת מפעיל והחזרה למקורי)","items":[{"text":"במידה והלקוח משתמש בתוסף השיחות הבינלאומיות שלנו – לוודא שהתוסף פעיל על הקו.","img":null},{"text":"💡 חשוב: תוסף השיחות הבינלאומיות של wecom הוא שירות דרך 018 אקספון. לקוח שאין לו את התוסף יכול לבצע שיחה בינלאומית דרך מפעיל בינלאומי אחר לפי בחירתו ובתמחור של אותו מפעיל.","img":null}],"images":[]},{"num":"5","title":"2️⃣ בודקים איך הלקוח מחייג","items":[{"text":"יש לוודא שהלקוח מחייג בפורמט תקין.","img":null}],"images":[]},{"num":"6","title":"קידומת מב\"ל נבחר > קידומת מדינה > מספר הטלפון","items":[],"images":[]},{"num":"7","title":"לדוגמה במספר אמריקאי","items":[],"images":[]},{"num":"8","title":"018","items":[],"images":[]},{"num":"9","title":"1XXXXXXXX","items":[{"text":"⚠️ כאשר מוסיפים קידומת מדינה, בדרך כלל יש להסיר את ה־ 0 המקומי שמופיע בתחילת המספר.","img":null}],"images":[]},{"num":"10","title":"חיוג דרך 018","items":[],"images":[]},{"num":"11","title":"018","items":[],"images":[]},{"num":"12","title":"קידומת מדינה","items":[],"images":[]},{"num":"13","title":"מספר הטלפון","items":[{"text":"אם הלקוח משתמש בתוסף השיחות הבינלאומיות של wecom יש לבצע את החיוג דרך 018.","img":null}],"images":[]},{"num":"14","title":"3️⃣ הלקוח עדיין לא מצליח? בודקים דרך הטלפון התפעולי","items":[{"text":"יש לנסות לחייג לאותו מספר יעד בדיוק דרך הקו התפעולי.","img":null}],"images":[]},{"num":"15","title":"✅ השיחה עובדת מהקו התפעולי","items":[{"text":"המשמעות היא שמספר היעד נגיש.","img":null}],"images":[]},{"num":"16","title":"יש","items":[{"text":"לוודא שוב שהלקוח מחייג את המספר בפורמט הנכון.","img":null},{"text":"לבדוק שהוא משתמש בקידומת המתאימה.","img":null},{"text":"לוודא שאין חסימה על הקו שלו.","img":null},{"text":"לאחר רענון, לבקש מהלקוח לבצע מצב טיסה / כיבוי והדלקה ולנסות שוב.","img":null},{"text":"אם השיחה מצליחה מהקו התפעולי אך ממשיכה להיכשל בקו הלקוח, לאחר שנבדקו צורת החיוג, השירות, החסימות והתוסף הרלוונטי ובוצע הרענון — העבר למומחה לפי E-40 — הסלמה למומחה בתקלת שיחות.","img":null},{"text":"צרף את פרטי הבדיקות המפורטים בסעיף התיעוד במסמך, וציין במפורש שהחיוג לאותו יעד ובאותה קידומת מפעיל הצליח מהקו התפעולי אך נכשל בקו הלקוח.","img":null},{"text":"🌐 הלקוח מחייג דרך מפעיל בינלאומי אחר?","img":null},{"text":"לדוגמה: 012 / 013 / 014 וכדומה.","img":null},{"text":"יש לנסות מהקו התפעולי לבצע את אותו חיוג ובאמצעות אותה קידומת מפעיל שבה משתמש הלקוח.","img":null}],"images":[]},{"num":"17","title":"אם גם מהקו התפעולי החיוג דרך אותו מפעיל לא עובד","items":[{"text":"הבעיה ככל הנראה נמצאת בשירות של המפעיל הבינלאומי שבו הלקוח בחר להשתמש.","img":null},{"text":"יש להסביר ללקוח שהקו הסלולרי תקין, אך החיוג דרך אותו מפעיל אינו עובר, ולכן עליו לבדוק את השירות מול המפעיל שבאמצעותו הוא מבצע את השיחה.","img":null},{"text":"⚠️ אין להפנות לקוח אוטומטית לאקספון. אם הלקוח בחר לבצע שיחה מזדמנת דרך מפעיל אחר – הבדיקה מתבצעת מול אותו מפעיל.","img":null}],"images":[]},{"num":"18","title":"4️⃣ השיחה לא עובדת גם מהקו התפעולי דרך 018","items":[],"images":[]},{"num":"19","title":"מבצעים בדיקת השוואה דרך מפעיל נוסף, לדוגמה 012","items":[],"images":[]},{"num":"20","title":"❌ לא עובד גם דרך 012","items":[],"images":[]},{"num":"21","title":"יש לבדוק שוב","items":[{"text":"שקידומת המדינה נכונה.","img":null},{"text":"שמספר הטלפון נכתב בפורמט בינלאומי תקין.","img":null},{"text":"שאין ספרות חסרות / עודפות.","img":null},{"text":"במידת האפשר, לבקש מהלקוח לוודא מול איש הקשר בחו״ל שזה אכן המספר הנכון.","img":null},{"text":"אם החיוג לא עובר דרך מספר מפעילים שונים – קיימת אינדיקציה לכך שהבעיה היא במספר היעד / ביעד עצמו, ולא בשירות 018.","img":null}],"images":[]},{"num":"22","title":"✅ עובד דרך 012 אבל לא דרך 018","items":[],"images":[]},{"num":"23","title":"יש אינדיקציה לתקלה בחיוג דרך 018","items":[{"text":"➡️ יש לפתוח פנייה למומחים עם כל פרטי הבדיקה.","img":null},{"text":"📝 מה חובה לתעד בפנייה למומחים?","img":null},{"text":"כדי למנוע בדיקות חוזרות, יש לציין:","img":null},{"text":"מספר המנוי של הלקוח.","img":null},{"text":"מספר היעד המלא שאליו מנסים לחייג.","img":null},{"text":"מדינת היעד.","img":null},{"text":"צורת החיוג שבוצעה.","img":null},{"text":"האם השירות „חיוג ליעדים בינלאומיים” פתוח.","img":null},{"text":"האם בוצע רענון למפעיל בינלאומי.","img":null},{"text":"האם ללקוח יש תוסף שיחות בינלאומיות.","img":null},{"text":"האם החיוג נכשל גם מהקו התפעולי.","img":null},{"text":"דרך אילו מפעילים נבדק החיוג.","img":null},{"text":"האם דרך מפעיל אחר השיחה הצליחה.","img":null},{"text":"הודעת השגיאה / ההקלטה שהלקוח שומע, אם קיימת.","img":null}],"images":[]},{"num":"24","title":"🎯 כלל אצבע לנציג","items":[{"text":"עובד בתפעולי באותה צורת חיוג - לבדוק את הקו / צורת החיוג של הלקוח.","img":null},{"text":"לא עובד בתפעולי דרך המפעיל שהלקוח בחר, אבל עובד דרך מפעיל אחר - התקלה קשורה למפעיל הבינלאומי.","img":null},{"text":"לא עובד דרך כמה מפעילים שונים - לבדוק את מספר היעד / פורמט המספר / זמינות היעד.","img":null},{"text":"עובד דרך מפעיל אחר אבל לא דרך 018 - פנייה למומחים לבדיקת 018.","img":null}],"images":[]}],"id":"kbnew_r45","cat":"intl","topicIds":[46],"worlds":["tech"],"status":"published","source":{"name":"R-45 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-45.docx?web=1"},"reviewNotes":["יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום.","יש לאמת את הקוד ואת ההפניות מול R-150 לפני אישור."],"track":{"state":"טיוטה חדשה","source":"תקלה בחיוג בינלאומי R-45 .docx","gap":"יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום. יש לאמת את הקוד ואת ההפניות מול R-150 לפני אישור."},"createdAt":1793532360000,"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"תקלה בחיוג בינלאומי R-45 .docx"};
window.dynamicDocs['kbnew_r50'] = {"kind":"R","topic":"R-50 · תקלה לאחר הפעלת SIM או eSIM","desc":"מסלול טיפול לאחר הפעלת SIM או eSIM.","tags":["SIM","eSIM","הפעלה"],"stages":[{"num":"1","title":"מסלול טיפול בחוסר שירות בחוסר גלישה או בגלישה איטית","items":[],"images":[]},{"num":"2","title":"מתי משתמשים במסלול","items":[{"text":"כאשר לאחר הפעלה או החלפה של SIM או eSIM אין שירות בקו, אין גלישה סלולרית או שהגלישה איטית. מתחילים בבדיקות המנוי והכרטיס, ורק לאחר מכן בוחרים את ענף הטיפול לפי התוצאה. אין לבצע במקביל כמה מסלולי תפעול לאותה תקלה.","img":null},{"text":"אם קוד QR לא התקבל, אינו נסרק או שהתקנת פרופיל eSIM טרם הושלמה, עבור ל־R‑51 — קוד QR של eSIM לא נסרק או לא מתקבל. אין לחזור כאן על תהליך הסריקה. אם הפרופיל כבר מותקן אך אין שירות, המשך במסמך זה.","img":null},{"text":"בצע כל בדיקה פעם אחת ותעד את תוצאתה. אין לחזור על פעולה שכבר בוצעה ללא שינוי בתנאי הבדיקה. אם נמצאה בעיה שאינך מורשה או אינך מצליח לתקן, תעד את הממצא והפעולות שבוצעו ועבור לשלב 7 — העברה למומחה. אין לסמן בדיקה שלא הושלמה כתקינה.","img":null}],"images":[]},{"num":"3","title":"שלב 1 בירור התקלה והכרטיס שבשימוש","items":[{"text":"ברר איזה כרטיס הופעל או הוחלף, האם מדובר ב־SIM פיזי או ב־eSIM, באיזה מכשיר הוא בשימוש ומה בדיוק אינו עובד. תעד את מועד ההפעלה ואת מועד תחילת התקלה.","img":null},{"text":"בדוק את החיווי בקו wecom: ״אין שירות״, ״אין רשת״, SOS או רשת סלולרית מוצגת. במכשיר עם שני קווים ודא שהלקוח מתאר את החיווי של הקו הנכון. אי־יכולת לבצע שיחות לבדה אינה מוכיחה שאין רישום לרשת.","img":null}],"images":[]},{"num":"4","title":"שלב 2 בדיקות מנוי ושיוך במערכת","items":[{"text":"בדוק ב־CRM שהמנוי פעיל ושההפעלה הושלמה, ושאין חסימה או הגבלה המשפיעה על השירות. לבדיקת מצב הקו השתמש ב־O‑40 — בדיקת סטטוס קו וחסימות שיחה במערכת, לפי הצורך.","img":null},{"text":"אתר את ה־SIM או ה־eSIM המשויך למנוי והשווה את ה־ICCID ב־CRM לכרטיס או לפרופיל שבשימוש בפועל. בדוק שאין שיוך כפול שגוי של כרטיסים לאותו מנוי. עצם קיומו של כרטיס נוסף אינו סיבה להסירו ללא זיהוי הכרטיס הנכון והתהליך המאושר.","img":null},{"text":"אם נמצאו חוסר התאמה, כפילות שגויה, חסימה או הפעלה שלא הושלמה, טפל לפי הנוהל ובהרשאות הנציג. אין להמשיך בשינויי רשת לפני בירור הממצא. אם לא ניתן להשלים את התיקון במסגרת הטיפול, עבור לשלב 7 עם פירוט הממצא; תקינות השיוך אינה תנאי לקבלת סיוע.","img":null},{"text":"אם התקלה בגלישה, בדוק גם שאין חסימת גלישה ב־CRM ובאזור האישי ושנותר נפח בחבילה. אם הנפח הסתיים או קיימת חסימה, טפל לפי התהליך המתאים לפני תפעול המכשיר. אם נמצא הסבר לתקלה וטופל, בדוק את השירות; אם התקלה נמשכת, המשך לשלב 3.","img":null}],"images":[]},{"num":"5","title":"שלב 3 זיהוי הכרטיס והפעלת הקו במכשיר","items":[],"images":[]},{"num":"6","title":"SIM פיזי","items":[{"text":"ודא שהכרטיס נמצא במגש באופן תקין ושהמכשיר מזהה אותו. אם מופיעה הודעת ״אין SIM״ או שהכרטיס אינו מזוהה, תעד את החיווי. אם בדיקת הישיבה במגש אינה פותרת את הבעיה ולא ניתן להשלים את הטיפול, עבור לשלב 7. אין לבצע החלפת כרטיס כברירת מחדל.","img":null}],"images":[]},{"num":"7","title":"eSIM","items":[{"text":"ודא שהפרופיל מופיע בהגדרות הסלולר ושהקו מופעל. אם הוא כבוי, הפעל את הקו ובדוק שוב. אם הפרופיל חסר או שהתקנתו לא הושלמה, עבור ל־R‑51. אין למחוק פרופיל או להפיק eSIM נוסף כדי לנסות לפתור את התקלה ללא הנחיה בתהליך המאושר.","img":null},{"text":"אם מצב ההתקנה אינו ברור, בדוק את הפרופיל ב־THALES באמצעות ה־ICCID שכבר אומת בשלב 2:","img":null},{"text":"Released — הפרופיל טרם נסרק: עבור ל־R‑51 לבדיקות הסריקה. בדיקת סטטוס ״בתהליך״ ב־CRM לפני ניסיון סריקה מתבצעת במסלול זה.","img":null},{"text":"Installed — הפרופיל הותקן אך אינו פעיל: בדוק שההפעלה באזור האישי הושלמה ושהקו מופעל במכשיר. להשלמת הפעלה השתמש ב־O‑51 או ב־O‑52, בהתאם להצטרפות חדשה או להחלפה במנוי קיים. אם ההפעלה אינה מצליחה, עבור לשלב 7.","img":null},{"text":"Installed_Disabled — הפרופיל מותקן אך כבוי במכשיר: הפעל את הקו בהגדרות הסלולר ובדוק שוב. אם לא ניתן להפעילו, תעד ועבור לשלב 7.","img":null},{"text":"Installed_Enabled — הפרופיל מותקן ופעיל: המשך לשלב 4 אם השירות עדיין אינו תקין. אם הסטטוס או ה־ICCID אינם תואמים למה שמופיע במכשיר ולא ניתן לפתור את הפער, תעד אותו ועבור לשלב 7.","img":null},{"text":"במכשיר עם שני קווים ודא שקו wecom נבחר לשירות הנבדק. בגלישה ודא שהוא נבחר לנתונים סלולריים. אין חובה להגדירו כקו הראשי לכל השירותים אם הוא קו נוסף של הלקוח.","img":null}],"images":[]},{"num":"8","title":"שלב 4 בחירת ענף הטיפול","items":[{"text":"אין שירות, אין רשת, SOS או שיחות חירום בלבד — המשך לשלב 5. אין לבצע בדיקת APN כפתרון לחוסר שירות לפני שהמכשיר נרשם לרשת.","img":null},{"text":"יש רשת אך אין גלישה או שהגלישה איטית — עבור לשלב 6.","img":null},{"text":"יש רשת והתקלה מוגבלת לשיחות — עבור ל־M‑40 לאבחון שיחות. אם התקלה מוגבלת ל־SMS, עבור ל־M‑60. צרף את בדיקות ההפעלה והשיוך שכבר הושלמו; אין לבצע אותן מחדש ללא צורך.","img":null}],"images":[]},{"num":"9","title":"שלב 5 אין שירות לאחר הפעלה","items":[{"text":"לאחר בדיקות הקו והכרטיס, ודא שמצב טיסה כבוי ושבחירת הרשת במכשיר מוגדרת לאוטומטית. אין לחזור על בדיקות השיוך או זיהוי הכרטיס משלב 2 ומשלב 3 אם כבר הושלמו.","img":null},{"text":"אם טרם בוצע, הפעל ובטל מצב טיסה, המתן להתחברות ובדוק את החיווי. אם עדיין אין שירות, כבה והפעל את המכשיר ובדוק שוב. בצע ריענון SIM במערכת רק בהתאם לנוהל הקיים ולהרשאות הנציג; לאחר פעולה במערכת בצע את בדיקת התוצאה שנקבעה בנוהל.","img":null},{"text":"הרישום לרשת חזר — בדוק את השירותים לפי שלב 8. אם נשארה רק תקלה בגלישה, המשך לשלב 6 בלי לחזור על פעולות שכבר בוצעו. אם עדיין אין שירות לאחר הבדיקות והפעולות הרלוונטיות שבסמכות הנציג, עבור לשלב 7.","img":null}],"images":[]},{"num":"10","title":"שלב 6 יש רשת אך אין גלישה או שהגלישה איטית","items":[{"text":"הסתמך על בדיקות החסימות, נפח החבילה והשיוך משלב 2 ועל בחירת הקו משלב 3. אין לבצע אותן מחדש אם לא חל שינוי. ודא שנתונים סלולריים פעילים וכבה Wi-Fi לצורך בדיקת גלישה סלולרית. לתפעול הבסיסי השתמש ב־O‑31.","img":null},{"text":"בצע לפי הסדר רק פעולות שטרם בוצעו: הפעלה וביטול של מצב טיסה; כיבוי והפעלת המכשיר; ויתר פעולות ריענון ה־SIM בהתאם לנוהל ולהרשאות הנציג. לאחר כל פעולה בדוק האם הגלישה חזרה. אם התקלה נפתרה, עבור לשלב 8.","img":null},{"text":"אם התקלה נמשכת לאחר פעולות התפעול והריענון, בדוק את ה־APN באמצעות O‑32 — הגדרת APN במכשיר, ותקן רק אם נדרש בהתאם למסמך. לאחר הבדיקה או השינוי בדוק שוב גלישה כשה־Wi-Fi כבוי. אין לשנות ערך שכבר נבדק ונמצא תקין.","img":null},{"text":"הגלישה חזרה לתפקוד תקין — עבור לשלב 8. אם הגלישה פועלת אך עדיין איטית, המשך ב־M‑30 ובמסלול האיטיות המתאים למדידה ולהערכת התוצאה, עם פירוט הבדיקות שכבר בוצעו. אם עדיין אין גלישה לאחר השלמת הבדיקות והפעולות הרלוונטיות שבסמכות הנציג, עבור לשלב 7.","img":null}],"images":[]},{"num":"11","title":"שלב 7 העברה למומחה","items":[{"text":"לאחר ביצוע כל הבדיקות והפעולות הרלוונטיות שבסמכות הנציג, אם התקלה עדיין קיימת — העבר למומחה. אם נמצא ממצא שלא ניתן לתקן במסגרת הרשאות הנציג, או שלא ניתן להשלים בדיקה או פעולה, תעד את הסיבה והעבר עם הממצאים שנאספו. אין חובה שכל התוצאות יהיו תקינות כתנאי להעברה.","img":null},{"text":"בחוסר שירות או בתקלה בשיחות פעל לפי E‑40 — הסלמה למומחה בתקלת שיחות. בתקלה בגלישה פעל לפי E‑30 — העברה למומחה בתקלת גלישה. אם המשכת ל־R‑51 או למסלול אחר, פעל לפי הוראות ההמשך שלו ולא במקביל למסלול הנוכחי.","img":null},{"text":"צרף לפנייה: מספר מנוי; דגם המכשיר; סוג הכרטיס וה־ICCID; מועד ההפעלה ותחילת התקלה; התרחיש והחיווי המדויקים; סטטוס המנוי; תוצאת בדיקת השיוך והכפילות; ב־eSIM גם סטטוס THALES ומצב הקו במכשיר; חסימות ונפח חבילה אם נבדקו; הפעולות ותוצאותיהן; בדיקת APN אם נדרשה; וכל ממצא שנותר או בדיקה שלא הושלמה.","img":null},{"text":"אין להעביר ישירות להנדסה ואין לתעד שכל הבדיקות תקינות כאשר נותר ממצא לא פתור. פתיחת פנייה אינה אישור שהתקלה נפתרה.","img":null}],"images":[]},{"num":"12","title":"שלב 8 בדיקות סיום ותיעוד","items":[{"text":"לאחר חזרת השירות בדוק קליטה, שיחה יוצאת ושיחה נכנסת, שליחה וקבלה של SMS רגיל וגלישה סלולרית כשה־Wi-Fi כבוי. ודא שהבדיקות מתבצעות בקו wecom ולא בקו נוסף במכשיר.","img":null},{"text":"כל השירותים שנבדקו תקינים — תעד מה פתר את התקלה ואת תוצאות הבדיקות, וסיים טיפול. חיווי רשת שחזר לבדו אינו מספיק לסיום.","img":null},{"text":"נשארה תקלה בשירות מסוים — המשך רק במסלול הרלוונטי: גלישה לפי שלב 6, שיחות לפי M‑40 או הודעות לפי M‑60. העבר את הבדיקות שכבר בוצעו והימנע מחזרה על אותו רצף. אם מסלול הטיפול הרלוונטי מוצה, פעל לפי תנאי ההעברה שבו.","img":null}],"images":[]}],"id":"kbnew_r50","cat":"sim","topicIds":[4],"worlds":["tech"],"status":"published","source":{"name":"R-50 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-50.docx?web=1"},"reviewNotes":["יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."],"track":{"state":"טיוטה חדשה","source":"R-50_מסלול טיפול לאחר הפעלת_SIM_eSIM.docx","gap":"יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."},"createdAt":1793532360000,"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-50_מסלול טיפול לאחר הפעלת_SIM_eSIM.docx"};
window.dynamicDocs['kbnew_r51'] = {"kind":"R","topic":"R-51 · קוד QR של ESIM לא נסרק / לא מתקבל","desc":"מסלול טיפול כאשר קוד QR של eSIM לא מתקבל או לא נסרק.","tags":["eSIM","QR"],"stages":[{"num":"1","title":"מידע כללי","items":[{"text":"אם קוד QR לא התקבל – יש לוודא שנשלח למייל תקין /מייל של לקוח מעודכן נכון – ולשלוח שוב .","img":null}],"images":[]},{"num":"2","title":"במידה ויש צורך בעדכון כתובת מייל יש לקחת פרטי זיהוי מלאים","items":[],"images":[]},{"num":"3","title":"שליחת קוד QR מחדש","items":[{"text":"במידה ויש צורך לשלוח שוב אחרי עדכון פרטי מייל – יש להכינס ל\"SIM\" ב CRM – תחת מנוי לקוח וללחוץ על \"שלח QR\"","img":null},{"text":"אין להפיק ESIM חדש !","img":null}],"images":[]},{"num":"4","title":"⚠️ לפני שמתחילים – דגשים חשובים","items":[{"text":"יש לוודא שהמכשיר תומך eSIM ושאפשרות \"הוספת \"eSIM” קיימת בהגדרות.","img":null},{"text":"מומלץ לוודא שמערכת ההפעלה מעודכנת. אין להתחייב שהתקנת eSIM תצליח במכשיר עם גרסת מערכת לא מעודכנת.","img":null},{"text":"המכשיר חייב להיות מחובר ל־ Wi-Fi / אינטרנט פעיל בזמן הורדת הפרופיל.","img":null},{"text":"לא ניתן לבצע את הסריקה במהלך שיחת טלפון.","img":null},{"text":"קוד ה־QR מיועד ל־eSIM ולמספר שעבורם הופק - יש לוודא שהוא משויך למספר הנכון.","img":null},{"text":"אין לסרוק את אותו QR בשני מכשירים שונים.","img":null},{"text":"אין לשלוח QR לכתובת מייל או מספר טלפון שאינם רשומים במערכת.","img":null},{"text":"אם קיימת אפשרות eSIM בדגם באופן כללי אך \"הוספת \"eSIM אינה מופיעה בפועל בהגדרות המכשיר, יש לוודא קודם שהמכשיר מעודכן. אם גם לאחר מכן האפשרות אינה קיימת - אין להתקדם בהתקנה ואין להתחייב לתמיכה במכשיר הספציפי.","img":null}],"images":[]},{"num":"5","title":"טיפ חשוב לנציג","items":[{"text":"במידת הצורך ניתן לבדוק במכשיר את ה־ICCID של ה־ eSIM שהותקן ולוודא שהוא תואם ל־ICCID שמופיע ב־CRM.","img":null},{"text":"כך ניתן לוודא שהפרופיל שהותקן הוא אכן הפרופיל הנכון.","img":null},{"text":"🔎 בדיקת מצב ה־ eSIM ב־THALES (מערכת לבדיקת סריקת איסימים)","img":null},{"text":"במקרה של ספק האם ה־QR נסרק / הותקן / הופעל, ניתן לבצע בדיקה לפי ICCID","img":null},{"text":"מחפשים את ה־ ICCID ובודקים את Latest Info – Status","img":null}],"images":[]},{"num":"6","title":"מקרא סטטוסים","items":[],"images":[]},{"num":"7","title":"סטטוס","items":[],"images":[]},{"num":"8","title":"משמעות","items":[{"text":"Released","img":null},{"text":"הפרופיל עדיין לא נסרק","img":null},{"text":"Installed","img":null},{"text":"הפרופיל הותקן אך אינו פעיל","img":null},{"text":"Installed_Enabled","img":null},{"text":"הפרופיל מותקן ופעיל","img":null},{"text":"Installed_Disabled","img":null},{"text":"הפרופיל הותקן והופעל בעבר, אך כעת כבוי/מושבת במכשיר","img":null},{"text":"מה עוד ניתן לבדוק?","img":null}],"images":[]},{"num":"9","title":"במסך ניתן לראות גם","items":[{"text":"ICCID – ולוודא שתואם ל־CRM","img":null},{"text":"Device Name – סוג המכשיר שעליו ה־ eSIM נסרק.","img":null},{"text":"Number of Installations – מידע על התקנות הפרופיל.","img":null},{"text":"Number of failed Confirmation code attempts – ניסיונות כושלים בהזנת קוד אימות.","img":null},{"text":"Required Confirmation Code – האם הפרופיל בכלל דורש Confirmation Code.","img":null},{"text":"📌 בדיקת Device Name שימושית במיוחד כאשר רוצים להבין האם ה־ QR נסרק בטעות על מכשיר אחר.","img":null}],"images":[]},{"num":"10","title":"❌ קוד QR לא נסרק","items":[{"text":"אם הסריקה אינה מצליחה, יש לבצע את הבדיקות לפי הסדר:","img":null},{"text":"לוודא שהמכשיר מחובר ל־Wi-Fi / אינטרנט פעיל.","img":null},{"text":"לוודא שלא מתבצעת כרגע שיחת טלפון.","img":null},{"text":"לוודא שאפשרות „הוספת eSIM” קיימת במכשיר.","img":null},{"text":"לוודא שגרסת מערכת ההפעלה מעודכנת.","img":null},{"text":"לוודא שה־QR מוצג במלואו ובצורה ברורה.","img":null},{"text":"להעלות את בהירות המסך שעליו מוצג ה־QR.","img":null},{"text":"לוודא שמנסים לסרוק את הקוד מהמכשיר שעליו רוצים להתקין את ה־ eSIM","img":null},{"text":"לוודא שהמכשיר אינו נעול למפעיל אחר.","img":null},{"text":"לוודא שה־QR משויך למספר הנכון.","img":null},{"text":"לבדוק ב־SM-DP את סטטוס הפרופיל.","img":null},{"text":"מה אומר הסטטוס?","img":null},{"text":"Released - הקוד עדיין לא נסרק.","img":null},{"text":"Installed / Installed_Enabled / Installed_Disabled הקוד כבר הגיע לשלב התקנה במכשיר ולכן אין להתייחס אליו כאל QR שטרם נסרק.","img":null},{"text":"🔄 ה־ QR כבר נסרק אבל ההתקנה לא הושלמה","img":null},{"text":"לא ממשיכים שוב ושוב עם אותו QR","img":null},{"text":"יש:","img":null},{"text":"לבדוק ב־ THALESאת הסטטוס.","img":null},{"text":"לבדוק על איזה Device Name בוצעה ההתקנה.","img":null},{"text":"לוודא שה־ICCID במכשיר תואם ל־CRM","img":null},{"text":"אם נדרש ניסיון התקנה מחדש – להעביר את ה־ eSIM ב־ CRM לסטטוס \"בתהליך”.","img":null},{"text":"לשלוח מחדש QR","img":null},{"text":"לבצע התקנה מחדש.","img":null},{"text":"רק לאחר שהפרופיל מופיע במכשיר – לבצע הפעלה באזור האישי.","img":null}],"images":[]},{"num":"11","title":"📩 הלקוח לא קיבל QR","items":[{"text":"יש לבדוק:","img":null},{"text":"האם כתובת המייל הרשומה במערכת נכונה.","img":null},{"text":"בדיקה אם קובץ הסריקה התקבל לספאם במייל","img":null},{"text":"לשלוח מחדש מתוך ה־CRM","img":null},{"text":"אין להפיק esim חדש !","img":null}],"images":[]},{"num":"12","title":"📵 ה־ eSIM הותקן אבל אין קליטה","items":[{"text":"כאן כבר לא מדובר בתקלה בסריקת QR","img":null}],"images":[]},{"num":"13","title":"יש לבדוק","items":[{"text":"שהסטטוס ב־ THALESהוא Installed_Enabled","img":null},{"text":"שהקו עבר הפעלה/אקטוב בהצלחה.","img":null},{"text":"שה־ eSIM פעיל בהגדרות המכשיר.","img":null},{"text":"שה־eSIM מוגדר כקו הראשי.","img":null},{"text":"שה־ICCID במכשיר תואם ל ־ CRM","img":null},{"text":"שאין כפילות SIM/eSIM על המנוי.","img":null},{"text":"לבצע כיבוי והדלקה.","img":null},{"text":"לבדוק רישום לרשת.","img":null},{"text":"אם הפרופיל נוסף למכשיר אך אין קליטה, הנוהל הקודם שלנו גם מגדיר לבדוק את סטטוס האקטוב, הגדרת הקו כראשי והפעלת המכשיר מחדש.","img":null},{"text":"iMessage / FaceTime 💬 לאחר ההפעלה","img":null},{"text":"במכשירי iPhone ייתכן עיכוב בהפעלת iMessage / FaceTime לאחר התקנה או מעבר של eSIM.","img":null},{"text":"אם:","img":null},{"text":"שיחות + SMS + גלישה עובדים תקין","img":null},{"text":"אין להסיק רק בגלל עיכוב ב־ iMessage/FaceTime שה־ eSIM לא הותקן או שהקו תקול.","img":null}],"images":[]},{"num":"14","title":"✅ צ'ק־ליסט קצר לנציג","items":[{"text":"לפני הפעלה: QR נכון - Wi-Fi - סריקה מהמכשיר הנכון - הפרופיל מופיע במכשיר - ICCID תואם.","img":null},{"text":"אחר כך: הפעלת eSIM באזור האישי - הגדרת הקו כראשי - הפעלה מחדש - שיחה - SMS - גלישה.","img":null},{"text":"אם לא הצליח: THALES - ICCID - Status - Device Name - Confirmation Code - ורק בהתאם לממצא ממשיכים לתפעול.","img":null}],"images":[]}],"id":"kbnew_r51","cat":"sim","topicIds":[5],"worlds":["tech"],"status":"published","source":{"name":"R-51 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/R-51.docx?web=1"},"reviewNotes":["יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."],"track":{"state":"טיוטה חדשה","source":"R-51 קוד QR  של ESIM לא נסרק - לא מתקבל .docx","gap":"יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."},"createdAt":1793532360000,"publishedAt":1793612878318,"updatedAt":1793612878318,"originName":"R-51 קוד QR  של ESIM לא נסרק - לא מתקבל .docx"};
window.dynamicDocs['kbhq_o200'] = {"id":"kbhq_o200","kind":"O","topic":"O-200 · נוהל העברת בעלות","cat":"hq","topicIds":[1014],"worlds":["hq"],"desc":"התהליך המלא לטיפול בבקשה להעברת בעלות על חשבון וקווים ללקוח אחר: מסמכים בגלסיקס, אישורים מוקלטים, חשבון חדש והעברת הקווים ב-CRM.","tags":["העברת בעלות","גלסיקס","CRM"],"owner":"","stages":[],"status":"pending","body":{"groups":[{"title":"מטרת הנוהל","ordered":false,"steps":[{"text":"מדריך זה מתאר, צעד אחר צעד, את התהליך לטיפול בבקשת לקוח להעברת בעלות על חשבון וקווים ללקוח אחר.","img":null},{"text":"העברת בעלות היא פעולה רגישה. הנוהל נועד להבטיח שההעברה מתבצעת רק בהסכמה אמיתית של שני הצדדים, למנוע ניסיונות הונאה, ולשמור בידי החברה תיעוד מלא ומוקלט של האישורים.","img":null}]},{"title":"מבט על התהליך","ordered":true,"steps":[{"text":"הלקוח פונה ומבקש להעביר בעלות.","img":null},{"text":"הנציג שולח את המסמכים למילוי דרך הגלסיקס.","img":null},{"text":"הלקוחות מחזירים מסמכים חתומים וצילומי תעודת זהות.","img":null},{"text":"הנציג מקבל אישור מוקלט מהלקוח המעביר.","img":null},{"text":"הנציג מקבל אישור מהלקוח החדש ומקים לו חשבון.","img":null},{"text":"הנציג מעביר את הקווים בין החשבונות ב-CRM.","img":null}]},{"title":"שלב 1: קבלת הפנייה","ordered":false,"steps":[{"text":"הלקוח פונה אל החברה ומבקש לבצע העברת בעלות. בשלב זה הנציג מתחיל את הטיפול ומכין את המשך התהליך.","img":null}]},{"title":"שלב 2: שליחת המסמכים דרך הגלסיקס","ordered":false,"steps":[{"text":"הנציג שולח מסמך העברת בעלות:","img":null},{"text":"<b>מסמך ללקוח המעביר:</b> הלקוח שבבעלותו החשבון כיום ממלא אותו.","img":null},{"text":"<b>מסמך ללקוח החדש:</b> הלקוח שיקבל את הבעלות ממלא אותו.","img":null}]},{"title":"שלב 3: קבלת המסמכים וצילומי תעודת זהות","ordered":false,"steps":[{"text":"לאחר שהמסמכים מולאו, הלקוח שולח לנציג גם צילום תעודת זהות של <b>שני</b> הצדדים בהעברה: המעביר והחדש.","img":null},{"text":"לפני שממשיכים, כדאי לוודא שכל המסמכים התקבלו ושצילומי שתי תעודות הזהות מצורפים.","img":null}]},{"title":"שלב 4: אישור מוקלט מהלקוח המעביר","ordered":false,"steps":[{"text":"הנציג מתקשר לבעל החשבון המעביר ומקבל ממנו אישור מוקלט שהוא מאשר את ביצוע ההעברה.","img":null},{"text":"<b>שתי מטרות לשלב הזה:</b>","img":null},{"text":"לוודא שאין הונאה, ושבעל החשבון עצמו אכן מעוניין בהעברה.","img":null},{"text":"לכסות את החברה מבחינת אישור, באמצעות הקלטה שמתעדת את ההסכמה.","img":null}]},{"title":"שלב 5: אישור מהלקוח החדש והקמת חשבון","ordered":false,"steps":[{"text":"הנציג מתקשר ללקוח החדש ומקבל גם ממנו אישור.","img":null},{"text":"לאחר קבלת האישור הנציג מקים עבורו <b>חשבון חדש</b> הכולל:","img":null},{"text":"הפרטים האישיים של הלקוח החדש.","img":null},{"text":"אמצעי תשלום חדש.","img":null}]},{"title":"שלב 6: העברת הקווים","ordered":false,"steps":[{"text":"לאחר קבלת כל האישורים והקמת החשבון, הנציג מבצע את ההעברה ב-CRM.","img":null}]},{"title":"רשימת בדיקה לנציג","ordered":false,"steps":[{"text":"<b>לפני סגירת הטיפול, ודאו ש:</b>","img":null},{"text":"הפנייה התקבלה והועברו שני המסמכים בגלסיקס.","img":null},{"text":"מסמכים מלאים התקבלו משני הצדדים.","img":null},{"text":"צילומי תעודת זהות של המעביר ושל החדש התקבלו.","img":null},{"text":"אישור מוקלט התקבל מהלקוח המעביר.","img":null},{"text":"אישור התקבל מהלקוח החדש.","img":null},{"text":"חשבון חדש הוקם עם פרטים אישיים ואמצעי תשלום.","img":null},{"text":"הקווים הועברו לחשבון החדש ב-CRM.","img":null}]}]},"originName":"O-200 מדריך נוהל העברת בעלות.docx","source":{"name":"O-200 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-200.docx?web=1"},"track":{"state":"טיוטה חדשה","priority":"","gap":"טיוטת Word לבדיקה: 5 פערים מסומנים ⚠ חסר","source":"O-200 מדריך נוהל העברת בעלות.docx"},"reviewNotes":["פריט חדש ממדריכי מטה: יש להשוות למסמך המקור ולהשלים את הפערים המסומנים לפני אישור ופרסום."],"createdAt":1794400800000,"updatedAt":1794400800000};
window.dynamicDocs['kbhq_o201'] = {"id":"kbhq_o201","kind":"O","topic":"O-201 · סיכום מדריכי חישובי נתונים","cat":"hq","topicIds":[1015],"worlds":["hq"],"desc":"חישוב עמלות ונתונים בתחילת חודש (TSF, אחוז מענה, זמן שיחה ממוצע, פיריון) והכנת דוח למשרד התקשורת.","tags":["דוחות","מוניטור","משרד התקשורת"],"owner":"","stages":[],"status":"pending","body":{"groups":[{"title":"חישוב עמלות ונתונים בתחילת חודש","ordered":false,"steps":[{"text":"<b>מיקום הדוחות:</b> מוניטור &gt; מטה wecom &gt; תת מוניטור \"דוחות ירין\"","img":null}]},{"title":"חישוב TSF","ordered":false,"steps":[{"text":"<b>דוח מקור:</b> נתוני TSF שירות חודשי/יומי","img":null},{"text":"<b>שירות:</b> שירות, סיום התקשרות","img":null},{"text":"<b>תמיכה:</b> תמיכה טכנית, חו\"ל","img":null},{"text":"<b>חישוב – מונה:</b> שיחות ברמת שירות A + יציאה מהתור","img":null},{"text":"<b>חישוב – מכנה:</b> סך כל השיחות","img":null}]},{"title":"אחוז מענה","ordered":false,"steps":[{"text":"<b>דוח מקור:</b> שירות לקוחות חודשי/יומי","img":null},{"text":"<b>שירות:</b> שירות, סיום התקשרות, תשלום חוב","img":null},{"text":"<b>תמיכה:</b> תמיכה טכנית, חו\"ל","img":null},{"text":"<b>חישוב:</b> אחוז השיחות שנענו, כולל שיחות חוזרות","img":null}]},{"title":"זמן שיחה ממוצע","ordered":false,"steps":[{"text":"הנתון נלקח מעמודת \"ממוצע משך שיחה\" בדוחות מסכמים.","img":null}]},{"title":"חישוב פיריון","ordered":false,"steps":[{"text":"<b>מיקום הדוחות:</b> מוניטור &gt; שירות לקוחות wecom &gt; לשונית \"דוחות\" &gt; שני הדוחות הראשונים שנקראים \"Table – User Performance extended\" – הראשון שירות, השני תמיכה","img":null},{"text":"<b>נוסחה – מונה:</b> משך מחובר נטו + משך תקשורת כתובה − משך תדריך","img":null},{"text":"<b>נוסחה – מכנה:</b> כלל השיחות הנכנסות + שיחות חייגן + פניות גלסיקס","img":null},{"text":"<b>פניות גלסיקס:</b> מוציאים מדוח \"דוח פניות מפורט\" ומסננים לפי נציג באקסל.","img":null},{"text":"<b>תבנית מוכנה:</b> קיים דוח \"דוח תבנית פיריון\" – רק צריך למלא בו את הנתונים לפי ההוראות שרשומות בתוכו.","img":null}]},{"title":"הכנת דוח למשרד התקשורת","ordered":false,"steps":[{"text":"הדוח מציג למשרד התקשורת נתוני זמינות, מענה, נטישות וקולבקים, לפי תקופות הזמן שהמשרד מציין.","img":null}]},{"title":"שלבי העבודה","ordered":true,"steps":[{"text":"<b>מיקום הדוח:</b> wecom מטה &gt; תת מוניטור \"דוחות 2026\" &gt; לשונית MOC","img":null},{"text":"להדביק את הנתונים בהתאם למה שמשרד התקשורת ביקש.","img":null}]},{"title":"מה רלוונטי בדוח","ordered":false,"steps":[{"text":"עמודת \"סטטוס שיחה\" – הערכים שחשובים:","img":null},{"text":"<b>ANSWER</b> – שיחות שנענו","img":null},{"text":"<b>ABANDONED</b> – שיחות שננטשו","img":null},{"text":"<b>CALLBACK</b> – שיחת קולבק","img":null},{"text":"עמודת \"שם מעגל\" – משמשת לבחירת המוקדים הרלוונטיים (שירות / תמיכה).","img":null}]}]},"originName":"O-201 סיכום מדריכי חישובי נתונים.docx","source":{"name":"O-201 – מסמך מקור מעוצב","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/formatted-source/O-201.docx?web=1"},"track":{"state":"טיוטה חדשה","priority":"","gap":"טיוטת Word לבדיקה: 4 פערים מסומנים ⚠ חסר","source":"O-201 סיכום מדריכי חישובי נתונים.docx"},"reviewNotes":["פריט חדש ממדריכי מטה: יש להשוות למסמך המקור ולהשלים את הפערים המסומנים לפני אישור ופרסום."],"createdAt":1794400800000,"updatedAt":1794400800000};
// END GENERATED SOURCE ITEMS


// ── TYPE-SPECIFIC CONTENT (spec §3–5, §8) ───────────────────────────────
// R and S items keep the step builder (doc.stages). The other types store
// their own content shape in doc.body:
//   O  {groups:[{title, steps:[{text,img}]}]}            numbered procedure, optional groups (e.g. per device)
//   I  {html}                                            rich text: headings, lists, tables, links, images
//   T  {scripts:[{situation, lines:[text]}]}             situation → suggested wording
//   E  {when:[], to:[], conditions:[], document:[], extra:[{title, lines:[]}]}
//   M  {intro:[], questions:[{title, q, hint, answers:[{text, note, go}]}], outro:[]}
//      go = 'q:<index>' (next question) | 'item:<id>' (open a knowledge item) | '' (end)
//      title = step name (optional). When every question has one, the item is
//      shown as an operational tree: all steps, each answer linking onwards.
//      ext = name of a document that is not in the app yet (answers with no go).
// Items written before these editors existed (and the built-in documents)
// have only stages; they are converted on display, and saved in the new
// shape the next time an editor saves them.

function nbIsStageKind(k){ return k==='R'||k==='S'||!NB_KINDS[k]; }
function nbLines(s){ return String(s||'').split('\n').map(function(x){return x.trim();}).filter(Boolean); }
function nbPlain(s){ return String(s==null?'':s).replace(/<[^>]*>/g,''); }

// Built-in typed content that is kept outside the seed documents. (The abroad
// documents now carry their own body in the seed, e.g. pdf_011 — M-00.)
var NB_SEED_BODIES={};

function nbStageItems(s){ return (s.items||[]).map(function(i){return typeof i==='object'?i:{text:i,img:null};}); }

function nbBodyFromStages(doc){
  var st=doc.stages||[];
  switch(doc.kind){
    case 'O': return {groups:st.map(function(s){return {title:s.title,steps:nbStageItems(s).map(function(i){return {text:i.text,img:i.img||null};})};})};
    case 'I': return {html:st.map(function(s){
      return '<h3>'+s.title+'</h3><ul>'+nbStageItems(s).map(function(i){return '<li>'+i.text+(i.img?'<br><img src="'+i.img+'">':'')+'</li>';}).join('')+'</ul>';
    }).join('')};
    case 'T': return {scripts:st.map(function(s){return {situation:s.title,lines:nbStageItems(s).map(function(i){return i.text;})};})};
    case 'E':
      var b={when:[],to:[],conditions:[],document:[],extra:[]};
      st.forEach(function(s){
        var t=nbPlain(s.title), L=nbStageItems(s).map(function(i){return i.text;});
        if(/מתי/.test(t)) b.when=b.when.concat(L);
        else if(/למי|לאן/.test(t)) b.to=b.to.concat(L);
        else if(/ודא|תנאי/.test(t)) b.conditions=b.conditions.concat(L);
        else if(/מתעד|תיעוד|לתעד/.test(t)) b.document=b.document.concat(L);
        else b.extra.push({title:s.title,lines:L});
      });
      return b;
    case 'M':
      return {intro:[].concat.apply([],st.map(function(s){return nbStageItems(s).map(function(i){return i.text;});})),questions:[],outro:[]};
  }
  return null;
}

// Content to display for an item: its own body, a built-in diagnosis, or a
// conversion of its steps. null → show the classic step view.
function nbGetBody(doc){
  if(nbIsStageKind(doc.kind)) return null;
  if(doc.body) return doc.body;
  if(NB_SEED_BODIES[doc.id]) return NB_SEED_BODIES[doc.id];
  if(doc.kind==='M') return null; // prose diagnosis without questions yet
  return (doc.stages&&doc.stages.length)?nbBodyFromStages(doc):null;
}
// Content to load into the editor (never null for typed kinds).
function nbBodyForEditor(doc){
  var b=doc.body||NB_SEED_BODIES[doc.id]||nbBodyFromStages(doc)||nbEmptyBody(doc.kind);
  return JSON.parse(JSON.stringify(b));
}
function nbEmptyBody(k){
  switch(k){
    case 'O': return {groups:[{title:'',steps:[{text:'',img:null}]}]};
    case 'I': return {html:''};
    case 'T': return {scripts:[{situation:'',lines:[]}]};
    case 'E': return {when:[],to:[],conditions:[],document:[],extra:[]};
    case 'M': return {intro:[],questions:[{q:'',hint:'',answers:[{text:'',note:'',go:''},{text:'',note:'',go:''}]}],outro:[]};
  }
  return {};
}

// ── Rich text cleaning (type I) ──
// Keeps structure (headings, lists, tables, links, images) and drops
// everything else — including the styling Word adds when pasting.
var NB_RICH_TAGS={H2:1,H3:1,H4:1,P:1,BR:1,B:1,STRONG:1,I:1,EM:1,U:1,UL:1,OL:1,LI:1,A:1,TABLE:1,THEAD:1,TBODY:1,TR:1,TH:1,TD:1,IMG:1,BLOCKQUOTE:1,HR:1};
function nbSanitizeRich(html){
  var tpl=document.createElement('template');
  tpl.innerHTML=String(html||'');
  (function clean(node){
    Array.prototype.slice.call(node.childNodes).forEach(function(ch){
      if(ch.nodeType===3) return;
      if(ch.nodeType!==1){ ch.remove(); return; }
      var tag=ch.tagName.toUpperCase();
      if(/^(SCRIPT|STYLE|META|LINK|TITLE|XML|IFRAME|OBJECT|EMBED|FORM|INPUT|BUTTON|SELECT|TEXTAREA)$/.test(tag)||tag.indexOf(':')!==-1){ ch.remove(); return; }
      clean(ch);
      if(!NB_RICH_TAGS[tag]){
        if(tag==='DIV'||tag==='H1'||tag==='H5'||tag==='H6'){
          var p=document.createElement(tag==='DIV'?'p':(tag==='H1'?'h2':'h4'));
          while(ch.firstChild) p.appendChild(ch.firstChild);
          ch.replaceWith(p);
        } else {
          ch.replaceWith.apply(ch,Array.prototype.slice.call(ch.childNodes));
        }
        return;
      }
      Array.prototype.slice.call(ch.attributes).forEach(function(a){
        var n=a.name.toLowerCase(), v=a.value;
        var keep=(tag==='A'&&n==='href'&&/^(https?:|mailto:|tel:)/i.test(v))
          ||(tag==='IMG'&&n==='src'&&/^(https?:|data:image\/(png|jpe?g|gif|webp);base64,)/i.test(v))
          ||((tag==='TD'||tag==='TH')&&(n==='colspan'||n==='rowspan'));
        if(!keep) ch.removeAttribute(a.name);
      });
      // Images/links whose address was unsafe and got removed are dropped.
      if(tag==='IMG'&&!ch.getAttribute('src')){ ch.remove(); return; }
      if(tag==='A'&&!ch.getAttribute('href')){ ch.replaceWith.apply(ch,Array.prototype.slice.call(ch.childNodes)); return; }
      if(tag==='A'){ ch.setAttribute('target','_blank'); ch.setAttribute('rel','noopener'); }
    });
  })(tpl.content);
  return tpl.innerHTML.replace(/<p>(\s|&nbsp;|<br>)*<\/p>/g,'').trim();
}

// Drops empty rows so saved items stay clean.
function nbCleanBody(k,b){
  b=JSON.parse(JSON.stringify(b||nbEmptyBody(k)));
  var nonEmpty=function(s){return String(s||'').trim()!=='';};
  switch(k){
    case 'O':
      b.groups=(b.groups||[]).map(function(g){
        var out={title:(g.title||'').trim(),steps:(g.steps||[]).filter(function(s){return nonEmpty(s.text)||s.img;})};
        if(g.ordered===false) out.ordered=false;
        return out;
      })
        .filter(function(g){return g.steps.length;});
      break;
    case 'I': b.html=nbSanitizeRich(b.html); break;
    case 'T':
      b.scripts=(b.scripts||[]).map(function(s){return {situation:(s.situation||'').trim(),lines:(s.lines||[]).filter(nonEmpty)};})
        .filter(function(s){return s.lines.length||s.situation;});
      break;
    case 'E':
      ['when','to','conditions','document'].forEach(function(f){b[f]=(b[f]||[]).filter(nonEmpty);});
      b.extra=(b.extra||[]).map(function(x){return {title:(x.title||'').trim(),lines:(x.lines||[]).filter(nonEmpty)};}).filter(function(x){return x.lines.length;});
      break;
    case 'M':
      b.intro=(b.intro||[]).filter(nonEmpty); b.outro=(b.outro||[]).filter(nonEmpty);
      b.questions=(b.questions||[]).map(function(q){return {title:(q.title||'').trim(),q:(q.q||'').trim(),hint:(q.hint||'').trim(),
        answers:(q.answers||[]).filter(function(a){return nonEmpty(a.text);}).map(function(a){var o={text:a.text.trim(),note:(a.note||'').trim(),go:a.go||''};if(a.ext&&!o.go) o.ext=String(a.ext).trim();return o;})};});
      break;
  }
  return b;
}
function nbBodyHasContent(k,b){
  switch(k){
    case 'O': return b.groups.length>0;
    case 'I': return nbPlain(b.html).trim()!==''||/<img/i.test(b.html);
    case 'T': return b.scripts.some(function(s){return s.lines.length;});
    case 'E': return ['when','to','conditions','document'].some(function(f){return b[f].length;})||b.extra.length>0;
    case 'M': return b.questions.some(function(q){return q.q&&q.answers.length;});
  }
  return true;
}

// ── AGENT VIEWS ─────────────────────────────────────────────────────────
// Display spec per type (knowledge_prompts, Nov 2026). The content and its
// order come from the source and never change with what the agent clicks:
// opening and closing stages, jumping, going back and copying wording are
// reading aids only. Nothing is hidden because of an answer, nothing is
// locked, and no question has to be answered before moving on.
var NB_VIEW={
  M:{label:'אבחון',back:'לאבחון'},
  R:{label:'טיפול',back:'למסלול הטיפול'},
  O:{label:'תפעול',back:'למסמך התפעול'},
  E:{label:'העברה לגורם נוסף',back:'להנחיות ההעברה'},
  S:{label:'מסלול מומחה',back:'למסלול המומחה'},
  T:{label:'ניסוח ללקוח',back:'לתסריטי השיחה'},
  I:{label:'מידע',back:'למסמך המידע'}
};
function nbViewOf(k){ return NB_VIEW[k]||NB_VIEW.R; }
// An item's title without its code ("R-01 · אין קליטה…" → code R-01, title "אין קליטה…").
function nbSplitTitle(topic){
  var t=nbPlain(topic).trim(), m=/^([A-Z]-\d{2,3})(?!\d)\s*[·\-–—:]?\s*/.exec(t);
  return m?{code:m[1],title:t.slice(m[0].length).trim()||t}:{code:'',title:t};
}
// Section titles that describe the document (shown open at the top, also on direct entry)
// and titles that close it (shown at the end).
var NB_INTRO_TITLE=/^(מטרת|מתי משתמשים|מתי להשתמש|לפני שמתחילים|תנאי כניסה|תנאים מקדימים|למי מיועד|קהל היעד|הרשאות|אזהרות|מידע שיש לקבל|מידע שחובה לקבל)/;
var NB_END_TITLE=/^(תנאי סיום|סיום|סגירת|תוצאות אפשריות|מתי מעבירים|העברה ל|כלל מנחה|הנחיות כלליות)/;

// Header: the full title, the type label, the description and the update date.
function nbViewHeadHTML(doc){
  // Each fact once: the title; one row with the type, status, content worlds and date;
  // the description only when it adds to the title; the tags; the owner. The document
  // links are in the editing panel ("מעקב עריכה"), not repeated here.
  var k=NB_KINDS[doc.kind]||NB_KINDS.R, st=nbSplitTitle(doc.topic), date=doc.publishedAt||doc.updatedAt;
  // A description whose words are all in the title only repeats it.
  var words=function(s){ return nbPlain(s).replace(/[\-–—·.,:;!?()"״'׳/]/g,' ').split(/\s+/).filter(Boolean); };
  var tw=words(st.title);
  var desc=doc.desc&&!words(doc.desc).every(function(w){ return tw.indexOf(w)!==-1; })?doc.desc:'';
  return '<div class="article-head av-head">'
    +'<h1 class="article-title">'+nbEsc(st.title)+'</h1>'
    +'<div class="av-label-row"><span class="av-label" style="color:'+k.color+';background:'+k.bg+';border-color:'+k.color+'33">'+nbViewOf(doc.kind).label+'</span>'
    +nbStatusBadge(doc)+'<span class="nb-edit-only">'+nbReviewBadge(doc)+'</span>'
    +(doc.worlds||[]).map(function(w){return '<span class="world-chip">'+nbEsc(nbWorldName(w))+'</span>';}).join('')
    +(date?'<span class="av-date">עודכן: '+nbFmtDate(date)+'</span>':'')+'</div>'
    +(desc?'<div class="article-sub">'+desc+'</div>':'')
    +(doc.tags&&doc.tags.length?'<div class="ic-tags">'+doc.tags.map(nbTagChip).join('')+'</div>':'')
    +(doc.owner?'<div class="item-fields">גורם מקצועי אחראי: '+nbEsc(doc.owner)+'</div>':'')
    +(doc.reviewNotes&&doc.reviewNotes.length&&doc.status!=='published'?'<div class="import-issues nb-edit-only"><div class="ii-title">⚠ הערות לפני אישור</div><ul>'+doc.reviewNotes.map(function(n){return '<li>'+nbEsc(n)+'</li>';}).join('')+'</ul></div>':'')
    +nbTrackPanelHTML(doc)
    +'</div>';
}

// ── Lines of content ──
// Wording for the customer (a quoted line, or "עוגן:") is set apart from internal
// instructions, with a copy button. Quoted lines after "אין לומר" are examples of
// what not to say, so they get no copy button.
function nbIsSayLine(p){ return /^\s*["״“”„]/.test(p)||/^\s*(עוגן|anchor)\s*:/i.test(p); }
var NB_DONT_SAY=/(אין|אסור|לא|אל)\s+(ל)?(לומר|להגיד|תאמר|תגיד|להבטיח|תבטיח)/;
// R / S: what kind of action a line is, by its opening word (shown only where it applies).
function nbLineTag(p){
  if(/^(שאל|ברר)/.test(p)) return 'מה לשאול';
  if(/^(בדוק|ודא|וודא|אמת)\s/.test(p)) return 'מה לבדוק';
  if(/^(אמור|הסבר ללקוח|עדכן את הלקוח|הנחה את הלקוח)/.test(p)) return 'מה לומר ללקוח';
  if(/^(עבור|המשך|חזור|העבר)\s/.test(p)) return 'איך ממשיכים';
  return '';
}
function nbImgHTML(src){ return src?'<img class="kv-img" src="'+src+'" onclick="event.stopPropagation();nbOpenLightbox(this.src)">':''; }
function nbSayHTML(text){
  return '<div class="av-say"><span class="av-say-label">ללקוח</span><div class="av-say-text">'+text+'</div>'
    +'<button type="button" class="av-copy" onclick="nbCopySay(this)">העתקת נוסח</button></div>';
}
// lines: strings or {text,img}. opts: {tags, ordered}
function nbLinesHTML(lines,opts){
  opts=opts||{};
  var dont=false, tag=opts.ordered?'ol':'ul';
  return '<'+tag+' class="av-lines'+(opts.ordered?' av-ol':'')+'">'+lines.map(function(l){
    var text=typeof l==='object'?l.text:l, img=typeof l==='object'?nbImgHTML(l.img):'';
    var p=nbPlain(text).trim();
    if(nbIsSayLine(p)){
      if(dont) return '<li class="av-dont">'+text+img+'</li>';
      return '<li class="av-say-li">'+nbSayHTML(text)+img+'</li>';
    }
    dont=NB_DONT_SAY.test(p);
    var warn=/^(⚠(?!\s*חסר)|חשוב|שים לב|אזהרה)/.test(p), t=opts.tags?nbLineTag(p):'';
    return '<li'+(warn?' class="av-warn"':'')+'>'+(t?'<span class="av-tag">'+t+'</span>':'')+text+img+'</li>';
  }).join('')+'</'+tag+'>';
}
function nbCopyText(text,done){
  if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done,function(){});
  else { var ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select(); try{document.execCommand('copy');done();}catch(e){} ta.remove(); }
}
// Copies the customer wording only: no label, no quote marks, placeholders kept as written.
function nbCopySay(btn){
  var t=btn.parentNode.querySelector('.av-say-text');
  var text=(t?t.innerText:'').trim().replace(/^(עוגן|anchor)\s*:\s*/i,'').replace(/^["״“”„]+|["״“”„]+$/g,'').trim();
  nbCopyText(text,function(){ btn.textContent='✓ הועתק'; setTimeout(function(){btn.textContent='העתקת נוסח';},1500); });
}

// ── Stages the agent opens and closes (R, S, O) ──
// u.title is plain text (escaped here). u.name: the stage's name without "שלב N", for back links.
function nbUnitHTML(u){
  return '<section class="av-unit'+(u.plain?' av-plain':'')+'" id="'+u.id+'"'+(u.stage?' data-stage="'+u.stage+'"':'')+(u.name?' data-stage-title="'+nbEsc(u.name)+'"':'')+' data-toc-title="'+nbEsc(u.title)+'">'
    +'<div class="av-unit-head" role="button" tabindex="0" aria-expanded="false" onclick="nbToggleUnit(this.parentNode)" onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();nbToggleUnit(this.parentNode);}">'
    +(u.num?'<span class="av-unit-num">'+u.num+'</span>':'')
    +'<h2 class="av-unit-title">'+nbEsc(u.title)+'</h2><span class="av-chev" aria-hidden="true">▾</span></div>'
    +'<div class="av-unit-body">'+u.body+'</div></section>';
}
var NB_MODE_KEY='wecom_kb_view_mode';
function nbViewMode(){ try{ return localStorage.getItem(NB_MODE_KEY)==='stepped'?'stepped':'full'; }catch(e){ return 'full'; } }
function nbSetViewMode(m){ try{ localStorage.setItem(NB_MODE_KEY,m); }catch(e){} nbApplyViewMode(m); }
function nbApplyViewMode(m){
  var root=document.getElementById('article-content');
  if(!root) return;
  // The switch appears in the sidebar and at the top of the item (narrow screens).
  document.querySelectorAll('.av-mode:not(.av-omode) button').forEach(function(b){ b.classList.toggle('on',b.getAttribute('data-mode')===m); b.setAttribute('aria-pressed',b.getAttribute('data-mode')===m?'true':'false'); });
  root.querySelectorAll('.av-unit,.av-col').forEach(function(u){ nbSetUnitOpen(u,m==='full'); });
}
// Sections the agent opens and closes: R / S / O stages (.av-unit) and the sections of
// every other item with a table of contents (.av-col: M steps, T cards, I headings, O sections).
function nbUnitIsOpen(u){ return u.classList.contains('av-col')?!u.classList.contains('av-closed'):u.classList.contains('open'); }
function nbSetUnitOpen(u,open){
  if(u.classList.contains('av-col')) u.classList.toggle('av-closed',!open);
  else u.classList.toggle('open',open);
  var h=u.querySelector(':scope > .av-unit-head, :scope > .av-col-head'); if(h) h.setAttribute('aria-expanded',open?'true':'false');
}
// Opening a section never opens the next one. In the step-by-step view one section is open at a time.
function nbToggleUnit(u){
  var open=!nbUnitIsOpen(u);
  if(open&&nbViewMode()==='stepped') document.querySelectorAll('#article-content .av-unit,#article-content .av-col').forEach(function(x){ if(x!==u&&nbUnitIsOpen(x)) nbSetUnitOpen(x,false); });
  nbSetUnitOpen(u,open);
}
// Section titles of .av-col sections open and close them (mouse and keyboard).
document.addEventListener('click',function(e){
  var h=e.target.closest&&e.target.closest('#article-content .av-col-head');
  if(!h||e.target.closest('a,button:not(.av-col-head)')) return;
  nbToggleUnit(h.parentNode);
});
document.addEventListener('keydown',function(e){
  var h=e.target.classList&&e.target.classList.contains('av-col-head')?e.target:null;
  if(!h||(e.key!=='Enter'&&e.key!==' ')) return;
  e.preventDefault(); nbToggleUnit(h.parentNode);
});
// Shows a section: opens it if closed, scrolls to it and highlights it.
function nbRevealEl(el){
  if((el.classList.contains('av-unit')||el.classList.contains('av-col'))&&!nbUnitIsOpen(el)) nbToggleUnit(el);
  el.scrollIntoView({behavior:'smooth',block:'start'});
  el.classList.remove('nb-flash'); void el.offsetWidth; el.classList.add('nb-flash');
}
// After a jump inside the item, the target offers a way back to where the agent was.
function nbMarkFrom(target,from){
  document.querySelectorAll('#article-content .av-from').forEach(function(b){ b.remove(); });
  if(!from||from===target||from.contains(target)) return;
  var n=from.getAttribute('data-stage'), name=(n?nbStageName(from):from.getAttribute('data-toc-title'))||'';
  var b=document.createElement('button');
  b.type='button'; b.className='av-from';
  b.textContent='↩ חזרה ל'+(n?'שלב '+n+(name?' – '+name:''):(name||'מקום הקודם'));
  b.addEventListener('click',function(e){ e.stopPropagation(); b.remove(); nbRevealEl(from); });
  var head=target.querySelector('.m-step-head'), body=target.querySelector('.av-unit-body');
  if(head) head.parentNode.insertBefore(b,head.nextSibling);
  else if(body) body.insertBefore(b,body.firstChild);
  else target.insertBefore(b,target.firstChild);
}

// R / S: the source's stages. "שלב N" titles are the stages; the titles between
// them are the cases and branches of the stage above. What comes before the
// first stage describes the document; closing titles after the last one form the end.
function nbStagesViewHTML(doc){
  var st=(doc.stages||[]).slice(), own=nbSplitTitle(doc.topic);
  var bare=function(s){ return !nbStageItems(s).length&&!(s.images&&s.images.length); };
  // A first section that only repeats the item's title.
  if(st.length&&bare(st[0])&&own.code&&nbPlain(st[0].title).trim().indexOf(own.code)===0) st.shift();
  var numbered=st.some(function(s){return nbStageNum(s.title);});
  var lastNum=-1; st.forEach(function(s,i){ if(nbStageNum(s.title)) lastNum=i; });
  var intro=[], units=[], end=[];
  st.forEach(function(s,i){
    var t=nbPlain(s.title).trim(), n=nbStageNum(s.title);
    if(end.length){ end.push(s); return; }
    if(numbered){
      if(n){ units.push({s:s,subs:[]}); return; }
      if(!units.length){ intro.push(s); return; }
      if(i>lastNum&&NB_END_TITLE.test(t)){ end.push(s); return; }
      units[units.length-1].subs.push(s); return;
    }
    if(!units.length&&NB_INTRO_TITLE.test(t)){ intro.push(s); return; }
    if(units.length&&NB_END_TITLE.test(t)){ end.push(s); return; }
    units.push({s:s,subs:[]});
  });
  var block=function(s){
    var L=nbStageItems(s);
    return (L.length?nbParaHTML(L):'')+((s.images||[]).map(nbImgHTML).join(''));
  };
  var sub=function(s){ return '<div class="av-sub"><div class="av-sub-title">'+s.title+'</div>'+block(s)+'</div>'; };
  var html='';
  if(intro.length) html+='<div class="av-intro">'+intro.map(function(s){return '<div class="av-intro-title">'+s.title+'</div>'+block(s);}).join('')+'</div>';
  // Only the source's own stage numbers are shown, once, in the title.
  html+=units.map(function(u,i){
    var n=nbStageNum(u.s.title), name=nbPlain(u.s.title).replace(/^\s*שלב\s*\d+\s*[-–—:.]?\s*/,'').trim();
    var title=n?'שלב '+n+(name?' – '+name:''):nbPlain(u.s.title);
    return nbUnitHTML({id:'av-u-'+i,plain:true,stage:n||null,name:n?name:'',title:title,body:block(u.s)+u.subs.map(sub).join('')});
  }).join('');
  // Closing sections keep their own titles and get no number.
  html+=end.map(function(s,i){ return nbUnitHTML({id:'av-u-end-'+i,plain:true,title:nbPlain(s.title),body:block(s)}); }).join('');
  return '<div class="av-stages">'+html+'</div>';
}
// ── O (תפעול): operating instructions by device ──
// The explanation first, then clickable boxes with the device names found in the
// source, then a section per device with its own numbered actions, and the
// general notes at the end, each marked with an asterisk. Nothing is reordered
// except those closing notes, which the spec places at the bottom.
var NB_DEVICE_RE=/(iphone|אייפון|apple|samsung|סמסונג|galaxy|xiaomi|שיאומי|redmi|poco|huawei|וואווי|pixel|פיקסל|motorola|מוטורולה|realme|רילמי|oppo|אופו|oneplus|one plus|וואן פלוס|vivo|nothing phone|honor|android|אנדרואיד|כשר)/i;
var NB_NOTE_TITLE=/^(חשוב לנציג|חשוב|כלל מנחה|דגש|דגשים|הערות|הערה|לזכור|מקורות)/;
var NB_O_AFTER=/^(שלב|לאחר|תוצאה|תוצאת|בדיקת סיום|בדיקה לאחר|סיום|המשך|אם אף|אפליקציות צד שלישי|סדר|מה לתעד|תיעוד)/;
function nbTitleText(t){ return nbPlain(t).replace(/^[^֐-׿A-Za-z0-9"״]+/,'').trim(); }
function nbIsDeviceTitle(t){
  t=nbPlain(t).trim();
  return t.length>0&&t.length<=48&&!/https?:/.test(t)&&!/^(שלב|אם|לאחר|בדיקת|ב-|החל|יתר)/.test(nbTitleText(t))&&!/:\s*\S/.test(t)&&NB_DEVICE_RE.test(t);
}
// A device name in full; an English name next to a Hebrew one goes on its own line.
function nbDeviceNameHTML(title){
  var t=nbPlain(title).trim().replace(/[\s–—-]+$/,'');
  var lat=t.match(/[A-Za-z][A-Za-z0-9.+()\/ \-]*[A-Za-z0-9)+]/g)||[];
  if(lat.length!==1||!/[֐-׿]/.test(t)) return '<span class="av-he">'+nbEsc(t)+'</span>';
  var he=t.replace(lat[0],' ').replace(/\s*[–—-]\s*$/,'').replace(/\s{2,}/g,' ').trim();
  if(!/[֐-׿]/.test(he)) return '<span class="av-he">'+nbEsc(t)+'</span>';
  return '<span class="av-he">'+nbEsc(he)+'</span><span class="av-en">'+nbEsc(lat[0].trim())+'</span>';
}
// The device a section is for, so the same device under several stages is one choice.
function nbDeviceKey(title){ return nbTitleText(title).replace(/[\s–—-]+$/,'').replace(/\s+/g,' ').toLowerCase(); }
// Picked device view (the default): only the picked device's sections are shown;
// sections shared by all devices, the explanation and the notes stay. "תצוגה מלאה" shows every device.
var nbODevice=null, nbOFull=false;
function nbApplyOView(){
  var o=document.querySelector('#article-content .av-o-pick');
  if(!o) return;
  o.classList.toggle('av-o-full',nbOFull);
  o.classList.toggle('av-o-none',!nbOFull&&!nbODevice);
  o.querySelectorAll('.av-dev').forEach(function(s){ s.classList.toggle('av-picked',s.getAttribute('data-dev')===nbODevice); });
  o.querySelectorAll('.av-dev-btn').forEach(function(b){ var on=b.getAttribute('data-dev')===nbODevice; b.classList.toggle('on',on); b.setAttribute('aria-pressed',on?'true':'false'); });
  document.querySelectorAll('.av-omode button').forEach(function(b){ var on=(b.getAttribute('data-mode')==='full')===nbOFull; b.classList.toggle('on',on); b.setAttribute('aria-pressed',on?'true':'false'); });
}
function nbPickDevice(key){
  nbODevice=key;
  nbApplyOView();
  var first=document.querySelector('#article-content .av-dev[data-dev="'+(window.CSS&&CSS.escape?CSS.escape(key):key)+'"]');
  if(first) nbRevealEl(first);
}
function nbSetOMode(full){ nbOFull=!!full; nbApplyOView(); }
function nbOViewHTML(b){
  var G=b.groups||[], n=G.length;
  var isDev=G.map(function(g){ return nbIsDeviceTitle(g.title); });
  var hasDev=isDev.indexOf(true)!==-1;
  var warnRe=/^(⚠(?!\s*חסר)|חשוב|שים לב|אזהרה)/;
  var steps=function(g){
    if(!g.steps.length) return '';
    return (g.ordered===false?'<ul class="o-steps o-plain">':'<ol class="o-steps">')
      +g.steps.map(function(s){ return '<li'+(warnRe.test(nbPlain(s.text).trim())?' class="av-warn"':'')+'><div class="o-text">'+s.text+'</div>'+nbImgHTML(s.img)+'</li>'; }).join('')
      +(g.ordered===false?'</ul>':'</ol>');
  };
  // Closing notes: the trailing run of note sections after the last device or stage.
  var notesFrom=n;
  for(var i=n-1;i>=0;i--){
    if(isDev[i]||nbStageNum(G[i].title)) break;
    if(NB_NOTE_TITLE.test(nbTitleText(G[i].title))) notesFrom=i;
  }
  var introEnd=0;
  while(introEnd<notesFrom&&!isDev[introEnd]&&(!G[introEnd].title||NB_INTRO_TITLE.test(nbTitleText(G[introEnd].title)))) introEnd++;
  var lastDev=-1; for(i=0;i<notesFrom;i++) if(isDev[i]) lastDev=i;
  // A device's section takes the cases written under it, up to the next device or a new stage.
  var parts=[], devs=[], cur=null, stageName='';
  for(i=introEnd;i<notesFrom;i++){
    var g=G[i], tt=nbTitleText(g.title);
    if(isDev[i]){
      cur={g:g,subs:[],id:'av-d-'+devs.length,stage:stageName};
      devs.push(cur); parts.push({dev:cur}); continue;
    }
    if(cur){
      var empty=!cur.g.steps.length&&!cur.subs.length;
      var attach=i<lastDev?(empty||!nbStageNum(g.title)):(!cur.g.steps.length&&!NB_O_AFTER.test(tt));
      if(attach){ cur.subs.push(g); continue; }
      cur=null;
    }
    if(nbStageNum(g.title)) stageName=nbPlain(g.title).replace(/^\s*שלב\s*\d+\s*[-–—:.]?\s*/,'').trim();
    parts.push({sec:g,id:'av-s-'+i});
  }
  var sub=function(g){ return '<div class="av-sub"><div class="av-sub-title">'+g.title+'</div>'+steps(g)+'</div>'; };
  // One box per device; a device that appears under several stages has a section in each,
  // and picking it shows all of them.
  var keys=[];
  devs.forEach(function(d){ d.key=nbDeviceKey(d.g.title); if(keys.indexOf(d.key)===-1){ keys.push(d.key); d.first=true; } });
  var html='<div class="kv-o av-o'+(devs.length?' av-o-pick':'')+'">';
  if(introEnd) html+='<div class="av-intro">'+G.slice(0,introEnd).map(function(g){return (g.title?'<div class="av-intro-title">'+g.title+'</div>':'')+steps(g);}).join('')+'</div>';
  if(devs.length) html+='<nav class="av-picker" id="av-picker" aria-label="בחירת מכשיר"><div class="av-picker-title">בחירת מכשיר</div><div class="av-picker-grid">'
    +devs.filter(function(d){return d.first;}).map(function(d){
      return '<button type="button" class="av-dev-btn" data-dev="'+nbEsc(d.key)+'" aria-pressed="false" onclick="nbPickDevice(this.getAttribute(\'data-dev\'))">'+nbDeviceNameHTML(d.g.title)+'</button>';
    }).join('')+'</div><div class="av-pick-hint">בחרו מכשיר כדי להציג את הוראות התפעול שלו. כל המכשירים מוצגים ב"תצוגה מלאה".</div></nav>';
  html+=parts.map(function(p){
    if(p.dev){
      var d=p.dev;
      return '<section class="av-dev" id="'+d.id+'" data-dev="'+nbEsc(d.key)+'"><h2 class="av-dev-title">'+nbDeviceNameHTML(d.g.title)+'</h2>'
        +steps(d.g)+d.subs.map(sub).join('')
        +'<button type="button" class="av-back-pick" onclick="nbTocGo(\'av-picker\')">↑ חזרה לבחירת מכשיר</button></section>';
    }
    var g=p.sec, sn=nbStageNum(g.title);
    if(!g.steps.length) return '<h2 class="av-part" id="'+p.id+'"'+(sn?' data-stage="'+sn+'"':'')+(hasDev?'':' data-toc-title="'+nbEsc(nbPlain(g.title))+'"')+'>'+g.title+'</h2>';
    return '<section class="av-sec" id="'+p.id+'"'+(sn?' data-stage="'+sn+'"':'')+(hasDev?'':' data-toc-title="'+nbEsc(nbPlain(g.title))+'"')+'>'
      +(g.title?'<h2 class="av-sec-title">'+g.title+'</h2>':'')+steps(g)+'</section>';
  }).join('');
  if(notesFrom<n) html+='<div class="av-notes">'+G.slice(notesFrom).map(function(g){
    var L=g.steps.map(function(s){ return '<li'+(warnRe.test(nbPlain(s.text).trim())?' class="av-warn"':'')+'>'+s.text+nbImgHTML(s.img)+'</li>'; }).join('');
    return '<div class="av-notes-title">'+g.title+'</div>'+(L?'<ul>'+L+'</ul>':'');
  }).join('')+'</div>';
  return html+'</div>';
}

// R / S text as readable paragraphs. Bullets only for sub-actions listed after a
// line ending in ":". A bare "כן" / "לא" line heads the instructions that follow it,
// shown as "אם כן" / "אם לא" with them. Customer wording stays set apart.
function nbParaHTML(items){
  var out='', inList=false, inBranch=false, dont=false;
  var closeList=function(){ if(inList){ out+='</ul>'; inList=false; } };
  var LIST_STOP=/^(אם|לאחר|המשך|עבור|חזור|במקרה|כאשר|ודא|וודא|בדוק)\s/;
  items.forEach(function(it){
    var text=typeof it==='object'?it.text:it, img=typeof it==='object'?nbImgHTML(it.img):'';
    var p=nbPlain(text).trim(), yn=/^(?:אם\s+)?(כן|לא)\s*[:.]?$/.exec(p);
    if(yn){
      closeList(); if(inBranch) out+='</div>';
      out+='<div class="av-branch"><div class="av-branch-title">אם '+yn[1]+'</div>'; inBranch=true; dont=false; return;
    }
    if(nbIsSayLine(p)){
      closeList();
      out+=dont?'<p class="av-p av-dont">'+text+'</p>'+img:nbSayHTML(text)+img;
      return;
    }
    dont=NB_DONT_SAY.test(p);
    var warn=/^(⚠(?!\s*חסר)|חשוב|שים לב|אזהרה)/.test(p);
    if(inList&&p.length<=140&&!LIST_STOP.test(p)&&!/:$/.test(p)){ out+='<li'+(warn?' class="av-warn"':'')+'>'+text+img+'</li>'; return; }
    closeList();
    out+='<p class="av-p'+(warn?' av-warn':'')+'">'+text+'</p>'+img;
    if(/:$/.test(p)){ out+='<ul class="av-lines">'; inList=true; }
  });
  closeList(); if(inBranch) out+='</div>';
  return out;
}

function nbKindBodyHTML(doc){
  var b=nbGetBody(doc);
  if(!b) return null;
  switch(doc.kind){
    case 'O':
      return nbOViewHTML(b);
    case 'I':
      // All content shown; headings feed the table of contents.
      return '<div class="kv-rich">'+b.html+'</div>';
    case 'T':
      // A card per situation. Generic headings ("תסריט", "חשוב"…) belong to the card above them.
      var GENERIC=/^(תסריט|נוסח|חשוב|הפניה:?|פתרון משלים|דגשים?|הערה)$/;
      var cards=[], introT=null;
      b.scripts.forEach(function(s,i){
        var t=nbPlain(s.situation).trim(), cur=cards[cards.length-1];
        NB_CODE_RE.lastIndex=0;
        if(!s.lines.length&&cur&&NB_CODE_RE.test(t)){ cur.parts.push({lines:[s.situation]}); return; }
        if(i===0&&NB_INTRO_TITLE.test(t)){ introT=s; return; }
        if(!cur||!GENERIC.test(t)){ cards.push({title:s.situation,parts:[{lines:s.lines}]}); return; }
        cur.parts.push({sub:s.situation,lines:s.lines});
      });
      return '<div class="kv-t">'
        +(introT?'<div class="av-intro"><div class="av-intro-title">'+introT.situation+'</div>'+nbLinesHTML(introT.lines)+'</div>':'')
        +cards.map(function(c,i){
          return '<section class="t-card" id="av-t-'+i+'" data-toc-title="'+nbEsc(nbPlain(c.title))+'"><h2 class="t-card-title">'+c.title+'</h2>'
            +c.parts.map(function(p){ return (p.sub?'<div class="t-sub">'+p.sub+'</div>':'')+(p.lines.length?nbLinesHTML(p.lines):''); }).join('')
            +'</section>';
        }).join('')+'</div>';
    case 'E':
      // Stop and transfer conditions first, then the checks, the receiver, what to document, and the rest in source order.
      var sec=function(icon,title,lines,cls,ordered){
        return '<div class="e-sec '+cls+'"><div class="e-title"><span class="e-icon">'+icon+'</span>'+title+'</div>'
          +(lines&&lines.length?nbLinesHTML(lines,{ordered:ordered})
            :'<div class="e-missing">⚠ לא הוגדר — יש להשלים מול הגורם המקצועי האחראי</div>')+'</div>';
      };
      return '<div class="kv-e av-e">'
        +sec('⏱','מתי מפסיקים טיפול ומעבירים',b.when,'e-when')
        +sec('✓','בדיקות חובה לפני ההעברה',b.conditions,'e-cond',true)
        +sec('➜','הגורם המקבל ואופן ההעברה',b.to,'e-to')
        +sec('✎','מה חובה לתעד',b.document,'e-doc')
        +(b.extra||[]).map(function(x){
          if(!x.lines.length) return '<div class="av-part">'+x.title+'</div>';
          return '<div class="e-sec e-extra"><div class="e-title">'+x.title+'</div>'+nbLinesHTML(x.lines)+'</div>';
        }).join('')
        +'</div>';
    case 'M':
      // Every question, condition and referral is shown up front, in source order.
      if(b.questions&&b.questions.length) return nbMTreeHTML(doc,b);
      return '<div class="kv-m">'
        +(b.intro.length?'<div class="m-intro">'+nbMIntroLines(b.intro)+'</div>':'')
        +(b.outro.length?'<div class="m-outro"><div class="m-outro-title">הנחיות כלליות</div><ul>'+b.outro.map(function(l){return '<li>'+l+'</li>';}).join('')+'</ul></div>':'')
        +'</div>';
  }
  return null;
}

// ── After rendering: references as boxes, table of contents, view switch ──
// A line that refers to another item keeps its text on the right and gets a
// clickable box with the item's full title on the left (stacked on narrow screens).
function nbRefRows(root){
  if(!root) return;
  var hosts=[];
  root.querySelectorAll('.kb-link-item').forEach(function(a){
    if(a.closest('.m-branch,.av-say,td,th,.av-unit-head,.t-card-title,.av-sub-title,.av-intro-title,.e-title,.av-part')) return;
    var h=a.closest('li,p,.o-text,.m-step-hint>div,.m-intro>div');
    if(h&&root.contains(h)&&hosts.indexOf(h)===-1) hosts.push(h);
  });
  // One box per linked item in each section: a later line in the same section
  // that mentions it again keeps the mention as a link in the text instead.
  var sections=[], sectionSeen=[];
  function seenIn(host){
    var sec=host.parentNode&&host.parentNode.closest('[data-stage],section,.av-unit,.av-rsec')||root;
    var i=sections.indexOf(sec);
    if(i===-1){ sections.push(sec); sectionSeen.push({}); i=sections.length-1; }
    return sectionSeen[i];
  }
  hosts.forEach(function(host){
    var seen=seenIn(host), boxed={};
    var links=[].slice.call(host.querySelectorAll('.kb-link-item'));
    links.forEach(function(a){
      var id=a.getAttribute('data-doc');
      if(window.dynamicDocs[id]&&!seen[id]){ seen[id]=1; boxed[id]=1; }
    });
    if(!Object.keys(boxed).length) return;
    var text=document.createElement('div'); text.className='av-ref-text';
    var boxes=document.createElement('div'); boxes.className='av-ref-boxes';
    var done={};
    links.forEach(function(a){
      var id=a.getAttribute('data-doc'), d=window.dynamicDocs[id];
      if(!boxed[id]) return;
      var span=document.createElement('span'); span.className='av-ref-inline'; span.textContent=a.textContent;
      a.parentNode.replaceChild(span,a);
      if(done[id]) return;
      done[id]=1;
      var b=document.createElement('button');
      b.type='button'; b.className='av-ref'; b.title=nbPlain(d.topic);
      b.innerHTML=nbKindBadge(d.kind,true)+'<span>'+nbEsc(nbSplitTitle(d.topic).title)+'</span><span class="av-ref-arrow" aria-hidden="true">←</span>'+nbNewTabIcon(id);
      b.addEventListener('click',function(e){ e.stopPropagation(); showDynamicDoc(id); window.scrollTo(0,0); });
      boxes.appendChild(b);
    });
    while(host.firstChild) text.appendChild(host.firstChild);
    var row=document.createElement('div'); row.className='av-ref-row';
    row.appendChild(text); row.appendChild(boxes);
    host.appendChild(row);
    host.classList.add('av-ref-li');
  });
}
function nbTocGo(id){ var el=document.getElementById(id); if(el) nbRevealEl(el); }
function nbBuildToolbar(root){
  var bar=document.getElementById('av-toolbar');
  if(!bar||!root) return;
  // Information items: the headings of the text are its sections.
  var rich=root.querySelector('.kv-rich');
  if(rich){
    var hs=[].slice.call(rich.querySelectorAll('h2')); if(hs.length<2) hs=[].slice.call(rich.querySelectorAll('h3'));
    if(hs.length>=2&&hs.every(function(h){ return h.parentNode===rich; })){
      // Each heading and the text under it, up to the next heading, form one section.
      hs.forEach(function(h,i){
        var sec=document.createElement('section');
        sec.className='av-rsec'; sec.id='av-h-'+i; sec.setAttribute('data-toc-title',nbPlain(h.textContent).trim());
        rich.insertBefore(sec,h);
        for(var n=h;n&&n!==hs[i+1];){ var nx=n.nextSibling; sec.appendChild(n); n=nx; }
      });
    } else hs.forEach(function(h,i){ h.id='av-h-'+i; h.setAttribute('data-toc-title',nbPlain(h.textContent).trim()); });
  }
  // Every section in the table of contents opens and closes from its title, so the
  // full / step-by-step switch works on every item with a table of contents.
  [].forEach.call(root.querySelectorAll('[data-toc-title]:not(.av-unit)'),function(sec){
    if(/^H[1-6]$/.test(sec.tagName)) return; // a heading on its own (no text under it)
    var head=sec.querySelector(':scope > .m-step-head, :scope > .t-card-title, :scope > .av-sec-title, :scope > h2, :scope > h3, :scope > h4');
    if(!head||head===sec.lastElementChild) return;
    sec.classList.add('av-col');
    head.classList.add('av-col-head');
    head.setAttribute('role','button'); head.setAttribute('tabindex','0'); head.setAttribute('aria-expanded','true');
  });
  var entries=[].filter.call(root.querySelectorAll('[data-toc-title]'),function(el){ return el.id&&el.getAttribute('data-toc-title'); });
  var toc=entries.length>=2?'<nav class="av-toc" aria-label="תוכן עניינים"><div class="av-toc-title">תוכן עניינים</div><ol>'
    +entries.map(function(el){ return '<li><a onclick="nbTocGo(\''+el.id+'\')">'+nbEsc(el.getAttribute('data-toc-title'))+'</a></li>'; }).join('')+'</ol></nav>':'';
  var units=root.querySelectorAll('.av-unit,.av-col').length;
  var mode=units>1?'<div class="av-mode" role="group" aria-label="אופן התצוגה">'
    +'<button type="button" data-mode="full" onclick="nbSetViewMode(\'full\')">תצוגה מלאה</button>'
    +'<button type="button" data-mode="stepped" onclick="nbSetViewMode(\'stepped\')">שלב אחר שלב</button></div>':'';
  // O with devices: the picked device's instructions by default, every device in the full view.
  var pick=root.querySelector('.av-o-pick');
  if(pick){
    nbODevice=null; nbOFull=false;
    mode='<div class="av-mode av-omode" role="group" aria-label="אופן התצוגה">'
      +'<button type="button" data-mode="device" onclick="nbSetOMode(false)">המכשיר שנבחר</button>'
      +'<button type="button" data-mode="full" onclick="nbSetOMode(true)">תצוגה מלאה</button></div>';
  }
  // The view switch comes first, above the table of contents. On a wide screen both sit in
  // the sidebar; on a narrow one (no sidebar) they stay at the top of the item.
  var side=document.getElementById('snav-doc');
  if(side) side.innerHTML=(mode||toc)?'<div class="snav-section">'+mode+toc+'</div>':'';
  bar.innerHTML=mode+toc;
  if(!toc&&!mode) bar.remove();
  if(pick) nbApplyOView();
  nbApplyViewMode(units>1?nbViewMode():'full');
}

// ── Feedback from agents ──
// In this version feedback is kept in this browser and shown to editors in the
// item's tracking panel; on WordPress it will be stored on the server.
var NB_FEEDBACK_KEY='wecom_kb_feedback';
function nbFeedbackAll(){ try{ return JSON.parse(localStorage.getItem(NB_FEEDBACK_KEY)||'[]')||[]; }catch(e){ return []; } }
function nbFeedbackFor(id){ return nbFeedbackAll().filter(function(f){ return f.docId===id; }); }
function nbFeedbackRowHTML(doc){
  var src=[];
  if(doc.originName) src.push('מסמך מקור: '+nbEsc(doc.originName));
  if(doc.publishedAt) src.push('גרסה שפורסמה: '+nbFmtDate(doc.publishedAt));
  return '<div class="av-feedback"><span>'+src.join(' · ')+'</span>'
    +'<button type="button" onclick="nbOpenFeedback(\''+nbEsc(doc.id)+'\')">דיווח על בעיה / משוב</button></div>';
}
function nbOpenFeedback(docId){
  var doc=window.dynamicDocs[docId];
  if(!doc) return;
  var overlay=document.createElement('div');
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px';
  overlay.innerHTML='<div role="dialog" aria-modal="true" aria-labelledby="nb-fb-title" style="background:#fff;border-radius:16px;padding:22px 20px;max-width:440px;width:100%;font-family:Rubik,sans-serif;direction:rtl">'
    +'<div id="nb-fb-title" style="font-size:16px;font-weight:700;color:var(--navy);margin-bottom:4px">דיווח על בעיה / משוב</div>'
    +'<div style="font-size:13px;color:var(--muted);margin-bottom:12px">'+nbEsc(nbSplitTitle(doc.topic).title)+'</div>'
    +'<textarea id="nb-fb-text" rows="5" style="width:100%;box-sizing:border-box;font-family:Rubik,sans-serif;font-size:14px;border:1.5px solid var(--border-strong);border-radius:10px;padding:10px;resize:vertical" placeholder="מה לא ברור, חסר או שגוי במסמך?"></textarea>'
    +'<div id="nb-fb-msg" style="font-size:12.5px;color:var(--muted);margin:8px 0 14px">המשוב יועבר לעורכי התוכן. הוא לא משנה את המסמך.</div>'
    +'<div style="display:flex;gap:10px"><button type="button" id="nb-fb-send" style="flex:1;height:40px;background:var(--navy);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif">שליחה</button>'
    +'<button type="button" id="nb-fb-cancel" style="flex:1;height:40px;background:#fff;color:var(--navy);border:2px solid var(--border);border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif">ביטול</button></div></div>';
  document.body.appendChild(overlay);
  var ta=overlay.querySelector('#nb-fb-text'); ta.focus();
  var close=function(){ overlay.remove(); };
  overlay.addEventListener('click',function(e){ if(e.target===overlay) close(); });
  overlay.querySelector('#nb-fb-cancel').addEventListener('click',close);
  overlay.querySelector('#nb-fb-send').addEventListener('click',function(){
    var text=ta.value.trim();
    if(!text){ ta.focus(); return; }
    var all=nbFeedbackAll();
    all.push({docId:doc.id,title:nbPlain(doc.topic),version:doc.publishedAt||doc.updatedAt||null,text:text,at:Date.now()});
    try{ localStorage.setItem(NB_FEEDBACK_KEY,JSON.stringify(all)); }catch(e){}
    overlay.firstChild.innerHTML='<div style="font-size:15px;font-weight:700;color:var(--navy);margin-bottom:14px">תודה, המשוב התקבל.</div>'
      +'<button type="button" style="width:100%;height:40px;background:var(--navy);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif">סגירה</button>';
    overlay.querySelector('button').addEventListener('click',close);
  });
}

function nbCopyLine(btn){
  var t=btn.parentNode.querySelector('.t-text');
  var text=(t?t.innerText:'').replace(/^\s*(עוגן|anchor)\s*:\s*/i,'');
  var done=function(){ btn.textContent='✓ הועתק'; setTimeout(function(){btn.textContent='העתק';},1500); };
  if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done,function(){});
  else { var ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select(); try{document.execCommand('copy');done();}catch(e){} ta.remove(); }
}

// ── Links between items (spec §4, §7 "מעבר ישיר בין פריטי ידע מקושרים") ──
// Document codes in the text (M-00, R-01, O-05, E-01…) become links to the
// item whose title starts with that code. Codes with no item stay plain text.
function nbFindByCode(code){
  var docs=window.dynamicDocs||{}, re=new RegExp('^\\s*'+code+'(?!\\d)');
  for(var k in docs){ if(docs[k]&&nbVisible(docs[k])&&re.test(nbPlain(docs[k].topic))) return docs[k]; }
  return null;
}
// The number of a stage title ("שלב 3 - בדיקות במכשיר" → 3), or 0.
function nbStageNum(title){ var m=/^\s*שלב\s*(\d+)(?!\d)/.exec(nbPlain(title)); return m?parseInt(m[1],10):0; }
// A stage's name without its number ("שלב 3 - בדיקות במכשיר" → "בדיקות במכשיר").
function nbStageName(el){
  var t=el.getAttribute('data-stage-title');
  if(t==null){ var h=el.querySelector('.av-unit-title,.step-title,.o-title'); t=h?nbPlain(h.textContent):''; }
  return t.replace(/^\s*שלב\s*\d+\s*[-–—:.]?\s*/,'').trim();
}
// Jumps to a stage of the open item, opens it if it is closed, and highlights it.
// from: the section the agent jumped from, offered as the way back.
function nbJumpToStage(n,from){
  var el=document.querySelector('#article-content [data-stage="'+n+'"]');
  if(!el) return;
  nbMarkFrom(el,from||null);
  nbRevealEl(el);
}
// Title letters only, for comparing a title written in the text with the item's title.
function nbTitleKey(c){ return /[\s\-‐‑‒–—·"״׳'“”„:|()]/.test(c)?'':c.toLowerCase(); }
// How far the text after a code repeats the item's title (0 if it does not).
function nbTitleSpan(after,title){
  var i=0,j=0,end=0,matched=0,letters=0;
  for(var k=0;k<title.length;k++) if(nbTitleKey(title.charAt(k))) letters++;
  while(i<after.length&&j<title.length){
    var a=nbTitleKey(after.charAt(i)), b=nbTitleKey(title.charAt(j));
    if(!a&&i<after.length){ i++; continue; }
    if(!b){ j++; continue; }
    if(a!==b) break;
    i++; j++; matched++; end=i;
  }
  return matched>=Math.min(10,letters)&&matched>=letters*0.6?end:0;
}
// Runs over rendered item content: item codes become links showing the item's
// title, "שלב N" references jump to that stage, and "⚠ חסר" lines are marked.
var NB_CODE_RE=/([MROESTIH])[-‐‑‒–](\d{2,3})(?!\d)/g;
var NB_STAGE_RE=/(שלב)\s*(\d+)(?!\d)/g;
// A quoted name ("…", ״…״, “…”) that is exactly an item's title also links to
// the item, for references written by name without the code.
var NB_QUOTED_RE=/["״“”„]([^"״“”„\n]{4,120}?)["״“”„]/g;
function nbNormTitle(s){ return nbPlain(s).replace(/[׳״]/g,' ').replace(/[^֐-׿a-zA-Z0-9]+/g,' ').trim().toLowerCase(); }
function nbTitleIndex(){
  var docs=window.dynamicDocs||{}, idx={};
  Object.keys(docs).forEach(function(k){
    var d=docs[k]; if(!d||!nbVisible(d)) return;
    var st=nbSplitTitle(d.topic), key=nbNormTitle(st.title);
    // Only items with a code, and the same item the code itself would open.
    if(st.code&&key.length>=6&&!idx[key]&&nbFindByCode(st.code)===d) idx[key]=d;
  });
  return idx;
}
function nbEnhance(root){
  if(!root) return;
  var walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null), nodes=[];
  while(walker.nextNode()) nodes.push(walker.currentNode);
  var shown=window.nbShownDocId, titleIdx=null;
  nodes.forEach(function(n){
    var p=n.parentNode, t=n.nodeValue;
    if(!p||(p.closest&&p.closest('a,button,textarea,input,select,.article-title,.m-map'))) return;
    // Stage titles may link to other items, but "שלב N" in a title is the stage itself.
    var inTitle=!!p.closest('.step-title,.o-title,.m-step-title,.av-unit-title');
    if(/⚠\s*חסר/.test(t)){ var host=p.closest('li,.action-item,td')||p; host.classList.add('kb-missing'); }
    // Matches in order of position: item codes and stage references.
    var found=[], m;
    NB_CODE_RE.lastIndex=0;
    while((m=NB_CODE_RE.exec(t))){
      var code=m[1]+'-'+m[2], d=nbFindByCode(code);
      // A code with no item (or one not published yet) is marked for completion, never a fake link.
      if(!d){
        var cur=shown&&window.dynamicDocs[shown];
        if(!cur||nbSplitTitle(cur.topic).code!==code) found.push({at:m.index,end:m.index+m[0].length,unresolved:code});
        continue;
      }
      if(d.id===shown) continue;
      var title=nbPlain(d.topic).replace(/^\s*[A-Z]-\d{2,3}\s*[·\-–—]?\s*/,'').trim();
      var after=t.slice(m.index+m[0].length), span=nbTitleSpan(after,title);
      found.push({at:m.index,codeEnd:m.index+m[0].length,end:m.index+m[0].length+span,doc:d,code:code,addTitle:span?'':title});
    }
    NB_QUOTED_RE.lastIndex=0;
    while((m=NB_QUOTED_RE.exec(t))){
      titleIdx=titleIdx||nbTitleIndex();
      var qd=titleIdx[nbNormTitle(m[1])];
      // Not a title: try again from the next character (the closing mark may open the real quote).
      if(!qd){ NB_QUOTED_RE.lastIndex=m.index+1; continue; }
      if(qd.id===shown) continue;
      found.push({at:m.index,codeEnd:m.index,end:m.index+m[0].length,doc:qd,code:nbSplitTitle(qd.topic).code,byTitle:true});
    }
    NB_STAGE_RE.lastIndex=0;
    while(!inTitle&&(m=NB_STAGE_RE.exec(t))){
      var st=root.ownerDocument.querySelector('#article-content [data-stage="'+m[2]+'"]');
      if(!st||(p.closest('[data-stage]')===st&&!p.closest('.m-branch,.m-step-hint'))) continue;
      found.push({at:m.index,end:m.index+m[0].length,stage:parseInt(m[2],10),name:nbStageName(st)});
    }
    if(!found.length) return;
    found.sort(function(a,b){return a.at-b.at;});
    var frag=document.createDocumentFragment(), last=0;
    found.forEach(function(f){
      if(f.at<last) return;
      frag.appendChild(document.createTextNode(t.slice(last,f.at)));
      if(f.unresolved){
        var u=document.createElement('span');
        u.className='kb-unresolved'; u.textContent=t.slice(f.at,f.end);
        u.title='הפניה שלא זוהתה בפריטי הידע – להשלמה';
        frag.appendChild(u); last=f.end; return;
      }
      var a=document.createElement('a');
      if(f.doc){
        a.className='kb-link kb-link-item'; a.title=nbPlain(f.doc.topic); a.setAttribute('data-doc',f.doc.id);
        var codeEl=document.createElement('span'); codeEl.className='kb-code'; codeEl.textContent=f.code;
        a.appendChild(codeEl);
        // The title as written after the code, or the item's title when the text has only the code.
        a.appendChild(document.createTextNode(f.byTitle?' '+t.slice(f.at,f.end):f.addTitle?' — '+f.addTitle:t.slice(f.codeEnd,f.end)));
        a.href=nbItemHref(f.doc.id);
        a.addEventListener('click',function(e){
          e.stopPropagation();
          // Ctrl / ⌘ / Shift + click: the browser opens the link in a new tab or window.
          if(e.ctrlKey||e.metaKey||e.shiftKey){ nbRoleHandoff(); return; }
          e.preventDefault(); showDynamicDoc(this.getAttribute('data-doc')); window.scrollTo(0,0);
        });
      } else {
        a.className='kb-link kb-link-stage'; a.setAttribute('data-stage-link',f.stage);
        a.textContent=t.slice(f.at,f.end)+(f.name?' – '+f.name:'');
        a.title='מעבר לשלב '+f.stage+' במסמך';
        a.addEventListener('click',function(e){ e.stopPropagation(); nbJumpToStage(this.getAttribute('data-stage-link'),this.closest('.av-unit,[data-stage]')); });
      }
      frag.appendChild(a);
      last=f.end;
    });
    frag.appendChild(document.createTextNode(t.slice(last)));
    p.replaceChild(frag,n);
  });
}

// Section titles from the source document ("מטרת המסמך", "מתי משתמשים במסמך"…)
// show in bold: a known section name, or a short line with no closing
// punctuation that is followed by more text.
var NB_SECTION_TITLES=/^(מטרת המסמך|מטרת האבחון|מתי משתמשים(?: בתהליך| במסמך)?\??|לפני שמתחילים:?|כלל מנחה(?: לנציג)?|הנחיות כלליות|תוצאת האבחון|מידע שיש לאסוף.*|הפניות למסמכי ידע קיימים|סדר העבודה לנציג|הערות)$/;
function nbIsSectionTitle(lines,i){
  var t=nbPlain(lines[i]).trim();
  if(NB_SECTION_TITLES.test(t)) return true;
  return i<lines.length-1&&t.length>0&&t.length<=40&&!/[.:,;!?"״”)]$/.test(t);
}
function nbMIntroLines(lines){
  return lines.map(function(l,i){ return nbIsSectionTitle(lines,i)?'<div class="m-intro-title">'+l+'</div>':'<div>'+l+'</div>'; }).join('');
}

// ── Diagnosis as an operational tree (type M with named steps) ──
// When every question has a step name, all steps are shown on the page. Each
// answer is a branch: "אם <answer> ←" a link that jumps to the step it leads
// to, or opens the item it refers to. A map at the top shows the whole tree.
function nbMIsTree(b){ return b.questions.length>0&&b.questions.every(function(q){return q.title;}); }
function nbMTreeHTML(doc,b){
  var action=function(a,from){
    var go=a.go||'';
    if(/^q:\d+$/.test(go)) return 'nbMJump('+from+','+parseInt(go.slice(2),10)+')';
    if(go.indexOf('item:')===0&&window.dynamicDocs[go.slice(5)]&&nbVisible(window.dynamicDocs[go.slice(5)])) return 'showDynamicDoc(\''+nbEsc(go.slice(5))+'\')';
    return '';
  };
  var target=function(a,from){
    var go=a.go||'';
    if(/^q:\d+$/.test(go)){
      var n=parseInt(go.slice(2),10), q=b.questions[n];
      if(!q) return '<div class="m-target end">השלב שאליו מפנה התשובה כבר לא קיים</div>';
      return '<button class="m-target step" onclick="'+action(a,from)+'"><span class="m-target-kind">שלב '+(n+1)+'</span><span>'+q.title+'</span><span class="m-go-arrow">←</span></button>';
    }
    if(go.indexOf('item:')===0){
      var d=window.dynamicDocs[go.slice(5)];
      if(!d) return '<div class="m-target end">פריט הידע שאליו מפנה התשובה כבר לא קיים</div>';
      if(!nbVisible(d)) return '<div class="m-target end">פריט הידע עדיין לא פורסם — פנו לראש הצוות</div>';
      return '<button class="m-target item" onclick="'+action(a,from)+'" title="'+nbEsc(nbPlain(d.topic))+'">'+nbKindBadge(d.kind,true)+'<span>'+nbEsc(nbSplitTitle(d.topic).title)+'</span><span class="m-go-arrow">←</span>'+nbNewTabIcon(go.slice(5))+'</button>';
    }
    // A document that is not in the app yet (a.ext names it): marked for completion, not a link.
    if(a.ext) return '<div class="m-target ext" title="הפניה שלא זוהתה בפריטי הידע – להשלמה"><span class="av-todo">להשלמה</span> '+a.ext+'</div>';
    return '<div class="m-target end">סיום האבחון</div>';
  };
  var stepTitle=function(q,qi){ return q.title||nbPlain(q.q).trim()||('שאלה '+(qi+1)); };
  var hint=function(h){
    var L=nbLines(h);
    if(!L.length) return '';
    return '<div class="m-step-hint"><div>'+L[0]+'</div>'+(L.length>1?'<ul>'+L.slice(1).map(function(l){return '<li>'+l+'</li>';}).join('')+'</ul>':'')+'</div>';
  };
  // The table of contents (built from data-toc-title) lists the steps; each step shows all its cases.
  var steps=b.questions.map(function(q,qi){
    var title=stepTitle(q,qi);
    return '<section class="m-step" id="m-step-'+qi+'" data-stage="'+(qi+1)+'" data-stage-title="'+nbEsc(nbPlain(title))+'" data-toc-title="'+nbEsc(nbPlain(title))+'">'
      +'<div class="m-step-head"><span class="m-step-num">'+(qi+1)+'</span><h2 class="m-step-title">'+(q.title?q.title:'שלב '+(qi+1))+'</h2><button class="m-step-from" id="m-from-'+qi+'" hidden></button></div>'
      +(q.q?'<div class="m-step-q"><span class="m-step-ask">שאל:</span> '+q.q+'</div>':'')
      +hint(q.hint)
      +'<div class="m-branches">'+q.answers.map(function(a){
        return '<div class="m-branch"><div class="m-cond"><span class="m-if">אם</span>'+a.text+'</div>'
          +(a.note?'<div class="m-branch-note">'+a.note+'</div>':'')+target(a,qi)+'</div>';
      }).join('')+'</div></section>';
  }).join('');
  return '<div class="kv-m m-tree">'
    +(b.intro.length?'<div class="m-intro">'+nbMIntroLines(b.intro)+'</div>':'')
    +steps
    +(b.outro.length?'<div class="m-outro"><div class="m-outro-title">הנחיות כלליות</div><ul>'+b.outro.map(function(l){return '<li>'+l+'</li>';}).join('')+'</ul></div>':'')
    +'</div>';
}
// Jumps to a step and highlights it; the step offers a way back to where the agent came from.
function nbMJump(from,to){
  var el=document.getElementById('m-step-'+to);
  if(!el) return;
  document.querySelectorAll('.m-step-from').forEach(function(x){x.hidden=true;});
  if(from!=null&&from!==to){
    var back=document.getElementById('m-from-'+to);
    if(back){ back.hidden=false; back.textContent='↩ חזרה לשלב '+(from+1); back.onclick=function(){ nbMJump(null,from); }; }
  }
  if(el.classList.contains('av-col')&&!nbUnitIsOpen(el)) nbToggleUnit(el);
  el.scrollIntoView({behavior:'smooth',block:'start'});
  el.classList.remove('m-flash'); void el.offsetWidth; el.classList.add('m-flash');
}

// ── Guided diagnosis (type M, spec §5 "מסלול מונחה") ──
var nbMPath=[]; // [{q, a}] answers chosen so far

function nbMStart(){ nbMPath=[]; nbMRender(); }
function nbMBack(i){ nbMPath=nbMPath.slice(0,i); nbMRender(); }
function nbMAnswer(qi,ai){ nbMPath.push({q:qi,a:ai}); nbMRender(); }

function nbMRender(){
  var el=document.getElementById('m-flow');
  if(!el) return;
  var doc=window.dynamicDocs[el.getAttribute('data-doc')];
  var b=doc&&nbGetBody(doc);
  if(!b||!b.questions.length){ el.innerHTML='<div class="info-box">טרם הוגדרו שאלות אבחון.</div>'; return; }
  var html='';
  // The answers given so far — click one to go back and change it.
  if(nbMPath.length){
    html+='<div class="m-trail">'+nbMPath.map(function(p,i){
      var q=b.questions[p.q], a=q&&q.answers[p.a];
      return '<button class="m-trail-item" onclick="nbMBack('+i+')" title="חזור לשאלה זו"><span class="m-trail-q">'+(q?q.q:'')+'</span><span class="m-trail-a">'+(a?a.text:'')+'</span></button>';
    }).join('')+'</div>';
  }
  var cur=0, last=null;
  if(nbMPath.length){
    last=nbMPath[nbMPath.length-1];
    var la=b.questions[last.q]&&b.questions[last.q].answers[last.a];
    if(la&&/^q:\d+$/.test(la.go)) cur=parseInt(la.go.slice(2)); else cur=-1;
  }
  var lastAnswer=last?b.questions[last.q].answers[last.a]:null;
  if(lastAnswer&&lastAnswer.note) html+='<div class="m-note">'+lastAnswer.note+'</div>';
  if(cur>=0&&b.questions[cur]){
    var q=b.questions[cur];
    html+='<div class="m-q"><div class="m-q-num">שאלה '+(nbMPath.length+1)+'</div><div class="m-q-text">'+q.q+'</div>'
      +(q.hint?'<div class="m-q-hint">'+q.hint+'</div>':'')
      +'<div class="m-answers">'+q.answers.map(function(a,ai){
        return '<button class="m-answer" onclick="nbMAnswer('+cur+','+ai+')">'+a.text+'</button>';
      }).join('')+'</div></div>';
  } else {
    // End of the path: send the agent to the item, or close with the note.
    var go=lastAnswer&&lastAnswer.go||'';
    var target=go.indexOf('item:')===0?window.dynamicDocs[go.slice(5)]:null;
    if(target&&!nbVisible(target)){
      html+='<div class="info-box">פריט הידע שאליו מפנה התשובה עדיין לא פורסם. פנו לראש הצוות.</div>';
    } else if(target){
      html+='<div class="m-result"><div class="m-result-label">המשך הטיפול:</div>'
        +'<button class="m-go" onclick="showDynamicDoc(\''+nbEsc(target.id)+'\')">'+nbKindBadge(target.kind)+'<span>'+target.topic+'</span><span class="m-go-arrow">←</span></button></div>';
    } else if(go.indexOf('item:')===0){
      html+='<div class="info-box">פריט הידע שאליו מפנה התשובה כבר לא קיים. יש לעדכן את מסמך האבחון.</div>';
    } else {
      html+='<div class="m-result"><div class="m-result-label">סוף האבחון</div></div>';
    }
  }
  if(nbMPath.length) html+='<button class="m-restart" onclick="nbMStart()">↺ התחל אבחון מחדש</button>';
  el.innerHTML=html;
  nbEnhance(el);
}

// ── EDITORS (in "פריט ידע חדש", replacing the step builder for O/I/T/E/M) ──
function nbCurKind(){ var d=nbState.s1&&nbState.s1.s1data; return (d&&d.kind)||'R'; }
function nbBody(k){
  nbState._bodies=nbState._bodies||{};
  if(!nbState._bodies[k]) nbState._bodies[k]=nbEmptyBody(k);
  return nbState._bodies[k];
}
// Generic edits addressed by a path like "groups.0.steps.2.text".
function nbPathGet(obj,path){ return path.split('.').reduce(function(o,k){return o==null?o:o[k];},obj); }
function nbPathParent(obj,path){ var p=path.split('.'); var last=p.pop(); return {parent:p.length?nbPathGet(obj,p.join('.')):obj,key:last}; }
function nbBSet(el){
  var b=nbBody(nbCurKind()), r=nbPathParent(b,el.getAttribute('data-path'));
  r.parent[r.key]=el.hasAttribute('data-lines')?nbLines(el.value):el.value;
  nbSaveDraft(); nbUpdateSummary();
}
function nbBAdd(path,tpl){
  var b=nbBody(nbCurKind()), arr=nbPathGet(b,path);
  if(Array.isArray(arr)) arr.push(JSON.parse(tpl));
  nbRenderKindEditor();
}
function nbBDel(path){
  var b=nbBody(nbCurKind()), r=nbPathParent(b,path);
  if(Array.isArray(r.parent)) r.parent.splice(parseInt(r.key),1);
  nbRenderKindEditor();
}
// Deleting a question shifts the numbers of the ones after it, so fix the
// "go to question N" links.
function nbMDelQuestion(i){
  var b=nbBody('M');
  b.questions.splice(i,1);
  b.questions.forEach(function(q){q.answers.forEach(function(a){
    var m=/^q:(\d+)$/.exec(a.go||''); if(!m) return;
    var n=parseInt(m[1]); a.go=n===i?'':(n>i?'q:'+(n-1):a.go);
  });});
  nbRenderKindEditor();
}
function nbRenderKindEditor(){
  var el=document.getElementById('nb-kind-editor');
  if(el) el.innerHTML=nbKindEditorHTML(nbCurKind());
  nbSaveDraft(); nbUpdateSummary();
}

function nbTA(path,val,ph,rows,lines){
  return '<textarea class="s1-input ke-ta" rows="'+(rows||2)+'" data-path="'+path+'"'+(lines?' data-lines="1"':'')+' oninput="nbBSet(this)" placeholder="'+nbEsc(ph||'')+'">'+nbEsc(lines?(val||[]).join('\n'):(val||''))+'</textarea>';
}
function nbIN(path,val,ph){
  return '<input class="s1-input" data-path="'+path+'" oninput="nbBSet(this)" value="'+nbEsc(val||'')+'" placeholder="'+nbEsc(ph||'')+'">';
}
function nbDelBtn(onclick,title){ return '<button type="button" class="ke-del" onclick="'+onclick+'" title="'+(title||'מחק')+'">✕</button>'; }
function nbAddBtn(path,tpl,label){ return '<button type="button" class="ke-add" onclick="nbBAdd(\''+path+'\',\''+nbEsc(JSON.stringify(tpl))+'\')">'+label+'</button>'; }

function nbKindEditorHTML(k){
  var b=nbBody(k), K=NB_KINDS[k], h='';
  h+='<div class="ke-head">'+nbKindBadge(k)+'<div><div class="ke-title">תוכן '+K.full+'</div><div class="ke-sub">'+K.hint+'</div></div></div>';
  switch(k){
    case 'O':
      h+='<div class="s1-help">שלבי ביצוע ממוספרים. אפשר לחלק לקבוצות — למשל לפי יצרן מכשיר או לפי מערכת.</div>';
      h+=b.groups.map(function(g,gi){
        return '<div class="ke-card"><div class="ke-row">'+nbIN('groups.'+gi+'.title',g.title,'כותרת קבוצה (אופציונלי) — לדוגמה: Samsung')+nbDelBtn('nbBDel(\'groups.'+gi+'\')','מחק קבוצה')+'</div>'
          +'<ol class="ke-steps">'+g.steps.map(function(s,si){
            return '<li><div class="ke-row">'+nbTA('groups.'+gi+'.steps.'+si+'.text',s.text,'תיאור השלב',1)+nbDelBtn('nbBDel(\'groups.'+gi+'.steps.'+si+'\')','מחק שלב')+'</div>'
              +(s.img?'<img class="ke-thumb" src="'+s.img+'">':'')+'</li>';
          }).join('')+'</ol>'
          +nbAddBtn('groups.'+gi+'.steps',{text:'',img:null},'+ שלב')+'</div>';
      }).join('');
      h+=nbAddBtn('groups',{title:'',steps:[{text:'',img:null}]},'+ קבוצת שלבים');
      break;
    case 'I':
      var tb=[['h3','כותרת'],['h4','תת-כותרת'],['p','פסקה'],['b','<b>B</b>'],['ul','• רשימה'],['ol','1. רשימה'],['link','🔗 קישור'],['table','▦ טבלה'],['img','🖼 תמונה'],['clear','נקה עיצוב']];
      h+='<div class="s1-help">עורך טקסט מלא: כותרות, רשימות, טבלאות, קישורים ותמונות. אפשר להדביק ישירות ממסמך Word.</div>'
        +'<div class="rich-toolbar">'+tb.map(function(t){return '<button type="button" onmousedown="event.preventDefault()" onclick="nbRichCmd(\''+t[0]+'\')">'+t[1]+'</button>';}).join('')
        +'<input type="file" accept="image/*" id="nb-rich-img" style="display:none" onchange="nbRichImage(this)"></div>'
        +'<div class="rich-edit kv-rich" id="nb-rich" contenteditable="true" oninput="nbRichSync()" onpaste="nbRichPaste(event)">'+(b.html||'')+'</div>';
      break;
    case 'T':
      h+='<div class="s1-help">לכל מצב: ניסוחים מומלצים לנציג, שורה לכל ניסוח. שורה שמתחילה ב"עוגן:" תודגש כמשפט מפתח.</div>';
      h+=b.scripts.map(function(s,i){
        return '<div class="ke-card"><div class="ke-row">'+nbIN('scripts.'+i+'.situation',s.situation,'מצב / התנגדות — לדוגמה: התנגדות למחיר')+nbDelBtn('nbBDel(\'scripts.'+i+'\')','מחק')+'</div>'
          +nbTA('scripts.'+i+'.lines',s.lines,'"אני מבין אותך…"\nעוגן: "יש זול — ויש חכם"',4,true)+'</div>';
      }).join('');
      h+=nbAddBtn('scripts',{situation:'',lines:[]},'+ מצב נוסף');
      break;
    case 'E':
      [['when','⏱ מתי מפסיקים טיפול ומעבירים','לדוגמה: לאחר שבוצעו כל הבדיקות במסלול והשירות עדיין לא עובד'],
       ['to','➜ למי מעבירים','תור / צוות / גורם, ואיך מעבירים'],
       ['conditions','✓ תנאים שחייבים להתקיים לפני ההעברה','שורה לכל תנאי'],
       ['document','✎ מה חובה לתעד','שורה לכל פרט שחובה לתעד']].forEach(function(f){
        h+='<div class="ke-card"><div class="s1-label">'+f[1]+'</div>'+nbTA(f[0],b[f[0]],f[2],3,true)+'</div>';
      });
      h+=(b.extra||[]).map(function(x,i){
        return '<div class="ke-card"><div class="ke-row">'+nbIN('extra.'+i+'.title',x.title,'כותרת סעיף נוסף')+nbDelBtn('nbBDel(\'extra.'+i+'\')','מחק סעיף')+'</div>'+nbTA('extra.'+i+'.lines',x.lines,'שורה לכל פריט',3,true)+'</div>';
      }).join('');
      h+=nbAddBtn('extra',{title:'',lines:[]},'+ סעיף נוסף');
      break;
    case 'M':
      var docs=window.dynamicDocs||{};
      var editing=window.nbEditingDocId;
      var itemOpts=Object.keys(docs).map(function(id){return docs[id];}).filter(function(d){return d&&d.id!==editing;})
        .sort(function(a,c){return nbPlain(a.topic).localeCompare(nbPlain(c.topic),'he');});
      h+='<div class="s1-help">שאלות אבחון לנציג. כל תשובה ממשיכה לשאלה אחרת, מפנה לפריט ידע (לרוב מסלול טיפול R), או מסיימת עם הנחיה. כשלכל שאלה יש שם שלב, האבחון מוצג לנציג כעץ תפעולי: כל השלבים בעמוד, וכל תשובה מקשרת לשלב או לפריט שאליו היא מובילה.</div>';
      h+='<div class="ke-card"><div class="s1-label">פתיח (מטרה, כללים לפני שמתחילים)</div>'+nbTA('intro',b.intro,'שורה לכל הנחיה',3,true)+'</div>';
      h+=b.questions.map(function(q,qi){
        return '<div class="ke-card ke-q"><div class="ke-row"><span class="ke-qnum">שלב '+(qi+1)+'</span>'+nbIN('questions.'+qi+'.title',q.title||'','שם השלב — לדוגמה: אין גלישה')+nbDelBtn('nbMDelQuestion('+qi+')','מחק שלב')+'</div>'
          +nbIN('questions.'+qi+'.q',q.q,'השאלה — לדוגמה: האם מופיע במכשיר שם של רשת?')
          +nbIN('questions.'+qi+'.hint',q.hint,'הנחיה לנציג (אופציונלי) — מה לבדוק או לשאול')
          +'<div class="ke-answers">'+q.answers.map(function(a,ai){
            var p='questions.'+qi+'.answers.'+ai;
            var opts='<option value="">■ סיום (עם ההנחיה)</option>'
              +'<optgroup label="המשך לשלב">'+b.questions.map(function(q2,i2){return i2===qi?'':'<option value="q:'+i2+'"'+(a.go==='q:'+i2?' selected':'')+'>שלב '+(i2+1)+': '+nbEsc(nbPlain(q2.title||q2.q).slice(0,40))+'</option>';}).join('')+'</optgroup>'
              +'<optgroup label="פתח פריט ידע">'+itemOpts.map(function(d){return '<option value="item:'+nbEsc(d.id)+'"'+(a.go==='item:'+d.id?' selected':'')+'>['+d.kind+'] '+nbEsc(nbPlain(d.topic).slice(0,50))+'</option>';}).join('')+'</optgroup>';
            return '<div class="ke-answer"><div class="ke-row">'+nbIN(p+'.text',a.text,'תשובה')
              +'<select class="s1-input ke-go" data-path="'+p+'.go" onchange="nbBSet(this)">'+opts+'</select>'+nbDelBtn('nbBDel(\''+p+'\')','מחק תשובה')+'</div>'
              +nbIN(p+'.note',a.note,'הנחיה לנציג אחרי בחירת התשובה (אופציונלי)')+'</div>';
          }).join('')+'</div>'
          +nbAddBtn('questions.'+qi+'.answers',{text:'',note:'',go:''},'+ תשובה')+'</div>';
      }).join('');
      h+=nbAddBtn('questions',{title:'',q:'',hint:'',answers:[{text:'',note:'',go:''},{text:'',note:'',go:''}]},'+ שלב');
      h+='<div class="ke-card"><div class="s1-label">הנחיות כלליות (בסוף)</div>'+nbTA('outro',b.outro,'שורה לכל הנחיה',2,true)+'</div>';
      break;
  }
  return h;
}

// ── Rich text editor commands (type I) ──
function nbRichSync(){
  var el=document.getElementById('nb-rich');
  if(!el) return;
  nbBody('I').html=el.innerHTML;
  nbSaveDraft();
}
function nbRichCmd(c){
  var el=document.getElementById('nb-rich');
  if(!el) return;
  el.focus();
  if(c==='h3'||c==='h4'||c==='p') document.execCommand('formatBlock',false,c);
  else if(c==='b') document.execCommand('bold');
  else if(c==='ul') document.execCommand('insertUnorderedList');
  else if(c==='ol') document.execCommand('insertOrderedList');
  else if(c==='link'){ var u=prompt('כתובת הקישור (https://…)'); if(u&&/^(https?:|mailto:|tel:)/i.test(u)) document.execCommand('createLink',false,u); }
  else if(c==='table') document.execCommand('insertHTML',false,'<table><thead><tr><th>כותרת</th><th>כותרת</th></tr></thead><tbody><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table><p><br></p>');
  else if(c==='img'){ var f=document.getElementById('nb-rich-img'); if(f) f.click(); return; }
  else if(c==='clear'){ document.execCommand('removeFormat'); document.execCommand('formatBlock',false,'p'); }
  nbRichSync();
}
function nbRichImage(input){
  var file=input.files&&input.files[0];
  if(!file) return;
  var r=new FileReader();
  r.onload=function(ev){
    var el=document.getElementById('nb-rich');
    if(el){ el.focus(); document.execCommand('insertImage',false,ev.target.result); nbRichSync(); }
    input.value='';
  };
  r.readAsDataURL(file);
}
// Pasting from Word/web: keep the structure, drop the styling.
function nbRichPaste(e){
  var cd=e.clipboardData||window.clipboardData;
  if(!cd) return;
  var html=cd.getData('text/html');
  e.preventDefault();
  if(html) document.execCommand('insertHTML',false,nbSanitizeRich(html));
  else document.execCommand('insertText',false,cd.getData('text/plain'));
  nbRichSync();
}

// Short description of the typed content for the summary panel.
function nbBodySummaryHTML(k){
  var b=nbCleanBody(k,nbBody(k)), txt;
  switch(k){
    case 'O': txt=b.groups.length+' קבוצות, '+b.groups.reduce(function(n,g){return n+g.steps.length;},0)+' שלבים'; break;
    case 'I': txt=nbPlain(b.html).trim().length+' תווים של טקסט'; break;
    case 'T': txt=b.scripts.length+' מצבים, '+b.scripts.reduce(function(n,s){return n+s.lines.length;},0)+' ניסוחים'; break;
    case 'E': txt=['when','to','conditions','document'].filter(function(f){return b[f].length;}).length+' מתוך 4 סעיפי חובה מולאו'; break;
    case 'M': txt=b.questions.length+' שאלות אבחון'; break;
  }
  return '<div style="margin-bottom:16px"><div style="font-size:11px;font-weight:600;letter-spacing:.6px;color:var(--muted);margin-bottom:8px">תוכן – '+NB_KINDS[k].full+'</div>'
    +'<div style="background:var(--input-bg);border:1px solid var(--border);border-radius:var(--rs);padding:8px 10px;font-size:13px;color:var(--text)">'+txt+(nbBodyHasContent(k,b)?'':' <span style="color:var(--red)">— עדיין אין תוכן</span>')+'</div></div>';
}

// ── LOCAL PERSISTENCE ────────────────────────────────────────────────────
// Keeps created knowledge items and the in-progress "פריט ידע חדש" form
// draft across page refreshes by mirroring them into localStorage.
var NB_STORAGE_KEYS={docs:'wecom_kb_docs_v1',topics:'wecom_kb_topics_v1',worlds:'wecom_kb_worlds_v1',draft:'wecom_kb_draft_v1',trash:'wecom_kb_trash_v1',seedVersion:'wecom_kb_seed_version_v1',history:'wecom_kb_history_v1',recent:'wecom_kb_recent_items_v1'};
var NB_HISTORY_MAX=25;

function nbSaveLibrary(historyLabel){
  try{
    localStorage.setItem(NB_STORAGE_KEYS.docs, JSON.stringify(window.dynamicDocs||{}));
    localStorage.setItem(NB_STORAGE_KEYS.topics, JSON.stringify(TOPICS||[]));
    localStorage.setItem(NB_STORAGE_KEYS.worlds, JSON.stringify(WORLDS||[]));
    localStorage.setItem(NB_STORAGE_KEYS.trash, JSON.stringify(nbTrash||[]));
    localStorage.setItem(NB_STORAGE_KEYS.seedVersion, String(NB_SEED_VERSION));
  }catch(e){ /* localStorage unavailable — fail silently */ }
  nbSnapshotHistory(historyLabel);
  nbUpdateHistoryBadge();
}

// ── VERSION HISTORY ──────────────────────────────────────────────────────
// Every time the library is saved, a snapshot of the full state (topics +
// docs) is kept so unwanted changes can be found and reverted later. Rolling
// window — oldest snapshots drop off once the cap is reached.
function nbSnapshotHistory(label){
  try{
    var raw=localStorage.getItem(NB_STORAGE_KEYS.history);
    var history=raw?JSON.parse(raw):[];
    history.push({
      id:'hist-'+Date.now()+'-'+Math.floor(Math.random()*10000),
      ts:Date.now(),
      label:label||'עדכון בספרייה',
      topics:JSON.parse(JSON.stringify(TOPICS||[])),
      docs:JSON.parse(JSON.stringify(window.dynamicDocs||{})),
      worlds:JSON.parse(JSON.stringify(WORLDS||[]))
    });
    if(history.length>NB_HISTORY_MAX) history=history.slice(history.length-NB_HISTORY_MAX);
    localStorage.setItem(NB_STORAGE_KEYS.history, JSON.stringify(history));
  }catch(e){ /* storage full or unavailable — skip this snapshot silently */ }
}

function nbGetHistory(){
  try{
    var raw=localStorage.getItem(NB_STORAGE_KEYS.history);
    return raw?JSON.parse(raw):[];
  }catch(e){ return []; }
}

function nbUpdateHistoryBadge(){
  var badge=document.getElementById('nb-history-count-nav');
  if(!badge) return;
  var n=nbGetHistory().length;
  if(n){ badge.textContent=n; badge.style.display='inline-block'; }
  else{ badge.style.display='none'; }
}

function nbRestoreHistorySnapshot(histId){
  var history=nbGetHistory();
  var snap=history.find(function(h){return h.id===histId;});
  if(!snap) return;
  var dateStr=new Date(snap.ts).toLocaleDateString('he-IL')+' '+new Date(snap.ts).toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
  nbConfirmGeneric(
    'שחזור גרסה',
    'לשחזר את הספרייה למצב שהיה ב-<strong style="color:var(--navy)">'+dateStr+'</strong>?<br><span style="font-size:12px;color:var(--muted)">כל שינוי שנעשה אחרי הגרסה הזו יוחלף (אך יישמר כגרסה משלו, כך שגם את זה ניתן יהיה לבטל).</span>',
    'שחזר',
    'var(--navy)',
    function(){
      TOPICS=JSON.parse(JSON.stringify(snap.topics));
      window.dynamicDocs=JSON.parse(JSON.stringify(snap.docs));
      if(snap.worlds) WORLDS=JSON.parse(JSON.stringify(snap.worlds));
      nbNormalizeModel(); // snapshots taken before the restructure use the old format
      nbRenderSidebar();
      nbRenderLibFilters();
      renderLibrary('all');
      renderHomeWaves();
      showView('library');
      nbSaveLibrary('שוחזר לגרסה מתאריך '+dateStr);
      nbUpdateTrashBadge();
      nbUpdateHistoryBadge();
      nbOpenHistory();
    }
  );
}

function nbOpenHistory(){
  var existing=document.getElementById('nb-history-overlay');
  if(existing) existing.remove();

  var overlay=document.createElement('div');
  overlay.id='nb-history-overlay';
  overlay.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:flex;align-items:center;justify-content:center;padding:20px';

  var modal=document.createElement('div');
  modal.style.cssText='background:#fff;border-radius:16px;padding:22px;max-width:480px;width:100%;max-height:80vh;overflow-y:auto;font-family:Rubik,sans-serif;direction:rtl';

  var head=document.createElement('div');
  head.style.cssText='display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid var(--border)';
  head.innerHTML='<div style="font-size:16px;font-weight:700;color:var(--navy)"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:-3px;margin-left:6px"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l3 3"/></svg>היסטוריית גרסאות</div>';

  var closeBtn=document.createElement('button');
  closeBtn.textContent='✕';
  closeBtn.style.cssText='background:none;border:none;font-size:16px;color:var(--muted);cursor:pointer;padding:4px 8px';
  closeBtn.addEventListener('click',function(){ overlay.remove(); });
  head.appendChild(closeBtn);

  var list=document.createElement('div');
  var history=nbGetHistory();
  if(!history.length){
    list.innerHTML='<div style="text-align:center;color:var(--muted);font-size:13.5px;padding:30px 10px">אין עדיין גרסאות שמורות</div>';
  } else {
    list.innerHTML=history.slice().reverse().map(function(snap){
      var d=new Date(snap.ts);
      var dateStr=d.toLocaleDateString('he-IL')+' '+d.toLocaleTimeString('he-IL',{hour:'2-digit',minute:'2-digit'});
      return '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 4px;border-bottom:1px solid var(--border)">'
        +'<div style="min-width:0"><div style="font-size:13.5px;font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+snap.label+'</div>'
        +'<div style="font-size:11.5px;color:var(--muted);margin-top:2px">'+dateStr+'</div></div>'
        +'<button onclick="nbRestoreHistorySnapshot(\''+snap.id+'\')" style="height:32px;padding:0 14px;background:var(--navy);color:#fff;border:none;border-radius:7px;font-size:12.5px;font-weight:600;cursor:pointer;font-family:Rubik,sans-serif;flex-shrink:0">↩️ שחזר</button>'
        +'</div>';
    }).join('');
  }

  modal.appendChild(head);
  modal.appendChild(list);
  overlay.appendChild(modal);
  overlay.addEventListener('click',function(e){ if(e.target===overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

// Built-in documents that were replaced by newer ones. On the first load
// after the content version changes, saved copies are moved to the trash
// (restorable), never silently deleted.
// <generated:doc-info>
// Generated by scripts/doc-info.cjs: origin document links and missing details per item code.
var NB_DOC_INFO = {"E-01":{"origin":{"name":"E-01 - העברה למומחה בתקלת חול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/E-01%20-%20%D7%94%D7%A2%D7%91%D7%A8%D7%94%20%D7%9C%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%D7%91%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%97%D7%95%D7%9C.docx?web=1"},"missing":["⚠ חסר מידע להשלמה:","יש להשלים רק פרטי יעד, תור או זמני טיפול שאושרו על ידי הגורם המקצועי; אין להסיק אותם מהמסמך."]},"E-10":{"origin":{"name":"E-10   הסלמה למומחה – בעיות קליטה בארץ .docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/E-10%20%20%20%D7%94%D7%A1%D7%9C%D7%9E%D7%94%20%D7%9C%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%E2%80%93%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5%20.docx?web=1"},"missing":["⚠ תפקיד הנציג הוא להשלים את מסלול הטיפול שבתחום אחריותו ולהעביר למומחה פנייה שכבר מכילה אבחון, מיקום ותוצאות בדיקות.","יש להשלים רק פרטי יעד, תור או זמני טיפול שאושרו על ידי הגורם המקצועי; אין להסיק אותם מהמסמך."]},"E-30":{"origin":{"name":"E-30 העברה למומחה בתקלת גלישה.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/E-30%20%D7%94%D7%A2%D7%91%D7%A8%D7%94%20%D7%9C%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%D7%91%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%92%D7%9C%D7%99%D7%A9%D7%94.docx?web=1"},"missing":["יש להשלים רק פרטי יעד, תור או זמני טיפול שאושרו על ידי הגורם המקצועי; אין להסיק אותם מהמסמך."]},"E-40":{"origin":{"name":"E-40 - הסלמה למומחה בתקלת שיחות.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/E-40%20-%20%D7%94%D7%A1%D7%9C%D7%9E%D7%94%20%D7%9C%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%D7%91%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA.docx?web=1"},"missing":["⚠ יש להשלים תחילה את כל הבדיקות והפעולות שבתחום האחריות של הנציג.","יש להשלים רק פרטי יעד, תור או זמני טיפול שאושרו על ידי הגורם המקצועי; אין להסיק אותם מהמסמך."]},"E-60":{"origin":{"name":"E-60 - הסלמה למומחה תקלות סמס בארץ.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/E-60%20-%20%D7%94%D7%A1%D7%9C%D7%9E%D7%94%20%D7%9C%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%D7%AA%D7%A7%D7%9C%D7%95%D7%AA%20%D7%A1%D7%9E%D7%A1%20%D7%91%D7%90%D7%A8%D7%A5.docx?web=1"},"missing":["יש להשלים רק פרטי יעד, תור או זמני טיפול שאושרו על ידי הגורם המקצועי; אין להסיק אותם מהמסמך."]},"I-101":{"missing":["⚠ חסר: איך מעבירים אליהם בקשה","⚠ חסר: האם צריכים להתקיים כל התנאים או אחד מהם"]},"I-102":{"missing":["⚠ חסר: נתיב ביצוע הניתוק ב-CRM, ומי מבצע (נציג / צוות שימור)"]},"I-111":{"missing":["⚠ חסר: האם אפשר לשנות, ואילו מסמכים נדרשים (למשל שינוי שם אחרי נישואין)","⚠ חסר: הנתיב, והאם השינוי נרשם ביומן אוטומטית","⚠ חסר: האם זה מיושם בפועל, ואיך הנציג מאמת סיסמה","⚠ חסר: איך רושמים איש קשר ב-CRM"]},"I-112":{"missing":["⚠ חסר: היכן נמצא טופס העברת הבעלות, ואיך הלקוחות מחזירים אותו (מייל / אתר / אפליקציה)","⚠ חסר: מי מבצע (נציג / צוות back office), וזמן טיפול","⚠ חסר: מה קורה לחוב פתוח של המוסר, להטבות ולתקופות התחייבות, ולחשבונית החודש שבו מתבצעת ההעברה."]},"I-115":{"missing":["⚠ חסר: אילו פרטים בדיוק מרכיבים \"זיהוי מלא\" – למשל ת״ז + 4 ספרות אחרונות של אמצעי התשלום + פרט נוסף?","⚠ חסר: האם ואיך הנציג מאמת סיסמה","⚠ חסר: איך מזהים איש קשר ומה הוא רשאי לבצע"]},"I-116":{"missing":["⚠ חסר: העלות בפועל","⚠ חסר: הנתיב ב-CRM","⚠ חסר: מה ההבדל בינה לבין \"הפסקת שירות זמנית\", ולמי מציעים כל אחת – למשל שהייה ארוכה מ-90 יום"]},"I-121":{"missing":["⚠ חסר: לאשר","⚠ חסר: קודי הדחייה ומשמעותם","⚠ חסר: היכן רואים סטטוס ניוד ב-CRM"]},"I-155":{"missing":["⚠ חסר: איך מעבירים","⚠ חסר: שלוחות ותורים נוספים (שירות ↔ תמיכה, גבייה, שימור), שעות פעילות, והאם העברה היא \"חמה\" (עם הצגה) או \"קרה\"."]},"I-81":{"missing":["⚠ חסר: היכן ואיך – מערכת מאובטחת / IVR / קישור / אזור אישי; האם הנציג רשאי להקליד מספר כרטיס","⚠ חסר: התהליך (טופס הרשאה לחיוב? אישור בנק?) וזמן הקליטה","⚠ חסר: האם מבצעים מיד סליקה חוזרת על אמצעי התשלום החדש"]},"I-82":{"missing":["⚠ חסר: עד איזה סכום הנציג מזכה בעצמו, ומעליו – אחמ״ש / מנהל","⚠ חסר: האם יש מדיניות פיצוי","⚠ חסר: איך הזיכוי מופיע – בחשבונית הבאה? החזר לכרטיס? תוך כמה זמן"]},"I-83":{"missing":["⚠ חסר: לאשר שהתעריפים בטבלה עדכניים"]},"I-93":{"missing":["⚠ חסר: איך משלמים חוב: תשלום מיידי בשיחה, קישור לתשלום, אזור אישי, ניסיון סליקה חוזר – ומי מורשה לבצע כל אחד.","⚠ חסר: תוך כמה זמן הקו נפתח אחרי תשלום, האם אוטומטית, ומה עושים אם לא נפתח."]},"M-00":{"origin":{"name":"M-00 תקלות ושירות בחול - אבחון מרכזי.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/M-00%20%D7%AA%D7%A7%D7%9C%D7%95%D7%AA%20%D7%95%D7%A9%D7%99%D7%A8%D7%95%D7%AA%20%D7%91%D7%97%D7%95%D7%9C%20-%20%D7%90%D7%91%D7%97%D7%95%D7%9F%20%D7%9E%D7%A8%D7%9B%D7%96%D7%99.docx?web=1"},"missing":["לאמת את מבנה העץ מול מסמך המקור: כל תשובה מובילה לשלב או לפריט הנכון.","לאמת הפניות לפריטים אחרים, שמות מסכים וערכים במערכות מול מסמך המקור והגורם המקצועי."]},"M-10":{"origin":{"name":"M-10_אבחון_מרכזי_קליטה_בארץ_מתוקן.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/M-10_%D7%90%D7%91%D7%97%D7%95%D7%9F_%D7%9E%D7%A8%D7%9B%D7%96%D7%99_%D7%A7%D7%9C%D7%99%D7%98%D7%94_%D7%91%D7%90%D7%A8%D7%A5_%D7%9E%D7%AA%D7%95%D7%A7%D7%9F.docx?web=1"},"missing":["לאמת את מבנה העץ מול מסמך המקור: כל תשובה מובילה לשלב או לפריט הנכון.","חסר: המסמך \"בעיות VoLTE ומכשירים ישנים\" אינו קיים באפליקציה — להוסיף אותו ולקשר את הענף \"השיחה מתחברת אך מתנתקת… במקומות שונים\".","לאמת הפניות לפריטים אחרים, שמות מסכים וערכים במערכות מול מסמך המקור והגורם המקצועי."]},"M-30":{"origin":{"name":"M-30 - איטיות או חוסר גלישה - אבחון מרכזי.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/M-30%20-%20%D7%90%D7%99%D7%98%D7%99%D7%95%D7%AA%20%D7%90%D7%95%20%D7%97%D7%95%D7%A1%D7%A8%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20-%20%D7%90%D7%91%D7%97%D7%95%D7%9F%20%D7%9E%D7%A8%D7%9B%D7%96%D7%99.docx?web=1"},"missing":["לאמת את מבנה העץ מול מסמך המקור: כל תשובה מובילה לשלב או לפריט הנכון.","לאמת הפניות לפריטים אחרים, שמות מסכים וערכים במערכות מול מסמך המקור והגורם המקצועי."]},"M-40":{"origin":{"name":"M-40 אבחון מרכזי שיחות הפניה לקליטה מעודכן.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/M-40%20%D7%90%D7%91%D7%97%D7%95%D7%9F%20%D7%9E%D7%A8%D7%9B%D7%96%D7%99%20%D7%A9%D7%99%D7%97%D7%95%D7%AA%20%D7%94%D7%A4%D7%A0%D7%99%D7%94%20%D7%9C%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%9E%D7%A2%D7%95%D7%93%D7%9B%D7%9F.docx?web=1"},"missing":["לאמת את מבנה העץ מול מסמך המקור: כל תשובה מובילה לשלב או לפריט הנכון.","חסר: המסמך \"בעיות VoLTE ומכשירים ישנים\" אינו קיים באפליקציה — להוסיף אותו ולקשר את הענף \"השיחה מתחברת אך מתנתקת… במקומות שונים\".","לאמת הפניות לפריטים אחרים, שמות מסכים וערכים במערכות מול מסמך המקור והגורם המקצועי."]},"M-60":{"origin":{"name":"M-60 - אבחון מרכזי תקלות סמס בארץ.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/M-60%20-%20%D7%90%D7%91%D7%97%D7%95%D7%9F%20%D7%9E%D7%A8%D7%9B%D7%96%D7%99%20%D7%AA%D7%A7%D7%9C%D7%95%D7%AA%20%D7%A1%D7%9E%D7%A1%20%D7%91%D7%90%D7%A8%D7%A5.docx?web=1"},"missing":["לאמת את מבנה העץ מול מסמך המקור: כל תשובה מובילה לשלב או לפריט הנכון.","לאמת הפניות לפריטים אחרים, שמות מסכים וערכים במערכות מול מסמך המקור והגורם המקצועי."]},"M-80":{"missing":["⚠ חסר: לאשר לאיזה חודש זה חל ומתי להסיר מהמסמך","⚠ חסר: איפה הלקוח רואה ומוריד חשבוניות (אזור אישי / אפליקציה / מייל), ותמונה מסומנת של סעיפי החשבונית."]},"O-01":{"origin":{"name":"O-01 - בדיקות שירותי נדידה וחבילת חול במערכת.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/O-01%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%95%D7%AA%20%D7%A9%D7%99%D7%A8%D7%95%D7%AA%D7%99%20%D7%A0%D7%93%D7%99%D7%93%D7%94%20%D7%95%D7%97%D7%91%D7%99%D7%9C%D7%AA%20%D7%97%D7%95%D7%9C%20%D7%91%D7%9E%D7%A2%D7%A8%D7%9B%D7%AA.docx?web=1"}},"O-02":{"origin":{"name":"O-02 - בדיקה והפעלת נדידת נתונים במכשיר.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/O-02%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%94%20%D7%95%D7%94%D7%A4%D7%A2%D7%9C%D7%AA%20%D7%A0%D7%93%D7%99%D7%93%D7%AA%20%D7%A0%D7%AA%D7%95%D7%A0%D7%99%D7%9D%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8.docx?web=1"},"missing":[]},"O-03":{"origin":{"name":"O-03 - הגדרת APN בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/O-03%20-%20%D7%94%D7%92%D7%93%D7%A8%D7%AA%20APN%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":[]},"O-04":{"origin":{"name":"O-04  תפעול_STK_בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/O-04%20%20%D7%AA%D7%A4%D7%A2%D7%95%D7%9C_STK_%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":[]},"O-05":{"origin":{"name":"O-05 - בחירת רשת ידנית בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/O-05%20-%20%D7%91%D7%97%D7%99%D7%A8%D7%AA%20%D7%A8%D7%A9%D7%AA%20%D7%99%D7%93%D7%A0%D7%99%D7%AA%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":[]},"O-06":{"origin":{"name":"0-06 תאימות מכשירים  בארהב.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/0-06%20%D7%AA%D7%90%D7%99%D7%9E%D7%95%D7%AA%20%D7%9E%D7%9B%D7%A9%D7%99%D7%A8%D7%99%D7%9D%20%20%D7%91%D7%90%D7%A8%D7%94%D7%91.docx?web=1"},"missing":["טיוטת פריט חדש — לבדיקה ואישור, לא לפרסום","יש להשוות את התוכן וההפניות למקור, להשלים רק מידע מאומת, ולא לפרסם לפני בדיקה ואישור.","יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום.","שם המקור מתחיל ב־0-06; יש לאמת את הקוד מול הגורם המקצועי."]},"O-10":{"origin":{"name":"O-10 - בדיקת מפת כיסוי ואנטנות.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/O-10%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%AA%20%D7%9E%D7%A4%D7%AA%20%D7%9B%D7%99%D7%A1%D7%95%D7%99%20%D7%95%D7%90%D7%A0%D7%98%D7%A0%D7%95%D7%AA.docx?web=1"},"missing":["⚠ נדרש להשלים:"]},"O-12":{"origin":{"name":"O-12 - הפעלת שיחות ברשת אלחוטית  wifiCalling.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/O-12%20-%20%D7%94%D7%A4%D7%A2%D7%9C%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA%20%D7%91%D7%A8%D7%A9%D7%AA%20%D7%90%D7%9C%D7%97%D7%95%D7%98%D7%99%D7%AA%20%20wifiCalling.docx?web=1"},"missing":["⚠ יש לבדוק מול רשימת המכשירים הנתמכים של החברה, אם קיימת."]},"O-13":{"origin":{"name":"איפוס הגדרות רשת O-13.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/%D7%90%D7%99%D7%A4%D7%95%D7%A1%20%D7%94%D7%92%D7%93%D7%A8%D7%95%D7%AA%20%D7%A8%D7%A9%D7%AA%20O-13.docx?web=1"},"missing":[]},"O-156":{"missing":["⚠ חסר: הכלי – משימה ב-CRM / פנייה פתוחה / יומן Callback","⚠ חסר: יעד זמן (SLA) לחזרה, ומספר ניסיונות לפני סגירה","⚠ חסר: האם שולחים SMS, וכמה ניסיונות"]},"O-200":{"origin":{"name":"O-200 מדריך נוהל העברת בעלות.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99%20%D7%9E%D7%98%D7%94/O-200%20%D7%9E%D7%93%D7%A8%D7%99%D7%9A%20%D7%A0%D7%95%D7%94%D7%9C%20%D7%94%D7%A2%D7%91%D7%A8%D7%AA%20%D7%91%D7%A2%D7%9C%D7%95%D7%AA.docx?web=1"},"missing":["⚠ להשלים: מי מבצע את הנוהל – נציג שירות או גורם במטה (המסמך נמסר כחלק ממדריכי מטה).","⚠ להשלים: שם המסמך / התבנית בגלסיקס, והיכן היא נמצאת.","⚠ להשלים: איך מבצעים את ההקלטה והיכן היא נשמרת.","⚠ להשלים: מה עושים אם אחד הצדדים לא מאשר או לא זמין.","⚠ להשלים: הפעולות המדויקות ב-CRM להעברת הקווים בין החשבונות."]},"O-201":{"origin":{"name":"O-201 סיכום מדריכי חישובי נתונים.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99%20%D7%9E%D7%98%D7%94/O-201%20%D7%A1%D7%99%D7%9B%D7%95%D7%9D%20%D7%9E%D7%93%D7%A8%D7%99%D7%9B%D7%99%20%D7%97%D7%99%D7%A9%D7%95%D7%91%D7%99%20%D7%A0%D7%AA%D7%95%D7%A0%D7%99%D7%9D.docx?web=1"},"missing":["⚠ להשלים: מה ההגדרה של \"רמת שירות A\" (סף זמן מענה).","⚠ להשלים: באילו דוחות מסכמים מדובר והיכן הם נמצאים.","⚠ להשלים: היכן נמצאים \"דוח פניות מפורט\" ו\"דוח תבנית פיריון\".","⚠ להשלים: למי ובאיזו דרך שולחים את הדוח, ובאיזו תדירות המשרד מבקש אותו."]},"O-31":{"origin":{"name":"O-31 הגדרות בסיסיות לגלישה סלולרית.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/O-31%20%D7%94%D7%92%D7%93%D7%A8%D7%95%D7%AA%20%D7%91%D7%A1%D7%99%D7%A1%D7%99%D7%95%D7%AA%20%D7%9C%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%A1%D7%9C%D7%95%D7%9C%D7%A8%D7%99%D7%AA.docx?web=1"},"missing":[]},"O-32":{"origin":{"name":"הגדרת APN במכשיר O-32.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/%D7%94%D7%92%D7%93%D7%A8%D7%AA%20APN%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8%20O-32.docx?web=1"},"missing":["⚠ ⚙️ הגדרת ה־ APN במכשיר חסרה או אינה מוגדרת נכון.","⚠️ אם לא קיימת אפשרות להוסיף נקודת גישה – ייתכן שמדובר בחסימה של הדגם הכשר."]},"O-33":{"origin":{"name":"O-33 חוסך נתונים ומגבלת נתונים - בדיקה וביטול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/O-33%20%D7%97%D7%95%D7%A1%D7%9A%20%D7%A0%D7%AA%D7%95%D7%A0%D7%99%D7%9D%20%D7%95%D7%9E%D7%92%D7%91%D7%9C%D7%AA%20%D7%A0%D7%AA%D7%95%D7%A0%D7%99%D7%9D%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%94%20%D7%95%D7%91%D7%99%D7%98%D7%95%D7%9C.docx?web=1"},"missing":[]},"O-34":{"origin":{"name":"תקלת גלישה - VPN פעיל במכשיר O-34.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20-%20VPN%20%D7%A4%D7%A2%D7%99%D7%9C%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8%20O-34.docx?web=1"},"missing":["⚠ אם החיבור מנוהל או שלא ניתן לנתקו, אין לעקוף הגבלה. הפנה לגורם המנהל לצורך הבדיקה ותעד שלא ניתן היה להשלים אותה."]},"O-35":{"origin":{"name":"O35 תקלת גלישה קו מנוהל והגבלות ארגוניות.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/O35%20%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%A7%D7%95%20%D7%9E%D7%A0%D7%95%D7%94%D7%9C%20%D7%95%D7%94%D7%92%D7%91%D7%9C%D7%95%D7%AA%20%D7%90%D7%A8%D7%92%D7%95%D7%A0%D7%99%D7%95%D7%AA.docx?web=1"},"missing":["⚠ אם בדיקה לא הושלמה בשל מגבלה חיצונית, יש להשלים אותה מול הגורם המנהל ולהמשיך לפי תוצאותיה. אין לסמן אותה כתקינה."]},"O-36":{"origin":{"name":"נקודת גישה אישית Hotspot לא עובד O-36.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/%D7%A0%D7%A7%D7%95%D7%93%D7%AA%20%D7%92%D7%99%D7%A9%D7%94%20%D7%90%D7%99%D7%A9%D7%99%D7%AA%20Hotspot%20%D7%9C%D7%90%20%D7%A2%D7%95%D7%91%D7%93%20O-36.docx?web=1"},"missing":["טיוטת פריט חדש — לבדיקה ואישור, לא לפרסום","יש להשוות את התוכן וההפניות למקור, להשלים רק מידע מאומת, ולא לפרסם לפני בדיקה ואישור."]},"O-37":{"origin":{"name":"O-37 תקלת גלישה שני קווים פעילים במכשיר.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/O-37%20%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%A9%D7%A0%D7%99%20%D7%A7%D7%95%D7%95%D7%99%D7%9D%20%D7%A4%D7%A2%D7%99%D7%9C%D7%99%D7%9D%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8.docx?web=1"},"missing":["טיוטת פריט חדש — לבדיקה ואישור, לא לפרסום","יש להשוות את התוכן וההפניות למקור, להשלים רק מידע מאומת, ולא לפרסם לפני בדיקה ואישור.","יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."]},"O-40":{"origin":{"name":"אצל שחר O-40 - בדיקת סטטוס קו וחסימות שיחה במערכת.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%98%D7%99%D7%95%D7%98%D7%94%20-%20%D7%91%D7%91%D7%93%D7%99%D7%A7%D7%94%20%D7%A2%D7%93%D7%99%D7%9F/%D7%90%D7%A6%D7%9C%20%D7%A9%D7%97%D7%A8%20O-40%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%AA%20%D7%A1%D7%98%D7%98%D7%95%D7%A1%20%D7%A7%D7%95%20%D7%95%D7%97%D7%A1%D7%99%D7%9E%D7%95%D7%AA%20%D7%A9%D7%99%D7%97%D7%94%20%D7%91%D7%9E%D7%A2%D7%A8%D7%9B%D7%AA.docx?web=1"},"missing":["⚠ להשלמה: צילום מסך של הבדיקה.","⚠ להשלמה: לבדוק מול שחר אם הבדיקה קיימת ב-CRM.","⚠ להשלמה: צילום מסך של הבדיקה.","⚠ להשלמה: צילום מסך של הבדיקה.","⚠ להשלמה: צילום מסך וקישור חדש לתהליך הרענון.","⚠ להוסיף צילום מסך","⚠ לבדוק מול שחר אם קיים בCRM","⚠ להוסיף צילום מסך","⚠ להוסיף צילום מסך","⚠ להוסיף צילום מסך – לינק חדש","שלבים 2, 5, 6 ו\"לאחר תיקון במערכת\" – חסרים צילומי מסך.","שלב 3 – לא אומת אם בדיקת חסימות השיחה קיימת ב-CRM (לבדוק מול שחר).","שלב 2 – \"התהליך המאושר\" לטיפול בחסימה כספית אינו מפורט ואין אליו הפניה.","לאחר תיקון – \"תהליך הרענון המאושר\" אינו מפורט; נדרש קישור."]},"O-41":{"origin":{"name":"אצל שחר O-41 - בדיקת הפניית שיחות והגדרות שיחה במערכת.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%98%D7%99%D7%95%D7%98%D7%94%20-%20%D7%91%D7%91%D7%93%D7%99%D7%A7%D7%94%20%D7%A2%D7%93%D7%99%D7%9F/%D7%90%D7%A6%D7%9C%20%D7%A9%D7%97%D7%A8%20O-41%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%AA%20%D7%94%D7%A4%D7%A0%D7%99%D7%99%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA%20%D7%95%D7%94%D7%92%D7%93%D7%A8%D7%95%D7%AA%20%D7%A9%D7%99%D7%97%D7%94%20%D7%91%D7%9E%D7%A2%D7%A8%D7%9B%D7%AA.docx?web=1"},"missing":["⚠ להשלמה: שחר – צילום מסך והנחיות היכן בודקים הפניות במערכת.","⚠ שחר להוסיף צילום מסך והנחיות איפה בודקים הפניות","שלב 1 – חסרים צילום מסך והנחיות היכן בודקים הפניות (שחר)."]},"O-42":{"origin":{"name":"O-42 - בדיקת חסימות והגדרות שיחה במכשיר.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/O-42%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%AA%20%D7%97%D7%A1%D7%99%D7%9E%D7%95%D7%AA%20%D7%95%D7%94%D7%92%D7%93%D7%A8%D7%95%D7%AA%20%D7%A9%D7%99%D7%97%D7%94%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8.docx?web=1"},"missing":[]},"O-43":{"origin":{"name":"O-43 -VoLTE בדיקה והפעלת וולטה במכשיר.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/O-43%20-VoLTE%20%D7%91%D7%93%D7%99%D7%A7%D7%94%20%D7%95%D7%94%D7%A4%D7%A2%D7%9C%D7%AA%20%D7%95%D7%95%D7%9C%D7%98%D7%94%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8.docx?web=1"},"missing":[]},"O-44":{"origin":{"name":"אצל שחר  O-44 - בדיקת תאימות מכשיר וולטה-VoLTE.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%98%D7%99%D7%95%D7%98%D7%94%20-%20%D7%91%D7%91%D7%93%D7%99%D7%A7%D7%94%20%D7%A2%D7%93%D7%99%D7%9F/%D7%90%D7%A6%D7%9C%20%D7%A9%D7%97%D7%A8%20%20O-44%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%AA%20%D7%AA%D7%90%D7%99%D7%9E%D7%95%D7%AA%20%D7%9E%D7%9B%D7%A9%D7%99%D7%A8%20%D7%95%D7%95%D7%9C%D7%98%D7%94-VoLTE.docx?web=1"},"missing":["⚠ להשלמה: שחר – רשימת המכשירים המאושרים ל-VoLTE.","⚠ שחר להוסיף את הרשימה","⚠ יש להשלים זיהוי מדויק לפני המשך הטיפול.","שלב 2 – חסרה רשימת המכשירים המאושרים ל-VoLTE (שחר).","שלב 2 – \"מדיניות התמיכה של החברה\" למכשיר שאינו ברשימה אינה מפורטת.","תוצאה – \"התהליך שנקבע למכשיר שאינו תומך ב-VoLTE\" אינו מפורט ואין אליו הפניה."]},"O-50":{"origin":{"name":"O-50 הפעלת SIM פיזי חדש.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/50%20-%20SIM%20%26%20Esim/O-50%20%D7%94%D7%A4%D7%A2%D7%9C%D7%AA%20SIM%20%D7%A4%D7%99%D7%96%D7%99%20%D7%97%D7%93%D7%A9.docx?web=1"},"missing":[]},"O-51":{"origin":{"name":"O-51 __הפעלת_eSIM באמצעות_קוד_QR.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/50%20-%20SIM%20%26%20Esim/O-51%20__%D7%94%D7%A4%D7%A2%D7%9C%D7%AA_eSIM%20%D7%91%D7%90%D7%9E%D7%A6%D7%A2%D7%95%D7%AA_%D7%A7%D7%95%D7%93_QR.docx?web=1"},"missing":[]},"O-52":{"origin":{"name":"O-52   מעבר מסים פיזי לאיסים או מעבר למכשיר חדש.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/50%20-%20SIM%20%26%20Esim/O-52%20%20%20%D7%9E%D7%A2%D7%91%D7%A8%20%D7%9E%D7%A1%D7%99%D7%9D%20%D7%A4%D7%99%D7%96%D7%99%20%D7%9C%D7%90%D7%99%D7%A1%D7%99%D7%9D%20%D7%90%D7%95%20%D7%9E%D7%A2%D7%91%D7%A8%20%D7%9C%D7%9E%D7%9B%D7%A9%D7%99%D7%A8%20%D7%97%D7%93%D7%A9.docx?web=1"},"missing":[]},"O-53":{"missing":["⚠ חסר: רשימת סטטוסי הקו ב-CRM (פעיל / רשום / בניוד…) ומשמעות כל אחד","⚠ חסר: מה המשמעות של קוד 13 ושל קוד 33 ומה עושים בכל מקרה","⚠ חסר: לאן מסלימים תקלת קו חדש בארץ (מומחה / תמיכה טכנית דרג ב׳), ובאיזה פורמט"]},"O-54":{"missing":["⚠ חסר: איך שולחים מחדש את מייל ה-QR מה-CRM, ואם אפשר לשלוח לכתובת אחרת","⚠ חסר: האם QR של wecom חד-פעמי, ונתיב ההנפקה מחדש","⚠ חסר: בניוד – האם הקוד נשלח למספר המנויד שעדיין פעיל אצל המפעיל הקודם (ואז הסים הישן חייב להיות במכשיר)","⚠ חסר: חלופה להפעלה (הפעלה ע״י נציג?)"]},"O-55":{"origin":{"name":"החלפת SIM אבוד, גנוב או תקול וחסימת קו O 55.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/50%20-%20SIM%20%26%20Esim/%D7%94%D7%97%D7%9C%D7%A4%D7%AA%20SIM%20%D7%90%D7%91%D7%95%D7%93%2C%20%D7%92%D7%A0%D7%95%D7%91%20%D7%90%D7%95%20%D7%AA%D7%A7%D7%95%D7%9C%20%D7%95%D7%97%D7%A1%D7%99%D7%9E%D7%AA%20%D7%A7%D7%95%20O%2055.docx?web=1"},"missing":[]},"O-56":{"origin":{"name":"תיאום שליחות ובירור סטטוס משלוח SIM  O 56.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/50%20-%20SIM%20%26%20Esim/%D7%AA%D7%99%D7%90%D7%95%D7%9D%20%D7%A9%D7%9C%D7%99%D7%97%D7%95%D7%AA%20%D7%95%D7%91%D7%99%D7%A8%D7%95%D7%A8%20%D7%A1%D7%98%D7%98%D7%95%D7%A1%20%D7%9E%D7%A9%D7%9C%D7%95%D7%97%20SIM%20%20O%2056.docx?web=1"},"missing":["⚠ משלוח שלא ניתן למסור בעקבות פרטים שגויים או חסרים."]},"O-57":{"missing":["⚠ חסר: האם זה שיתוף פעולה פעיל, ובאילו סניפים","⚠ חסר: רשימת סניפים או קישור, ושעות פתיחה","⚠ חסר: תעודה מזהה? הודעת SMS / קוד איסוף?","⚠ חסר: מותר? באילו תנאים?","⚠ חסר: כמה ימים הכרטיס ממתין בסניף, ומה קורה אחר כך","⚠ חסר: האם יש עלות לאיסוף","⚠ חסר: למי פונים ומה בודקים"]},"O-58":{"missing":[]},"O-59":{"missing":[]},"O-60":{"origin":{"name":"O-60 - בדיקת חסימות, ספאם והגדרות  סמס במכשיר.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/O-60%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%AA%20%D7%97%D7%A1%D7%99%D7%9E%D7%95%D7%AA%2C%20%D7%A1%D7%A4%D7%90%D7%9D%20%D7%95%D7%94%D7%92%D7%93%D7%A8%D7%95%D7%AA%20%20%D7%A1%D7%9E%D7%A1%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8.docx?web=1"},"missing":[]},"O-61":{"origin":{"name":"O-61 - בדיקת מרכז הודעות סמס במכשיר.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/O-61%20-%20%D7%91%D7%93%D7%99%D7%A7%D7%AA%20%D7%9E%D7%A8%D7%9B%D7%96%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%A1%D7%9E%D7%A1%20%D7%91%D7%9E%D7%9B%D7%A9%D7%99%D7%A8.docx?web=1"},"missing":["אם העדכון הצליח, המשך לשלב 4. אם התפריט אינו נפתח, השדה אינו זמין או שלא ניתן להשלים את העדכון, תעד זאת וחזור ל־R‑60 לשלב הבא. אין לחזור שוב ושוב על ניסיון שנכשל או להשתמש בקודים אחרים."]},"O-80":{"missing":["⚠ חסר: האם מותר לשלוח לכתובת מייל אחרת שהלקוח מוסר בשיחה","⚠ חסר: הנתיב – שליחה מה-CRM / הפניה לאזור האישי או לאפליקציה","⚠ חסר: האם יש מסמך אישור, ואיך מפיקים אותו"]},"R-01":{"origin":{"name":"R-01 אין קליטה אין רישום לרשת בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-01%20%D7%90%D7%99%D7%9F%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%90%D7%99%D7%9F%20%D7%A8%D7%99%D7%A9%D7%95%D7%9D%20%D7%9C%D7%A8%D7%A9%D7%AA%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":["⚠ להוסיף לינק לבדיקת האם נדידה פתוחה"]},"R-02":{"origin":{"name":"R-02 - אין גלישה בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-02%20-%20%D7%90%D7%99%D7%9F%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":[]},"R-03":{"origin":{"name":"R-03 - תקלה באפליקציה מסוימת בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-03%20-%20%D7%AA%D7%A7%D7%9C%D7%94%20%D7%91%D7%90%D7%A4%D7%9C%D7%99%D7%A7%D7%A6%D7%99%D7%94%20%D7%9E%D7%A1%D7%95%D7%99%D7%9E%D7%AA%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":[]},"R-04":{"origin":{"name":"R-04 תקלת שיחות בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-04%20%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":["⚠ לפי מסמך המקור, אין צורך להוסיף קידומת מדינה בחיוג לישראל."]},"R-05":{"origin":{"name":"R-05 - תקלות הודעות בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%9E%D7%95%D7%9B%D7%9F%20-%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-05%20-%20%D7%AA%D7%A7%D7%9C%D7%95%D7%AA%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"},"missing":[]},"R-06":{"origin":{"name":"אצל דקלR-06 תקלה בקבלת OTP בחול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/00%20-%20%D7%97%D7%95%D7%9C/%D7%98%D7%99%D7%95%D7%98%D7%94%20-%20%D7%A2%D7%93%D7%99%D7%9F%20%D7%91%D7%91%D7%93%D7%99%D7%A7%D7%94/%D7%90%D7%A6%D7%9C%20%D7%93%D7%A7%D7%9CR-06%20%D7%AA%D7%A7%D7%9C%D7%94%20%D7%91%D7%A7%D7%91%D7%9C%D7%AA%20OTP%20%D7%91%D7%97%D7%95%D7%9C.docx?web=1"}},"R-100":{"missing":["⚠ חסר: האם נציג שירות/תמיכה מוכר בעצמו, או תמיד מעביר למכירות","⚠ חסר: שעות המכירות – בצילום המסך מופיע \"עד 17:00\""]},"R-11":{"origin":{"name":"R-11 - קליטה חלשה במקום מסוים.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R-11%20-%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%97%D7%9C%D7%A9%D7%94%20%D7%91%D7%9E%D7%A7%D7%95%D7%9D%20%D7%9E%D7%A1%D7%95%D7%99%D7%9D.docx?web=1"},"missing":[]},"R-12":{"origin":{"name":"R-12 - קליטה חלשה או ניתוקים בנסיעה.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R-12%20-%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%97%D7%9C%D7%A9%D7%94%20%D7%90%D7%95%20%D7%A0%D7%99%D7%AA%D7%95%D7%A7%D7%99%D7%9D%20%D7%91%D7%A0%D7%A1%D7%99%D7%A2%D7%94.docx?web=1"},"missing":[]},"R-13":{"origin":{"name":"R-13 - הרעה חדשה בקליטה באזור.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R-13%20-%20%D7%94%D7%A8%D7%A2%D7%94%20%D7%97%D7%93%D7%A9%D7%94%20%D7%91%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%96%D7%95%D7%A8.docx?web=1"},"missing":[]},"R-14":{"origin":{"name":"R-14 אין קליטה אין שירות בארץ - מסלול טיפול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R-14%20%D7%90%D7%99%D7%9F%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%90%D7%99%D7%9F%20%D7%A9%D7%99%D7%A8%D7%95%D7%AA%20%D7%91%D7%90%D7%A8%D7%A5%20-%20%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C.docx?web=1"},"missing":["טיוטת פריט חדש — לבדיקה ואישור, לא לפרסום","יש להשוות את התוכן וההפניות למקור, להשלים רק מידע מאומת, ולא לפרסם לפני בדיקה ואישור.","יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."]},"R-31":{"origin":{"name":"R31 - אין גלישה בכל מקום - מסלול טיפול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R31%20-%20%D7%90%D7%99%D7%9F%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%9B%D7%9C%20%D7%9E%D7%A7%D7%95%D7%9D%20-%20%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C.docx?web=1"},"missing":["⚠ נדרש להשלים ידע והפניה למסמך תפעול מתאים.","⚠ נדרש להשלים: שם הכפתור, מיקום במערכת והנחיות שימוש."]},"R-32":{"origin":{"name":"R32 - אין גלישה במקום מסוים - מסלול טיפול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R32%20-%20%D7%90%D7%99%D7%9F%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%9E%D7%A7%D7%95%D7%9D%20%D7%9E%D7%A1%D7%95%D7%99%D7%9D%20-%20%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C.docx?web=1"},"missing":[]},"R-33":{"origin":{"name":"R-33_גלישה_איטית_בכל_מקום_מתוקן.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R-33_%D7%92%D7%9C%D7%99%D7%A9%D7%94_%D7%90%D7%99%D7%98%D7%99%D7%AA_%D7%91%D7%9B%D7%9C_%D7%9E%D7%A7%D7%95%D7%9D_%D7%9E%D7%AA%D7%95%D7%A7%D7%9F.docx?web=1"},"missing":[]},"R-34":{"origin":{"name":"R34 - גלישה איטית במקום מסוים - מסלול טיפול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R34%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%90%D7%99%D7%98%D7%99%D7%AA%20%D7%91%D7%9E%D7%A7%D7%95%D7%9D%20%D7%9E%D7%A1%D7%95%D7%99%D7%9D%20-%20%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C.docx?web=1"},"missing":[]},"R-35":{"origin":{"name":"R35 - אין גלישה במהלך שיחה - מסלול טיפול.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/R35%20-%20%D7%90%D7%99%D7%9F%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%9E%D7%94%D7%9C%D7%9A%20%D7%A9%D7%99%D7%97%D7%94%20-%20%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C.docx?web=1"},"missing":[]},"R-36":{"missing":["⚠ חסר: האם כל החבילות מאפשרות Hotspot, כולל SIM DATA, ואם יש מגבלת נפח לשיתוף","⚠ חסר: לאן מסלימים"]},"R-40":{"origin":{"name":"R-40 - לא ניתן להוציא ולקבל שיחות.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-40%20-%20%D7%9C%D7%90%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%94%D7%95%D7%A6%D7%99%D7%90%20%D7%95%D7%9C%D7%A7%D7%91%D7%9C%20%D7%A9%D7%99%D7%97%D7%95%D7%AA.docx?web=1"},"missing":[]},"R-41":{"origin":{"name":"R-41 - לא ניתן להוציא שיחות.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-41%20-%20%D7%9C%D7%90%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%94%D7%95%D7%A6%D7%99%D7%90%20%D7%A9%D7%99%D7%97%D7%95%D7%AA.docx?web=1"},"missing":["⚠ פער מקצועי להשלמה:יש להגדיר את בדיקת התאמת ה-SIM למערכת ואת פעולת רענון ה SIM המאושרת לנציג."]},"R-42":{"origin":{"name":"R-42 - לא מתקבלות שיחות.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-42%20-%20%D7%9C%D7%90%20%D7%9E%D7%AA%D7%A7%D7%91%D7%9C%D7%95%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA.docx?web=1"},"missing":["⚠ הקשב למה שמתקבל בחיוג - צליל חיוג, הודעה, מעבר לתא קולי או ניתוק - כדי לאמת את התקלה ולזהות כיצד היא מתבטאת.","⚠ פער מקצועי להשלמה:יש להגדיר את בדיקת התאמת ה-SIM למערכת ואת פעולת רענון ה SIM המאושרת לנציג."]},"R-43":{"origin":{"name":"קושי בקבלת הוצאת שיחות מספר מסוים R43.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/%D7%A7%D7%95%D7%A9%D7%99%20%D7%91%D7%A7%D7%91%D7%9C%D7%AA%20%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA%20%D7%9E%D7%A1%D7%A4%D7%A8%20%D7%9E%D7%A1%D7%95%D7%99%D7%9D%20R43.docx?web=1"},"missing":[]},"R-44":{"origin":{"name":"R-44  לא מתקבלות שיחות לאחר ניוד.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/R-44%20%20%D7%9C%D7%90%20%D7%9E%D7%AA%D7%A7%D7%91%D7%9C%D7%95%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA%20%D7%9C%D7%90%D7%97%D7%A8%20%D7%A0%D7%99%D7%95%D7%93.docx?web=1"},"missing":[]},"R-45":{"origin":{"name":"תקלה בחיוג בינלאומי R-45 .docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/%D7%AA%D7%A7%D7%9C%D7%94%20%D7%91%D7%97%D7%99%D7%95%D7%92%20%D7%91%D7%99%D7%A0%D7%9C%D7%90%D7%95%D7%9E%D7%99%20R-45%20.docx?web=1"},"missing":["טיוטת פריט חדש — לבדיקה ואישור, לא לפרסום","יש להשוות את התוכן וההפניות למקור, להשלים רק מידע מאומת, ולא לפרסם לפני בדיקה ואישור.","יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום.","יש לאמת את הקוד ואת ההפניות מול R-150 לפני אישור."]},"R-50":{"origin":{"name":"R-50_מסלול טיפול לאחר הפעלת_SIM_eSIM.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/50%20-%20SIM%20%26%20Esim/R-50_%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C%20%D7%9C%D7%90%D7%97%D7%A8%20%D7%94%D7%A4%D7%A2%D7%9C%D7%AA_SIM_eSIM.docx?web=1"},"missing":["טיוטת פריט חדש — לבדיקה ואישור, לא לפרסום","יש להשוות את התוכן וההפניות למקור, להשלים רק מידע מאומת, ולא לפרסם לפני בדיקה ואישור.","יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."]},"R-51":{"origin":{"name":"R-51 קוד QR  של ESIM לא נסרק - לא מתקבל .docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/50%20-%20SIM%20%26%20Esim/R-51%20%D7%A7%D7%95%D7%93%20QR%20%20%D7%A9%D7%9C%20ESIM%20%D7%9C%D7%90%20%D7%A0%D7%A1%D7%A8%D7%A7%20-%20%D7%9C%D7%90%20%D7%9E%D7%AA%D7%A7%D7%91%D7%9C%20.docx?web=1"},"missing":["טיוטת פריט חדש — לבדיקה ואישור, לא לפרסום","יש להשוות את התוכן וההפניות למקור, להשלים רק מידע מאומת, ולא לפרסם לפני בדיקה ואישור.","יש להשוות את התוכן וההפניות למסמך המקור לפני אישור ופרסום."]},"R-60":{"origin":{"name":"R-60 - לא ניתן לשלוח  סמס בכלל.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/R-60%20-%20%D7%9C%D7%90%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A9%D7%9C%D7%95%D7%97%20%20%D7%A1%D7%9E%D7%A1%20%D7%91%D7%9B%D7%9C%D7%9C.docx?web=1"},"missing":[]},"R-61":{"origin":{"name":"R-61 - לא ניתן לקבל סמס בכלל.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/R-61%20-%20%D7%9C%D7%90%20%D7%A0%D7%99%D7%AA%D7%9F%20%D7%9C%D7%A7%D7%91%D7%9C%20%D7%A1%D7%9E%D7%A1%20%D7%91%D7%9B%D7%9C%D7%9C.docx?web=1"},"missing":[]},"R-62":{"origin":{"name":"R-62 - תקלה בשליחה או קבלה מול מספר מסוים.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/R-62%20-%20%D7%AA%D7%A7%D7%9C%D7%94%20%D7%91%D7%A9%D7%9C%D7%99%D7%97%D7%94%20%D7%90%D7%95%20%D7%A7%D7%91%D7%9C%D7%94%20%D7%9E%D7%95%D7%9C%20%D7%9E%D7%A1%D7%A4%D7%A8%20%D7%9E%D7%A1%D7%95%D7%99%D7%9D.docx?web=1"},"missing":[]},"R-63":{"origin":{"name":"R-63 - לא מתקבלות הודעות OTP  .docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/R-63%20-%20%D7%9C%D7%90%20%D7%9E%D7%AA%D7%A7%D7%91%D7%9C%D7%95%D7%AA%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20OTP%20%20.docx?web=1"},"missing":["⚠ פערים להשלמה מול הנדסה"]},"R-80":{"missing":[]},"S-30":{"origin":{"name":"S-30 המשך טיפול מומחה בתקלת גלישה - להשלים.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/30%20-%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/S-30%20%D7%94%D7%9E%D7%A9%D7%9A%20%D7%98%D7%99%D7%A4%D7%95%D7%9C%20%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%D7%91%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%92%D7%9C%D7%99%D7%A9%D7%94%20-%20%D7%9C%D7%94%D7%A9%D7%9C%D7%99%D7%9D.docx?web=1"}},"S-40":{"origin":{"name":"S-40 - מסלול טיפול מומחה בתקלת שיחות. להשלים.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/40%20-%20%D7%A7%D7%91%D7%9C%D7%AA%20%D7%95%D7%94%D7%95%D7%A6%D7%90%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA/%D7%9E%D7%95%D7%9B%D7%9F%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/S-40%20-%20%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C%20%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%D7%91%D7%AA%D7%A7%D7%9C%D7%AA%20%D7%A9%D7%99%D7%97%D7%95%D7%AA.%20%D7%9C%D7%94%D7%A9%D7%9C%D7%99%D7%9D.docx?web=1"}},"S-60":{"origin":{"name":"להשלים S-60    מסלול טיפול מומחה תקלות סמס בארץ.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/60%20-%20%D7%94%D7%95%D7%93%D7%A2%D7%95%D7%AA%20%D7%98%D7%A7%D7%A1%D7%98/%D7%9C%D7%94%D7%A9%D7%9C%D7%99%D7%9D%20S-60%20%20%20%20%D7%9E%D7%A1%D7%9C%D7%95%D7%9C%20%D7%98%D7%99%D7%A4%D7%95%D7%9C%20%D7%9E%D7%95%D7%9E%D7%97%D7%94%20%D7%AA%D7%A7%D7%9C%D7%95%D7%AA%20%D7%A1%D7%9E%D7%A1%20%D7%91%D7%90%D7%A8%D7%A5.docx?web=1"},"missing":[]},"T-10":{"origin":{"name":"T-10 - תיאום ציפיות רשת סלולארית.docx","url":"https://marathon051-my.sharepoint.com/personal/liat_i_we-com_co_il/Documents/%D7%A9%D7%95%D7%9C%D7%97%D7%9F%20%D7%94%D7%A2%D7%91%D7%95%D7%93%D7%94/Kira/KnowledgeBase/%D7%9E%D7%A1%D7%9E%D7%9B%D7%99%20DOCx%20%D7%9E%D7%95%D7%9B%D7%A0%D7%99%D7%9D%20%D7%9C%D7%A4%D7%A8%D7%A1%D7%95%D7%9D/10-%20%D7%91%D7%A2%D7%99%D7%95%D7%AA%20%D7%A7%D7%9C%D7%99%D7%98%D7%94%20%D7%91%D7%90%D7%A8%D7%A5/T-10%20-%20%D7%AA%D7%99%D7%90%D7%95%D7%9D%20%D7%A6%D7%99%D7%A4%D7%99%D7%95%D7%AA%20%D7%A8%D7%A9%D7%AA%20%D7%A1%D7%9C%D7%95%D7%9C%D7%90%D7%A8%D7%99%D7%AA.docx?web=1"},"missing":[]}};
// </generated:doc-info>
// Built-in items retired from the code: browsers that saved them move them to the trash (restorable).
var NB_SEED_RETIRED={pdf_004:'הוחלף ב-R-01',pdf_010:'הוחלף ב-R-02'};
// 10.11.2026: items with no read-only origin document in "מסמכי DOCx מוכנים לפרסום" were dropped.
["view-churn-doc","view-browsing-doc","pdf_001","pdf_002","pdf_003","pdf_005","pdf_006","pdf_007","pdf_008","pdf_009","kb_s01","kb_h03","kb_h02","kb_h01","kbd_r10","kbd_r11","kbd_i10","kbd_r13","kbd_r14","kbd_r15","kbd_i11","kbd_r16","kbd_o14","kbd_r17","kbd_o15","kbd_r18","kbd_r19","kbd_r20","kbd_o16","kbd_o17","kbd_o18","kbd_r21","kbd_r22","kbd_i12","kbd_i13","kbd_o19","kbd_i14","kbm_i01","kbm_s10","kbm_o45","kbm_o70","kbm_r150","kbm_m90","kbm_i91","kbm_i92","kbm_i94","kbm_i95","kbm_i96","kbm_i97","kbm_m100","kbm_i104","kbm_i105","kbm_m120","kbm_i122","kbm_i123","kbm_i124","kbm_i125","kbm_i113","kbm_i114","kbm_i117","kbm_i118","kbm_i103","kbm_m106","kbm_i107","kbm_i108","kbm_i109","kbm_i110","kbm_i150","kbm_i151","kbm_i152","kbm_i153","kbm_i154"].forEach(function(k){ NB_SEED_RETIRED[k]='אין מסמך מקור בתיקיית מוכנים לפרסום'; });
var NB_SEED_PUBLICATION_MIGRATIONS={
  42:['pdf_021','kbm_e10','kbm_e30','kbm_e40','kbm_e60','pdf_011','kbm_m10','kbm_m30','kbm_m40','kbm_m60','kb_o01','pdf_017','pdf_018','pdf_019','pdf_020','kbm_o10','kbm_o12','kbm_o13','kbm_o31','kbm_o32','kbm_o33','kbm_o34','kbm_o35','kbm_o40','kbm_o41','kbm_o42','kbm_o43','kbm_o44','kbd_o10','kbd_o11','kbd_o12','kbd_r12','kbd_o13','kbm_o60','kbm_o61','pdf_012','pdf_013','pdf_014','pdf_015','pdf_016','kbm_r11','kbm_r12','kbm_r13','kbm_r31','kbm_r32','kbm_r33','kbm_r34','kbm_r35','kbm_r40','kbm_r41','kbm_r42','kbm_r43','kbm_r44','kbm_r60','kbm_r61','kbm_r62','kbm_r63','kbm_s60','kbm_t10','kbnew_o06','kbnew_o36','kbnew_o37','kbnew_r14','kbnew_r45','kbnew_r50','kbnew_r51']
};
// Official content fields of built-in documents: refreshed from the code when
// the content version changes. Links, worlds and owner stay as people set them.
// Codes that must exist only once: the built-in item published on 2.11.
var NB_SEED_SINGLE_COPY=['O-06','O-36','O-37','R-14','R-45','R-50','R-51'];
var NB_SEED_CONTENT_FIELDS=['topic','stages','body','kind','desc','tags','revision','draftDoc','reviewNotes','originName'];
var NB_SEED_ITEM_FIELDS=['kind','topic','desc','tags','stages','body'];
var NB_SEED_SIGS={}; // built-in content signature per item, taken before the saved library replaces it

function nbSeedSig(doc){
  var s=JSON.stringify(NB_SEED_CONTENT_FIELDS.map(function(f){ return doc[f]===undefined?null:doc[f]; }));
  var h=5381;
  for(var i=0;i<s.length;i++) h=(h*33^s.charCodeAt(i))|0;
  return s.length+'-'+(h>>>0).toString(36);
}
function nbTakeSeedSigs(){
  var docs=window.dynamicDocs||{};
  Object.keys(docs).forEach(function(k){ NB_SEED_SIGS[k]=nbSeedSig(docs[k]); });
}
// An item approved, rejected or edited in the app: built-in updates no longer overwrite its content.
function nbMarkLocalEdit(d,docId){
  d.localEdit=true;
  if(!d.seedSig&&NB_SEED_SIGS[docId]) d.seedSig=NB_SEED_SIGS[docId];
}
function nbSameItem(a,b){
  var key=function(x){ return JSON.stringify(NB_SEED_ITEM_FIELDS.map(function(f){
    var v=x[f];
    return (v==null||v===''||(Array.isArray(v)&&!v.length))?null:v;
  })); };
  return key(a)===key(b);
}
// Built-in content of an item changed in the app: the app's version stays, and
// anything new in the built-in content comes in as a proposed version to review.
function nbReconcileEditedDoc(saved,seed,sig){
  if(saved.seedSig===sig) return;
  // A proposal an editor uploaded is kept; the built-in update is offered at the next version.
  if(saved.revision&&!saved.revision.builtIn) return;
  saved.seedSig=sig;
  if(nbSameItem(saved,seed.revision?seed.revision.item:seed)){
    if(saved.revision) delete saved.revision;
    // The built-in content now is this version (it was published in the code): nothing is local anymore.
    if(!seed.revision){ delete saved.localEdit; delete saved.seedSig; }
    return;
  }
  if(seed.revision){ saved.revision=JSON.parse(JSON.stringify(seed.revision)); return; }
  var item={};
  NB_SEED_ITEM_FIELDS.forEach(function(f){ item[f]=seed[f]===undefined?null:JSON.parse(JSON.stringify(seed[f])); });
  saved.revision={item:item,issues:['התוכן המובנה של הפריט עודכן, ולפריט יש גרסה שאושרה או נערכה באפליקציה. הגרסה הקיימת נשארת עד שתאשרו.'],
    source:seed.source||saved.source||null,createdAt:Date.now(),builtIn:true};
}

// Brings a saved library up to the built-in content of this version.
// Used by the browser version and by the WordPress bridge.
function nbReconcileSeed(savedDocs,seedDocs,trash,previousVersion){
  var trashed={};
  (trash||[]).forEach(function(e){ if(e&&e.docId) trashed[e.docId]=true; });
  Object.keys(seedDocs).forEach(function(k){
    var seed=seedDocs[k], saved=savedDocs[k];
    if(saved){
      var edited=!!saved.localEdit;
      NB_SEED_CONTENT_FIELDS.forEach(function(f){
        if(edited&&(f==='revision'||NB_SEED_ITEM_FIELDS.indexOf(f)!==-1)) return;
        if(seed[f]!==undefined) saved[f]=JSON.parse(JSON.stringify(seed[f]));
        else if(f==='body'||f==='draftDoc'||f==='originName') delete saved[f];
      });
      // A built-in proposed version that has since been published (or withdrawn) in the code is no longer pending.
      if(edited) nbReconcileEditedDoc(saved,seed,NB_SEED_SIGS[k]||nbSeedSig(seed));
      else if(!seed.revision&&saved.revision&&saved.revision.builtIn) delete saved.revision;
      // Built-in content changed after the saved copy did: "עודכן" shows when it changed.
      if(seed.updatedAt&&(!saved.updatedAt||seed.updatedAt>saved.updatedAt)) saved.updatedAt=seed.updatedAt;
      var meta=NB_SEED_META[k];
      if(meta&&Array.isArray(saved.topicIds)) meta.topics.forEach(function(t){ if(saved.topicIds.indexOf(t)===-1) saved.topicIds.push(t); });
      // Status, tracking notes and owner are editors' work: only fill them in
      // when the saved item has none yet, never overwrite.
      if(seed.status&&!saved.status) saved.status=seed.status;
      if(seed.track&&(!saved.track||!Object.keys(saved.track).length)) saved.track=JSON.parse(JSON.stringify(seed.track));
      if(seed.owner&&!saved.owner) saved.owner=seed.owner;
      // The built-in source link follows the file if it moves; a source an editor uploaded (another file) is kept.
      if(seed.source&&(!saved.source||saved.source.name===seed.source.name||/sharepoint\.com/.test(saved.source.url||''))) saved.source=JSON.parse(JSON.stringify(seed.source));
      // Origin documents are never linked: drop a SharePoint link the built-in item no longer has.
      else if(!seed.source&&saved.source&&/sharepoint\.com/.test(saved.source.url||'')) delete saved.source;
      // Built-in Word drafts: tracking notes and owner follow the document map until an editor changes them.
      if(k.indexOf('kbd_')===0&&seed.track&&saved.track&&/^טיוטת Word לבדיקה/.test(saved.track.gap||'')){
        saved.track=JSON.parse(JSON.stringify(seed.track));
        if(seed.owner) saved.owner=seed.owner;
      }
    } else if(!trashed[k]){
      savedDocs[k]=JSON.parse(JSON.stringify(seed));
    }
  });
  Object.keys(NB_SEED_PUBLICATION_MIGRATIONS).forEach(function(version){
    if((Number(previousVersion)||0)>=Number(version)) return;
    NB_SEED_PUBLICATION_MIGRATIONS[version].forEach(function(k){
      var saved=savedDocs[k], seed=seedDocs[k];
      if(!saved||!seed) return;
      saved.status='published';
      delete saved.revision;
      if(seed.publishedAt) saved.publishedAt=seed.publishedAt;
      if(seed.updatedAt) saved.updatedAt=seed.updatedAt;
    });
  });
  Object.keys(NB_SEED_RETIRED).forEach(function(k){
    var d=savedDocs[k];
    if(!d) return;
    trash.push({trashId:'trash-'+Date.now()+'-'+k,type:'doc',docId:k,doc:d,
      topicSnapshots:TOPICS.filter(function(t){return (d.topicIds||[]).indexOf(t.id)!==-1;}),
      title:nbPlain(d.topic)+' ('+NB_SEED_RETIRED[k]+')',deletedAt:Date.now()});
    delete savedDocs[k];
  });
  // Items that are not built-in and whose title was saved with broken Hebrew
  // ("????", from an import with the wrong text encoding) go to the trash.
  Object.keys(savedDocs).forEach(function(k){
    var d=savedDocs[k];
    if(!d||seedDocs[k]||!/\?{4,}/.test(nbPlain(d.topic||''))) return;
    trash.push({trashId:'trash-'+Date.now()+'-'+k,type:'doc',docId:k,doc:d,
      topicSnapshots:TOPICS.filter(function(t){return (d.topicIds||[]).indexOf(t.id)!==-1;}),
      title:nbPlain(d.topic)+' (טקסט פגום)',deletedAt:Date.now()});
    delete savedDocs[k];
  });
  // Some browsers also hold an earlier import of these items under another id.
  // Keep only the built-in version (published 2.11) and move the copy to the trash.
  var builtInByCode={};
  Object.keys(seedDocs).forEach(function(k){
    var c=(/^\s*([A-Z]-\d{2,3})(?!\d)/.exec(nbPlain(seedDocs[k].topic||''))||[])[1];
    if(c&&NB_SEED_SINGLE_COPY.indexOf(c)!==-1) builtInByCode[c]=k;
  });
  Object.keys(savedDocs).forEach(function(k){
    var d=savedDocs[k];
    if(!d||seedDocs[k]) return;
    var c=(/^\s*([A-Z]-\d{2,3})(?!\d)/.exec(nbPlain(d.topic||''))||[])[1];
    if(!c||!builtInByCode[c]) return;
    trash.push({trashId:'trash-'+Date.now()+'-'+k,type:'doc',docId:k,doc:d,
      topicSnapshots:TOPICS.filter(function(t){return (d.topicIds||[]).indexOf(t.id)!==-1;}),
      title:nbPlain(d.topic)+' (כפילות – נשמרה גרסת 2.11)',deletedAt:Date.now()});
    delete savedDocs[k];
  });
}

function nbLoadLibrary(){
  try{
    // If the code's built-in seed content has changed since this browser last
    // saved, don't let the old saved snapshot mask the update — reconcile
    // instead of blindly restoring it wholesale.
    var savedVersion=localStorage.getItem(NB_STORAGE_KEYS.seedVersion);
    var seedMatches=(savedVersion===String(NB_SEED_VERSION));

    var docsRaw=localStorage.getItem(NB_STORAGE_KEYS.docs);
    if(docsRaw){
      // The saved library is the source of truth, so built-in documents that
      // were deleted stay deleted. When the built-in content in the code has
      // changed (seed version bumped), refresh the content of the built-in
      // documents that still exist, keep their links and fields, and add
      // built-in documents that are new in this version.
      var savedDocs=JSON.parse(docsRaw);
      if(!seedMatches){
        var savedTrashForSeed=[];
        try{ savedTrashForSeed=JSON.parse(localStorage.getItem(NB_STORAGE_KEYS.trash))||[]; }catch(e){}
        nbReconcileSeed(savedDocs,window.dynamicDocs||{},savedTrashForSeed,Number(savedVersion)||0);
        try{ localStorage.setItem(NB_STORAGE_KEYS.trash,JSON.stringify(savedTrashForSeed)); }catch(e){}
      }
      window.dynamicDocs=savedDocs;
    }
    var worldsRaw=localStorage.getItem(NB_STORAGE_KEYS.worlds);
    if(worldsRaw){
      var savedWorlds=JSON.parse(worldsRaw);
      if(Array.isArray(savedWorlds)&&savedWorlds.length) WORLDS=savedWorlds;
    }
    var topicsRaw=localStorage.getItem(NB_STORAGE_KEYS.topics);
    if(topicsRaw){
      var savedTopics=JSON.parse(topicsRaw);
      if(Array.isArray(savedTopics) && savedTopics.length){
        if(seedMatches){
          TOPICS=savedTopics;
        } else {
          // Keep the fresh hardcoded seed topics, but bring back any topics
          // the person actually created themselves through the app.
          savedTopics.filter(function(t){ return nbIsUserTopicId(t.id); }).forEach(function(t){
            if(!TOPICS.some(function(x){return x.id===t.id;})) TOPICS.push(t);
          });
        }
      }
    }
    var trashRaw=localStorage.getItem(NB_STORAGE_KEYS.trash);
    if(trashRaw){
      var savedTrash=JSON.parse(trashRaw);
      if(Array.isArray(savedTrash)) nbTrash=savedTrash;
    }
    if(!seedMatches) nbSaveLibrary(); // stamp the reconciled state with the current version
  }catch(e){ /* localStorage unavailable or corrupt — start fresh */ }
}

function nbSaveDraft(){
  try{
    localStorage.setItem(NB_STORAGE_KEYS.draft, JSON.stringify({
      state:nbState,
      custom:nbCustomStages,
      seq:nbCustomStageSeq,
      order:nbStageOrder,
      editingId:window.nbEditingDocId||null,
      linkTopicId:window.nbLinkToTopicId||null
    }));
  }catch(e){ /* localStorage unavailable — fail silently */ }
}

function nbLoadDraft(){
  try{
    var raw=localStorage.getItem(NB_STORAGE_KEYS.draft);
    if(!raw) return;
    var d=JSON.parse(raw);
    if(d.state) nbState=d.state;
    if(d.custom) nbCustomStages=d.custom;
    if(typeof d.seq==='number') nbCustomStageSeq=d.seq;
    if(d.order) nbStageOrder=d.order;
    if(d.editingId) window.nbEditingDocId=d.editingId;
    if(d.linkTopicId) window.nbLinkToTopicId=d.linkTopicId;
  }catch(e){ /* localStorage unavailable or corrupt — start fresh */ }
}

// Safety net: also save right before the tab/page closes or refreshes
window.addEventListener('beforeunload', nbSaveDraft);

document.addEventListener("DOMContentLoaded", function(){
  nbTakeSeedSigs();
  nbLoadLibrary();
  nbLoadDraft();
  nbUpdateTrashBadge();
  nbUpdateHistoryBadge();
  initObservers();
  nbRender();
  // Bring saved data from older versions to the worlds → topics → items
  // model, and store the converted library once.
  var before=JSON.stringify({t:TOPICS,d:window.dynamicDocs});
  nbNormalizeModel();
  if(JSON.stringify({t:TOPICS,d:window.dynamicDocs})!==before) nbSaveLibrary('עדכון מבנה הספרייה: עולמות תוכן, נושאים וסוגי פריטים');
  nbRenderSidebar();
  nbRenderLibFilters();
  renderLibrary('all');
  nbLibraryReady=true;
  if(nbPendingSearch!==null){ var q=nbPendingSearch; nbPendingSearch=null; nbSearch(q); }
});

// ── DEMO ROLE GATE (static prototype only) ──────────────────────────────
// An entry screen to demonstrate what each role sees (spec §11). This is a
// DEMO, not access control: a static site can't protect anything, and its
// content is readable in the page source. Real logins and permissions are
// enforced by the WordPress plugin, which skips this gate (window.WECOM_KB).
var NB_ROLES={
  admin:{name:'מנהל מערכת',icon:'🛡️',desc:'הכל: יצירה, עריכה ומחיקה של פריטי ידע, סל מיחזור, היסטוריית גרסאות, וניהול עולמות התוכן'},
  editor:{name:'עורך תוכן',icon:'✏️',desc:'יצירה ועריכה של פריטי ידע, סל מיחזור והיסטוריית גרסאות'},
  agent:{name:'נציג שירות',icon:'🎧',desc:'צפייה בלבד: ספרייה, חיפוש, אבחון מונחה ותסריטים — בלי עריכה'}
};
var NB_ROLE_KEY='wecom_kb_demo_role';
function nbGetRole(){ try{ return sessionStorage.getItem(NB_ROLE_KEY); }catch(e){ return null; } }

// ── SITE PASSWORD (GitHub version only) ─────────────────────────────────
// Before the role screen, the GitHub version asks for a password. Only its
// SHA-256 hash is kept here. The site is static and public, so this keeps
// casual visitors out; it does not hide the content from someone who reads
// the page's code. The browser tab stays unlocked until it is closed.
// WordPress has its own login and never shows this step.
var NB_SITE_PW_HASH='8e314059d60884de414898c3d73acedeafd3d10d948277e29a00a4d3bd74f8a6';
var NB_UNLOCK_KEY='wecom_kb_unlocked';
function nbIsUnlocked(){ try{ return sessionStorage.getItem(NB_UNLOCK_KEY)==='1'; }catch(e){ return false; } }
function nbSha256(text){
  return crypto.subtle.digest('SHA-256',new TextEncoder().encode(text)).then(function(buf){
    return [].map.call(new Uint8Array(buf),function(b){ return ('0'+b.toString(16)).slice(-2); }).join('');
  });
}
function nbGateLockHTML(){
  return '<h1 class="gate-title">מאגר ידע פנימי</h1>'
    +'<div class="gate-sub">הזינו את הסיסמה כדי להיכנס</div>'
    +'<form class="gate-lock" id="nb-lock-form" onsubmit="event.preventDefault();nbTryUnlock()">'
    +'<label class="sr-only" for="nb-lock-pw">סיסמה</label>'
    +'<input type="password" id="nb-lock-pw" class="gate-pw" autocomplete="current-password" placeholder="סיסמה" required>'
    +'<button type="submit" class="gate-pw-btn">כניסה <span class="gate-pw-chev" aria-hidden="true">›</span></button>'
    +'<div class="gate-pw-err" id="nb-lock-err" role="alert" hidden>הסיסמה שגויה. נסו שוב.</div>'
    +'</form>'
    +'<div class="gate-foot">גישה לצוות wecom בלבד</div>';
}
function nbTryUnlock(){
  var inp=document.getElementById('nb-lock-pw'), err=document.getElementById('nb-lock-err');
  if(!inp||!inp.value) return;
  nbSha256(inp.value).then(function(h){
    if(h!==NB_SITE_PW_HASH){ err.hidden=false; inp.value=''; inp.focus(); return; }
    try{ sessionStorage.setItem(NB_UNLOCK_KEY,'1'); }catch(e){}
    var r=nbGetRole();
    if(NB_ROLES[r]){ nbEnterAs(r); return; }
    var card=document.querySelector('#nb-gate .gate-card');
    if(card){ card.classList.remove('lock'); card.innerHTML=nbGateBrandHTML()+nbGateRolesHTML(); }
  });
}
function nbGateBrandHTML(){ return '<div class="gate-brand">'+((document.querySelector('.topnav img')||{}).outerHTML||'').replace(/ onclick="[^"]*"/,'').replace(/ style="[^"]*"/,'').replace(/ title="[^"]*"/,'')+'</div>'; }

function nbShowGate(){
  var overlay=document.createElement('div');
  overlay.id='nb-gate';
  var locked=!nbIsUnlocked();
  overlay.innerHTML='<div class="gate-card'+(locked?' lock':'')+'">'+nbGateBrandHTML()+(locked?nbGateLockHTML():nbGateRolesHTML())+'</div>';
  document.body.appendChild(overlay);
  document.body.classList.add('gate-open');
  var pw=document.getElementById('nb-lock-pw'); if(pw) pw.focus();
}
function nbGateRolesHTML(){
  return '<h1 class="gate-title">מאגר ידע פנימי</h1>'
    +'<div class="gate-sub">בחרו תפקיד כדי להיכנס</div>'
    +'<div class="gate-roles">'+Object.keys(NB_ROLES).map(function(r){
      var R=NB_ROLES[r];
      return '<button class="gate-role" onclick="nbEnterAs(\''+r+'\')"><span class="gate-icon">'+R.icon+'</span>'
        +'<span class="gate-role-name">'+R.name+'</span><span class="gate-role-desc">'+R.desc+'</span></button>';
    }).join('')+'</div>'
    +'<div class="gate-note">גרסת הדגמה: בחירת התפקיד מציגה מה כל משתמש רואה. ההרשאות האמיתיות, עם שם משתמש וסיסמה, מנוהלות באתר ה-WordPress.</div>';
}

function nbEnterAs(role){
  try{ sessionStorage.setItem(NB_ROLE_KEY,role); }catch(e){}
  var g=document.getElementById('nb-gate'); if(g) g.remove();
  document.body.classList.remove('gate-open');
  nbApplyRole(role);
  showView('library');
}

function nbApplyRole(role){
  document.body.classList.add('role-'+role);
  if(role==='agent'){
    document.body.classList.add('wkb-readonly');
    // Same lock-down as the WordPress read-only mode.
    var noop=function(){};
    ['nbEditDoc','nbConfirmDeleteDoc','nbConfirmDeleteTopic','nbOpenTrash','nbOpenHistory','nbGoNew','nbCreateDoc',
     'nbRestoreFromTrash','nbPermanentlyDeleteFromTrash','nbNewItemForTopic','nbManageWorlds','nbAddWorld','nbRenameWorld',
     'nbSetStatus','nbOpenTracking','nbExportTracking',
     'nbStartImport','nbStartSourceUpdate','nbOpenReview','nbApproveRevision','nbEditRevision','nbRejectRevision'].forEach(function(fn){ window[fn]=noop; });
    var origShowView=window.showView;
    window.showView=function(id){ if(id==='new') return; return origShowView.apply(this,arguments); };
  }
  if(role==='editor'){ window.nbManageWorlds=window.nbAddWorld=window.nbRenameWorld=function(){}; }
  // What's visible depends on the role (agents: published items only).
  nbRenderSidebar();
  renderLibrary(nbCurrentLibCat||'all');
  var nav=document.querySelector('.topnav');
  if(nav&&!document.getElementById('role-badge')){
    var R=NB_ROLES[role];
    var b=document.createElement('div');
    b.id='role-badge';
    b.className='role-badge';
    b.innerHTML='<span class="rb-icon">'+R.icon+'</span><span class="rb-name">'+R.name+'</span><button onclick="nbSwitchUser()" title="כניסה בתפקיד אחר">החלף</button>';
    nav.appendChild(b);
  }
}

function nbSwitchUser(){
  try{ sessionStorage.removeItem(NB_ROLE_KEY); }catch(e){}
  location.reload();
}

document.addEventListener('DOMContentLoaded',function(){
  if(window.WECOM_KB) return; // WordPress: real login and permissions
  var r=nbGetRole();
  if(!NB_ROLES[r]) r=nbTakeRoleHandoff();
  // The password comes first; then the role (skipped when this tab already has one).
  if(NB_ROLES[r]&&nbIsUnlocked()) nbApplyRole(r); else nbShowGate();
});

// ── OPEN AN ITEM IN A NEW TAB ───────────────────────────────────────────
// Item links have a real address (#item=…), so Ctrl+click, middle-click and
// "open in new tab" open a browser tab. The ↗ icon opens the item in a tab
// inside the app instead (nbOpenInAppTab, with the app's tabs below).
// Demo only: the role is kept per tab, so the new tab receives it for a few
// seconds instead of asking again (WordPress has its own login).
var NB_ROLE_HANDOFF='wecom_kb_role_handoff';
function nbRoleHandoff(){
  var r=nbGetRole();
  if(r) try{ localStorage.setItem(NB_ROLE_HANDOFF,JSON.stringify({role:r,at:Date.now()})); }catch(e){}
}
function nbTakeRoleHandoff(){
  try{
    var h=JSON.parse(localStorage.getItem(NB_ROLE_HANDOFF)||'null');
    localStorage.removeItem(NB_ROLE_HANDOFF);
    // Only an unlocked tab hands its role over, so the new browser tab is unlocked too.
    if(h&&NB_ROLES[h.role]&&Date.now()-h.at<30000){ sessionStorage.setItem(NB_ROLE_KEY,h.role); sessionStorage.setItem(NB_UNLOCK_KEY,'1'); return h.role; }
  }catch(e){}
  return null;
}
function nbItemHref(id){ return nbNavUrl('item='+encodeURIComponent(id)); }

// ── READABLE ADDRESSES (WordPress) ──────────────────────────────────────
// On WordPress every screen has a real address under the knowledge base page:
//   /kb/O-50-sim-activation   an item: its code + a short English name
//   /kb/topic/no-mobile-data   a topic
//   /kb/tracking, /kb/new, /kb/review/O-50-sim-activation
// The plugin sends every address under /kb/ to the same page. Items are found
// by their code, so changing an English name never breaks an old link, and
// old #item=… links still work. The GitHub version has no server to answer
// such addresses and keeps #item=….
var NB_ITEM_SLUGS={
  'E-01':'abroad-escalation','E-10':'reception-escalation','E-30':'data-escalation','E-40':'calls-escalation','E-60':'sms-escalation',
  'M-00':'abroad-diagnosis','M-10':'reception-diagnosis','M-30':'data-diagnosis','M-40':'calls-diagnosis','M-60':'sms-diagnosis',
  'O-01':'roaming-system-check','O-02':'data-roaming-on-device','O-03':'apn-abroad','O-04':'stk-network-identity','O-05':'manual-network-abroad',
  'O-06':'usa-device-compatibility','O-10':'coverage-map','O-12':'wifi-calling','O-13':'reset-network-settings',
  'O-31':'mobile-data-settings','O-32':'apn-setup','O-33':'data-saver-limits','O-34':'vpn-on-device','O-35':'managed-line-restrictions',
  'O-36':'hotspot','O-37':'dual-sim-data','O-40':'line-status-call-blocks','O-41':'call-forwarding-settings','O-42':'device-call-blocks',
  'O-43':'volte-on-device','O-44':'volte-compatibility','O-50':'sim-activation','O-51':'esim-qr-activation','O-52':'sim-esim-replacement',
  'O-55':'lost-stolen-sim','O-56':'sim-delivery-status','O-60':'sms-blocks-spam','O-61':'sms-center-number',
  'O-200':'ownership-transfer','O-201':'data-reports-guide',
  'R-01':'no-signal-abroad','R-02':'no-data-abroad','R-03':'app-issue-abroad','R-04':'calls-abroad','R-05':'sms-abroad',
  'R-11':'weak-signal-location','R-12':'weak-signal-driving','R-13':'new-signal-drop','R-14':'no-service',
  'R-31':'no-data-anywhere','R-32':'no-data-location','R-33':'slow-data-anywhere','R-34':'slow-data-location','R-35':'no-data-during-call',
  'R-40':'no-calls','R-41':'cannot-make-calls','R-42':'cannot-receive-calls','R-43':'calls-specific-numbers','R-44':'no-calls-after-porting',
  'R-45':'international-dialing','R-50':'issue-after-activation','R-51':'esim-qr-not-received',
  'R-60':'cannot-send-sms','R-61':'cannot-receive-sms','R-62':'sms-specific-number','R-63':'otp-not-received',
  'S-30':'data-specialist','S-40':'calls-specialist','S-60':'sms-network-blocks','T-10':'network-expectations'
};
var NB_TOPIC_SLUGS={
  1:'sim-activation',2:'esim-qr',3:'sim-esim-switch',4:'issue-after-activation',5:'qr-not-scanned',6:'lost-stolen-sim',
  7:'sim-delivery',8:'home-center-pickup',9:'device-compatibility',10:'unactivated-lines',11:'no-mobile-data',12:'slow-data',
  13:'apn-setup',14:'no-signal',15:'calls-not-working',16:'dropped-calls',17:'volte-old-devices',18:'sms-otp',19:'hotspot',
  20:'basic-troubleshooting',21:'high-bill',22:'invoice-explained',23:'debt-payment',24:'payment-method',25:'credits-refunds',
  26:'invoice-copy',27:'plan-change',28:'add-line-5g',29:'cancel-line',30:'freeze-line',31:'ownership-transfer',
  32:'customer-details',33:'number-porting',34:'abroad-package',35:'abroad-data-signal',36:'abroad-rates',
  37:'customer-verification',38:'call-transfer',39:'callback',40:'complaints-escalations',41:'churn',
  42:'abroad-diagnosis',43:'no-signal-abroad',44:'no-data-abroad',45:'app-issue-abroad',46:'calls-abroad',47:'sms-abroad',
  48:'data-roaming',50:'stk-network-identity',51:'manual-network',52:'abroad-escalation',
  1001:'data-sim',1002:'international-dialing',1003:'extra-services',1004:'new-customer',1005:'personal-area',
  1006:'customer-deceased',1007:'line-status',1008:'number-change',1009:'accessibility',1010:'marketing-opt-out',
  1011:'premium-numbers',1012:'business-vip',1013:'class-actions',1014:'ownership-transfer-hq',1015:'data-reports'
};
// The knowledge base page's own path (e.g. "/kb/"), or null outside WordPress
// or without pretty permalinks.
function nbPathBase(){
  var b=window.WECOM_KB&&window.WECOM_KB.baseUrl;
  if(!b) return null;
  try{ var u=new URL(b,location.href); return u.search?null:u.pathname.replace(/\/?$/,'/'); }catch(e){ return null; }
}
function nbSlugify(s){ return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,''); }
function nbItemSlug(d,key){
  var st=nbSplitTitle(d.topic);
  if(st.code){ var n=NB_ITEM_SLUGS[st.code]||nbSlugify(d.slug); return st.code+(n?'-'+n:''); }
  return 'item-'+nbSlugify(key||d.id);
}
function nbTopicSlug(t){ return NB_TOPIC_SLUGS[t.id]||String(t.id); }
// "O-50-sim-activation" → the item's key. Found by the code; the name is only for people.
function nbDocKeyFromSlug(s){
  var docs=window.dynamicDocs||{}, m=/^([A-Za-z])-(\d{2,3})(?![0-9])/.exec(s), k, found=null;
  if(m){
    var code=m[1].toUpperCase()+'-'+m[2];
    for(k in docs){ if(docs[k]&&nbSplitTitle(docs[k].topic).code===code){ if(nbVisible(docs[k])) return k; found=found||k; } }
    return found;
  }
  m=/^item-(.+)$/.exec(s);
  if(m) for(k in docs){ if(nbSlugify(k)===m[1]) return k; }
  return null;
}
function nbLocToPath(loc){
  var base=nbPathBase(), m=/^(item|topic|review|view)=(.+)$/.exec(loc||''), val=m?decodeURIComponent(m[2]):'';
  if(!m) return base;
  if(m[1]==='item'||m[1]==='review'){
    var d=window.dynamicDocs[val], slug=d?nbItemSlug(d,val):'item-'+nbSlugify(val);
    return base+(m[1]==='review'?'review/':'')+encodeURI(slug);
  }
  if(m[1]==='topic'){ var t=TOPICS.find(function(x){return String(x.id)===val;}); return base+'topic/'+encodeURI(t?nbTopicSlug(t):val); }
  return base+encodeURI(val);
}
function nbPathToLoc(path){
  var base=nbPathBase();
  if(!base||path.indexOf(base)!==0) return '';
  var rest; try{ rest=decodeURIComponent(path.slice(base.length)); }catch(e){ rest=path.slice(base.length); }
  var p=rest.replace(/\/+$/,'').split('/'), key;
  if(!p[0]) return '';
  if(p[0]==='topic'&&p[1]){
    var t=TOPICS.find(function(x){ return nbTopicSlug(x)===p[1]||String(x.id)===p[1]; });
    return t?'topic='+encodeURIComponent(t.id):'';
  }
  if(p[0]==='review'&&p[1]){ key=nbDocKeyFromSlug(p[1]); return key?'review='+encodeURIComponent(key):''; }
  if(p[0]==='tracking'||p[0]==='new') return 'view='+p[0];
  key=nbDocKeyFromSlug(p[0]);
  return key?'item='+encodeURIComponent(key):'';
}
// The screen the address names: the path on WordPress, else (and for old links) the #… part.
function nbCurrentLoc(){
  var l=nbPathBase()?nbPathToLoc(location.pathname):'';
  return l||location.hash.replace(/^#/,'');
}
var NB_NEWTAB_SVG='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>';
function nbNewTabIcon(id){
  return '<span class="nb-newtab" role="link" tabindex="0" data-newtab="'+nbEsc(id)+'" title="פתיחה בלשונית חדשה" aria-label="פתיחה בלשונית חדשה">'+NB_NEWTAB_SVG+'</span>';
}
// Runs before the card's or box's own click, so the current page doesn't change.
document.addEventListener('click',function(e){
  var t=e.target.closest&&e.target.closest('[data-newtab]');
  if(!t) return;
  e.preventDefault(); e.stopPropagation();
  nbOpenInAppTab(t.getAttribute('data-newtab'));
},true);
document.addEventListener('keydown',function(e){
  if(e.key!=='Enter'&&e.key!==' ') return;
  var t=e.target.closest&&e.target.closest('[data-newtab]');
  if(!t) return;
  e.preventDefault(); e.stopPropagation();
  nbOpenInAppTab(t.getAttribute('data-newtab'));
},true);
// Middle-click and right-click ("open in new tab") on an item link: hand the role over too.
document.addEventListener('mousedown',function(e){
  if(e.target.closest&&e.target.closest('a.kb-link-item')) nbRoleHandoff();
},true);

// ── NAVIGATION: REFRESH, BACK AND SHARED LINKS ──────────────────────────
// The open item, topic or screen is kept in the address (#item=…, #topic=…,
// #review=…, #view=…), so a refresh or a shared link opens it again. Every
// screen change is a browser history entry: the app's back links and the
// browser's Back button return to the previous screen, and the library comes
// back with its search and filters.
var nbStartLocation=location.hash.replace(/^#/,'');
// On WordPress the address is a path; it's read once the library has loaded
// (nbRestoreLocation), so keep it before anything rewrites the address.
var nbStartPath=location.pathname;
var nbNavBusy=0, nbNavRestoring=false;
function nbNavState(){
  var s=history.state;
  return s&&typeof s.idx==='number'?s:{idx:0,loc:nbCurrentLoc()};
}
function nbNavUrl(loc){
  if(nbPathBase()) return nbLocToPath(loc);
  return loc?'#'+loc:location.pathname+location.search;
}
function nbSetLocation(loc){
  try{ var s=Object.assign({},nbNavState(),{loc:loc}); history.replaceState(s,'',nbNavUrl(loc)); }catch(e){}
}
// How the back link names a screen ("← חזרה …").
function nbLocLabel(loc){
  var m=/^(item|topic|review|view)=(.+)$/.exec(loc||''), val=m?decodeURIComponent(m[2]):'';
  var cut=function(s){ s=nbPlain(s||'').trim(); return s.length>45?s.slice(0,44)+'…':s; };
  // Items are named in full, by their type ("לאבחון: …", "למסלול הטיפול: …").
  if(m&&m[1]==='item'&&window.dynamicDocs[val]){ var d=window.dynamicDocs[val]; return nbViewOf(d.kind).back+': '+nbSplitTitle(d.topic).title; }
  if(m&&m[1]==='topic'){ var t=TOPICS.find(function(x){return String(x.id)===val;}); if(t) return 'לנושא: '+cut(t.title); }
  if(m&&m[1]==='review') return 'להשוואת הגרסאות';
  if(m&&m[1]==='view'&&val==='tracking') return 'למעקב העריכה';
  if(m&&m[1]==='view'&&val==='new') return 'לפריט החדש';
  if(nbSearchQuery) return 'לתוצאות החיפוש';
  if(nbMostViewedFilter) return 'לנצפות ביותר';
  return 'לספרייה';
}
// The screen being left, saved in its own history entry so Back restores it.
function nbNavSnapshot(){
  var loc=nbNavState().loc||'';
  return {loc:loc,label:nbLocLabel(loc),scroll:window.scrollY||0,ui:nbCaptureItemUI(),
    lib:{world:nbCurrentWorld,kind:nbCurrentKind,cat:nbCurrentLibCat,search:nbSearchQuery,mostViewed:nbMostViewedFilter}};
}
// Which stages of the open item are open, so Back restores them as they were.
function nbCaptureItemUI(){
  var v=document.getElementById('view-article');
  if(!v||!v.classList.contains('active')) return null;
  var units=document.querySelectorAll('#article-content .av-unit,#article-content .av-col');
  var pick=document.querySelector('#article-content .av-o-pick');
  if(!units.length&&!pick) return null;
  return {open:[].filter.call(units,nbUnitIsOpen).map(function(u){return u.id;}),
    device:pick?nbODevice:null,full:pick?nbOFull:false};
}
// Also restores the picked device and the view of an operating item.
function nbApplyItemUI(ui){
  if(!ui) return;
  if(ui.open) document.querySelectorAll('#article-content .av-unit,#article-content .av-col').forEach(function(u){ nbSetUnitOpen(u,ui.open.indexOf(u.id)!==-1); });
  if(document.querySelector('#article-content .av-o-pick')){ nbODevice=ui.device||null; nbOFull=!!ui.full; nbApplyOView(); }
}
function nbNavigate(loc,leaving){
  if(nbNavRestoring||loc===leaving.loc){ nbSetLocation(loc); return; }
  try{
    var s=nbNavState();
    history.replaceState(Object.assign({},s,{loc:leaving.loc,lib:leaving.lib,scroll:leaving.scroll,ui:leaving.ui}),'',nbNavUrl(leaving.loc));
    history.pushState({idx:(s.idx||0)+1,loc:loc,prevLabel:leaving.label},'',nbNavUrl(loc));
  }catch(e){}
}
// Back links go to the previous screen; on the first screen they keep their own target.
function nbUpdateBackLinks(){
  var s=nbNavState();
  document.querySelectorAll('.view.active .article-back').forEach(function(b){
    if(!b.hasAttribute('data-nb-back')){ b.setAttribute('data-nb-back',b.getAttribute('onclick')||''); b.setAttribute('data-nb-back-text',b.textContent); }
    if(s.idx>0&&s.prevLabel){ b.setAttribute('onclick','nbGoBack()'); b.textContent='← חזרה '+s.prevLabel; }
    else if(b.getAttribute('onclick')==='nbGoBack()'){ b.setAttribute('onclick',b.getAttribute('data-nb-back')); b.textContent=b.getAttribute('data-nb-back-text'); }
  });
  nbTabsSync();
}
function nbGoBack(){ history.back(); }

// ── TABS INSIDE THE APP ─────────────────────────────────────────────────
// The ↗ icon on a reference box, diagnosis answer, item card or search result
// opens the item in a new tab of the app's tab strip; the page on screen stays.
// Each tab remembers its screen (item, topic, library with its filters), the
// open stages and the scroll position. The strip shows once there are two tabs,
// and the tabs are kept for this browser tab (they survive a refresh).
var NB_TABS_KEY='wecom_kb_tabs', nbTabs=null, nbActiveTab=0;
function nbTabsSave(){
  try{ sessionStorage.setItem(NB_TABS_KEY,JSON.stringify({tabs:nbTabs,active:nbActiveTab})); }catch(e){}
}
function nbTabsLoad(){
  try{
    var s=JSON.parse(sessionStorage.getItem(NB_TABS_KEY)||'null');
    if(s&&Array.isArray(s.tabs)&&s.tabs.length&&s.tabs[s.active]){ nbTabs=s.tabs; nbActiveTab=s.active; return; }
  }catch(e){}
  nbTabs=[{loc:''}]; nbActiveTab=0;
}
// The screen on display belongs to the active tab.
function nbTabsCapture(){
  if(!nbTabs) nbTabsLoad();
  var s=nbNavSnapshot();
  nbTabs[nbActiveTab]={loc:s.loc,lib:s.lib,ui:s.ui,scroll:s.scroll};
}
// Called after every screen change (from nbUpdateBackLinks).
function nbTabsSync(){
  if(!document.getElementById('nb-tabs')) return;
  nbTabsCapture(); nbTabsSave(); nbRenderTabs();
}
function nbTabLabel(loc){
  var m=/^(item|topic|review|view)=(.+)$/.exec(loc||''), val=m?decodeURIComponent(m[2]):'';
  if(m&&(m[1]==='item'||m[1]==='review')&&window.dynamicDocs[val]){
    var d=window.dynamicDocs[val], st=nbSplitTitle(d.topic);
    return {kind:d.kind,code:st.code,text:(m[1]==='review'?'השוואה: ':'')+st.title};
  }
  if(m&&m[1]==='topic'){ var t=TOPICS.find(function(x){return String(x.id)===val;}); if(t) return {text:'נושא: '+nbPlain(t.title)}; }
  if(m&&m[1]==='view'&&val==='tracking') return {text:'מעקב מסמכים'};
  if(m&&m[1]==='view'&&val==='new') return {text:'פריט ידע חדש'};
  return {text:'ספריית ידע'};
}
function nbRenderTabs(){
  var el=document.getElementById('nb-tabs');
  if(!el||!nbTabs) return;
  // When the strip appears or disappears, the page below it must not move under the mouse.
  var view=document.querySelector('.view.active'), before=view?view.getBoundingClientRect().top:0;
  var keepPlace=function(){
    if(!view||window.scrollY<=0) return;
    var diff=view.getBoundingClientRect().top-before;
    if(diff) window.scrollBy(0,diff);
  };
  el.hidden=nbTabs.length<2;
  document.body.classList.toggle('nb-has-tabs',nbTabs.length>1);
  if(nbTabs.length<2){ el.innerHTML=''; keepPlace(); return; }
  // Pinned right under the top bar, whatever its height on this screen.
  var bar=document.querySelector('.topnav');
  el.style.top=(bar&&getComputedStyle(bar).position==='sticky'?bar.getBoundingClientRect().height:0)+'px';
  el.innerHTML='<div class="nb-tabs-row" role="tablist" aria-label="לשוניות פתוחות">'+nbTabs.map(function(t,i){
    var L=nbTabLabel(t.loc), on=i===nbActiveTab;
    return '<div class="nb-tab'+(on?' active':'')+'" role="tab" tabindex="0" aria-selected="'+on+'" data-tab="'+i+'" title="'+nbEsc((L.code?L.code+' · ':'')+L.text)+'"'
      +' onclick="nbSwitchTab('+i+')" onauxclick="if(event.button===1){event.preventDefault();nbCloseTab('+i+',event)}"'
      +' onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();nbSwitchTab('+i+')}">'
      +(L.kind?'<span class="nb-tab-kind" style="background:'+(NB_KINDS[L.kind]||NB_KINDS.R).color+'">'+nbEsc(L.kind)+'</span>':'<span class="nb-tab-kind home">⌂</span>')
      +'<span class="nb-tab-text">'+(L.code?'<b>'+nbEsc(L.code)+'</b> ':'')+nbEsc(L.text)+'</span>'
      +'<button type="button" class="nb-tab-x" aria-label="סגירת הלשונית" title="סגירה" onclick="nbCloseTab('+i+',event)">×</button></div>';
  }).join('')+'</div>';
  keepPlace();
  // Bring the active tab into view inside the strip only (scrollIntoView would also scroll the page).
  var row=el.querySelector('.nb-tabs-row'), a=el.querySelector('.nb-tab.active');
  if(row&&a){ var rb=row.getBoundingClientRect(), ab=a.getBoundingClientRect(); if(ab.left<rb.left||ab.right>rb.right) row.scrollLeft+=ab.left<rb.left?ab.left-rb.left:ab.right-rb.right; }
}
// Shows a tab's saved screen as it was left.
function nbShowTab(t){
  nbShowLocation(t.loc||'',t.lib||null);
  nbApplyItemUI(t.ui);
  setTimeout(function(){ window.scrollTo(0,t.scroll||0); },120);
}
function nbSwitchTab(i){
  if(!nbTabs||!nbTabs[i]||i===nbActiveTab) return;
  nbTabsCapture();
  nbActiveTab=i;
  nbShowTab(nbTabs[i]);
  nbTabsSave(); nbRenderTabs();
}
function nbCloseTab(i,e){
  if(e) e.stopPropagation();
  if(!nbTabs||nbTabs.length<2||!nbTabs[i]) return;
  if(i===nbActiveTab){
    nbTabs.splice(i,1);
    nbActiveTab=Math.min(i,nbTabs.length-1);
    nbShowTab(nbTabs[nbActiveTab]);
  } else {
    nbTabsCapture();
    nbTabs.splice(i,1);
    if(i<nbActiveTab) nbActiveTab--;
  }
  nbTabsSave(); nbRenderTabs();
}
// The logo: back to the main page (the library, no search or filters) and
// every app tab closed.
function nbGoHome(){
  nbTabs=[{loc:''}]; nbActiveTab=0; nbTabsSave();
  nbSearchQuery='';
  var inp=document.getElementById('nb-search'); if(inp) inp.value='';
  nbCurrentWorld='all';
  showView('library');
  nbRenderLibFilters(); nbRenderSidebar();
  window.scrollTo(0,0);
}
// Opens an item in a new tab without leaving the current screen. An item that
// already has a tab isn't opened twice: its tab is highlighted.
function nbOpenInAppTab(id){
  var d=window.dynamicDocs[id];
  if(!d||!nbVisible(d)) return;
  nbTabsCapture();
  var loc='item='+encodeURIComponent(id), at=-1;
  nbTabs.forEach(function(t,i){ if(t.loc===loc) at=i; });
  if(at===-1){ nbTabs.push({loc:loc}); at=nbTabs.length-1; }
  nbTabsSave(); nbRenderTabs();
  var tab=document.querySelector('#nb-tabs .nb-tab[data-tab="'+at+'"]');
  if(tab){
    tab.classList.remove('nb-tab-flash'); void tab.offsetWidth; tab.classList.add('nb-tab-flash');
    var row=tab.parentNode, rb=row.getBoundingClientRect(), tb=tab.getBoundingClientRect();
    if(tb.left<rb.left||tb.right>rb.right) row.scrollLeft+=tb.left<rb.left?tb.left-rb.left:tb.right-rb.right;
  }
}
// Shows a saved screen without adding a history entry.
function nbShowLocation(loc,lib){
  var m=/^(item|topic|review|view)=(.+)$/.exec(loc||''), key=m&&m[1], val=m?decodeURIComponent(m[2]):'';
  nbNavRestoring=true;
  try{
    if(key==='item'&&window.dynamicDocs[val]&&nbVisible(window.dynamicDocs[val])) showDynamicDoc(val);
    else if(key==='topic'&&TOPICS.some(function(t){return String(t.id)===val;})) nbOpenTopic(TOPICS.find(function(t){return String(t.id)===val;}).id);
    else if(key==='review'&&window.dynamicDocs[val]) nbOpenReview(val);
    else if(key==='view'&&val==='tracking') nbOpenTracking();
    else if(key==='view'&&val==='new') showView('new');
    else {
      showView('library');
      // Going back restores the filters exactly as they were (showView resets the type).
      if(lib){ nbCurrentWorld=lib.world||'all'; nbCurrentKind=lib.kind||'all'; }
      nbRenderLibFilters(); nbRenderSidebar();
      if(lib&&lib.mostViewed){ var mv=[].find.call(document.querySelectorAll('#lib-filters .filter-btn'),function(b){return /הנצפות/.test(b.textContent);}); filterMostViewed(mv); }
      else if(lib&&lib.search){ var inp=document.getElementById('nb-search'); if(inp) inp.value=lib.search; nbSearch(lib.search); }
      else {
        var rc=(lib&&lib.cat)||'all';
        document.querySelectorAll('#lib-filters .filter-btn').forEach(function(b){b.classList.toggle('active',b.getAttribute('data-cat')===rc);});
        renderLibrary(rc);
      }
      if(m) nbSetLocation('');
    }
  } finally { nbNavRestoring=false; }
  nbUpdateBackLinks();
}
(function(){
  // Only the outermost call records the screen change (showDynamicDoc calls showView inside).
  function track(orig,locOf){
    return function(){
      if(nbNavBusy) return orig.apply(this,arguments);
      var leaving=nbNavSnapshot(), r;
      nbNavBusy++;
      try{ r=orig.apply(this,arguments); } finally { nbNavBusy--; }
      var loc=locOf.apply(this,arguments);
      if(loc!==null) nbNavigate(loc,leaving);
      nbUpdateBackLinks();
      return r;
    };
  }
  showView=track(showView,function(id){
    if(id==='library') return '';
    if(id==='tracking'||id==='new') return 'view='+id;
    return null;
  });
  showDynamicDoc=track(showDynamicDoc,function(docId){
    var d=window.dynamicDocs[docId];
    return d&&nbVisible(d)?'item='+encodeURIComponent(docId):null;
  });
  nbOpenTopic=track(nbOpenTopic,function(id){ return TOPICS.some(function(t){return t.id===id;})?'topic='+encodeURIComponent(id):null; });
  nbOpenReview=track(nbOpenReview,function(docId){
    var d=window.dynamicDocs[docId];
    return d&&d.revision?'review='+encodeURIComponent(docId):(d&&nbVisible(d)?'item='+encodeURIComponent(docId):null);
  });
  nbOpenTracking=track(nbOpenTracking,function(){ return 'view=tracking'; });
})();
window.addEventListener('popstate',function(e){
  var s=e.state||{loc:nbCurrentLoc()};
  nbShowLocation(s.loc||'',s.lib);
  nbApplyItemUI(s.ui);
  setTimeout(function(){ window.scrollTo(0,s.scroll||0); },120);
});
function nbRestoreLocation(){
  var loc=nbStartLocation||(nbPathBase()?nbPathToLoc(nbStartPath):'');
  nbStartLocation=''; nbStartPath='';
  if(loc) nbShowLocation(loc,null); else nbUpdateBackLinks();
}
// After the library and the role are in place (this listener runs after the
// ones above). With the demo role gate open, restore once a role is chosen.
document.addEventListener('DOMContentLoaded',function(){
  if(document.getElementById('nb-gate')){
    var origEnterAs=nbEnterAs;
    nbEnterAs=function(role){
      nbNavRestoring=true;
      var r;
      try{ r=origEnterAs.apply(this,arguments); } finally { nbNavRestoring=false; }
      nbRestoreLocation();
      return r;
    };
    return;
  }
  nbRestoreLocation();
});

// Single delegated listener for option clicks
document.addEventListener('click', function(e){
  var opt = e.target.closest('.nb-opt');
  if(!opt) return;
  // Only handle if it has data-s and data-i (checkbox options, not radio items)
  var sid = opt.getAttribute('data-s');
  var idx = parseInt(opt.getAttribute('data-i'));
  if(!sid || isNaN(idx)) return;
  // Make sure this stage has options (not s1 fields type)
  var stageDef = nbGetAllStages().filter(function(x){return x.id===sid;})[0];
  if(!stageDef || stageDef.type==='fields') return;
  e.stopPropagation();
  nbPickOpt(sid, idx);
});
// ── IMAGE UPLOAD HANDLING ────────────────────────────────────────────────
document.addEventListener('change', function(e){
  var input = e.target;
  if(input.type !== 'file' || !input.files[0]) return;
  
  var sid = input.getAttribute('data-sid');
  var idx = input.getAttribute('data-idx');
  if(!sid) return;
  
  var file = input.files[0];
  var reader = new FileReader();
  reader.onload = function(ev){
    var dataUrl = ev.target.result;
    if(!nbState[sid]) return;
    if(!nbState[sid].images) nbState[sid].images = {};
    
    var key = (idx !== null && idx !== 'custom') ? parseInt(idx) : 'stage_' + Date.now();
    nbState[sid].images[key] = dataUrl;
    
    // Show preview
    var uid = 'nb-opt-' + sid + '-' + idx;
    var previewEl = document.getElementById('nb-opt-imgs-' + uid);
    if(previewEl){
      var wrap = document.createElement('div');
      wrap.style.cssText = 'position:relative;display:inline-block;margin-top:8px';
      wrap.setAttribute('data-key', key);
      var img = document.createElement('img');
      img.src = dataUrl;
      img.style.cssText = 'max-width:100%;max-height:180px;width:auto;border-radius:6px;border:1px solid var(--border);display:block';
      nbMakeZoomable(img);
      var del = document.createElement('button');
      del.textContent = '×';
      del.style.cssText = 'position:absolute;top:2px;right:2px;background:var(--red);color:#fff;border:none;border-radius:50%;width:18px;height:18px;font-size:12px;cursor:pointer;line-height:18px;padding:0;text-align:center';
      del.addEventListener('click', function(e){
        e.stopPropagation();
        delete nbState[sid].images[key];
        wrap.remove();
      });
      wrap.appendChild(img);
      wrap.appendChild(del);
      previewEl.appendChild(wrap);
    }
    
    // Stage-level image container
    var stageImgsEl = document.getElementById('nb-imgs-' + sid);
    if(stageImgsEl && (idx === null || idx === 'custom')){
      var wrap2 = document.createElement('div');
      wrap2.style.cssText = 'position:relative;display:block;margin-top:8px;width:100%';
      var img2 = document.createElement('img');
      img2.src = dataUrl;
      img2.style.cssText = 'width:100%;max-height:300px;object-fit:contain;border-radius:6px;border:1px solid var(--border);display:block;background:#f9f9f9';
      var del2 = document.createElement('button');
      del2.textContent = '×';
      del2.style.cssText = 'position:absolute;top:2px;right:2px;background:var(--red);color:#fff;border:none;border-radius:50%;width:18px;height:18px;font-size:12px;cursor:pointer;line-height:18px;padding:0;text-align:center';
      del2.addEventListener('click', function(e){
        e.stopPropagation();
        delete nbState[sid].images[key];
        wrap2.remove();
      });
      wrap2.appendChild(img2);
      wrap2.appendChild(del2);
      stageImgsEl.appendChild(wrap2);
    }
    
    input.value = ''; // allow re-select same file
  };
  reader.readAsDataURL(file);
});
